<?php
/*
Plugin Name: CCJV Menu System V2 (Grouped ERP UI)
Description: Adds grouped ERP launcher/admin menu under CCJV Unified Core and a cleaner ERP directory page.
Version: 1.0.0
Author: OpenAI
*/

if (!defined('ABSPATH')) exit;

if (!(defined('CCJV_CORE_ACTIVE') || function_exists('ccjv_core_loaded'))) {
    add_action('admin_notices', function () {
        echo '<div class="notice notice-warning"><p><strong>CCJV Menu System V2</strong> is active, but CCJV / Core X was not detected.</p></div>';
    });
}

function ccjv_menu_v2_groups() {
    return [
        'Iter ERP' => [
            ['label' => 'Portal', 'slug' => 'iter-portal'],
            ['label' => 'Dashboard', 'slug' => 'iter-dashboard'],
            ['label' => 'Travel', 'slug' => 'iter-travel'],
            ['label' => 'Tours', 'slug' => 'iter-tours'],
            ['label' => 'Assets', 'slug' => 'iter-assets'],
            ['label' => 'Economics', 'slug' => 'iter-economics'],
            ['label' => 'Payments', 'slug' => 'iter-payments'],
            ['label' => 'Compliance', 'slug' => 'iter-compliance'],
        ],
        'Surge ERP' => [
            ['label' => 'Portal', 'slug' => 'surge-portal'],
            ['label' => 'Dashboard', 'slug' => 'surge-dashboard'],
            ['label' => 'Events', 'slug' => 'surge-events'],
            ['label' => 'Venues', 'slug' => 'surge-venues'],
            ['label' => 'Sponsors', 'slug' => 'surge-sponsors'],
            ['label' => 'Tickets', 'slug' => 'surge-tickets'],
            ['label' => 'Operations', 'slug' => 'surge-operations'],
            ['label' => 'Finance', 'slug' => 'surge-finance'],
        ],
        'WKF ERP' => [
            ['label' => 'Portal', 'slug' => 'wkf-portal'],
            ['label' => 'Dashboard', 'slug' => 'wkf-dashboard'],
            ['label' => 'AI', 'slug' => 'wkf-ai'],
            ['label' => 'Orders', 'slug' => 'wkf-orders'],
            ['label' => 'Voters', 'slug' => 'wkf-voters'],
            ['label' => 'Strategy', 'slug' => 'wkf-strategy'],
        ],
        'Cibus ERP' => [
            ['label' => 'Portal', 'slug' => 'cibus-portal'],
            ['label' => 'ERP', 'slug' => 'cibus-erp'],
        ],
    ];
}

function ccjv_menu_v2_parent_slug() {
    global $menu;
    if (!empty($menu) && is_array($menu)) {
        foreach ($menu as $item) {
            $title = isset($item[0]) ? wp_strip_all_tags($item[0]) : '';
            $slug  = isset($item[2]) ? $item[2] : '';
            if ($title === 'CCJV Unified Core') return $slug;
        }
    }
    return 'ccjv-unified-core';
}

add_action('admin_menu', function () {
    $parent = ccjv_menu_v2_parent_slug();

    add_submenu_page(
        $parent,
        'ERP Directory',
        'ERP Directory',
        'manage_options',
        'ccjv-erp-directory',
        'ccjv_menu_v2_directory_page',
        1
    );

    $groups = ccjv_menu_v2_groups();
    foreach ($groups as $group_name => $items) {
        $group_slug = 'ccjv-group-' . sanitize_title($group_name);
        add_submenu_page(
            $parent,
            $group_name,
            $group_name,
            'manage_options',
            $group_slug,
            function() use ($group_name, $items) {
                ccjv_menu_v2_group_page($group_name, $items);
            }
        );
    }
}, 5);

function ccjv_menu_v2_group_page($group_name, $items) {
    echo '<div class="wrap"><h1>' . esc_html($group_name) . '</h1>';
    echo '<p>Grouped ERP launcher view for cleaner navigation.</p>';
    echo '<div class="ccjv-menu-v2-grid">';
    foreach ($items as $item) {
        $url = home_url('/' . ltrim($item['slug'], '/'));
        echo '<a class="ccjv-menu-v2-card" href="' . esc_url($url) . '" target="_blank">';
        echo '<strong>' . esc_html($item['label']) . '</strong>';
        echo '<span>' . esc_html('/' . $item['slug']) . '</span>';
        echo '</a>';
    }
    echo '</div></div>';
}

function ccjv_menu_v2_directory_page() {
    $groups = ccjv_menu_v2_groups();
    echo '<div class="wrap"><h1>ERP Directory</h1>';
    echo '<p>Use this grouped directory instead of a long flat sidebar list.</p>';
    foreach ($groups as $group_name => $items) {
        echo '<div class="ccjv-menu-v2-section">';
        echo '<h2>' . esc_html($group_name) . '</h2>';
        echo '<div class="ccjv-menu-v2-grid">';
        foreach ($items as $item) {
            $url = home_url('/' . ltrim($item['slug'], '/'));
            echo '<a class="ccjv-menu-v2-card" href="' . esc_url($url) . '" target="_blank">';
            echo '<strong>' . esc_html($item['label']) . '</strong>';
            echo '<span>' . esc_html('/' . $item['slug']) . '</span>';
            echo '</a>';
        }
        echo '</div></div>';
    }
    echo '</div>';
}

add_action('admin_head', function () {
    ?>
    <style>
    .ccjv-menu-v2-grid{
        display:grid;
        grid-template-columns:repeat(auto-fit,minmax(220px,1fr));
        gap:16px;
        margin:14px 0 28px;
    }
    .ccjv-menu-v2-card{
        display:flex;
        flex-direction:column;
        gap:8px;
        text-decoration:none;
        background:#fff;
        border:1px solid #d7dde7;
        border-radius:16px;
        padding:18px;
        box-shadow:0 8px 20px rgba(0,0,0,.04);
    }
    .ccjv-menu-v2-card strong{
        color:#0f172a;
        font-size:16px;
    }
    .ccjv-menu-v2-card span{
        color:#475569;
    }
    .ccjv-menu-v2-section{
        margin-bottom:26px;
    }
    </style>
    <?php
});

add_action('admin_enqueue_scripts', function() {
    $css = '
    #adminmenu a[href*="iter-portal"],
    #adminmenu a[href*="iter-dashboard"],
    #adminmenu a[href*="iter-travel"],
    #adminmenu a[href*="iter-tours"],
    #adminmenu a[href*="iter-assets"],
    #adminmenu a[href*="iter-economics"],
    #adminmenu a[href*="iter-payments"],
    #adminmenu a[href*="iter-compliance"],
    #adminmenu a[href*="surge-portal"],
    #adminmenu a[href*="surge-dashboard"],
    #adminmenu a[href*="surge-events"],
    #adminmenu a[href*="surge-venues"],
    #adminmenu a[href*="surge-sponsors"],
    #adminmenu a[href*="surge-tickets"],
    #adminmenu a[href*="surge-operations"],
    #adminmenu a[href*="surge-finance"],
    #adminmenu a[href*="wkf-portal"],
    #adminmenu a[href*="wkf-dashboard"],
    #adminmenu a[href*="wkf-ai"],
    #adminmenu a[href*="wkf-orders"],
    #adminmenu a[href*="wkf-voters"],
    #adminmenu a[href*="wkf-strategy"]{
        display:none !important;
    }';
    wp_register_style('ccjv-menu-v2-inline', false);
    wp_enqueue_style('ccjv-menu-v2-inline');
    wp_add_inline_style('ccjv-menu-v2-inline', $css);
});
