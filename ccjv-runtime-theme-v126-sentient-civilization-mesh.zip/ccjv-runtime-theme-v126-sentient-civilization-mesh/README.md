# CCJV Runtime Theme V126 — Sentient Civilization Mesh

Uploadable WordPress theme.

Includes:
- Editable CCJV Runtime settings panel
- Dynamic ecosystem registry API
- Full token/domain registry
- MetaMask wallet connect UI
- CCJV modules: CRM, HRM, Accounting, Project Management, IoT
- Omnichain and XMarkets routing
- Buy CJV Direct configurable URL
- AI onboarding copilot
- Operational GIS / digital twin visual layer
- Runtime cockpit cards

Install:
Appearance → Themes → Add New → Upload Theme → Activate.

Configure:
WP Admin → CCJV Runtime.
