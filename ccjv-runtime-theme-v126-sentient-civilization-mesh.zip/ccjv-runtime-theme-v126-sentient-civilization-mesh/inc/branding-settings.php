<?php
add_action('admin_menu', function () {
    add_menu_page('CCJV Runtime','CCJV Runtime','manage_options','ccjv-runtime-settings','ccjv_runtime_settings_page','dashicons-networking',58);
});
add_action('admin_init', function () {
    foreach (['ccjv_runtime_logo','ccjv_runtime_dark_logo','ccjv_runtime_light_logo','ccjv_runtime_favicon','ccjv_runtime_title','ccjv_runtime_subtitle','ccjv_runtime_accent','ccjv_runtime_glow','ccjv_buy_cjv_url','ccjv_omnichain_url','ccjv_xmarkets_url'] as $setting) {
        register_setting('ccjv_runtime_settings', $setting);
    }
});
function ccjv_runtime_settings_page() { ?>
<div class="wrap"><h1>CCJV Runtime Settings</h1><form method="post" action="options.php">
<?php settings_fields('ccjv_runtime_settings'); ?>
<table class="form-table">
<tr><th>Main Logo URL</th><td><input name="ccjv_runtime_logo" type="text" value="<?php echo esc_attr(get_option('ccjv_runtime_logo')); ?>" class="regular-text"></td></tr>
<tr><th>Dark Logo URL</th><td><input name="ccjv_runtime_dark_logo" type="text" value="<?php echo esc_attr(get_option('ccjv_runtime_dark_logo')); ?>" class="regular-text"></td></tr>
<tr><th>Light Logo URL</th><td><input name="ccjv_runtime_light_logo" type="text" value="<?php echo esc_attr(get_option('ccjv_runtime_light_logo')); ?>" class="regular-text"></td></tr>
<tr><th>Favicon URL</th><td><input name="ccjv_runtime_favicon" type="text" value="<?php echo esc_attr(get_option('ccjv_runtime_favicon')); ?>" class="regular-text"></td></tr>
<tr><th>Runtime Title</th><td><input name="ccjv_runtime_title" type="text" value="<?php echo esc_attr(get_option('ccjv_runtime_title','CCJV')); ?>" class="regular-text"></td></tr>
<tr><th>Runtime Subtitle</th><td><input name="ccjv_runtime_subtitle" type="text" value="<?php echo esc_attr(get_option('ccjv_runtime_subtitle','Institutional Civilization Runtime')); ?>" class="regular-text"></td></tr>
<tr><th>Accent Color</th><td><input name="ccjv_runtime_accent" type="text" value="<?php echo esc_attr(get_option('ccjv_runtime_accent','#3b82f6')); ?>" class="regular-text"></td></tr>
<tr><th>Glow Color</th><td><input name="ccjv_runtime_glow" type="text" value="<?php echo esc_attr(get_option('ccjv_runtime_glow','#22d3ee')); ?>" class="regular-text"></td></tr>
<tr><th>Buy CJV Direct URL</th><td><input name="ccjv_buy_cjv_url" type="text" value="<?php echo esc_attr(get_option('ccjv_buy_cjv_url','#')); ?>" class="regular-text"></td></tr>
<tr><th>Omnichain URL</th><td><input name="ccjv_omnichain_url" type="text" value="<?php echo esc_attr(get_option('ccjv_omnichain_url','https://omnichain.ca')); ?>" class="regular-text"></td></tr>
<tr><th>XMarkets URL</th><td><input name="ccjv_xmarkets_url" type="text" value="<?php echo esc_attr(get_option('ccjv_xmarkets_url','https://xmarkets.ca')); ?>" class="regular-text"></td></tr>
</table><?php submit_button(); ?></form></div><?php }
