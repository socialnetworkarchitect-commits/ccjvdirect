<?php
function ccjv_enqueue_runtime_assets() {
    $theme_uri = get_template_directory_uri();
    wp_enqueue_style('ccjv-runtime-v126-style', $theme_uri . '/dist/assets/index.css', [], '1.26');
    wp_enqueue_script('ccjv-runtime-v126-app', $theme_uri . '/dist/assets/index.js', [], '1.26', true);
    wp_localize_script('ccjv-runtime-v126-app', 'CCJV_RUNTIME', [
        'api' => esc_url_raw(rest_url('ccjv/v1')),
        'nonce' => wp_create_nonce('wp_rest'),
        'siteUrl' => esc_url_raw(site_url()),
        'fallbackTitle' => get_option('ccjv_runtime_title', 'CCJV'),
        'fallbackSubtitle' => get_option('ccjv_runtime_subtitle', 'Institutional Civilization Runtime'),
        'fallbackLogo' => get_option('ccjv_runtime_logo', ''),
        'buyCjvUrl' => get_option('ccjv_buy_cjv_url', '#'),
        'omnichainUrl' => get_option('ccjv_omnichain_url', 'https://omnichain.ca'),
        'xmarketsUrl' => get_option('ccjv_xmarkets_url', 'https://xmarkets.ca')
    ]);
}
add_action('wp_enqueue_scripts', 'ccjv_enqueue_runtime_assets');
