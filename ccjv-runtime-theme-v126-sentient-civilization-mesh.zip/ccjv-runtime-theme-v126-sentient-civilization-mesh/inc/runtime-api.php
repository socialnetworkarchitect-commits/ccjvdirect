<?php
add_action('rest_api_init', function () {
    register_rest_route('ccjv/v1', '/runtime-state', [
        'methods' => 'GET',
        'callback' => 'ccjv_runtime_state',
        'permission_callback' => '__return_true'
    ]);
    register_rest_route('ccjv/v1', '/ecosystem-registry', [
        'methods' => 'GET',
        'callback' => 'ccjv_ecosystem_registry',
        'permission_callback' => '__return_true'
    ]);
});
function ccjv_runtime_state() {
    return rest_ensure_response([
        'status'=>'ONLINE',
        'version'=>'1.26',
        'title'=>get_option('ccjv_runtime_title','CCJV'),
        'subtitle'=>get_option('ccjv_runtime_subtitle','Institutional Civilization Runtime'),
        'logo'=>get_option('ccjv_runtime_logo',''),
        'buyCjvUrl'=>get_option('ccjv_buy_cjv_url','#'),
        'omnichainUrl'=>get_option('ccjv_omnichain_url','https://omnichain.ca'),
        'xmarketsUrl'=>get_option('ccjv_xmarkets_url','https://xmarkets.ca')
    ]);
}
function ccjv_ecosystem_registry() {
    return rest_ensure_response(['items'=>[
['name'=>'Space Assets','symbol'=>'SAT','address'=>'0x774476ADa9a2127BC3f92Be059f0ef38e183A2dF','domain'=>'spaceassets.ca','category'=>'Space Assets','status'=>'ONLINE'],
['name'=>'Aediles','symbol'=>'AEDI','address'=>'0x0895AD723c1268456625E18A5788491c79C99CDE','domain'=>'aediles.ca','category'=>'Environmental','status'=>'ONLINE'],
['name'=>'Lex','symbol'=>'LEX','address'=>'0x7099c7838faD4DcE242f8DE2c7a0994D7d5dC3Ba','domain'=>'lexcoin.ca','category'=>'Legal','status'=>'ONLINE'],
['name'=>'Cultura','symbol'=>'CUL','address'=>'0xaFDcD8Da6eC6342da76d3763565Ef9284B8b41D7','domain'=>'culturacoin.ca','category'=>'Culture','status'=>'ONLINE'],
['name'=>'Sanitas','symbol'=>'SAN','address'=>'0x9DE984041fC827D97F322c5E95eAD9EDbbAD73B2','domain'=>'sanitascoin.ca','category'=>'Health','status'=>'ONLINE'],
['name'=>'Pecunia','symbol'=>'PEC','address'=>'0x04366C3aE0EA5ca96991cf04C745c92678B32Be6','domain'=>'pecuniacoin.ca','category'=>'Finance','status'=>'ONLINE'],
['name'=>'Ingenium','symbol'=>'ING','address'=>'0x194960905525B0bF14b7b15D491098e96fC8173b','domain'=>'ingeniumcoin.ca','category'=>'Engineering','status'=>'ONLINE'],
['name'=>'Industria','symbol'=>'IND','address'=>'0xB98174106491452D2252D7673CC7ec30E6C01160','domain'=>'industriacoin.ca','category'=>'Industry','status'=>'ONLINE'],
['name'=>'Constructum','symbol'=>'CST','address'=>'0x6d44681fA4441345AA7b0265b9Fa3fc4b70Fbe40','domain'=>'constructum.ca','category'=>'Construction','status'=>'ONLINE'],
['name'=>'Cattle Chain','symbol'=>'CTL','address'=>'0xe3e3093E50A1649179F4c7E08aEc2512eb14bdd5','domain'=>'cattlechain.ca','category'=>'Agriculture','status'=>'ONLINE'],
['name'=>'Vehiculum','symbol'=>'VEH','address'=>'0xb58C3F3d130d5a150109A2c9E431cf6A61c9ffAd','domain'=>'vehiculum.ca','category'=>'Mobility','status'=>'ONLINE'],
['name'=>'Educatio','symbol'=>'EDU','address'=>'0x9Ae36403DE76BA35BA1B366A8bd9ee48277c7519','domain'=>'educatio.ca','category'=>'Education','status'=>'ONLINE'],
['name'=>'Manufactura','symbol'=>'MFC','address'=>'0xdac84ABe686d3851fd6d6F71a199F9d3c61df0F8','domain'=>'manufactura.ca','category'=>'Manufacturing','status'=>'ONLINE'],
['name'=>'Impensa','symbol'=>'IMP','address'=>'0x22904d7E67899E00F6eE5149b6c0f15C822Bb3ea','domain'=>'impensa.ca','category'=>'Logistics','status'=>'ONLINE'],
['name'=>'AquaCoin','symbol'=>'AQUA','address'=>'0x82C51e80Cb63071D1502E4eB8dAf9858fd8F42DD','domain'=>'aquacoin.ca','category'=>'Water','status'=>'ONLINE'],
['name'=>'Datum','symbol'=>'DAT','address'=>'0xd58F7Be707ba00B27Ee943740af7D5665F6Eb316','domain'=>'datumcoin.ca','category'=>'Data','status'=>'ONLINE'],
['name'=>'OmniChain','symbol'=>'OMC','address'=>'0xf23BBc223438b0ec81f69efe2699325E8EB67e75','domain'=>'omnichain.ca','category'=>'Mining','status'=>'ONLINE'],
['name'=>'Pro Box Sports','symbol'=>'PXS','address'=>'0xA60121B4F08894169E63A1e21b7FebAEB324B265','domain'=>'proboxsports.ca','category'=>'Sports','status'=>'ONLINE'],
['name'=>'Iter Coin','symbol'=>'ITR','address'=>'0x22372160c7000a41794d2d01CbAFF0c9967FE4bd','domain'=>'itercoin.ca','category'=>'Travel','status'=>'ONLINE'],
['name'=>'Cibus Coin','symbol'=>'CIB','address'=>'0xA86AB9663Be3F64ffaE6Ad73aA305d38447f3C80','domain'=>'cibuscoin.ca','category'=>'Food','status'=>'ONLINE'],
['name'=>'George Mandryk Drives','symbol'=>'GMD','address'=>'0x1415c7C65C3534012D86F430E364Feceb77f535B','domain'=>'georgedrives.ca','category'=>'Automotive','status'=>'ONLINE'],
['name'=>'Surge Symposia','symbol'=>'SYS','address'=>'0x4d80Ae78C8BeA3A9aFEFF005FbF7bc3E72e0Cb42','domain'=>'surgesymposia.ca','category'=>'Events','status'=>'ONLINE'],
['name'=>'CCJV','symbol'=>'CJV','address'=>'0x02E7769903c7069A909bc951D297d9D2F504393B','domain'=>'ccjv.ca','category'=>'Core','status'=>'ONLINE'],
['name'=>'XMarkets','symbol'=>'XMA','address'=>'0x0345b81642f0AAF50350Efc6Ce0d08CDA35951c7','domain'=>'xmarkets.ca','category'=>'Marketplace','status'=>'ONLINE'],
['name'=>'Workers First','symbol'=>'WKF','address'=>'0x1d09ee25163d61e6569165145b866df8a1399e47','domain'=>'workersfirst.ca','category'=>'Labour','status'=>'ONLINE'],
['name'=>'QCN Wealth','symbol'=>'QCN','address'=>'0x6131119e74EaF8f4aA75F7BfD037217d12f066c8','domain'=>'qcnwealth.ca','category'=>'Wealth','status'=>'ONLINE'],
['name'=>'Free Assembly','symbol'=>'FRE','address'=>'0x74B4ea16007FfddFcf0d376DBED904CE279B9148','domain'=>'freeassembly.ca','category'=>'Faith','status'=>'ONLINE'],
['name'=>'One World Coin','symbol'=>'OWO','address'=>'0x7C087b41C13DEAFB8c31507f457c91af19880ffB','domain'=>'oneworldcoin.ca','category'=>'Currency','status'=>'ONLINE'],
['name'=>'Citizen James','symbol'=>'CIJ','address'=>'0x9b1B75446edCDb2Ce2E53779351Ec17124Aa3F7a','domain'=>'citizenjames.ca','category'=>'Civic','status'=>'ONLINE'],
['name'=>'Radio You','symbol'=>'RDY','address'=>'0xf4b01c5DAb515Cf7efdA01914e2e8405f68ae57e','domain'=>'radioyou.ca','category'=>'Media','status'=>'ONLINE'],
['name'=>'TVYou','symbol'=>'TVY','address'=>'0x7acF61460B54716Cf53CD946848C7F6c22c61f04','domain'=>'tvyou.ca','category'=>'Media','status'=>'ONLINE'],
['name'=>'Empowerment','symbol'=>'EPW','address'=>'0x9b4b06e31C5B5c7b6246021778B682825529c7E7','domain'=>'empowermentcoin.ca','category'=>'Empowerment','status'=>'ONLINE'],
['name'=>'Tatanka Tawowin','symbol'=>'TKW','address'=>'0xb41046439520Ba6c539bD1cD70e0c868CB478Ed2','domain'=>'tatankatawowin.ca','category'=>'First Peoples','status'=>'ONLINE'],
['name'=>'Land Bank','symbol'=>'LBK','address'=>'0x3060471CA3091637D3B6b2DBF703305572b3E351','domain'=>'landbankcoin.ca','category'=>'Land','status'=>'ONLINE'],
['name'=>'Plasticus','symbol'=>'PLS','address'=>'0x2E4baa2318fbd86Ad5B1f9Ce9EA124b724Ca696A','domain'=>'plasticus.ca','category'=>'Circular Economy','status'=>'ONLINE'],
['name'=>'Alta Coin','symbol'=>'ALC','address'=>'0x13a9F630BF04ffDfAd64d704602EBD0b39f8B5e7','domain'=>'altacoin.ca','category'=>'Infrastructure','status'=>'ONLINE'],
['name'=>'Qing Coin','symbol'=>'QNG','address'=>'0x6BA03C525880534d9D966fa6CbF75f00DeafADdd','domain'=>'qingcoin.ca','category'=>'Mining','status'=>'ONLINE'],
['name'=>'Energy Chain','symbol'=>'ENC','address'=>'0xdC06E2aE25271BB7cA63A6c0Be6D14dF17Db6e24','domain'=>'energychain.ca','category'=>'Energy','status'=>'ONLINE']
]]);
}
