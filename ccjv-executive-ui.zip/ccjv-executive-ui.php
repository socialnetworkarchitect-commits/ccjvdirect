<?php
/*
Plugin Name: CCJV Executive UI Panel
*/
add_action('admin_menu', function(){
 add_menu_page('Executive Panel','Executive','manage_options','ccjv-exec',function(){
  echo '<h1>Executive Dashboard</h1><p>Revenue, Treasury, ERP usage unified.</p>';
 });
});
