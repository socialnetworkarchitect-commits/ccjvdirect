<?php
if (!defined('ABSPATH')) exit;

add_action('after_setup_theme', function() {
    add_theme_support('title-tag');
});

function ccjv_theme_menu() {
    register_nav_menu('primary', 'Primary Menu');
}
add_action('init', 'ccjv_theme_menu');
