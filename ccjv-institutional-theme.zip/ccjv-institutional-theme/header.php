<!DOCTYPE html>
<html>
<head>
<?php wp_head(); ?>
</head>
<body>
<header>
    <h1>CCJV Institutional Runtime</h1>

    <nav>
        <a href="/">Home</a>
        <a href="/crm">CRM</a>
        <a href="/hrm">HRM</a>
        <a href="/treasury">Treasury</a>
        <a href="/vault">Vault</a>
        <a href="/governance">Governance</a>
    </nav>
</header>
