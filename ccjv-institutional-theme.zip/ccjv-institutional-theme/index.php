<?php get_header(); ?>

<section class="hero">
    <h2>Operational Civilization Runtime</h2>
    <p>Unified institutional runtime substrate for federated ERPs.</p>

    <p>
        <a class="button" href="/wp-json/ccjv-runtime/v1/health">Runtime Health</a>
    </p>
</section>

<section class="grid">
    <div class="card">
        <h3>CRM</h3>
        <p>Institutional relationship runtime.</p>
    </div>

    <div class="card">
        <h3>HRM</h3>
        <p>Workforce and readiness runtime.</p>
    </div>

    <div class="card">
        <h3>Treasury</h3>
        <p>ERC20 and institutional treasury enforcement.</p>
    </div>

    <div class="card">
        <h3>Vault</h3>
        <p>SHA256 hashing and Avalanche proof continuity.</p>
    </div>

    <div class="card">
        <h3>Governance</h3>
        <p>Replay-aware institutional governance.</p>
    </div>

    <div class="card">
        <h3>Observability</h3>
        <p>Operational telemetry and replay diagnostics.</p>
    </div>
</section>

<?php get_footer(); ?>
