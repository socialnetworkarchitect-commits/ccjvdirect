<footer style="padding:40px;text-align:center;background:#111827;">
CCJV Runtime Theme
</footer>

<?php wp_footer(); ?>
</body>
</html>
