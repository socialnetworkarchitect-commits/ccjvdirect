<?php
/*
Plugin Name: CJ V3 Step 2 — UI + Workspace + Module Framework
Description: Adds UI, workspace switcher, and module framework on top of V3 core
Version: 1.0
*/

if (!defined('ABSPATH')) exit;

define('CJV3S2_PATH', plugin_dir_path(__FILE__));
define('CJV3S2_URL', plugin_dir_url(__FILE__));

require_once CJV3S2_PATH . 'includes/ui.php';
require_once CJV3S2_PATH . 'includes/modules.php';
require_once CJV3S2_PATH . 'includes/workspace_ui.php';

add_action('wp_enqueue_scripts', function(){
    wp_enqueue_style('cjv3s2-style', CJV3S2_URL . 'assets/style.css');
});

/* SHORTCODE */
function cjv3s2_portal(){
    ob_start();
    echo cjv3s2_shell();
    return ob_get_clean();
}
add_shortcode('cjv3_portal_v2', 'cjv3s2_portal');
