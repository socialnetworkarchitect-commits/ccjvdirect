<?php
function cjv3s2_workspace_bar(){
    return "
    <div class='cjv3-workspace'>
        <strong>Workspace:</strong>
        <select>
            <option>Default Workspace</option>
        </select>
        <button>Create Workspace</button>
    </div>
    ";
}
