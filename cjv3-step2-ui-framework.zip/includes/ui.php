<?php
function cjv3s2_shell(){
    $active = $_GET['tab'] ?? 'dashboard';
    ob_start();
    ?>
    <div class="cjv3-wrap">
        <?php echo cjv3s2_workspace_bar(); ?>
        <div class="cjv3-nav">
            <a href="?tab=dashboard">Dashboard</a>
            <a href="?tab=identity">Identity</a>
            <a href="?tab=doctrine">Doctrine</a>
            <a href="?tab=content">Content</a>
            <a href="?tab=network">Network</a>
            <a href="?tab=events">Events</a>
            <a href="?tab=assets">Assets</a>
            <a href="?tab=reports">Reports</a>
        </div>
        <div class="cjv3-panel">
            <?php echo cjv3s2_render_tab($active); ?>
        </div>
    </div>
    <?php
    return ob_get_clean();
}
