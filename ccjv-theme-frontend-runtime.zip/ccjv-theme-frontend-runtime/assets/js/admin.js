window.CCJVRuntime = { slug: 'ccjv-theme-frontend-runtime', status: 'loaded' };
