<?php
/**
 * Plugin Name: CCJV Theme Frontend Runtime
 * Description: Operational CCJV subsystem package: public_frontend, onboarding, wallet_connect, erp_marketplace, tenant_routing, mobile_ux.
 * Version: 1.0.0
 * Author: CCJV
 */
if (!defined('ABSPATH')) { exit; }
define('CCJV_THEMEFRONTENDRUNTIME_PATH', plugin_dir_path(__FILE__));
define('CCJV_THEMEFRONTENDRUNTIME_URL', plugin_dir_url(__FILE__));
define('CCJV_THEMEFRONTENDRUNTIME_VERSION', '1.0.0');
require_once CCJV_THEMEFRONTENDRUNTIME_PATH . 'includes/class-runtime.php';
register_activation_hook(__FILE__, array('CCJV_ThemeFrontendRuntime', 'activate'));
register_deactivation_hook(__FILE__, array('CCJV_ThemeFrontendRuntime', 'deactivate'));
add_action('plugins_loaded', array('CCJV_ThemeFrontendRuntime', 'boot'));
