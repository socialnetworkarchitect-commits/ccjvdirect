CCJV Theme Frontend Runtime

Install:
1. Upload ccjv-theme-frontend-runtime.zip in WordPress Plugins > Add New > Upload Plugin.
2. Activate.
3. Verify /wp-json/ccjv/v1/ccjv-theme-frontend-runtime/status.
4. Optional PM2 worker: pm2 start pm2/ecosystem.ccjv-theme-frontend-runtime.config.js

No shebang/interpreter lines are included.
