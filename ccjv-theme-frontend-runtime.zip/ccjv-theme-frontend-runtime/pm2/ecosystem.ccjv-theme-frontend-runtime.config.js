module.exports = { apps: [{ name: 'ccjv-theme-frontend-runtime-worker', script: './workers/ccjv-theme-frontend-runtime-worker.js' }] };
