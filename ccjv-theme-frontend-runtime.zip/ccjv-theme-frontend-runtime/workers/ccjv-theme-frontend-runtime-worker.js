const fs = require('fs');
const path = require('path');
const logDir = path.join(__dirname, '..', 'runtime-logs');
if (!fs.existsSync(logDir)) fs.mkdirSync(logDir, { recursive: true });
setInterval(() => {
  const line = JSON.stringify({ runtime: 'ccjv-theme-frontend-runtime', status: 'alive', features: ["public_frontend", "onboarding", "wallet_connect", "erp_marketplace", "tenant_routing", "mobile_ux"], at: new Date().toISOString() }) + '\n';
  fs.appendFileSync(path.join(logDir, 'ccjv-theme-frontend-runtime.log'), line);
  console.log(line.trim());
}, 15000);
