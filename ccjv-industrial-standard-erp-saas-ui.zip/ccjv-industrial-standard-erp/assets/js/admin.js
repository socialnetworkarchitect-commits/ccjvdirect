console.log('CCJV Industrial Standard ERP SaaS UI loaded');
