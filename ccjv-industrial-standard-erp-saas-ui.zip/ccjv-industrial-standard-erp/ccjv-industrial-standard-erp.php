<?php
/**
 * Plugin Name: CCJV Industrial Standard ERP
 * Description: Industrial-standard CCJV Core ERP control plane with SaaS commercial UI/UX, multi-tenant runtime, wallet/token gating, vault/Avalanche proof lineage, replay, treasury, observability, reporting, and federation dashboards.
 * Version: 1.0.0
 * Author: CCJV
 */

if (!defined('ABSPATH')) { exit; }

define('CCJV_IND_VERSION', '1.0.0');
define('CCJV_IND_PATH', plugin_dir_path(__FILE__));
define('CCJV_IND_URL', plugin_dir_url(__FILE__));

spl_autoload_register(function ($class) {
    $prefix = 'CCJV\\Industrial\\';
    if (strpos($class, $prefix) !== 0) { return; }
    $relative = substr($class, strlen($prefix));
    $file = CCJV_IND_PATH . 'src/' . str_replace('\\', '/', $relative) . '.php';
    if (file_exists($file)) { require_once $file; }
});

register_activation_hook(__FILE__, ['CCJV\\Industrial\\Bootstrap\\Activator', 'activate']);

add_action('plugins_loaded', function () {
    \CCJV\Industrial\Kernel\ServiceRegistry::boot();
    \CCJV\Industrial\Dashboards\AdminShell::boot();
    \CCJV\Industrial\Reporting\RuntimePacketController::boot();
});
