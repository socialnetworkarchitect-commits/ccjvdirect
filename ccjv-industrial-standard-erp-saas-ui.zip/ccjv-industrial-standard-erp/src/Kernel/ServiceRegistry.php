<?php
namespace CCJV\Industrial\Kernel;
if (!defined('ABSPATH')) { exit; }

class ServiceRegistry {
    public static function boot(): void {
        add_shortcode('ccjv_saas_user_dashboard', ['CCJV\\Industrial\\Dashboards\\Shortcodes', 'userDashboard']);
        add_shortcode('ccjv_saas_tenant_dashboard', ['CCJV\\Industrial\\Dashboards\\Shortcodes', 'tenantDashboard']);
        add_shortcode('ccjv_wallet_connect', ['CCJV\\Industrial\\Dashboards\\Shortcodes', 'walletConnect']);
    }
    public static function option(string $key, $default = null) {
        return get_option('ccjv_ind_' . $key, $default);
    }
}
