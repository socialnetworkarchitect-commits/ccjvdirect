<?php
namespace CCJV\Industrial\Dashboards;
if (!defined('ABSPATH')) { exit; }

class AdminShell {
    public static function boot(): void {
        add_action('admin_menu', [__CLASS__, 'menu']);
        add_action('admin_enqueue_scripts', [__CLASS__, 'assets']);
    }
    public static function assets(): void {
        wp_enqueue_style('ccjv-industrial-admin', CCJV_IND_URL . 'assets/css/admin.css', [], CCJV_IND_VERSION);
        wp_enqueue_script('ccjv-industrial-admin', CCJV_IND_URL . 'assets/js/admin.js', [], CCJV_IND_VERSION, true);
    }
    public static function menu(): void {
        add_menu_page('CCJV SaaS ERP', 'CCJV SaaS ERP', 'manage_options', 'ccjv-industrial', [__CLASS__, 'command'], 'dashicons-superhero-alt', 54);
        $pages = [
            ['Command Center','Command','command'], ['Tenants','Tenants','tenants'], ['Users','Users','users'],
            ['Workspaces','Workspaces','workspaces'], ['Modules','Modules','modules'], ['Token Pricing','Token Pricing','pricing'],
            ['Vault','Vault','vault'], ['Treasury','Treasury','treasury'], ['Replay','Replay','replay'],
            ['Proof','Proof','proof'], ['Observability','Observability','observability'], ['Runtime Reporting','Reporting','reporting'],
            ['SaaS UX Pages','Pages / Smart Codes','smartcodes'], ['System Manifest','Manifest','manifest']
        ];
        foreach ($pages as $p) add_submenu_page('ccjv-industrial', $p[0], $p[1], 'manage_options', 'ccjv-industrial-'.$p[2], [__CLASS__, $p[2]]);
    }
    private static function countTable(string $table): int {
        global $wpdb;
        return (int)$wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}{$table}");
    }
    private static function rows(string $table): array {
        global $wpdb;
        return $wpdb->get_results("SELECT * FROM {$wpdb->prefix}{$table} ORDER BY id DESC LIMIT 150", ARRAY_A) ?: [];
    }
    private static function renderTable(array $rows): string {
        if (!$rows) return '<div class="ccjv-empty">No records yet.</div>';
        $html = '<table class="ccjv-table"><thead><tr>';
        foreach (array_keys($rows[0]) as $k) $html .= '<th>'.esc_html($k).'</th>';
        $html .= '</tr></thead><tbody>';
        foreach ($rows as $r) {
            $html .= '<tr>';
            foreach ($r as $v) $html .= '<td><code>'.esc_html(is_scalar($v)?(string)$v:wp_json_encode($v)).'</code></td>';
            $html .= '</tr>';
        }
        return $html.'</tbody></table>';
    }
    private static function shell(string $title, string $content): void {
        echo '<div class="ccjv-app"><aside class="ccjv-side"><div class="ccjv-brand">CCJV</div><div class="ccjv-sub">Industrial SaaS ERP</div></aside><main class="ccjv-main"><div class="ccjv-top"><h1>'.esc_html($title).'</h1><span class="ccjv-pill">Replay Native</span><span class="ccjv-pill">Vault Native</span><span class="ccjv-pill">Avalanche Native</span></div>'.$content.'</main></div>';
    }
    public static function command(): void {
        $cards = [
            'Tenants'=>self::countTable('ccjv_ind_tenants'), 'Workspaces'=>self::countTable('ccjv_ind_workspaces'),
            'Modules'=>self::countTable('ccjv_ind_modules'), 'Vault Objects'=>self::countTable('ccjv_ind_vault_objects'),
            'Replay Events'=>self::countTable('ccjv_ind_replay_events'), 'Proofs'=>self::countTable('ccjv_ind_proofs'),
            'Treasury Rows'=>self::countTable('ccjv_ind_treasury_ledger'), 'Runtime Packets'=>self::countTable('ccjv_ind_runtime_packets')
        ];
        $html = '<section class="ccjv-hero"><h2>Operational Civilization Control Plane</h2><p>Multi-tenant, multi-user, token-gated SaaS ERP with vault, Avalanche anchoring, replay, treasury, observability, and federation.</p></section><section class="ccjv-grid">';
        foreach ($cards as $k=>$v) $html .= '<div class="ccjv-card"><div class="ccjv-number">'.esc_html($v).'</div><div>'.esc_html($k).'</div></div>';
        $html .= '</section><section class="ccjv-panel"><h2>Constitutional Rules</h2><div class="ccjv-checks"><span>Everything saved → Vault</span><span>Vault objects → SHA256 hash</span><span>Hashes → Avalanche proof</span><span>Token gate after theme</span><span>Token fee/module/month</span><span>Upload rewards + view/download fees</span></div></section>';
        self::shell('Super Admin Command Center', $html);
    }
    public static function tenants(): void { self::shell('Tenant Administration', self::renderTable(self::rows('ccjv_ind_tenants'))); }
    public static function users(): void { self::shell('User Administration', '<div class="ccjv-panel">WordPress users integrate with wallet, tenant, workspace, module access, vault, rewards, and fees.</div>'); }
    public static function workspaces(): void { self::shell('Workspace Administration', self::renderTable(self::rows('ccjv_ind_workspaces'))); }
    public static function modules(): void { self::shell('Module Registry', self::renderTable(self::rows('ccjv_ind_modules'))); }
    public static function pricing(): void { self::shell('Token Pricing + Module Fees', '<div class="ccjv-panel">Edit ERP gate, token fee/module/month, vault upload rewards, view fees, download fees, and treasury routing.</div>'.self::renderTable(self::rows('ccjv_ind_modules'))); }
    public static function vault(): void { self::shell('Vault Center', self::renderTable(self::rows('ccjv_ind_vault_objects'))); }
    public static function treasury(): void { self::shell('Treasury Center', self::renderTable(self::rows('ccjv_ind_treasury_ledger'))); }
    public static function replay(): void { self::shell('Replay Center', self::renderTable(self::rows('ccjv_ind_replay_events'))); }
    public static function proof(): void { self::shell('Proof / Avalanche Center', self::renderTable(self::rows('ccjv_ind_proofs'))); }
    public static function observability(): void { self::shell('Observability Center', self::renderTable(self::rows('ccjv_ind_observability_traces'))); }
    public static function reporting(): void { \CCJV\Industrial\Reporting\RuntimePacketController::page(); }
    public static function smartcodes(): void { self::shell('Pages Required + Smart Codes', '<div class="ccjv-panel"><h2>Shortcodes</h2><code>[ccjv_wallet_connect]</code><br><code>[ccjv_saas_user_dashboard]</code><br><code>[ccjv_saas_tenant_dashboard]</code></div>'); }
    public static function manifest(): void {
        $file = CCJV_IND_PATH.'industrial-manifest.json';
        self::shell('Industrial Build Manifest', '<pre class="ccjv-pre">'.esc_html(file_exists($file)?file_get_contents($file):'No manifest').'</pre>');
    }
}
