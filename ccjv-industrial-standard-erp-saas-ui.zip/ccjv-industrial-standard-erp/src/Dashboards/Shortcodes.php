<?php
namespace CCJV\Industrial\Dashboards;
if (!defined('ABSPATH')) { exit; }

class Shortcodes {
    public static function walletConnect(): string {
        return '<div class="ccjv-public-card"><h3>Connect Wallet</h3><p>Connect wallet and verify SIWE/token access.</p><button class="ccjv-btn">Connect Wallet</button></div>';
    }
    public static function userDashboard(): string {
        return '<div class="ccjv-public-card"><h2>User Dashboard</h2><p>Wallet, module access, uploads, downloads, rewards, fees, vault, and activity.</p></div>';
    }
    public static function tenantDashboard(): string {
        return '<div class="ccjv-public-card"><h2>Tenant Dashboard</h2><p>Users, workspaces, modules, vault, treasury, reporting, runtime health.</p></div>';
    }
}
