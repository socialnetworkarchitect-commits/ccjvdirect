# CCJV Industrial Standard ERP

Industrial-standard CCJV Core ERP control plane with commercial SaaS UI/UX.

## Includes

- Super Admin Command Center
- Multi-tenant SaaS structure
- Multi-user dashboard shortcodes
- Module/workspace framework
- Token pricing and module/month fee center
- Vault center
- Treasury center
- Replay center
- Proof/Avalanche center
- Observability center
- Runtime reporting center
- Commercial SaaS-style admin UI
- Preserved prior build under `preserved-prior-build`

## Install

Upload and activate as a WordPress plugin.

## Smart Codes

- `[ccjv_wallet_connect]`
- `[ccjv_saas_user_dashboard]`
- `[ccjv_saas_tenant_dashboard]`
