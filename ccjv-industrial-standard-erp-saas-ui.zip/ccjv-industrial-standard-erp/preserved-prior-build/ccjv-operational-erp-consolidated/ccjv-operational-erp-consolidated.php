<?php
/**
 * Plugin Name: CCJV Operational ERP Consolidated Runtime
 * Description: Consolidated CCJV Core ERP control plane with multi-tenant SaaS dashboards, wallet/token gate settings, vault/Avalanche proof registry, replay visibility, treasury, observability, and runtime reporting. Preserves source artifacts under preserved-artifacts.
 * Version: 0.9.0
 * Author: CCJV
 */

if (!defined('ABSPATH')) { exit; }

define('CCJV_OERP_VERSION', '0.9.0');
define('CCJV_OERP_PATH', plugin_dir_path(__FILE__));
define('CCJV_OERP_URL', plugin_dir_url(__FILE__));

require_once CCJV_OERP_PATH . 'includes/class-ccjv-oerp-activator.php';
require_once CCJV_OERP_PATH . 'includes/class-ccjv-oerp-core.php';
require_once CCJV_OERP_PATH . 'includes/class-ccjv-oerp-admin.php';
require_once CCJV_OERP_PATH . 'includes/class-ccjv-oerp-reporting.php';

register_activation_hook(__FILE__, ['CCJV_OERP_Activator','activate']);

add_action('plugins_loaded', function () {
    CCJV_OERP_Core::boot();
    CCJV_OERP_Admin::boot();
    CCJV_OERP_Reporting::boot();
});
