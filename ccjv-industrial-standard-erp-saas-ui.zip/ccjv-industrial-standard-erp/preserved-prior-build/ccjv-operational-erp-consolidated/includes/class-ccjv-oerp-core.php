<?php
if (!defined('ABSPATH')) { exit; }

class CCJV_OERP_Core {
    public static function boot(): void {
        add_shortcode('ccjv_user_dashboard', [__CLASS__, 'user_dashboard_shortcode']);
        add_shortcode('ccjv_tenant_dashboard', [__CLASS__, 'tenant_dashboard_shortcode']);
        add_shortcode('ccjv_wallet_connect', [__CLASS__, 'wallet_connect_shortcode']);
    }

    public static function trace(string $operation, array $payload = []): string {
        global $wpdb;
        $trace_id = $payload['trace_id'] ?? wp_generate_uuid4();
        $correlation_id = $payload['correlation_id'] ?? wp_generate_uuid4();
        $lineage_id = $payload['lineage_id'] ?? wp_generate_uuid4();
        $wpdb->insert($wpdb->prefix.'ccjv_observability_traces', [
            'trace_id'=>$trace_id,
            'correlation_id'=>$correlation_id,
            'lineage_id'=>$lineage_id,
            'source_erp'=>$payload['source_erp'] ?? 'ccjv',
            'operation'=>$operation,
            'status'=>$payload['status'] ?? 'recorded',
            'replay_reference'=>$payload['replay_reference'] ?? null,
            'treasury_reference'=>$payload['treasury_reference'] ?? null,
            'vault_reference'=>$payload['vault_reference'] ?? null,
            'proof_reference'=>$payload['proof_reference'] ?? null,
            'payload'=>wp_json_encode($payload),
            'created_at'=>gmdate('Y-m-d H:i:s')
        ]);
        return $trace_id;
    }

    public static function replay(string $event_type, array $payload = []): int {
        global $wpdb;
        $position = (int)$wpdb->get_var("SELECT COALESCE(MAX(replay_position),0)+1 FROM {$wpdb->prefix}ccjv_replay_events");
        $wpdb->insert($wpdb->prefix.'ccjv_replay_events', [
            'replay_position'=>$position,
            'event_id'=>wp_generate_uuid4(),
            'correlation_id'=>$payload['correlation_id'] ?? wp_generate_uuid4(),
            'causation_id'=>$payload['causation_id'] ?? null,
            'lineage_id'=>$payload['lineage_id'] ?? wp_generate_uuid4(),
            'tenant_id'=>$payload['tenant_id'] ?? null,
            'workspace_id'=>$payload['workspace_id'] ?? null,
            'source_runtime'=>$payload['source_runtime'] ?? 'wordpress',
            'source_module'=>$payload['source_module'] ?? 'ccjv',
            'actor_id'=>get_current_user_id(),
            'event_type'=>$event_type,
            'event_version'=>'1.0',
            'payload'=>wp_json_encode($payload),
            'created_at'=>gmdate('Y-m-d H:i:s')
        ]);
        return $position;
    }

    public static function wallet_connect_shortcode(): string {
        return '<div class="ccjv-card"><h3>Connect Wallet</h3><p>Wallet/SIWE settings are managed in CCJV Runtime Settings.</p><button type="button" class="button button-primary" disabled>Wallet Connect Runtime Required</button></div>';
    }

    public static function user_dashboard_shortcode(): string {
        if (!is_user_logged_in()) return '<p>Please log in to view your CCJV user dashboard.</p>';
        return '<div class="ccjv-dashboard"><h2>CCJV User Dashboard</h2><p>Wallet, vault, uploads, downloads, rewards, fees, and module access are managed here.</p></div>';
    }

    public static function tenant_dashboard_shortcode(): string {
        if (!is_user_logged_in()) return '<p>Please log in to view tenant dashboard.</p>';
        return '<div class="ccjv-dashboard"><h2>CCJV Tenant Dashboard</h2><p>Tenant users, workspaces, modules, vault, billing, activity, and reports.</p></div>';
    }
}
