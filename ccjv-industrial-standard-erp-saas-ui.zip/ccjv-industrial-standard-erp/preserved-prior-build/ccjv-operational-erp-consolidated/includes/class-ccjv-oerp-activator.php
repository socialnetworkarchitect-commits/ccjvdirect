<?php
if (!defined('ABSPATH')) { exit; }

class CCJV_OERP_Activator {
    public static function activate(): void {
        global $wpdb;
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        $c = $wpdb->get_charset_collate();
        $p = $wpdb->prefix;

        $sql = [];

        $sql[] = "CREATE TABLE {$p}ccjv_tenants (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            tenant_key VARCHAR(96) NOT NULL,
            tenant_name VARCHAR(191) NOT NULL,
            status VARCHAR(64) NOT NULL DEFAULT 'active',
            wallet_address VARCHAR(128) NULL,
            settings LONGTEXT NULL,
            created_at DATETIME NOT NULL,
            PRIMARY KEY (id),
            UNIQUE KEY tenant_key (tenant_key)
        ) $c;";

        $sql[] = "CREATE TABLE {$p}ccjv_workspaces (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            tenant_id BIGINT UNSIGNED NOT NULL,
            workspace_key VARCHAR(96) NOT NULL,
            workspace_name VARCHAR(191) NOT NULL,
            status VARCHAR(64) NOT NULL DEFAULT 'active',
            settings LONGTEXT NULL,
            created_at DATETIME NOT NULL,
            PRIMARY KEY (id),
            KEY tenant_id (tenant_id),
            UNIQUE KEY workspace_key (workspace_key)
        ) $c;";

        $sql[] = "CREATE TABLE {$p}ccjv_modules (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            module_key VARCHAR(96) NOT NULL,
            module_name VARCHAR(191) NOT NULL,
            module_group VARCHAR(96) NULL,
            status VARCHAR(64) NOT NULL DEFAULT 'active',
            token_contract VARCHAR(128) NULL,
            entry_token_fee DECIMAL(24,8) NULL,
            monthly_token_fee DECIMAL(24,8) NULL,
            settings LONGTEXT NULL,
            created_at DATETIME NOT NULL,
            PRIMARY KEY (id),
            UNIQUE KEY module_key (module_key)
        ) $c;";

        $sql[] = "CREATE TABLE {$p}ccjv_entitlements (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            tenant_id BIGINT UNSIGNED NULL,
            user_id BIGINT UNSIGNED NULL,
            module_key VARCHAR(96) NOT NULL,
            wallet_address VARCHAR(128) NULL,
            status VARCHAR(64) NOT NULL DEFAULT 'pending',
            expires_at DATETIME NULL,
            replay_reference VARCHAR(191) NULL,
            treasury_reference VARCHAR(191) NULL,
            created_at DATETIME NOT NULL,
            PRIMARY KEY (id),
            KEY module_key (module_key),
            KEY wallet_address (wallet_address)
        ) $c;";

        $sql[] = "CREATE TABLE {$p}ccjv_vault_objects (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            tenant_id BIGINT UNSIGNED NULL,
            workspace_id BIGINT UNSIGNED NULL,
            module_key VARCHAR(96) NULL,
            object_key VARCHAR(191) NOT NULL,
            object_name VARCHAR(255) NULL,
            object_hash VARCHAR(128) NULL,
            storage_uri TEXT NULL,
            owner_user_id BIGINT UNSIGNED NULL,
            reward_status VARCHAR(64) NULL,
            replay_reference VARCHAR(191) NULL,
            proof_reference VARCHAR(191) NULL,
            created_at DATETIME NOT NULL,
            PRIMARY KEY (id),
            KEY object_key (object_key),
            KEY object_hash (object_hash),
            KEY module_key (module_key)
        ) $c;";

        $sql[] = "CREATE TABLE {$p}ccjv_proofs (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            vault_object_id BIGINT UNSIGNED NULL,
            proof_id VARCHAR(191) NULL,
            object_hash VARCHAR(128) NULL,
            merkle_root VARCHAR(128) NULL,
            tx_hash VARCHAR(191) NULL,
            block_number VARCHAR(64) NULL,
            verification_status VARCHAR(64) NOT NULL DEFAULT 'pending',
            payload LONGTEXT NULL,
            created_at DATETIME NOT NULL,
            PRIMARY KEY (id),
            KEY proof_id (proof_id),
            KEY tx_hash (tx_hash),
            KEY object_hash (object_hash)
        ) $c;";

        $sql[] = "CREATE TABLE {$p}ccjv_replay_events (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            replay_position BIGINT UNSIGNED NULL,
            event_id VARCHAR(96) NULL,
            correlation_id VARCHAR(96) NULL,
            causation_id VARCHAR(96) NULL,
            lineage_id VARCHAR(96) NULL,
            tenant_id BIGINT UNSIGNED NULL,
            workspace_id BIGINT UNSIGNED NULL,
            source_runtime VARCHAR(96) NULL,
            source_module VARCHAR(96) NULL,
            actor_id VARCHAR(96) NULL,
            event_type VARCHAR(191) NOT NULL,
            event_version VARCHAR(32) NULL,
            payload LONGTEXT NULL,
            created_at DATETIME NOT NULL,
            PRIMARY KEY (id),
            KEY replay_position (replay_position),
            KEY correlation_id (correlation_id),
            KEY lineage_id (lineage_id),
            KEY event_type (event_type)
        ) $c;";

        $sql[] = "CREATE TABLE {$p}ccjv_treasury_ledger (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            tenant_id BIGINT UNSIGNED NULL,
            module_key VARCHAR(96) NULL,
            wallet_address VARCHAR(128) NULL,
            action_type VARCHAR(96) NOT NULL,
            token_contract VARCHAR(128) NULL,
            amount DECIMAL(24,8) NULL,
            tx_hash VARCHAR(191) NULL,
            status VARCHAR(64) NOT NULL DEFAULT 'pending',
            replay_reference VARCHAR(191) NULL,
            created_at DATETIME NOT NULL,
            PRIMARY KEY (id),
            KEY module_key (module_key),
            KEY wallet_address (wallet_address),
            KEY tx_hash (tx_hash)
        ) $c;";

        $sql[] = "CREATE TABLE {$p}ccjv_observability_traces (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            trace_id VARCHAR(96) NOT NULL,
            correlation_id VARCHAR(96) NOT NULL,
            lineage_id VARCHAR(96) NOT NULL,
            source_erp VARCHAR(96) NULL,
            operation VARCHAR(191) NOT NULL,
            status VARCHAR(64) NOT NULL DEFAULT 'recorded',
            replay_reference VARCHAR(191) NULL,
            treasury_reference VARCHAR(191) NULL,
            vault_reference VARCHAR(191) NULL,
            proof_reference VARCHAR(191) NULL,
            payload LONGTEXT NULL,
            created_at DATETIME NOT NULL,
            PRIMARY KEY (id),
            KEY trace_id (trace_id),
            KEY correlation_id (correlation_id),
            KEY lineage_id (lineage_id)
        ) $c;";

        $sql[] = "CREATE TABLE {$p}ccjv_runtime_packets (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            source_erp VARCHAR(96) NOT NULL,
            packet_name VARCHAR(191) NOT NULL,
            packet_hash VARCHAR(128) NULL,
            compliance_score DECIMAL(5,2) NULL,
            packet_payload LONGTEXT NULL,
            created_at DATETIME NOT NULL,
            PRIMARY KEY (id),
            KEY source_erp (source_erp),
            KEY packet_hash (packet_hash)
        ) $c;";

        $sql[] = "CREATE TABLE {$p}ccjv_runtime_health (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            source_key VARCHAR(96) NOT NULL,
            service_key VARCHAR(96) NOT NULL,
            status VARCHAR(64) NOT NULL DEFAULT 'unknown',
            health_score DECIMAL(5,2) NULL,
            payload LONGTEXT NULL,
            checked_at DATETIME NOT NULL,
            PRIMARY KEY (id),
            KEY source_key (source_key),
            KEY service_key (service_key),
            KEY status (status)
        ) $c;";

        foreach ($sql as $s) { dbDelta($s); }

        self::seed_modules();
        update_option('ccjv_oerp_version', CCJV_OERP_VERSION);
    }

    private static function seed_modules(): void {
        global $wpdb;
        $modules = [
            ['crm','CRM','core'], ['hrm','HRM','core'], ['accounting','Accounting','core'],
            ['projects','Projects','core'], ['assets','Assets','core'], ['procurement','Procurement','core'],
            ['governance','Governance','core'], ['vault','Vault','runtime'], ['treasury','Treasury','runtime'],
            ['replay','Replay','runtime'], ['proof','Proof','runtime'], ['observability','Observability','runtime'],
            ['federation','Federation','runtime'], ['calendar','Calendar Federation','runtime'],
            ['cibus','Cibus ERP Connector','sector'], ['constructum','Constructum ERP Connector','sector'],
            ['vehiculum','Vehiculum ERP Connector','sector'], ['impensa','Impensa ERP Connector','sector'],
            ['aqua','Aqua ERP Connector','sector'], ['pecunia','Pecunia ERP Connector','sector'],
            ['lex','Lex ERP Connector','sector'], ['defensio','Defensio ERP Connector','sector'],
            ['sanitas','Sanitas ERP Connector','sector'], ['ingenium','Ingenium ERP Connector','sector']
        ];
        foreach ($modules as $m) {
            $exists = $wpdb->get_var($wpdb->prepare("SELECT id FROM {$wpdb->prefix}ccjv_modules WHERE module_key=%s", $m[0]));
            if (!$exists) {
                $wpdb->insert($wpdb->prefix.'ccjv_modules', [
                    'module_key'=>$m[0], 'module_name'=>$m[1], 'module_group'=>$m[2],
                    'status'=>'active', 'entry_token_fee'=>1, 'monthly_token_fee'=>1,
                    'created_at'=>gmdate('Y-m-d H:i:s')
                ]);
            }
        }
    }
}
