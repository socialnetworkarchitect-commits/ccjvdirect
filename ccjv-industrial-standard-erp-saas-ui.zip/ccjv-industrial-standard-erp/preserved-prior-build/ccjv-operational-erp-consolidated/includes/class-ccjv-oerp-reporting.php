<?php
if (!defined('ABSPATH')) { exit; }

class CCJV_OERP_Reporting {
    const NONCE = 'ccjv_oerp_packet_nonce';

    public static function boot(): void {
        add_action('admin_post_ccjv_oerp_upload_packet', [__CLASS__, 'upload_packet']);
    }

    public static function page(): void {
        global $wpdb;
        echo '<div class="wrap ccjv-oerp"><h1>Runtime Reporting Center</h1>';
        echo '<p>Upload ERP AI Runtime Packets. This keeps one reporting model across all ERPs.</p>';
        echo '<form method="post" enctype="multipart/form-data" action="'.esc_url(admin_url('admin-post.php')).'">';
        wp_nonce_field(self::NONCE);
        echo '<input type="hidden" name="action" value="ccjv_oerp_upload_packet" />';
        echo '<input type="file" name="runtime_packet" accept=".zip" required /> ';
        echo '<button class="button button-primary">Upload Runtime Packet</button></form><hr />';
        $rows = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}ccjv_runtime_packets ORDER BY id DESC LIMIT 100", ARRAY_A);
        if (!$rows) { echo '<p>No packets uploaded yet.</p></div>'; return; }
        echo '<table class="widefat striped"><thead><tr><th>ERP</th><th>Packet</th><th>Hash</th><th>Score</th><th>Created</th></tr></thead><tbody>';
        foreach ($rows as $r) {
            echo '<tr><td>'.esc_html($r['source_erp']).'</td><td>'.esc_html($r['packet_name']).'</td><td><code>'.esc_html($r['packet_hash']).'</code></td><td>'.esc_html($r['compliance_score']).'</td><td>'.esc_html($r['created_at']).'</td></tr>';
        }
        echo '</tbody></table></div>';
    }

    public static function upload_packet(): void {
        if (!current_user_can('manage_options')) wp_die('Unauthorized');
        check_admin_referer(self::NONCE);
        if (empty($_FILES['runtime_packet']['tmp_name'])) wp_die('No file uploaded.');
        $tmp = $_FILES['runtime_packet']['tmp_name'];
        $name = sanitize_file_name($_FILES['runtime_packet']['name']);
        $hash = hash_file('sha256', $tmp);
        $payload = ['files'=>[], 'uploaded_at'=>gmdate('c')];
        $zip = new ZipArchive();
        if ($zip->open($tmp) === true) {
            for ($i=0; $i<$zip->numFiles; $i++) {
                $stat = $zip->statIndex($i);
                $fname = $stat['name'];
                $raw = $zip->getFromIndex($i);
                if (substr($fname,-5)==='.json') $payload['files'][$fname] = json_decode($raw, true);
                else $payload['files'][$fname] = substr($raw, 0, 2000);
            }
            $zip->close();
        }
        $source = $payload['files']['runtime-health.json']['erp_slug'] ?? $payload['files']['runtime-health.json']['erp'] ?? 'unknown';
        $score = self::score($payload);
        global $wpdb;
        $wpdb->insert($wpdb->prefix.'ccjv_runtime_packets', [
            'source_erp'=>sanitize_text_field($source),
            'packet_name'=>$name,
            'packet_hash'=>$hash,
            'compliance_score'=>$score,
            'packet_payload'=>wp_json_encode($payload),
            'created_at'=>gmdate('Y-m-d H:i:s')
        ]);
        wp_safe_redirect(admin_url('admin.php?page=ccjv-oerp-reporting&uploaded=1'));
        exit;
    }

    private static function score(array $payload): float {
        $required = ['runtime-health.json','replay-summary.json','queue-health.json','websocket-health.json','treasury-status.json','vault-status.json','proof-status.json','observability-summary.json','tenant-map.json','module-registry.json'];
        $have = 0;
        foreach ($required as $r) if (isset($payload['files'][$r])) $have++;
        return round(($have / count($required)) * 100, 2);
    }
}
