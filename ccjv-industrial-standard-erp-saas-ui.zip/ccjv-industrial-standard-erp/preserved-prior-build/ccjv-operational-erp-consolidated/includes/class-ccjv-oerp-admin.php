<?php
if (!defined('ABSPATH')) { exit; }

class CCJV_OERP_Admin {
    public static function boot(): void {
        add_action('admin_menu', [__CLASS__, 'menu']);
        add_action('admin_enqueue_scripts', [__CLASS__, 'assets']);
    }

    public static function assets(): void {
        wp_enqueue_style('ccjv-oerp-admin', CCJV_OERP_URL.'assets/admin.css', [], CCJV_OERP_VERSION);
    }

    public static function menu(): void {
        add_menu_page('CCJV Core ERP', 'CCJV Core ERP', 'manage_options', 'ccjv-oerp', [__CLASS__, 'command_center'], 'dashicons-networking', 55);
        $pages = [
            ['Super Admin Dashboard','Super Admin','super_admin'],
            ['Tenant Dashboard','Tenants','tenants'],
            ['User Dashboard','Users','users'],
            ['Module Registry','Modules','modules'],
            ['Token + Pricing Controls','Token/Pricing','pricing'],
            ['Vault Center','Vault','vault'],
            ['Treasury Center','Treasury','treasury'],
            ['Replay Center','Replay','replay'],
            ['Proof Center','Proof','proof'],
            ['Observability Center','Observability','observability'],
            ['Runtime Health Center','Runtime Health','runtime_health'],
            ['Runtime Reporting Center','Reporting','reporting'],
            ['Preserved Artifacts','Preserved Artifacts','artifacts'],
            ['Smart Codes','Smart Codes','smartcodes'],
        ];
        foreach ($pages as $p) {
            add_submenu_page('ccjv-oerp', $p[0], $p[1], 'manage_options', 'ccjv-oerp-'.$p[2], [__CLASS__, $p[2]]);
        }
    }

    private static function rows(string $table, int $limit = 100): array {
        global $wpdb;
        return $wpdb->get_results("SELECT * FROM {$wpdb->prefix}{$table} ORDER BY id DESC LIMIT ".intval($limit), ARRAY_A) ?: [];
    }

    private static function table(array $rows): void {
        if (!$rows) { echo '<p>No records yet.</p>'; return; }
        echo '<table class="widefat striped ccjv-table"><thead><tr>';
        foreach (array_keys($rows[0]) as $k) echo '<th>'.esc_html($k).'</th>';
        echo '</tr></thead><tbody>';
        foreach ($rows as $r) {
            echo '<tr>';
            foreach ($r as $v) echo '<td><code>'.esc_html(is_scalar($v)?(string)$v:wp_json_encode($v)).'</code></td>';
            echo '</tr>';
        }
        echo '</tbody></table>';
    }

    private static function wrap(string $title, string $body): void {
        echo '<div class="wrap ccjv-oerp"><h1>'.esc_html($title).'</h1>'.$body.'</div>';
    }

    public static function command_center(): void {
        global $wpdb;
        $cards = [
            'Tenants'=> $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}ccjv_tenants"),
            'Modules'=> $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}ccjv_modules"),
            'Vault Objects'=> $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}ccjv_vault_objects"),
            'Replay Events'=> $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}ccjv_replay_events"),
            'Proofs'=> $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}ccjv_proofs"),
            'Treasury Rows'=> $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}ccjv_treasury_ledger"),
        ];
        $html = '<p>Multi-tenant, multi-user, token-gated SaaS ERP control plane.</p><div class="ccjv-grid">';
        foreach ($cards as $k=>$v) $html .= '<div class="ccjv-card"><h2>'.esc_html($v).'</h2><p>'.esc_html($k).'</p></div>';
        $html .= '</div><h2>Constitutional Rules</h2><ul><li>Everything saved to Vault.</li><li>Everything hashed and anchored to Avalanche.</li><li>Token gate after theme.</li><li>Token fee per module per month.</li><li>Vault upload rewards, view fees, and download fees.</li></ul>';
        self::wrap('CCJV Core ERP Command Center', $html);
    }

    public static function super_admin(): void { self::wrap('Super Admin Dashboard', '<p>ERP registry, tenant registry, user registry, wallet registry, token registry, replay, proof, vault, treasury, observability, federation, runtime health, and module registry.</p>'); }
    public static function tenants(): void { self::wrap('Tenant Dashboard / Registry', '<p>Tenant control, workspaces, users, modules, vault, billing, reporting.</p>'); self::table(self::rows('ccjv_tenants')); }
    public static function users(): void { self::wrap('User Dashboard Registry', '<p>User wallet, activity, workspace membership, module access, uploads, downloads, rewards, and fees.</p>'); }
    public static function modules(): void { self::wrap('Module Registry', '<p>Infinite module framework with token fees, module activation, and workspace routing.</p>'); self::table(self::rows('ccjv_modules', 200)); }
    public static function pricing(): void { self::wrap('Token + Pricing Controls', '<p>Edit ERP entry gate, module/month fees, vault rewards, view fees, download fees, and treasury routing.</p>'); self::table(self::rows('ccjv_modules', 200)); }
    public static function vault(): void { self::wrap('Vault Center', '<p>All saved objects, hashes, ownership, rewards, and proof lineage.</p>'); self::table(self::rows('ccjv_vault_objects')); }
    public static function treasury(): void { self::wrap('Treasury Center', '<p>Subscriptions, module fees, settlement, billing, upload rewards, view/download fees.</p>'); self::table(self::rows('ccjv_treasury_ledger')); }
    public static function replay(): void { self::wrap('Replay Center', '<p>Event sourcing, replay log, replay explorer, replay restoration, replay confidence.</p>'); self::table(self::rows('ccjv_replay_events')); }
    public static function proof(): void { self::wrap('Proof Center', '<p>Avalanche proof explorer, anchor explorer, Merkle explorer, verification explorer.</p>'); self::table(self::rows('ccjv_proofs')); }
    public static function observability(): void { self::wrap('Observability Center', '<p>Correlation IDs, trace IDs, lineage IDs, replay/vault/proof/treasury references.</p>'); self::table(self::rows('ccjv_observability_traces')); }
    public static function runtime_health(): void { self::wrap('Runtime Health Center', '<p>Replay, treasury, vault, proof, observability, federation, websocket, queue health.</p>'); self::table(self::rows('ccjv_runtime_health')); }
    public static function reporting(): void { CCJV_OERP_Reporting::page(); }
    public static function artifacts(): void {
        $manifest = json_decode(file_get_contents(CCJV_OERP_PATH.'consolidation-manifest.json'), true);
        self::wrap('Preserved Source Artifacts', '<pre>'.esc_html(json_encode($manifest, JSON_PRETTY_PRINT)).'</pre>');
    }
    public static function smartcodes(): void {
        self::wrap('Pages Required + Smart Codes', '<ul><li><code>[ccjv_wallet_connect]</code></li><li><code>[ccjv_user_dashboard]</code></li><li><code>[ccjv_tenant_dashboard]</code></li></ul>');
    }
}
