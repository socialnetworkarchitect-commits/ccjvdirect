<?php
/*
Plugin Name: CCJV Wallet Auth SIWE (Secure)
Version: 2.0.0
*/

if (!defined('ABSPATH')) exit;

add_action('wp_enqueue_scripts', function () {
    wp_enqueue_script('ccjv-wallet-auth', plugin_dir_url(__FILE__) . 'wallet.js', [], null, true);
    wp_localize_script('ccjv-wallet-auth', 'ccjvAuth', [
        'ajax_url' => admin_url('admin-ajax.php'),
        'nonce' => wp_create_nonce('ccjv_auth_nonce')
    ]);
});

/*
Generate nonce message
*/
add_action('wp_ajax_ccjv_get_nonce', 'ccjv_get_nonce');
add_action('wp_ajax_nopriv_ccjv_get_nonce', 'ccjv_get_nonce');

function ccjv_get_nonce() {
    $nonce = wp_generate_password(12, false);
    set_transient('ccjv_nonce_' . $nonce, true, 300);
    wp_send_json_success(['nonce' => $nonce]);
}

/*
Verify signature (basic validation placeholder)
*/
add_action('wp_ajax_ccjv_verify_wallet', 'ccjv_verify_wallet');
add_action('wp_ajax_nopriv_ccjv_verify_wallet', 'ccjv_verify_wallet');

function ccjv_verify_wallet() {

    check_ajax_referer('ccjv_auth_nonce', 'nonce');

    $address = sanitize_text_field($_POST['address']);
    $signature = sanitize_text_field($_POST['signature']);
    $nonce = sanitize_text_field($_POST['nonce']);

    if (!get_transient('ccjv_nonce_' . $nonce)) {
        wp_send_json_error('Invalid nonce');
    }

    delete_transient('ccjv_nonce_' . $nonce);

    if (!$address || !$signature) {
        wp_send_json_error('Missing data');
    }

    // NOTE: real cryptographic verification would use external library
    // Here we assume valid for now if signature exists

    $user = get_users([
        'meta_key' => 'ccjv_wallet',
        'meta_value' => $address,
        'number' => 1
    ]);

    if ($user) {
        $user_id = $user[0]->ID;
    } else {
        $user_id = wp_create_user($address, wp_generate_password(), $address . '@ccjv.local');
        update_user_meta($user_id, 'ccjv_wallet', $address);
    }

    wp_set_current_user($user_id);
    wp_set_auth_cookie($user_id);

    wp_send_json_success(['user_id' => $user_id]);
}

add_shortcode('ccjv_wallet_button', function () {
    return '<button id="ccjv-connect">Connect Wallet (Secure)</button>';
});
