document.addEventListener('DOMContentLoaded', function () {

    const btn = document.getElementById('ccjv-connect');
    if (!btn) return;

    btn.onclick = async () => {

        if (!window.ethereum) {
            alert("MetaMask not installed");
            return;
        }

        const accounts = await ethereum.request({ method: 'eth_requestAccounts' });
        const address = accounts[0];

        // get nonce
        const nonceRes = await fetch(ccjvAuth.ajax_url, {
            method: 'POST',
            headers: {'Content-Type': 'application/x-www-form-urlencoded'},
            body: new URLSearchParams({
                action: 'ccjv_get_nonce'
            })
        });

        const nonceData = await nonceRes.json();
        const nonce = nonceData.data.nonce;

        const message = "CCJV Login: " + nonce;

        const signature = await ethereum.request({
            method: 'personal_sign',
            params: [message, address]
        });

        const response = await fetch(ccjvAuth.ajax_url, {
            method: 'POST',
            headers: {'Content-Type': 'application/x-www-form-urlencoded'},
            body: new URLSearchParams({
                action: 'ccjv_verify_wallet',
                address: address,
                signature: signature,
                nonce: nonce,
                nonce: ccjvAuth.nonce
            })
        });

        const data = await response.json();

        if (data.success) {
            location.reload();
        } else {
            alert("Auth failed");
        }
    };
});
