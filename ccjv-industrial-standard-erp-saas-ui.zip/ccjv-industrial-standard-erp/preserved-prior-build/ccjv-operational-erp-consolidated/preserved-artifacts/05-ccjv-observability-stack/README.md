Prometheus Grafana Loki stack.
