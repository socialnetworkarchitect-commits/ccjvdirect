async function ccjvConnect(){
    if (typeof window.ethereum === 'undefined'){
        alert('MetaMask not found');
        return;
    }

    const accounts = await ethereum.request({ method: 'eth_requestAccounts' });
    const wallet = accounts[0];

    document.getElementById('ccjv-wallet-status').innerText = wallet;

    fetch(ajaxurl, {
        method: 'POST',
        headers: {'Content-Type':'application/x-www-form-urlencoded'},
        body: 'action=ccjv_save_wallet&wallet=' + wallet
    });
}
