<?php
/*
Plugin Name: CCJV Wallet + Token Gate
Version: 1.0
Description: Wallet connect + token gating layer for Core X
*/

if (!defined('ABSPATH')) exit;

// Require core
if (!defined('CCJV_CORE_ACTIVE')) return;

define('CCJV_WALLET_GATE', true);

// Enqueue JS
add_action('wp_enqueue_scripts', function(){
    wp_enqueue_script('ccjv-wallet-js', plugin_dir_url(__FILE__) . 'assets/wallet.js', [], null, true);
});

// Shortcode for wallet UI
add_shortcode('ccjv_wallet_ui', function(){
    ob_start(); ?>
    <div id="ccjv-wallet-box">
        <button onclick="ccjvConnect()">Connect Wallet</button>
        <div id="ccjv-wallet-status">Not Connected</div>
    </div>
    <?php return ob_get_clean();
});

// AJAX save wallet
add_action('wp_ajax_ccjv_save_wallet', 'ccjv_save_wallet');
add_action('wp_ajax_nopriv_ccjv_save_wallet', 'ccjv_save_wallet');

function ccjv_save_wallet(){
    if (!is_user_logged_in()) wp_send_json_error("Not logged in");
    $wallet = sanitize_text_field($_POST['wallet']);
    update_user_meta(get_current_user_id(), 'ccjv_wallet', $wallet);
    wp_send_json_success("Saved");
}

// Token gate check
function ccjv_check_token_gate($user_id, $required_token){
    // placeholder logic (extend with real chain check)
    $wallet = get_user_meta($user_id, 'ccjv_wallet', true);
    if (!$wallet) return false;

    // TEMP: allow if wallet exists
    return true;
}
