 (function(){
  function qs(sel, root){ return (root||document).querySelector(sel); }
  function qsa(sel, root){ return Array.prototype.slice.call((root||document).querySelectorAll(sel)); }
  function setMessage(html, cls){ var box = qs('.ccjv3-wallet-results'); if(!box) return; box.innerHTML = '<p class="'+cls+'">'+html+'</p>'; }
  function hexToDecimalString(hex){
    try { return BigInt(hex).toString(); } catch(e){ return '0'; }
  }
  function formatUnitsFromHex(hex, decimals){
    try {
      var raw = BigInt(hex);
      var base = BigInt(10) ** BigInt(decimals || 18);
      var whole = raw / base;
      var frac = raw % base;
      var fracStr = frac.toString().padStart(Number(decimals || 18), '0').replace(/0+$/, '').slice(0,8);
      return fracStr ? whole.toString() + '.' + fracStr : whole.toString();
    } catch(e){ return '0'; }
  }
  function encodeAddress(address){
    return address.toLowerCase().replace(/^0x/,'').padStart(64,'0');
  }
  async function ethCall(contract, data){
    return await window.ethereum.request({ method:'eth_call', params:[{to:contract,data:data}, 'latest'] });
  }
  async function switchAvalanche(){
    try {
      await window.ethereum.request({ method:'wallet_switchEthereumChain', params:[{ chainId: CCJV3Data.chainHex }] });
    } catch(err){
      if (err.code === 4902) {
        await window.ethereum.request({ method:'wallet_addEthereumChain', params:[{ chainId: CCJV3Data.chainHex, chainName: CCJV3Data.chainName, nativeCurrency: CCJV3Data.nativeCurrency, rpcUrls: CCJV3Data.rpcUrls, blockExplorerUrls: CCJV3Data.blockExplorerUrls }] });
      } else { throw err; }
    }
  }
  async function connectWallet(){
    if (!window.ethereum) { setMessage('MetaMask not detected in this browser.', 'error'); return; }
    if (!CCJV3Data.isLoggedIn) { setMessage('Please log in first so the wallet can be saved to your account.', 'error'); return; }
    try {
      await switchAvalanche();
      var accounts = await window.ethereum.request({ method:'eth_requestAccounts' });
      var address = accounts && accounts[0] ? accounts[0] : '';
      if (!address) throw new Error('No wallet address returned');
      var balances = {};
      for (var i=0;i<CCJV3Data.workspaceTokens.length;i++) {
        var token = CCJV3Data.workspaceTokens[i];
        if (!token.contract) continue;
        var data = '0x70a08231' + encodeAddress(address);
        try {
          var result = await ethCall(token.contract, data);
          balances[token.symbol] = formatUnitsFromHex(result, token.decimals || 18);
        } catch(tokenErr) {
          console.warn('Token read failed', token.symbol, tokenErr);
        }
      }
      var formData = new FormData();
      formData.append('action', 'ccjv3_save_wallet_sync');
      formData.append('nonce', CCJV3Data.nonce);
      formData.append('wallet_address', address);
      formData.append('balances', JSON.stringify(balances));
      formData.append('chain_name', 'Avalanche');
      formData.append('chain_id', CCJV3Data.chainHex);
      var response = await fetch(CCJV3Data.ajaxUrl, { method:'POST', credentials:'same-origin', body:formData });
      var json = await response.json();
      if (json && json.success) {
        var parts = Object.keys(balances).map(function(k){ return k + ': ' + balances[k]; });
        setMessage('Wallet synchronized: ' + address + (parts.length ? '<br>Balances: ' + parts.join(' | ') : '<br>No configured workspace token balances were returned.'), 'success');
        setTimeout(function(){ window.location.reload(); }, 1000);
      } else {
        setMessage((json && json.data && json.data.message) ? json.data.message : 'Could not save wallet.', 'error');
      }
    } catch(err) {
      setMessage((err && err.message) ? err.message : 'Wallet connection failed.', 'error');
    }
  }
  document.addEventListener('click', function(e){
    var btn = e.target.closest('.ccjv3-connect-wallet');
    if (btn) { e.preventDefault(); connectWallet(); }
  });
})(); 