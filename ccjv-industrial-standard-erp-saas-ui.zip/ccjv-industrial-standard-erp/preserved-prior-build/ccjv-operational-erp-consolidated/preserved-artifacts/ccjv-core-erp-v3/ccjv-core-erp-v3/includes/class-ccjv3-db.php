<?php
if (!defined('ABSPATH')) { exit; }
class CCJV3_DB {
    public static function table(string $name): string {
        global $wpdb;
        return $wpdb->prefix . 'ccjv3_' . $name;
    }
    public static function activate(): void {
        self::create_tables();
        self::seed_defaults();
    }
    public static function create_tables(): void {
        global $wpdb;
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        $c = $wpdb->get_charset_collate();
        $sql = [];
        $sql[] = "CREATE TABLE " . self::table('workspaces') . " (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            slug VARCHAR(100) NOT NULL,
            name VARCHAR(190) NOT NULL,
            token_symbol VARCHAR(30) NOT NULL DEFAULT '',
            token_contract VARCHAR(255) NOT NULL DEFAULT '',
            token_decimals INT NOT NULL DEFAULT 18,
            token_threshold DECIMAL(24,8) NOT NULL DEFAULT 0,
            accent_color VARCHAR(20) NOT NULL DEFAULT '#1d4ed8',
            hero_image VARCHAR(255) NOT NULL DEFAULT '',
            dashboard_title VARCHAR(190) NOT NULL DEFAULT '',
            description TEXT NULL,
            allowed_modules VARCHAR(255) NOT NULL DEFAULT 'overview,crm,hrm,accounting,invoices,projects,assets',
            is_active TINYINT(1) NOT NULL DEFAULT 1,
            created_at DATETIME NOT NULL,
            updated_at DATETIME NOT NULL,
            PRIMARY KEY (id),
            UNIQUE KEY slug (slug)
        ) $c";
        $sql[] = "CREATE TABLE " . self::table('ventures') . " (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            venture_code VARCHAR(50) NOT NULL DEFAULT '',
            venture_name VARCHAR(190) NOT NULL,
            workspace_id BIGINT UNSIGNED NULL,
            venture_type VARCHAR(100) NOT NULL DEFAULT '',
            stage VARCHAR(50) NOT NULL DEFAULT 'planning',
            owner_name VARCHAR(190) NOT NULL DEFAULT '',
            budget DECIMAL(18,2) NOT NULL DEFAULT 0,
            start_date DATE NULL,
            end_date DATE NULL,
            description LONGTEXT NULL,
            created_at DATETIME NOT NULL,
            updated_at DATETIME NOT NULL,
            PRIMARY KEY (id)
        ) $c";
        $sql[] = "CREATE TABLE " . self::table('workspace_permissions') . " (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            user_id BIGINT UNSIGNED NOT NULL,
            workspace_id BIGINT UNSIGNED NOT NULL,
            role_key VARCHAR(100) NOT NULL DEFAULT 'viewer',
            manual_override TINYINT(1) NOT NULL DEFAULT 0,
            front_modules VARCHAR(255) NOT NULL DEFAULT '',
            created_at DATETIME NOT NULL,
            updated_at DATETIME NOT NULL,
            PRIMARY KEY (id),
            UNIQUE KEY user_workspace (user_id, workspace_id)
        ) $c";
        $sql[] = "CREATE TABLE " . self::table('wallets') . " (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            user_id BIGINT UNSIGNED NOT NULL,
            wallet_address VARCHAR(255) NOT NULL,
            chain_name VARCHAR(50) NOT NULL DEFAULT 'Avalanche',
            chain_id VARCHAR(20) NOT NULL DEFAULT '0xa86a',
            status VARCHAR(30) NOT NULL DEFAULT 'connected',
            token_balances LONGTEXT NULL,
            last_verified_at DATETIME NULL,
            verification_source VARCHAR(50) NOT NULL DEFAULT 'metamask',
            created_at DATETIME NOT NULL,
            updated_at DATETIME NOT NULL,
            PRIMARY KEY (id),
            UNIQUE KEY user_wallet (user_id, wallet_address(120))
        ) $c";
        $sql[] = "CREATE TABLE " . self::table('crm_contacts') . " (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            workspace_id BIGINT UNSIGNED NULL,
            venture_id BIGINT UNSIGNED NULL,
            company VARCHAR(190) NOT NULL DEFAULT '',
            first_name VARCHAR(120) NOT NULL DEFAULT '',
            last_name VARCHAR(120) NOT NULL DEFAULT '',
            email VARCHAR(190) NOT NULL DEFAULT '',
            phone VARCHAR(60) NOT NULL DEFAULT '',
            status VARCHAR(50) NOT NULL DEFAULT 'lead',
            notes LONGTEXT NULL,
            created_at DATETIME NOT NULL,
            updated_at DATETIME NOT NULL,
            PRIMARY KEY (id)
        ) $c";
        $sql[] = "CREATE TABLE " . self::table('hrm_employees') . " (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            workspace_id BIGINT UNSIGNED NULL,
            venture_id BIGINT UNSIGNED NULL,
            employee_code VARCHAR(50) NOT NULL DEFAULT '',
            first_name VARCHAR(120) NOT NULL DEFAULT '',
            last_name VARCHAR(120) NOT NULL DEFAULT '',
            email VARCHAR(190) NOT NULL DEFAULT '',
            phone VARCHAR(60) NOT NULL DEFAULT '',
            department VARCHAR(120) NOT NULL DEFAULT '',
            position VARCHAR(120) NOT NULL DEFAULT '',
            hourly_rate DECIMAL(18,2) NOT NULL DEFAULT 0,
            salary DECIMAL(18,2) NOT NULL DEFAULT 0,
            status VARCHAR(50) NOT NULL DEFAULT 'active',
            start_date DATE NULL,
            notes LONGTEXT NULL,
            created_at DATETIME NOT NULL,
            updated_at DATETIME NOT NULL,
            PRIMARY KEY (id)
        ) $c";
        $sql[] = "CREATE TABLE " . self::table('chart_accounts') . " (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            account_code VARCHAR(50) NOT NULL,
            account_name VARCHAR(190) NOT NULL,
            account_type VARCHAR(50) NOT NULL,
            normal_balance VARCHAR(10) NOT NULL DEFAULT 'debit',
            is_active TINYINT(1) NOT NULL DEFAULT 1,
            created_at DATETIME NOT NULL,
            updated_at DATETIME NOT NULL,
            PRIMARY KEY (id),
            UNIQUE KEY account_code (account_code)
        ) $c";
        $sql[] = "CREATE TABLE " . self::table('journal_headers') . " (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            workspace_id BIGINT UNSIGNED NULL,
            venture_id BIGINT UNSIGNED NULL,
            journal_no VARCHAR(50) NOT NULL,
            entry_date DATE NOT NULL,
            source_type VARCHAR(50) NOT NULL DEFAULT '',
            source_id BIGINT UNSIGNED NULL,
            memo LONGTEXT NULL,
            status VARCHAR(30) NOT NULL DEFAULT 'posted',
            created_by BIGINT UNSIGNED NULL,
            created_at DATETIME NOT NULL,
            updated_at DATETIME NOT NULL,
            PRIMARY KEY (id),
            UNIQUE KEY journal_no (journal_no)
        ) $c";
        $sql[] = "CREATE TABLE " . self::table('journal_lines') . " (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            journal_id BIGINT UNSIGNED NOT NULL,
            account_code VARCHAR(50) NOT NULL,
            account_name VARCHAR(190) NOT NULL,
            entry_type VARCHAR(10) NOT NULL,
            amount DECIMAL(18,2) NOT NULL DEFAULT 0,
            line_memo VARCHAR(255) NOT NULL DEFAULT '',
            created_at DATETIME NOT NULL,
            updated_at DATETIME NOT NULL,
            PRIMARY KEY (id),
            KEY journal_id (journal_id),
            KEY account_code (account_code)
        ) $c";
        $sql[] = "CREATE TABLE " . self::table('invoices') . " (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            workspace_id BIGINT UNSIGNED NULL,
            venture_id BIGINT UNSIGNED NULL,
            invoice_no VARCHAR(50) NOT NULL,
            client_name VARCHAR(190) NOT NULL,
            issue_date DATE NOT NULL,
            due_date DATE NULL,
            status VARCHAR(50) NOT NULL DEFAULT 'draft',
            subtotal DECIMAL(18,2) NOT NULL DEFAULT 0,
            tax DECIMAL(18,2) NOT NULL DEFAULT 0,
            total DECIMAL(18,2) NOT NULL DEFAULT 0,
            paid_amount DECIMAL(18,2) NOT NULL DEFAULT 0,
            notes LONGTEXT NULL,
            created_at DATETIME NOT NULL,
            updated_at DATETIME NOT NULL,
            PRIMARY KEY (id),
            UNIQUE KEY invoice_no (invoice_no)
        ) $c";
        $sql[] = "CREATE TABLE " . self::table('invoice_lines') . " (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            invoice_id BIGINT UNSIGNED NOT NULL,
            line_no INT NOT NULL DEFAULT 1,
            description VARCHAR(255) NOT NULL,
            quantity DECIMAL(18,4) NOT NULL DEFAULT 1,
            unit_price DECIMAL(18,4) NOT NULL DEFAULT 0,
            line_total DECIMAL(18,2) NOT NULL DEFAULT 0,
            created_at DATETIME NOT NULL,
            updated_at DATETIME NOT NULL,
            PRIMARY KEY (id),
            KEY invoice_id (invoice_id)
        ) $c";
        $sql[] = "CREATE TABLE " . self::table('invoice_payments') . " (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            invoice_id BIGINT UNSIGNED NOT NULL,
            payment_date DATE NOT NULL,
            payment_method VARCHAR(50) NOT NULL DEFAULT 'bank',
            amount DECIMAL(18,2) NOT NULL DEFAULT 0,
            reference_no VARCHAR(100) NOT NULL DEFAULT '',
            notes LONGTEXT NULL,
            created_at DATETIME NOT NULL,
            updated_at DATETIME NOT NULL,
            PRIMARY KEY (id),
            KEY invoice_id (invoice_id)
        ) $c";
        $sql[] = "CREATE TABLE " . self::table('payroll_runs') . " (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            workspace_id BIGINT UNSIGNED NULL,
            venture_id BIGINT UNSIGNED NULL,
            employee_id BIGINT UNSIGNED NULL,
            pay_period_start DATE NOT NULL,
            pay_period_end DATE NOT NULL,
            pay_date DATE NOT NULL,
            regular_hours DECIMAL(10,2) NOT NULL DEFAULT 0,
            overtime_hours DECIMAL(10,2) NOT NULL DEFAULT 0,
            gross_pay DECIMAL(18,2) NOT NULL DEFAULT 0,
            deductions DECIMAL(18,2) NOT NULL DEFAULT 0,
            net_pay DECIMAL(18,2) NOT NULL DEFAULT 0,
            status VARCHAR(50) NOT NULL DEFAULT 'posted',
            notes LONGTEXT NULL,
            created_at DATETIME NOT NULL,
            updated_at DATETIME NOT NULL,
            PRIMARY KEY (id)
        ) $c";
        $sql[] = "CREATE TABLE " . self::table('projects') . " (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            workspace_id BIGINT UNSIGNED NULL,
            venture_id BIGINT UNSIGNED NULL,
            project_code VARCHAR(50) NOT NULL DEFAULT '',
            project_name VARCHAR(190) NOT NULL,
            manager_name VARCHAR(190) NOT NULL DEFAULT '',
            stage VARCHAR(50) NOT NULL DEFAULT 'planning',
            budget DECIMAL(18,2) NOT NULL DEFAULT 0,
            start_date DATE NULL,
            end_date DATE NULL,
            progress_percent TINYINT UNSIGNED NOT NULL DEFAULT 0,
            description LONGTEXT NULL,
            created_at DATETIME NOT NULL,
            updated_at DATETIME NOT NULL,
            PRIMARY KEY (id)
        ) $c";
        $sql[] = "CREATE TABLE " . self::table('project_tasks') . " (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            project_id BIGINT UNSIGNED NOT NULL,
            parent_task_id BIGINT UNSIGNED NULL,
            task_name VARCHAR(190) NOT NULL,
            assigned_to VARCHAR(190) NOT NULL DEFAULT '',
            status VARCHAR(50) NOT NULL DEFAULT 'not_started',
            stage_lane VARCHAR(50) NOT NULL DEFAULT 'backlog',
            start_date DATE NULL,
            due_date DATE NULL,
            dependency_task_ids VARCHAR(255) NOT NULL DEFAULT '',
            percent_complete TINYINT UNSIGNED NOT NULL DEFAULT 0,
            sort_order INT NOT NULL DEFAULT 0,
            notes LONGTEXT NULL,
            created_at DATETIME NOT NULL,
            updated_at DATETIME NOT NULL,
            PRIMARY KEY (id),
            KEY project_id (project_id)
        ) $c";
        $sql[] = "CREATE TABLE " . self::table('assets') . " (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            workspace_id BIGINT UNSIGNED NULL,
            venture_id BIGINT UNSIGNED NULL,
            asset_code VARCHAR(50) NOT NULL DEFAULT '',
            asset_name VARCHAR(190) NOT NULL,
            asset_type VARCHAR(100) NOT NULL DEFAULT '',
            location_name VARCHAR(190) NOT NULL DEFAULT '',
            owner_name VARCHAR(190) NOT NULL DEFAULT '',
            purchase_date DATE NULL,
            purchase_value DECIMAL(18,2) NOT NULL DEFAULT 0,
            salvage_value DECIMAL(18,2) NOT NULL DEFAULT 0,
            useful_life_years INT NOT NULL DEFAULT 5,
            depreciation_method VARCHAR(50) NOT NULL DEFAULT 'straight_line',
            current_value DECIMAL(18,2) NOT NULL DEFAULT 0,
            accumulated_depreciation DECIMAL(18,2) NOT NULL DEFAULT 0,
            status VARCHAR(50) NOT NULL DEFAULT 'active',
            notes LONGTEXT NULL,
            created_at DATETIME NOT NULL,
            updated_at DATETIME NOT NULL,
            PRIMARY KEY (id)
        ) $c";
        $sql[] = "CREATE TABLE " . self::table('depreciation_runs') . " (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            asset_id BIGINT UNSIGNED NOT NULL,
            run_date DATE NOT NULL,
            amount DECIMAL(18,2) NOT NULL DEFAULT 0,
            accumulated_amount DECIMAL(18,2) NOT NULL DEFAULT 0,
            book_value DECIMAL(18,2) NOT NULL DEFAULT 0,
            journal_id BIGINT UNSIGNED NULL,
            notes LONGTEXT NULL,
            created_at DATETIME NOT NULL,
            updated_at DATETIME NOT NULL,
            PRIMARY KEY (id),
            KEY asset_id (asset_id)
        ) $c";
        foreach ($sql as $s) { dbDelta($s); }
    }
    public static function seed_defaults(): void {
        global $wpdb;
        $now = current_time('mysql');
        $workspaces = self::table('workspaces');
        if (!(int)$wpdb->get_var("SELECT COUNT(*) FROM {$workspaces}")) {
            $rows = [
                ['slug'=>'constructum','name'=>'Constructum','token_symbol'=>'CST','token_threshold'=>1,'accent_color'=>'#ea580c','dashboard_title'=>'Construction Workspace','description'=>'Construction, labour, and project execution workspace.','allowed_modules'=>'overview,crm,hrm,projects,invoices,accounting,assets'],
                ['slug'=>'energychain','name'=>'EnergyChain','token_symbol'=>'ENRC','token_threshold'=>1,'accent_color'=>'#0ea5e9','dashboard_title'=>'Energy Workspace','description'=>'Energy and utility ventures, revenue, and assets.','allowed_modules'=>'overview,crm,projects,invoices,accounting,assets'],
                ['slug'=>'landbank','name'=>'LandBank','token_symbol'=>'LBC','token_threshold'=>1,'accent_color'=>'#16a34a','dashboard_title'=>'Land Workspace','description'=>'Land, development, and title-related venture workspace.','allowed_modules'=>'overview,crm,projects,assets,accounting,invoices']
            ];
            foreach ($rows as $r) {
                $r['created_at']=$now; $r['updated_at']=$now;
                $wpdb->insert($workspaces,$r);
            }
        }
        $coa = self::table('chart_accounts');
        if (!(int)$wpdb->get_var("SELECT COUNT(*) FROM {$coa}")) {
            $accounts = [
                ['1000','Cash','asset','debit'],['1100','Accounts Receivable','asset','debit'],['1500','Fixed Assets','asset','debit'],['1510','Accumulated Depreciation','contra_asset','credit'],
                ['2000','Accounts Payable','liability','credit'],['2100','Payroll Liability','liability','credit'],['3000','Equity','equity','credit'],
                ['4000','Revenue','revenue','credit'],['5000','Cost of Services','expense','debit'],['5100','Payroll Expense','expense','debit'],['5200','Depreciation Expense','expense','debit']
            ];
            foreach ($accounts as $a) {
                $wpdb->insert($coa, ['account_code'=>$a[0],'account_name'=>$a[1],'account_type'=>$a[2],'normal_balance'=>$a[3],'is_active'=>1,'created_at'=>$now,'updated_at'=>$now]);
            }
        }
    }
}
