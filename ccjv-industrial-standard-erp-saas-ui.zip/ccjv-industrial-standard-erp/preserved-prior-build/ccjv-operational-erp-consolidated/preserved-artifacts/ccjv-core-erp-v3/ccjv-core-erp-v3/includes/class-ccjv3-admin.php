<?php
if (!defined('ABSPATH')) { exit; }
class CCJV3_Admin {
    public static function init(): void {
        add_action('admin_menu', [__CLASS__, 'menu']);
        add_action('admin_enqueue_scripts', [__CLASS__, 'assets']);
    }
    public static function assets(): void {
        wp_enqueue_style('ccjv3-admin', CCJV3_URL . 'assets/css/admin.css', [], CCJV3_VERSION);
    }
    public static function menu(): void {
        add_menu_page('CCJV ERP','CCJV ERP','manage_options','ccjv3-dashboard',[__CLASS__,'dashboard'],'dashicons-chart-area',3);
        $pages = [
            'dashboard'=>'Dashboard','settings'=>'Settings','workspaces'=>'Workspaces','permissions'=>'Permissions','ventures'=>'Ventures','crm'=>'CRM','hrm'=>'HRM','coa'=>'Chart of Accounts','invoices'=>'Invoices','payroll'=>'Payroll','projects'=>'Projects','tasks'=>'Project Tasks','assets'=>'Assets','journals'=>'Journals'
        ];
        foreach ($pages as $slug=>$label) {
            if ($slug === 'dashboard') { add_submenu_page('ccjv3-dashboard','Dashboard','Dashboard','manage_options','ccjv3-dashboard',[__CLASS__,'dashboard']); }
            else add_submenu_page('ccjv3-dashboard',$label,$label,'manage_options','ccjv3-'.$slug,[__CLASS__,'router']);
        }
    }
    public static function router(): void {
        $page = sanitize_key(wp_unslash($_GET['page'] ?? 'ccjv3-dashboard'));
        $module = str_replace('ccjv3-','',$page);
        if ($module === 'settings') self::settings();
        elseif ($module === 'journals') self::journals();
        else self::module_page($module);
    }
    public static function dashboard(): void {
        $counts = CCJV3_Modules::counts(); $ledger = CCJV3_Accounting::totals();
        echo '<div class="wrap ccjv3-wrap"><h1>CCJV ERP V3</h1>';
        self::notice();
        echo '<div class="ccjv3-kpis">';
        foreach (['workspaces','ventures','crm','hrm','invoices','projects','assets','journals'] as $k) {
            echo '<div class="ccjv3-card"><label>'.esc_html(ucwords(str_replace('_',' ',$k))).'</label><strong>'.esc_html((string)($counts[$k] ?? 0)).'</strong></div>';
        }
        echo '</div>';
        echo '<div class="ccjv3-card"><h2>Accounting Snapshot</h2><p><strong>Debits:</strong> '.esc_html(number_format_i18n($ledger['debit'] ?? 0,2)).' &nbsp; <strong>Credits:</strong> '.esc_html(number_format_i18n($ledger['credit'] ?? 0,2)).'</p><p>Use the front-end shell with shortcode <code>[ccjv3_shell]</code>.</p></div>';
        echo '</div>';
    }
    public static function settings(): void {
        if (!empty($_POST['ccjv3_save_settings']) && check_admin_referer('ccjv3_save_settings')) {
            update_option('ccjv3_logo_url', esc_url_raw(wp_unslash($_POST['logo_url'] ?? '')));
            update_option('ccjv3_primary_color', sanitize_text_field(wp_unslash($_POST['primary_color'] ?? '#1d4ed8')));
            update_option('ccjv3_buy_token_url', esc_url_raw(wp_unslash($_POST['buy_token_url'] ?? '')));
            update_option('ccjv3_rpc_url', esc_url_raw(wp_unslash($_POST['rpc_url'] ?? 'https://api.avax.network/ext/bc/C/rpc')));
            echo '<div class="notice notice-success"><p>Settings saved.</p></div>';
        }
        echo '<div class="wrap ccjv3-wrap"><h1>Settings</h1><div class="ccjv3-card"><form method="post">'; wp_nonce_field('ccjv3_save_settings');
        echo '<table class="form-table">';
        $fields = [
            'logo_url'=>'Logo URL','primary_color'=>'Primary Color','buy_token_url'=>'Buy Token URL','rpc_url'=>'Avalanche RPC URL'
        ];
        foreach ($fields as $field=>$label) {
            $type = in_array($field,['logo_url','buy_token_url','rpc_url'],true) ? 'url' : 'text';
            $default = $field==='logo_url' ? 'http://ccjv.ca/wp-content/uploads/2024/04/ccjv-logo.jpeg' : ($field==='primary_color' ? '#1d4ed8' : ($field==='rpc_url' ? 'https://api.avax.network/ext/bc/C/rpc' : ''));
            echo '<tr><th>'.esc_html($label).'</th><td><input type="'.$type.'" class="regular-text" name="'.esc_attr($field).'" value="'.esc_attr(get_option('ccjv3_'.$field, $default)).'"></td></tr>';
        }
        echo '</table><p><button class="button button-primary" name="ccjv3_save_settings" value="1">Save</button></p></form></div></div>';
    }
    public static function journals(): void {
        global $wpdb;
        $headers = $wpdb->get_results("SELECT * FROM " . CCJV3_DB::table('journal_headers') . " ORDER BY id DESC LIMIT 100", ARRAY_A) ?: [];
        echo '<div class="wrap ccjv3-wrap"><h1>Journals</h1>'; self::notice();
        echo '<div class="ccjv3-card"><table class="widefat striped"><thead><tr><th>ID</th><th>Journal No</th><th>Date</th><th>Source</th><th>Source ID</th><th>Memo</th></tr></thead><tbody>';
        if (!$headers) echo '<tr><td colspan="6">No journals yet.</td></tr>';
        foreach ($headers as $h) echo '<tr><td>'.esc_html($h['id']).'</td><td>'.esc_html($h['journal_no']).'</td><td>'.esc_html($h['entry_date']).'</td><td>'.esc_html($h['source_type']).'</td><td>'.esc_html($h['source_id']).'</td><td>'.esc_html($h['memo']).'</td></tr>';
        echo '</tbody></table></div></div>';
    }
    private static function module_page(string $module): void {
        $cfg = CCJV3_Modules::configs()[$module] ?? null; if (!$cfg) { echo '<div class="wrap"><p>Module not found.</p></div>'; return; }
        $record = isset($_GET['edit']) ? CCJV3_Modules::get_record($module, absint($_GET['edit'])) : null;
        $records = CCJV3_Modules::get_records($module, 100);
        echo '<div class="wrap ccjv3-wrap"><h1>'.esc_html($cfg['title']).'</h1>'; self::notice();
        echo '<div class="ccjv3-grid">';
        echo '<div class="ccjv3-card"><h2>'.($record ? 'Edit' : 'Add').' Record</h2><form method="post" action="'.esc_url(admin_url('admin-post.php')).'">'; wp_nonce_field('ccjv3_save_record');
        echo '<input type="hidden" name="action" value="ccjv3_save_record"><input type="hidden" name="module" value="'.esc_attr($module).'"><input type="hidden" name="record_id" value="'.esc_attr($record['id'] ?? 0).'">';
        echo '<div class="ccjv3-form-grid">'; self::render_fields($module, $cfg, $record); echo '</div><p><button class="button button-primary">Save</button></p></form>';
        if ($module === 'invoices') self::invoice_extra($record);
        if ($module === 'payroll') self::payroll_runner();
        if ($module === 'assets') self::depreciation_runner();
        echo '</div>';
        echo '<div class="ccjv3-card"><h2>Records</h2><div class="ccjv3-table-wrap"><table class="widefat striped"><thead><tr>';
        $headers = $records ? array_keys(array_diff_key($records[0], array_flip(['notes','description']))) : ['id'];
        foreach ($headers as $h) echo '<th>'.esc_html(ucwords(str_replace('_',' ',$h))).'</th>';
        echo '<th>Actions</th></tr></thead><tbody>';
        if (!$records) echo '<tr><td colspan="20">No records yet.</td></tr>';
        foreach ($records as $row) {
            echo '<tr>'; foreach ($row as $k=>$v) { if (in_array($k,['notes','description'],true)) continue; echo '<td>'.esc_html((string)$v).'</td>'; }
            echo '<td><a class="button button-small" href="'.esc_url(add_query_arg(['page'=>'ccjv3-'.$module,'edit'=>$row['id']], admin_url('admin.php'))).'">Edit</a> <a class="button button-small" href="'.esc_url(wp_nonce_url(add_query_arg(['action'=>'ccjv3_delete_record','module'=>$module,'record_id'=>$row['id']], admin_url('admin-post.php')), 'ccjv3_delete_' . $module . '_' . $row['id'])).'" onclick="return confirm(\'Delete record?\');">Delete</a></td></tr>';
        }
        echo '</tbody></table></div></div></div></div>';
    }
    private static function render_fields(string $module, array $cfg, ?array $record): void {
        $workspace_options = CCJV3_Modules::select_options(CCJV3_DB::table('workspaces'), 'id', 'name');
        $venture_options = CCJV3_Modules::select_options(CCJV3_DB::table('ventures'), 'id', 'venture_name');
        $employee_options = CCJV3_Modules::select_options(CCJV3_DB::table('hrm_employees'), 'id', 'first_name');
        $project_options = CCJV3_Modules::select_options(CCJV3_DB::table('projects'), 'id', 'project_name');
        foreach ($cfg['fields'] as $field) {
            $value = $record[$field] ?? '';
            echo '<p><label><strong>'.esc_html(ucwords(str_replace('_',' ',$field))).'</strong></label>';
            if (in_array($field, ['description','notes'], true)) echo '<textarea name="'.esc_attr($field).'" rows="3">'.esc_textarea((string)$value).'</textarea>';
            elseif (in_array($field, $cfg['date_fields'], true)) echo '<input type="date" name="'.esc_attr($field).'" value="'.esc_attr((string)$value).'">';
            elseif (in_array($field, ['workspace_id','venture_id','employee_id','project_id'], true)) {
                $opts = $field==='workspace_id' ? $workspace_options : ($field==='venture_id' ? $venture_options : ($field==='employee_id' ? $employee_options : $project_options));
                echo '<select name="'.esc_attr($field).'"><option value="0">Select</option>';
                foreach ($opts as $id=>$label) echo '<option value="'.esc_attr((string)$id).'" '.selected((string)$value,(string)$id,false).'>'.esc_html($label.' (#'.$id.')').'</option>';
                echo '</select>';
            } elseif ($field === 'manual_override' || $field === 'is_active') {
                echo '<select name="'.esc_attr($field).'"><option value="1" '.selected((string)$value,'1',false).'>Yes</option><option value="0" '.selected((string)$value,'0',false).'>No</option></select>';
            } elseif (in_array($field, ['status','account_type','normal_balance','stage','depreciation_method','role_key','stage_lane'], true)) {
                $choices = [
                    'status'=>['lead','active','inactive','draft','posted','partially_paid','paid','planning','in_progress','completed','not_started'],
                    'account_type'=>['asset','contra_asset','liability','equity','revenue','expense'],
                    'normal_balance'=>['debit','credit'],
                    'stage'=>['planning','active','on_hold','completed'],
                    'depreciation_method'=>['straight_line'],
                    'role_key'=>['viewer','operator','manager'],
                    'stage_lane'=>['backlog','doing','review','done'],
                ][$field] ?? [];
                echo '<select name="'.esc_attr($field).'">'; foreach ($choices as $ch) echo '<option value="'.esc_attr($ch).'" '.selected((string)$value,$ch,false).'>'.esc_html(ucwords(str_replace('_',' ',$ch))).'</option>'; echo '</select>';
            } elseif (in_array($field, $cfg['numeric_fields'], true)) echo '<input type="number" step="0.01" name="'.esc_attr($field).'" value="'.esc_attr((string)$value).'">';
            else echo '<input type="text" name="'.esc_attr($field).'" value="'.esc_attr((string)$value).'">';
            echo '</p>';
        }
    }
    private static function invoice_extra(?array $record): void {
        if (!$record || empty($record['id'])) return;
        global $wpdb; $invoice_id = (int)$record['id'];
        $lines = $wpdb->get_results($wpdb->prepare("SELECT * FROM " . CCJV3_DB::table('invoice_lines') . " WHERE invoice_id=%d ORDER BY line_no ASC", $invoice_id), ARRAY_A) ?: [];
        $payments = $wpdb->get_results($wpdb->prepare("SELECT * FROM " . CCJV3_DB::table('invoice_payments') . " WHERE invoice_id=%d ORDER BY id DESC", $invoice_id), ARRAY_A) ?: [];
        echo '<hr><h2>Invoice Lines</h2><form method="post" action="'.esc_url(admin_url('admin-post.php')).'">'; wp_nonce_field('ccjv3_add_invoice_line');
        echo '<input type="hidden" name="action" value="ccjv3_add_invoice_line"><input type="hidden" name="invoice_id" value="'.esc_attr((string)$invoice_id).'">';
        echo '<p><label>Line No</label><input type="number" name="line_no" value="'.esc_attr((string)(count($lines)+1)).'"></p><p><label>Description</label><input type="text" name="description"></p><p><label>Qty</label><input type="number" step="0.0001" name="quantity" value="1"></p><p><label>Unit Price</label><input type="number" step="0.0001" name="unit_price" value="0"></p><p><button class="button">Add Line</button></p></form>';
        echo '<table class="widefat striped"><thead><tr><th>#</th><th>Description</th><th>Qty</th><th>Price</th><th>Total</th></tr></thead><tbody>'; if(!$lines) echo '<tr><td colspan="5">No lines yet.</td></tr>'; foreach($lines as $l) echo '<tr><td>'.esc_html($l['line_no']).'</td><td>'.esc_html($l['description']).'</td><td>'.esc_html($l['quantity']).'</td><td>'.esc_html($l['unit_price']).'</td><td>'.esc_html($l['line_total']).'</td></tr>'; echo '</tbody></table>';
        echo '<hr><h2>Payments</h2><form method="post" action="'.esc_url(admin_url('admin-post.php')).'">'; wp_nonce_field('ccjv3_add_invoice_payment');
        echo '<input type="hidden" name="action" value="ccjv3_add_invoice_payment"><input type="hidden" name="invoice_id" value="'.esc_attr((string)$invoice_id).'">';
        echo '<p><label>Payment Date</label><input type="date" name="payment_date" value="'.esc_attr(current_time('Y-m-d')).'"></p><p><label>Method</label><input type="text" name="payment_method" value="bank"></p><p><label>Amount</label><input type="number" step="0.01" name="amount"></p><p><label>Reference</label><input type="text" name="reference_no"></p><p><button class="button">Add Payment</button></p></form>';
        echo '<table class="widefat striped"><thead><tr><th>Date</th><th>Method</th><th>Amount</th><th>Reference</th></tr></thead><tbody>'; if(!$payments) echo '<tr><td colspan="4">No payments yet.</td></tr>'; foreach($payments as $p) echo '<tr><td>'.esc_html($p['payment_date']).'</td><td>'.esc_html($p['payment_method']).'</td><td>'.esc_html($p['amount']).'</td><td>'.esc_html($p['reference_no']).'</td></tr>'; echo '</tbody></table>';
        echo '<hr><h2>Post Invoice</h2><form method="post" action="'.esc_url(admin_url('admin-post.php')).'">'; wp_nonce_field('ccjv3_post_invoice'); echo '<input type="hidden" name="action" value="ccjv3_post_invoice"><input type="hidden" name="invoice_id" value="'.esc_attr((string)$invoice_id).'"><p><button class="button button-primary">Post Invoice to Journals</button></p></form>';
    }
    private static function payroll_runner(): void {
        $employees = CCJV3_Modules::get_records('hrm', 200); echo '<hr><h2>Quick Payroll Runner</h2><form method="post" action="'.esc_url(admin_url('admin-post.php')).'">'; wp_nonce_field('ccjv3_run_payroll');
        echo '<input type="hidden" name="action" value="ccjv3_run_payroll"><p><label>Employee</label><select name="employee_id">'; foreach($employees as $e) echo '<option value="'.esc_attr($e['id']).'">'.esc_html($e['first_name'].' '.$e['last_name']).'</option>'; echo '</select></p><p><label>Regular Hours</label><input type="number" step="0.01" name="regular_hours" value="80"></p><p><label>Overtime Hours</label><input type="number" step="0.01" name="overtime_hours" value="0"></p><p><label>Period Start</label><input type="date" name="pay_period_start" value="'.esc_attr(current_time('Y-m-01')).'"></p><p><label>Period End</label><input type="date" name="pay_period_end" value="'.esc_attr(current_time('Y-m-t')).'"></p><p><label>Pay Date</label><input type="date" name="pay_date" value="'.esc_attr(current_time('Y-m-d')).'"></p><p><button class="button">Run Payroll</button></p></form>';
    }
    private static function depreciation_runner(): void {
        $assets = CCJV3_Modules::get_records('assets', 200); echo '<hr><h2>Run Depreciation</h2><form method="post" action="'.esc_url(admin_url('admin-post.php')).'">'; wp_nonce_field('ccjv3_run_depreciation');
        echo '<input type="hidden" name="action" value="ccjv3_run_depreciation"><p><label>Asset</label><select name="asset_id">'; foreach($assets as $a) echo '<option value="'.esc_attr($a['id']).'">'.esc_html($a['asset_name']).'</option>'; echo '</select></p><p><button class="button">Run Depreciation</button></p></form>';
    }
    private static function notice(): void {
        if (!empty($_GET['ccjv3_notice'])) echo '<div class="notice notice-success"><p>'.esc_html(sanitize_text_field(wp_unslash($_GET['ccjv3_notice']))).'</p></div>';
    }
}
