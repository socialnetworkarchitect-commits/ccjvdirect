<?php
if (!defined('ABSPATH')) { exit; }
class CCJV3_Accounting {
    public static function next_journal_no(): string {
        global $wpdb;
        $table = CCJV3_DB::table('journal_headers');
        $count = (int)$wpdb->get_var("SELECT COUNT(*) FROM {$table}") + 1;
        return 'JRN-' . str_pad((string)$count, 6, '0', STR_PAD_LEFT);
    }
    public static function post_journal(array $header, array $lines) {
        $debits = 0.0; $credits = 0.0;
        foreach ($lines as $line) {
            $amt = (float)$line['amount'];
            if ($line['entry_type'] === 'debit') { $debits += $amt; } else { $credits += $amt; }
        }
        if (round($debits,2) !== round($credits,2)) {
            return new WP_Error('ccjv3_unbalanced', 'Journal is not balanced. Debits and credits must match.');
        }
        global $wpdb;
        $now = current_time('mysql');
        $header_table = CCJV3_DB::table('journal_headers');
        $line_table = CCJV3_DB::table('journal_lines');
        $journal_no = !empty($header['journal_no']) ? sanitize_text_field($header['journal_no']) : self::next_journal_no();
        $wpdb->insert($header_table, [
            'workspace_id' => absint($header['workspace_id'] ?? 0),
            'venture_id' => absint($header['venture_id'] ?? 0),
            'journal_no' => $journal_no,
            'entry_date' => sanitize_text_field($header['entry_date'] ?? current_time('Y-m-d')),
            'source_type' => sanitize_text_field($header['source_type'] ?? ''),
            'source_id' => absint($header['source_id'] ?? 0),
            'memo' => sanitize_textarea_field($header['memo'] ?? ''),
            'status' => 'posted',
            'created_by' => get_current_user_id(),
            'created_at' => $now,
            'updated_at' => $now,
        ]);
        $journal_id = (int)$wpdb->insert_id;
        foreach ($lines as $line) {
            $wpdb->insert($line_table, [
                'journal_id' => $journal_id,
                'account_code' => sanitize_text_field($line['account_code']),
                'account_name' => sanitize_text_field($line['account_name']),
                'entry_type' => sanitize_text_field($line['entry_type']),
                'amount' => (float)$line['amount'],
                'line_memo' => sanitize_text_field($line['line_memo'] ?? ''),
                'created_at' => $now,
                'updated_at' => $now,
            ]);
        }
        return $journal_id;
    }
    public static function account_name(string $code): string {
        global $wpdb;
        $table = CCJV3_DB::table('chart_accounts');
        $name = $wpdb->get_var($wpdb->prepare("SELECT account_name FROM {$table} WHERE account_code=%s LIMIT 1", $code));
        return $name ? (string)$name : $code;
    }
    public static function totals(): array {
        global $wpdb;
        $table = CCJV3_DB::table('journal_lines');
        $rows = $wpdb->get_results("SELECT entry_type, SUM(amount) total FROM {$table} GROUP BY entry_type", ARRAY_A) ?: [];
        $out = ['debit'=>0.0,'credit'=>0.0];
        foreach ($rows as $r) { $out[$r['entry_type']] = (float)$r['total']; }
        return $out;
    }
    public static function post_invoice(int $invoice_id) {
        global $wpdb;
        $table = CCJV3_DB::table('invoices');
        $invoice = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table} WHERE id=%d", $invoice_id), ARRAY_A);
        if (!$invoice) return new WP_Error('ccjv3_missing_invoice', 'Invoice not found');
        if ($invoice['status'] === 'posted' || $invoice['status'] === 'partially_paid' || $invoice['status'] === 'paid') {
            return new WP_Error('ccjv3_invoice_posted', 'Invoice already posted');
        }
        $journal = self::post_journal([
            'workspace_id' => $invoice['workspace_id'], 'venture_id' => $invoice['venture_id'], 'entry_date' => $invoice['issue_date'], 'source_type' => 'invoice', 'source_id' => $invoice_id,
            'memo' => 'Invoice ' . $invoice['invoice_no'] . ' posted'
        ], [
            ['account_code'=>'1100','account_name'=>self::account_name('1100'),'entry_type'=>'debit','amount'=>(float)$invoice['total'],'line_memo'=>'AR for invoice'],
            ['account_code'=>'4000','account_name'=>self::account_name('4000'),'entry_type'=>'credit','amount'=>(float)$invoice['subtotal'],'line_memo'=>'Revenue'],
            ((float)$invoice['tax'] > 0 ? ['account_code'=>'2000','account_name'=>self::account_name('2000'),'entry_type'=>'credit','amount'=>(float)$invoice['tax'],'line_memo'=>'Tax/Payable placeholder'] : null),
        ]);
        if (is_wp_error($journal)) return $journal;
        $status = ((float)$invoice['paid_amount'] > 0) ? 'partially_paid' : 'posted';
        $wpdb->update($table, ['status'=>$status,'updated_at'=>current_time('mysql')], ['id'=>$invoice_id]);
        return $journal;
    }
    public static function post_invoice_payment(int $payment_id) {
        global $wpdb;
        $payment = $wpdb->get_row($wpdb->prepare("SELECT p.*, i.workspace_id, i.venture_id, i.invoice_no, i.total, i.paid_amount FROM " . CCJV3_DB::table('invoice_payments') . " p INNER JOIN " . CCJV3_DB::table('invoices') . " i ON i.id = p.invoice_id WHERE p.id=%d", $payment_id), ARRAY_A);
        if (!$payment) return new WP_Error('ccjv3_missing_payment', 'Payment not found');
        $journal = self::post_journal([
            'workspace_id' => $payment['workspace_id'], 'venture_id' => $payment['venture_id'], 'entry_date' => $payment['payment_date'], 'source_type' => 'invoice_payment', 'source_id' => $payment_id,
            'memo' => 'Payment received for invoice ' . $payment['invoice_no']
        ], [
            ['account_code'=>'1000','account_name'=>self::account_name('1000'),'entry_type'=>'debit','amount'=>(float)$payment['amount'],'line_memo'=>'Cash received'],
            ['account_code'=>'1100','account_name'=>self::account_name('1100'),'entry_type'=>'credit','amount'=>(float)$payment['amount'],'line_memo'=>'Reduce AR'],
        ]);
        if (is_wp_error($journal)) return $journal;
        $invoice_table = CCJV3_DB::table('invoices');
        $invoice = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$invoice_table} WHERE id=%d", $payment['invoice_id']), ARRAY_A);
        if ($invoice) {
            $paid = (float)$invoice['paid_amount'] + (float)$payment['amount'];
            $status = $paid >= (float)$invoice['total'] ? 'paid' : 'partially_paid';
            $wpdb->update($invoice_table, ['paid_amount'=>$paid, 'status'=>$status, 'updated_at'=>current_time('mysql')], ['id'=>(int)$invoice['id']]);
        }
        return $journal;
    }
    public static function post_payroll(int $payroll_id) {
        global $wpdb;
        $table = CCJV3_DB::table('payroll_runs');
        $row = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table} WHERE id=%d", $payroll_id), ARRAY_A);
        if (!$row) return new WP_Error('ccjv3_missing_payroll', 'Payroll not found');
        return self::post_journal([
            'workspace_id'=>$row['workspace_id'],'venture_id'=>$row['venture_id'],'entry_date'=>$row['pay_date'],'source_type'=>'payroll','source_id'=>$payroll_id,
            'memo'=>'Payroll posted'
        ],[
            ['account_code'=>'5100','account_name'=>self::account_name('5100'),'entry_type'=>'debit','amount'=>(float)$row['gross_pay'],'line_memo'=>'Payroll expense'],
            ['account_code'=>'2100','account_name'=>self::account_name('2100'),'entry_type'=>'credit','amount'=>(float)$row['net_pay'],'line_memo'=>'Payroll liability'],
            ((float)$row['deductions']>0 ? ['account_code'=>'2100','account_name'=>self::account_name('2100'),'entry_type'=>'credit','amount'=>(float)$row['deductions'],'line_memo'=>'Deductions payable'] : null),
        ]);
    }
    public static function post_depreciation(int $asset_id, float $amount, string $run_date) {
        global $wpdb;
        $asset_table = CCJV3_DB::table('assets');
        $asset = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$asset_table} WHERE id=%d", $asset_id), ARRAY_A);
        if (!$asset) return new WP_Error('ccjv3_missing_asset', 'Asset not found');
        return self::post_journal([
            'workspace_id'=>$asset['workspace_id'],'venture_id'=>$asset['venture_id'],'entry_date'=>$run_date,'source_type'=>'depreciation','source_id'=>$asset_id,'memo'=>'Depreciation run for '.$asset['asset_name']
        ],[
            ['account_code'=>'5200','account_name'=>self::account_name('5200'),'entry_type'=>'debit','amount'=>$amount,'line_memo'=>'Depreciation expense'],
            ['account_code'=>'1510','account_name'=>self::account_name('1510'),'entry_type'=>'credit','amount'=>$amount,'line_memo'=>'Accumulated depreciation'],
        ]);
    }
}
