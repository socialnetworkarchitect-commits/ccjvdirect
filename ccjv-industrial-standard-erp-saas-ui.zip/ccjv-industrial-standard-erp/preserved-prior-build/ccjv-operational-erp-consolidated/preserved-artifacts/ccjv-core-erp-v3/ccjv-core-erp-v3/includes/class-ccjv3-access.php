<?php
if (!defined('ABSPATH')) { exit; }
class CCJV3_Access {
    public static function current_wallet(?int $user_id = null): ?array {
        if (!$user_id) { $user_id = get_current_user_id(); }
        if (!$user_id) { return null; }
        global $wpdb;
        $table = CCJV3_DB::table('wallets');
        $row = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table} WHERE user_id=%d ORDER BY id DESC LIMIT 1", $user_id), ARRAY_A);
        return $row ?: null;
    }
    public static function wallet_balances(?array $wallet = null): array {
        $wallet = $wallet ?: self::current_wallet();
        if (!$wallet || empty($wallet['token_balances'])) { return []; }
        $data = json_decode((string)$wallet['token_balances'], true);
        return is_array($data) ? $data : [];
    }
    public static function user_workspace_permission(int $user_id, int $workspace_id): ?array {
        global $wpdb;
        $table = CCJV3_DB::table('workspace_permissions');
        $row = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table} WHERE user_id=%d AND workspace_id=%d", $user_id, $workspace_id), ARRAY_A);
        return $row ?: null;
    }
    public static function workspace_access($workspace, int $user_id = 0): array {
        global $wpdb;
        if (!is_array($workspace)) {
            $workspace = $wpdb->get_row($wpdb->prepare("SELECT * FROM " . CCJV3_DB::table('workspaces') . " WHERE id=%d", (int)$workspace), ARRAY_A);
        }
        if (!$workspace) { return ['allowed'=>false, 'reason'=>'Workspace not found']; }
        $user_id = $user_id ?: get_current_user_id();
        if (current_user_can('manage_options')) { return ['allowed'=>true, 'reason'=>'Administrator', 'role'=>'admin']; }
        if (!$user_id) { return ['allowed'=>false, 'reason'=>'Login required']; }
        $perm = self::user_workspace_permission($user_id, (int)$workspace['id']);
        if ($perm && (int)$perm['manual_override'] === 1) {
            return ['allowed'=>true, 'reason'=>'Manual override', 'role'=>$perm['role_key'], 'front_modules'=>self::permission_modules($perm, $workspace)];
        }
        $balances = self::wallet_balances(self::current_wallet($user_id));
        $symbol = strtoupper((string)$workspace['token_symbol']);
        $need = (float)$workspace['token_threshold'];
        $have = isset($balances[$symbol]) ? (float)$balances[$symbol] : 0.0;
        if ($need <= 0 || $have >= $need) {
            return ['allowed'=>true, 'reason'=>'Token threshold met', 'role'=>$perm['role_key'] ?? 'viewer', 'have'=>$have, 'need'=>$need, 'front_modules'=>self::permission_modules($perm, $workspace)];
        }
        return ['allowed'=>false, 'reason'=>'Insufficient token balance', 'have'=>$have, 'need'=>$need, 'symbol'=>$symbol];
    }
    public static function permission_modules(?array $perm, array $workspace): array {
        $defaults = array_filter(array_map('trim', explode(',', (string)$workspace['allowed_modules'])));
        if (!$perm || empty($perm['front_modules'])) { return $defaults; }
        return array_filter(array_map('trim', explode(',', (string)$perm['front_modules'])));
    }
    public static function module_allowed(string $module, array $access): bool {
        if (!empty($access['role']) && $access['role'] === 'admin') return true;
        $mods = $access['front_modules'] ?? [];
        return in_array($module, $mods, true);
    }
    public static function sync_wallet(int $user_id, string $wallet_address, array $balances, string $chain_name = 'Avalanche', string $chain_id = '0xa86a'): bool {
        global $wpdb;
        $table = CCJV3_DB::table('wallets');
        $now = current_time('mysql');
        $data = [
            'wallet_address' => sanitize_text_field($wallet_address),
            'chain_name' => sanitize_text_field($chain_name),
            'chain_id' => sanitize_text_field($chain_id),
            'status' => 'connected',
            'token_balances' => wp_json_encode($balances),
            'last_verified_at' => $now,
            'verification_source' => 'metamask',
            'updated_at' => $now,
        ];
        $existing = $wpdb->get_row($wpdb->prepare("SELECT id FROM {$table} WHERE user_id=%d ORDER BY id DESC LIMIT 1", $user_id), ARRAY_A);
        if ($existing) {
            return false !== $wpdb->update($table, $data, ['id'=>(int)$existing['id']]);
        }
        $data['user_id'] = $user_id;
        $data['created_at'] = $now;
        return false !== $wpdb->insert($table, $data);
    }
}
