<?php
if (!defined('ABSPATH')) { exit; }
class CCJV3_Roles {
    public static function init(): void {}
    public static function activate(): void {
        add_role('ccjv_workspace_manager', 'CCJV Workspace Manager', ['read'=>true, 'upload_files'=>true]);
        add_role('ccjv_workspace_user', 'CCJV Workspace User', ['read'=>true]);
    }
    public static function deactivate(): void {}
}
