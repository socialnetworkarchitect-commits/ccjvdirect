<?php
if (!defined('ABSPATH')) { exit; }
class CCJV3_Frontend {
    public static function init(): void {
        add_shortcode('ccjv3_shell', [__CLASS__, 'shell']);
        add_shortcode('ccjv3_workspace_launcher', [__CLASS__, 'launcher']);
        add_action('wp_enqueue_scripts', [__CLASS__, 'assets']);
    }
    public static function assets(): void {
        wp_register_style('ccjv3-frontend', CCJV3_URL . 'assets/css/frontend.css', [], CCJV3_VERSION);
        wp_register_script('ccjv3-frontend', CCJV3_URL . 'assets/js/frontend.js', [], CCJV3_VERSION, true);
        wp_localize_script('ccjv3-frontend', 'CCJV3Data', [
            'ajaxUrl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('ccjv3_wallet_nonce'),
            'chainHex' => '0xa86a',
            'chainName' => 'Avalanche C-Chain',
            'nativeCurrency' => ['name'=>'Avalanche','symbol'=>'AVAX','decimals'=>18],
            'rpcUrls' => [get_option('ccjv3_rpc_url', 'https://api.avax.network/ext/bc/C/rpc')],
            'blockExplorerUrls' => ['https://snowtrace.io'],
            'isLoggedIn' => is_user_logged_in(),
            'workspaceTokens' => self::workspace_tokens(),
        ]);
    }
    public static function workspace_tokens(): array {
        global $wpdb; $rows = $wpdb->get_results("SELECT slug, token_symbol, token_contract, token_decimals FROM " . CCJV3_DB::table('workspaces') . " WHERE is_active=1", ARRAY_A) ?: [];
        $out = [];
        foreach ($rows as $r) { $out[] = ['slug'=>$r['slug'],'symbol'=>strtoupper((string)$r['token_symbol']),'contract'=>$r['token_contract'],'decimals'=>(int)$r['token_decimals']]; }
        return $out;
    }
    public static function launcher(): string {
        wp_enqueue_style('ccjv3-frontend'); wp_enqueue_script('ccjv3-frontend');
        return self::workspace_grid();
    }
    public static function shell(): string {
        wp_enqueue_style('ccjv3-frontend'); wp_enqueue_script('ccjv3-frontend');
        $workspace_slug = sanitize_key(wp_unslash($_GET['ccjv_workspace'] ?? ''));
        $view = sanitize_key(wp_unslash($_GET['ccjv_view'] ?? 'overview'));
        $logo = get_option('ccjv3_logo_url', 'http://ccjv.ca/wp-content/uploads/2024/04/ccjv-logo.jpeg');
        ob_start();
        echo '<div class="ccjv3-shell">';
        echo '<aside class="ccjv3-sidebar"><div class="ccjv3-brand">';
        if ($logo) echo '<img src="'.esc_url($logo).'" alt="CCJV">';
        echo '<div><strong>CCJV ERP</strong><span>Enterprise Shell</span></div></div>';
        echo '<nav><a href="'.esc_url(remove_query_arg(['ccjv_workspace','ccjv_view'])).'">Home</a>';
        if ($workspace_slug) {
            $base = add_query_arg(['ccjv_workspace'=>$workspace_slug], get_permalink());
            foreach (['overview'=>'Overview','crm'=>'CRM','hrm'=>'HRM','accounting'=>'Accounting','invoices'=>'Invoices','projects'=>'Projects','assets'=>'Assets'] as $k=>$label) {
                echo '<a href="'.esc_url(add_query_arg(['ccjv_workspace'=>$workspace_slug,'ccjv_view'=>$k], get_permalink())).'">'.esc_html($label).'</a>';
            }
        } else {
            echo '<a href="#workspaces">Workspaces</a><a href="#wallet">Wallet</a>';
        }
        echo '</nav></aside><main class="ccjv3-main">';
        echo '<header class="ccjv3-header"><div><h2>'.esc_html($workspace_slug ? ucfirst($workspace_slug) : 'Master Dashboard').'</h2><p>'.esc_html($workspace_slug ? 'Workspace routing and gated module access.' : 'Choose a workspace and connect your wallet.').'</p></div><div class="ccjv3-header-actions"><button type="button" class="ccjv3-connect-wallet">Connect MetaMask</button></div></header>';
        echo '<section id="wallet" class="ccjv3-panel ccjv3-wallet-panel"><h3>Wallet</h3><div class="ccjv3-wallet-status">'.self::wallet_status().'</div><div class="ccjv3-wallet-results"></div></section>';
        if (!$workspace_slug) {
            echo '<section class="ccjv3-panel"><h3>Workspace Launcher</h3>'.self::workspace_grid().'</section>';
            echo '<section class="ccjv3-panel"><h3>Master Summary</h3>'.self::master_summary().'</section>';
        } else {
            echo self::workspace_view($workspace_slug, $view);
        }
        echo '</main></div>';
        return ob_get_clean();
    }
    public static function wallet_status(): string {
        if (!is_user_logged_in()) return '<p>Please log in to save wallet access and token balances.</p>';
        $wallet = CCJV3_Access::current_wallet();
        if (!$wallet) return '<p>No wallet synchronized yet.</p>';
        $balances = CCJV3_Access::wallet_balances($wallet); $parts = [];
        foreach ($balances as $sym=>$bal) $parts[] = esc_html($sym . ': ' . $bal);
        return '<p><strong>Wallet:</strong> '.esc_html($wallet['wallet_address']).'</p><p><strong>Balances:</strong> '.(!empty($parts) ? implode(' | ', $parts) : 'None').'</p>';
    }
    public static function workspace_grid(): string {
        global $wpdb; $rows = $wpdb->get_results("SELECT * FROM " . CCJV3_DB::table('workspaces') . " WHERE is_active=1 ORDER BY name ASC", ARRAY_A) ?: [];
        ob_start(); echo '<div id="workspaces" class="ccjv3-workspace-grid">';
        foreach ($rows as $w) {
            $access = CCJV3_Access::workspace_access($w);
            $url = add_query_arg(['ccjv_workspace'=>$w['slug'],'ccjv_view'=>'overview'], get_permalink());
            echo '<article class="ccjv3-workspace-card" style="--accent:'.esc_attr($w['accent_color']).';'.(!empty($w['hero_image']) ? '--hero:url(' . esc_url($w['hero_image']) . ');' : '').'">';
            echo '<div class="ccjv3-workspace-head"><strong>'.esc_html($w['name']).'</strong><span>'.esc_html($w['token_symbol']).'</span></div>';
            echo '<p>'.esc_html((string)$w['description']).'</p>';
            echo '<div class="ccjv3-mini">Threshold: '.esc_html((string)$w['token_threshold']).' '.esc_html($w['token_symbol']).'</div>';
            echo '<div class="ccjv3-mini">'.esc_html($access['reason']).'</div><div class="ccjv3-cta-row">';
            if (!empty($access['allowed'])) echo '<a class="buttonlike" href="'.esc_url($url).'">Enter Workspace</a>';
            else {
                $buy = get_option('ccjv3_buy_token_url', '');
                echo $buy ? '<a class="buttonlike alt" href="'.esc_url($buy).'">Buy Token</a>' : '<button type="button" class="buttonlike alt">Acquire Token</button>';
            }
            echo '</div></article>';
        }
        echo '</div>'; return ob_get_clean();
    }
    public static function master_summary(): string {
        $counts = CCJV3_Modules::counts(); $ledger = CCJV3_Accounting::totals();
        ob_start(); echo '<div class="ccjv3-kpis">';
        foreach (['ventures','crm','hrm','invoices','projects','assets','journals'] as $k) echo '<div class="ccjv3-kpi"><label>'.esc_html(ucwords($k)).'</label><strong>'.esc_html((string)($counts[$k] ?? 0)).'</strong></div>';
        echo '<div class="ccjv3-kpi"><label>Debits</label><strong>'.esc_html(number_format_i18n($ledger['debit'] ?? 0,2)).'</strong></div>';
        echo '<div class="ccjv3-kpi"><label>Credits</label><strong>'.esc_html(number_format_i18n($ledger['credit'] ?? 0,2)).'</strong></div>';
        echo '</div>'; return ob_get_clean();
    }
    public static function workspace_view(string $slug, string $view): string {
        global $wpdb;
        $workspace = $wpdb->get_row($wpdb->prepare("SELECT * FROM " . CCJV3_DB::table('workspaces') . " WHERE slug=%s LIMIT 1", $slug), ARRAY_A);
        if (!$workspace) return '<section class="ccjv3-panel"><p>Workspace not found.</p></section>';
        $access = CCJV3_Access::workspace_access($workspace);
        if (empty($access['allowed'])) return '<section class="ccjv3-panel"><h3>Access Required</h3><p>'.esc_html($access['reason']).'</p></section>';
        if (!CCJV3_Access::module_allowed($view, $access) && $view !== 'overview') return '<section class="ccjv3-panel"><p>That module is not enabled for your role in this workspace.</p></section>';
        $style = '--accent:' . esc_attr($workspace['accent_color']) . ';';
        $html = '<section class="ccjv3-panel ccjv3-brand-panel" style="'.$style.'"><h3>'.esc_html($workspace['dashboard_title'] ?: $workspace['name']).'</h3><p>'.esc_html($workspace['description']).'</p><div class="ccjv3-mini">Role: '.esc_html($access['role'] ?? 'viewer').'</div></section>';
        switch ($view) {
            case 'crm': $html .= self::records_table('crm', ['workspace_id' => (string)$workspace['id']]); break;
            case 'hrm': $html .= self::records_table('hrm', ['workspace_id' => (string)$workspace['id']]); break;
            case 'accounting': $html .= self::journal_summary((int)$workspace['id']); break;
            case 'invoices': $html .= self::invoice_summary((int)$workspace['id']); break;
            case 'projects': $html .= self::project_board((int)$workspace['id']); break;
            case 'assets': $html .= self::asset_summary((int)$workspace['id']); break;
            default: $html .= self::overview_blocks((int)$workspace['id']);
        }
        return $html;
    }
    public static function overview_blocks(int $workspace_id): string {
        global $wpdb;
        $counts = [
            'CRM' => (int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM " . CCJV3_DB::table('crm_contacts') . " WHERE workspace_id=%d", $workspace_id)),
            'Employees' => (int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM " . CCJV3_DB::table('hrm_employees') . " WHERE workspace_id=%d", $workspace_id)),
            'Invoices' => (int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM " . CCJV3_DB::table('invoices') . " WHERE workspace_id=%d", $workspace_id)),
            'Projects' => (int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM " . CCJV3_DB::table('projects') . " WHERE workspace_id=%d", $workspace_id)),
            'Assets' => (int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM " . CCJV3_DB::table('assets') . " WHERE workspace_id=%d", $workspace_id)),
        ];
        ob_start(); echo '<section class="ccjv3-panel"><div class="ccjv3-kpis">'; foreach($counts as $k=>$v) echo '<div class="ccjv3-kpi"><label>'.esc_html($k).'</label><strong>'.esc_html((string)$v).'</strong></div>'; echo '</div></section>'; return ob_get_clean();
    }
    public static function records_table(string $module, array $where): string {
        $rows = CCJV3_Modules::get_records($module, 100, $where); ob_start();
        echo '<section class="ccjv3-panel"><h3>'.esc_html(ucfirst($module)).'</h3><div class="ccjv3-table-wrap"><table><thead><tr>';
        if (!$rows) { echo '<th>No records yet.</th></tr></thead><tbody><tr><td>Add records in admin.</td></tr></tbody></table></div></section>'; return ob_get_clean(); }
        $keys = array_keys(array_diff_key($rows[0], array_flip(['notes','description','updated_at','created_at']))); foreach($keys as $k) echo '<th>'.esc_html(ucwords(str_replace('_',' ',$k))).'</th>'; echo '</tr></thead><tbody>';
        foreach($rows as $r){ echo '<tr>'; foreach($keys as $k) echo '<td>'.esc_html((string)$r[$k]).'</td>'; echo '</tr>'; }
        echo '</tbody></table></div></section>'; return ob_get_clean();
    }
    public static function journal_summary(int $workspace_id): string {
        global $wpdb; $rows = $wpdb->get_results($wpdb->prepare("SELECT h.journal_no, h.entry_date, h.source_type, SUM(CASE WHEN l.entry_type='debit' THEN l.amount ELSE 0 END) debits, SUM(CASE WHEN l.entry_type='credit' THEN l.amount ELSE 0 END) credits FROM " . CCJV3_DB::table('journal_headers') . " h INNER JOIN " . CCJV3_DB::table('journal_lines') . " l ON l.journal_id=h.id WHERE h.workspace_id=%d GROUP BY h.id ORDER BY h.id DESC LIMIT 50", $workspace_id), ARRAY_A) ?: [];
        ob_start(); echo '<section class="ccjv3-panel"><h3>Accounting</h3><div class="ccjv3-table-wrap"><table><thead><tr><th>Journal</th><th>Date</th><th>Source</th><th>Debits</th><th>Credits</th></tr></thead><tbody>'; if(!$rows) echo '<tr><td colspan="5">No journal entries yet.</td></tr>'; foreach($rows as $r) echo '<tr><td>'.esc_html($r['journal_no']).'</td><td>'.esc_html($r['entry_date']).'</td><td>'.esc_html($r['source_type']).'</td><td>'.esc_html(number_format_i18n((float)$r['debits'],2)).'</td><td>'.esc_html(number_format_i18n((float)$r['credits'],2)).'</td></tr>'; echo '</tbody></table></div></section>'; return ob_get_clean();
    }
    public static function invoice_summary(int $workspace_id): string {
        global $wpdb; $rows = $wpdb->get_results($wpdb->prepare("SELECT invoice_no, client_name, issue_date, due_date, status, total, paid_amount FROM " . CCJV3_DB::table('invoices') . " WHERE workspace_id=%d ORDER BY id DESC LIMIT 50", $workspace_id), ARRAY_A) ?: [];
        ob_start(); echo '<section class="ccjv3-panel"><h3>Invoices</h3><div class="ccjv3-table-wrap"><table><thead><tr><th>Invoice</th><th>Client</th><th>Issue</th><th>Due</th><th>Status</th><th>Total</th><th>Paid</th></tr></thead><tbody>'; if(!$rows) echo '<tr><td colspan="7">No invoices yet.</td></tr>'; foreach($rows as $r) echo '<tr><td>'.esc_html($r['invoice_no']).'</td><td>'.esc_html($r['client_name']).'</td><td>'.esc_html($r['issue_date']).'</td><td>'.esc_html($r['due_date']).'</td><td>'.esc_html($r['status']).'</td><td>'.esc_html(number_format_i18n((float)$r['total'],2)).'</td><td>'.esc_html(number_format_i18n((float)$r['paid_amount'],2)).'</td></tr>'; echo '</tbody></table></div></section>'; return ob_get_clean();
    }
    public static function project_board(int $workspace_id): string {
        global $wpdb; $projects = $wpdb->get_results($wpdb->prepare("SELECT id, project_name, stage, progress_percent, start_date, end_date FROM " . CCJV3_DB::table('projects') . " WHERE workspace_id=%d ORDER BY id DESC LIMIT 20", $workspace_id), ARRAY_A) ?: [];
        $tasks = $wpdb->get_results($wpdb->prepare("SELECT t.*, p.project_name FROM " . CCJV3_DB::table('project_tasks') . " t INNER JOIN " . CCJV3_DB::table('projects') . " p ON p.id=t.project_id WHERE p.workspace_id=%d ORDER BY t.sort_order ASC, t.id DESC LIMIT 200", $workspace_id), ARRAY_A) ?: [];
        $lanes = ['backlog'=>'Backlog','doing'=>'Doing','review'=>'Review','done'=>'Done'];
        ob_start();
        echo '<section class="ccjv3-panel"><h3>Projects</h3><div class="ccjv3-table-wrap"><table><thead><tr><th>Project</th><th>Stage</th><th>Progress</th><th>Start</th><th>End</th></tr></thead><tbody>'; if(!$projects) echo '<tr><td colspan="5">No projects yet.</td></tr>'; foreach($projects as $p) echo '<tr><td>'.esc_html($p['project_name']).'</td><td>'.esc_html($p['stage']).'</td><td>'.esc_html($p['progress_percent']).'%</td><td>'.esc_html($p['start_date']).'</td><td>'.esc_html($p['end_date']).'</td></tr>'; echo '</tbody></table></div>';
        echo '<h3>Task Board</h3><div class="ccjv3-board">';
        foreach($lanes as $key=>$label){ echo '<div class="ccjv3-lane"><h4>'.esc_html($label).'</h4>'; $had=false; foreach($tasks as $t){ if(($t['stage_lane'] ?? 'backlog') !== $key) continue; $had=true; echo '<article class="ccjv3-task-card"><strong>'.esc_html($t['task_name']).'</strong><span>'.esc_html($t['project_name']).'</span><small>Assigned: '.esc_html($t['assigned_to']).'</small><small>Due: '.esc_html($t['due_date']).'</small><small>Depends: '.esc_html($t['dependency_task_ids']).'</small><div class="ccjv3-progress"><span style="width:'.esc_attr((string)max(0,min(100,(int)$t['percent_complete']))).'%"></span></div></article>'; } if(!$had) echo '<p class="ccjv3-empty">No tasks.</p>'; echo '</div>'; }
        echo '</div><h3>Timeline</h3><div class="ccjv3-timeline">';
        foreach($tasks as $t){ echo '<div class="ccjv3-timeline-row"><strong>'.esc_html($t['task_name']).'</strong><span>'.esc_html($t['start_date']).' → '.esc_html($t['due_date']).'</span><em>'.esc_html($t['dependency_task_ids']).'</em></div>'; }
        echo '</div></section>'; return ob_get_clean();
    }
    public static function asset_summary(int $workspace_id): string {
        global $wpdb; $rows = $wpdb->get_results($wpdb->prepare("SELECT asset_name, asset_type, purchase_value, current_value, accumulated_depreciation, status FROM " . CCJV3_DB::table('assets') . " WHERE workspace_id=%d ORDER BY id DESC LIMIT 50", $workspace_id), ARRAY_A) ?: [];
        ob_start(); echo '<section class="ccjv3-panel"><h3>Assets</h3><div class="ccjv3-table-wrap"><table><thead><tr><th>Asset</th><th>Type</th><th>Purchase</th><th>Current</th><th>Accumulated Depreciation</th><th>Status</th></tr></thead><tbody>'; if(!$rows) echo '<tr><td colspan="6">No assets yet.</td></tr>'; foreach($rows as $r) echo '<tr><td>'.esc_html($r['asset_name']).'</td><td>'.esc_html($r['asset_type']).'</td><td>'.esc_html(number_format_i18n((float)$r['purchase_value'],2)).'</td><td>'.esc_html(number_format_i18n((float)$r['current_value'],2)).'</td><td>'.esc_html(number_format_i18n((float)$r['accumulated_depreciation'],2)).'</td><td>'.esc_html($r['status']).'</td></tr>'; echo '</tbody></table></div></section>'; return ob_get_clean();
    }
}
