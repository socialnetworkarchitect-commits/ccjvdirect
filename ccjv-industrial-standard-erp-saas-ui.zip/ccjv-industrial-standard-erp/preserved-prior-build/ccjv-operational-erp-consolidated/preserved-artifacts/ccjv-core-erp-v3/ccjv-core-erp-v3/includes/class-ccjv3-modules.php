<?php
if (!defined('ABSPATH')) { exit; }
class CCJV3_Modules {
    public static function init(): void {
        add_action('admin_post_ccjv3_save_record', [__CLASS__, 'save_record']);
        add_action('admin_post_ccjv3_delete_record', [__CLASS__, 'delete_record']);
        add_action('admin_post_ccjv3_add_invoice_line', [__CLASS__, 'add_invoice_line']);
        add_action('admin_post_ccjv3_add_invoice_payment', [__CLASS__, 'add_invoice_payment']);
        add_action('admin_post_ccjv3_post_invoice', [__CLASS__, 'post_invoice']);
        add_action('admin_post_ccjv3_run_payroll', [__CLASS__, 'run_payroll']);
        add_action('admin_post_ccjv3_run_depreciation', [__CLASS__, 'run_depreciation']);
        add_action('wp_ajax_ccjv3_save_wallet_sync', [__CLASS__, 'ajax_save_wallet_sync']);
    }
    public static function configs(): array {
        return [
            'workspaces' => ['table'=>CCJV3_DB::table('workspaces'),'title'=>'Workspaces','fields'=>['slug','name','token_symbol','token_contract','token_decimals','token_threshold','accent_color','hero_image','dashboard_title','description','allowed_modules','is_active'],'numeric_fields'=>['token_decimals','token_threshold','is_active'],'date_fields'=>[]],
            'ventures' => ['table'=>CCJV3_DB::table('ventures'),'title'=>'Ventures','fields'=>['venture_code','venture_name','workspace_id','venture_type','stage','owner_name','budget','start_date','end_date','description'],'numeric_fields'=>['workspace_id','budget'],'date_fields'=>['start_date','end_date']],
            'permissions' => ['table'=>CCJV3_DB::table('workspace_permissions'),'title'=>'Workspace Permissions','fields'=>['user_id','workspace_id','role_key','manual_override','front_modules'],'numeric_fields'=>['user_id','workspace_id','manual_override'],'date_fields'=>[]],
            'crm' => ['table'=>CCJV3_DB::table('crm_contacts'),'title'=>'CRM','fields'=>['workspace_id','venture_id','company','first_name','last_name','email','phone','status','notes'],'numeric_fields'=>['workspace_id','venture_id'],'date_fields'=>[]],
            'hrm' => ['table'=>CCJV3_DB::table('hrm_employees'),'title'=>'HRM','fields'=>['workspace_id','venture_id','employee_code','first_name','last_name','email','phone','department','position','hourly_rate','salary','status','start_date','notes'],'numeric_fields'=>['workspace_id','venture_id','hourly_rate','salary'],'date_fields'=>['start_date']],
            'coa' => ['table'=>CCJV3_DB::table('chart_accounts'),'title'=>'Chart of Accounts','fields'=>['account_code','account_name','account_type','normal_balance','is_active'],'numeric_fields'=>['is_active'],'date_fields'=>[]],
            'invoices' => ['table'=>CCJV3_DB::table('invoices'),'title'=>'Invoices','fields'=>['workspace_id','venture_id','invoice_no','client_name','issue_date','due_date','status','subtotal','tax','total','paid_amount','notes'],'numeric_fields'=>['workspace_id','venture_id','subtotal','tax','total','paid_amount'],'date_fields'=>['issue_date','due_date']],
            'payroll' => ['table'=>CCJV3_DB::table('payroll_runs'),'title'=>'Payroll','fields'=>['workspace_id','venture_id','employee_id','pay_period_start','pay_period_end','pay_date','regular_hours','overtime_hours','gross_pay','deductions','net_pay','status','notes'],'numeric_fields'=>['workspace_id','venture_id','employee_id','regular_hours','overtime_hours','gross_pay','deductions','net_pay'],'date_fields'=>['pay_period_start','pay_period_end','pay_date']],
            'projects' => ['table'=>CCJV3_DB::table('projects'),'title'=>'Projects','fields'=>['workspace_id','venture_id','project_code','project_name','manager_name','stage','budget','start_date','end_date','progress_percent','description'],'numeric_fields'=>['workspace_id','venture_id','budget','progress_percent'],'date_fields'=>['start_date','end_date']],
            'tasks' => ['table'=>CCJV3_DB::table('project_tasks'),'title'=>'Project Tasks','fields'=>['project_id','parent_task_id','task_name','assigned_to','status','stage_lane','start_date','due_date','dependency_task_ids','percent_complete','sort_order','notes'],'numeric_fields'=>['project_id','parent_task_id','percent_complete','sort_order'],'date_fields'=>['start_date','due_date']],
            'assets' => ['table'=>CCJV3_DB::table('assets'),'title'=>'Assets','fields'=>['workspace_id','venture_id','asset_code','asset_name','asset_type','location_name','owner_name','purchase_date','purchase_value','salvage_value','useful_life_years','depreciation_method','current_value','accumulated_depreciation','status','notes'],'numeric_fields'=>['workspace_id','venture_id','purchase_value','salvage_value','useful_life_years','current_value','accumulated_depreciation'],'date_fields'=>['purchase_date']],
        ];
    }
    public static function get_records(string $module, int $limit = 100, array $where = []): array {
        global $wpdb;
        $cfg = self::configs()[$module] ?? null; if (!$cfg) return [];
        $limit = max(1, min(500, $limit));
        $sql = "SELECT * FROM {$cfg['table']}";
        $args = [];
        if ($where) {
            $clauses = [];
            foreach ($where as $k=>$v) { $clauses[] = $k . '=%s'; $args[] = $v; }
            $sql .= ' WHERE ' . implode(' AND ', $clauses);
        }
        $sql .= ' ORDER BY id DESC LIMIT ' . $limit;
        if ($args) { $sql = $wpdb->prepare($sql, $args); }
        return $wpdb->get_results($sql, ARRAY_A) ?: [];
    }
    public static function get_record(string $module, int $id): ?array {
        global $wpdb;
        $cfg = self::configs()[$module] ?? null; if (!$cfg || $id < 1) return null;
        $row = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$cfg['table']} WHERE id=%d", $id), ARRAY_A);
        return $row ?: null;
    }
    public static function counts(): array {
        global $wpdb; $out = [];
        foreach (self::configs() as $k=>$cfg) { $out[$k] = (int)$wpdb->get_var("SELECT COUNT(*) FROM {$cfg['table']}"); }
        $out['journals'] = (int)$wpdb->get_var("SELECT COUNT(*) FROM " . CCJV3_DB::table('journal_headers'));
        return $out;
    }
    public static function save_record(): void {
        if (!current_user_can('manage_options')) wp_die('Unauthorized');
        check_admin_referer('ccjv3_save_record');
        $module = sanitize_key(wp_unslash($_POST['module'] ?? ''));
        $cfg = self::configs()[$module] ?? null; if (!$cfg) wp_die('Invalid module');
        global $wpdb;
        $data = [];
        foreach ($cfg['fields'] as $field) {
            $raw = wp_unslash($_POST[$field] ?? '');
            if (in_array($field, $cfg['numeric_fields'], true)) $data[$field] = is_numeric($raw) ? $raw : 0;
            elseif (in_array($field, $cfg['date_fields'], true)) $data[$field] = $raw ? sanitize_text_field($raw) : null;
            elseif (in_array($field, ['notes','description'], true)) $data[$field] = sanitize_textarea_field($raw);
            else $data[$field] = sanitize_text_field($raw);
        }
        $now = current_time('mysql'); $data['updated_at'] = $now;
        $id = absint($_POST['record_id'] ?? 0);
        if ($module === 'invoices') {
            $data['subtotal'] = (float)$data['subtotal']; $data['tax'] = (float)$data['tax']; $data['total'] = round($data['subtotal'] + $data['tax'], 2);
        }
        if ($id) $wpdb->update($cfg['table'], $data, ['id'=>$id]);
        else { $data['created_at']=$now; $wpdb->insert($cfg['table'], $data); }
        wp_safe_redirect(add_query_arg(['page'=>'ccjv3-'.$module,'ccjv3_notice'=>'saved'], admin_url('admin.php'))); exit;
    }
    public static function delete_record(): void {
        if (!current_user_can('manage_options')) wp_die('Unauthorized');
        $module = sanitize_key(wp_unslash($_GET['module'] ?? '')); $id = absint($_GET['record_id'] ?? 0);
        if (!wp_verify_nonce(sanitize_text_field(wp_unslash($_GET['_wpnonce'] ?? '')), 'ccjv3_delete_' . $module . '_' . $id)) wp_die('Invalid nonce');
        $cfg = self::configs()[$module] ?? null; if (!$cfg || !$id) wp_die('Invalid request');
        global $wpdb; $wpdb->delete($cfg['table'], ['id'=>$id]);
        wp_safe_redirect(add_query_arg(['page'=>'ccjv3-'.$module,'ccjv3_notice'=>'deleted'], admin_url('admin.php'))); exit;
    }
    public static function ajax_save_wallet_sync(): void {
        check_ajax_referer('ccjv3_wallet_nonce', 'nonce');
        if (!is_user_logged_in()) wp_send_json_error(['message'=>'Login required'], 403);
        $wallet = sanitize_text_field(wp_unslash($_POST['wallet_address'] ?? ''));
        $balances = json_decode(stripslashes((string)($_POST['balances'] ?? '{}')), true);
        $chain_name = sanitize_text_field(wp_unslash($_POST['chain_name'] ?? 'Avalanche'));
        $chain_id = sanitize_text_field(wp_unslash($_POST['chain_id'] ?? '0xa86a'));
        if (!$wallet || !is_array($balances)) wp_send_json_error(['message'=>'Invalid payload'], 400);
        CCJV3_Access::sync_wallet(get_current_user_id(), $wallet, $balances, $chain_name, $chain_id);
        wp_send_json_success(['message'=>'Wallet synchronized']);
    }
    public static function add_invoice_line(): void {
        if (!current_user_can('manage_options')) wp_die('Unauthorized');
        check_admin_referer('ccjv3_add_invoice_line');
        global $wpdb; $table = CCJV3_DB::table('invoice_lines'); $now = current_time('mysql');
        $invoice_id = absint($_POST['invoice_id'] ?? 0); $qty = (float)($_POST['quantity'] ?? 1); $price = (float)($_POST['unit_price'] ?? 0);
        $wpdb->insert($table, ['invoice_id'=>$invoice_id,'line_no'=>absint($_POST['line_no'] ?? 1),'description'=>sanitize_text_field(wp_unslash($_POST['description'] ?? '')),'quantity'=>$qty,'unit_price'=>$price,'line_total'=>round($qty*$price,2),'created_at'=>$now,'updated_at'=>$now]);
        self::recalc_invoice($invoice_id);
        wp_safe_redirect(add_query_arg(['page'=>'ccjv3-invoices','edit'=>$invoice_id,'ccjv3_notice'=>'line_added'], admin_url('admin.php'))); exit;
    }
    public static function add_invoice_payment(): void {
        if (!current_user_can('manage_options')) wp_die('Unauthorized');
        check_admin_referer('ccjv3_add_invoice_payment');
        global $wpdb; $table = CCJV3_DB::table('invoice_payments'); $now = current_time('mysql');
        $invoice_id = absint($_POST['invoice_id'] ?? 0);
        $wpdb->insert($table, ['invoice_id'=>$invoice_id,'payment_date'=>sanitize_text_field(wp_unslash($_POST['payment_date'] ?? current_time('Y-m-d'))),'payment_method'=>sanitize_text_field(wp_unslash($_POST['payment_method'] ?? 'bank')),'amount'=>(float)($_POST['amount'] ?? 0),'reference_no'=>sanitize_text_field(wp_unslash($_POST['reference_no'] ?? '')),'notes'=>sanitize_textarea_field(wp_unslash($_POST['notes'] ?? '')),'created_at'=>$now,'updated_at'=>$now]);
        $payment_id = (int)$wpdb->insert_id; CCJV3_Accounting::post_invoice_payment($payment_id);
        wp_safe_redirect(add_query_arg(['page'=>'ccjv3-invoices','edit'=>$invoice_id,'ccjv3_notice'=>'payment_added'], admin_url('admin.php'))); exit;
    }
    public static function post_invoice(): void {
        if (!current_user_can('manage_options')) wp_die('Unauthorized');
        check_admin_referer('ccjv3_post_invoice');
        $invoice_id = absint($_POST['invoice_id'] ?? 0); $result = CCJV3_Accounting::post_invoice($invoice_id);
        $notice = is_wp_error($result) ? $result->get_error_message() : 'invoice_posted';
        wp_safe_redirect(add_query_arg(['page'=>'ccjv3-invoices','edit'=>$invoice_id,'ccjv3_notice'=>$notice], admin_url('admin.php'))); exit;
    }
    public static function run_payroll(): void {
        if (!current_user_can('manage_options')) wp_die('Unauthorized');
        check_admin_referer('ccjv3_run_payroll');
        global $wpdb; $emp_table = CCJV3_DB::table('hrm_employees'); $pay_table = CCJV3_DB::table('payroll_runs');
        $employee = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$emp_table} WHERE id=%d", absint($_POST['employee_id'] ?? 0)), ARRAY_A); if (!$employee) wp_die('Employee not found');
        $reg = (float)($_POST['regular_hours'] ?? 0); $ot = (float)($_POST['overtime_hours'] ?? 0); $rate = (float)$employee['hourly_rate'];
        $gross = round(($reg*$rate) + ($ot*$rate*1.5), 2); $ded = round($gross * 0.12, 2); $net = round($gross - $ded, 2); $now = current_time('mysql');
        $wpdb->insert($pay_table, ['workspace_id'=>$employee['workspace_id'],'venture_id'=>$employee['venture_id'],'employee_id'=>$employee['id'],'pay_period_start'=>sanitize_text_field(wp_unslash($_POST['pay_period_start'] ?? current_time('Y-m-01'))),'pay_period_end'=>sanitize_text_field(wp_unslash($_POST['pay_period_end'] ?? current_time('Y-m-t'))),'pay_date'=>sanitize_text_field(wp_unslash($_POST['pay_date'] ?? current_time('Y-m-d'))),'regular_hours'=>$reg,'overtime_hours'=>$ot,'gross_pay'=>$gross,'deductions'=>$ded,'net_pay'=>$net,'status'=>'posted','notes'=>'Auto payroll run','created_at'=>$now,'updated_at'=>$now]);
        $payroll_id = (int)$wpdb->insert_id; CCJV3_Accounting::post_payroll($payroll_id);
        wp_safe_redirect(add_query_arg(['page'=>'ccjv3-payroll','ccjv3_notice'=>'payroll_posted'], admin_url('admin.php'))); exit;
    }
    public static function run_depreciation(): void {
        if (!current_user_can('manage_options')) wp_die('Unauthorized');
        check_admin_referer('ccjv3_run_depreciation');
        global $wpdb; $asset_table = CCJV3_DB::table('assets'); $run_table = CCJV3_DB::table('depreciation_runs'); $now = current_time('mysql');
        $asset = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$asset_table} WHERE id=%d", absint($_POST['asset_id'] ?? 0)), ARRAY_A); if (!$asset) wp_die('Asset not found');
        $base = max(0, (float)$asset['purchase_value'] - (float)$asset['salvage_value']); $life = max(1, (int)$asset['useful_life_years']); $amount = round($base / ($life * 12), 2);
        $journal = CCJV3_Accounting::post_depreciation((int)$asset['id'], $amount, current_time('Y-m-d')); $journal_id = is_wp_error($journal) ? 0 : (int)$journal;
        $accum = (float)$asset['accumulated_depreciation'] + $amount; $book = max(0, (float)$asset['purchase_value'] - $accum);
        $wpdb->insert($run_table, ['asset_id'=>$asset['id'],'run_date'=>current_time('Y-m-d'),'amount'=>$amount,'accumulated_amount'=>$accum,'book_value'=>$book,'journal_id'=>$journal_id,'notes'=>'Monthly straight-line depreciation','created_at'=>$now,'updated_at'=>$now]);
        $wpdb->update($asset_table, ['accumulated_depreciation'=>$accum,'current_value'=>$book,'updated_at'=>$now], ['id'=>$asset['id']]);
        wp_safe_redirect(add_query_arg(['page'=>'ccjv3-assets','edit'=>$asset['id'],'ccjv3_notice'=>'depreciation_posted'], admin_url('admin.php'))); exit;
    }
    public static function recalc_invoice(int $invoice_id): void {
        global $wpdb;
        $sum = (float)$wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(line_total),0) FROM " . CCJV3_DB::table('invoice_lines') . " WHERE invoice_id=%d", $invoice_id));
        $invoice_table = CCJV3_DB::table('invoices');
        $invoice = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$invoice_table} WHERE id=%d", $invoice_id), ARRAY_A);
        if (!$invoice) return;
        $tax = (float)$invoice['tax']; $total = round($sum + $tax, 2);
        $wpdb->update($invoice_table, ['subtotal'=>$sum, 'total'=>$total, 'updated_at'=>current_time('mysql')], ['id'=>$invoice_id]);
    }
    public static function select_options(string $table, string $id_field, string $label_field): array {
        global $wpdb; $rows = $wpdb->get_results("SELECT {$id_field} AS id, {$label_field} AS label FROM {$table} ORDER BY label ASC", ARRAY_A) ?: []; $out = [];
        foreach ($rows as $r) $out[(int)$r['id']] = $r['label'];
        return $out;
    }
}
