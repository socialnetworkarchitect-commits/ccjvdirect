CCJV Core ERP V3

Shortcode: [ccjv3_shell]

Includes MetaMask/Avalanche wallet connect, on-chain token balance sync for configured workspace tokens, front-end shell, workspace routing, invoices with line items/payments, journal posting, payroll posting, project board/timeline, and asset depreciation.
