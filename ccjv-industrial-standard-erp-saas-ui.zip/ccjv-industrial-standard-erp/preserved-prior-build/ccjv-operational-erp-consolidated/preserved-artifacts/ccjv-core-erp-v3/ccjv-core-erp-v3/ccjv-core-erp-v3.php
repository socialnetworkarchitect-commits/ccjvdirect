<?php
/**
 * Plugin Name: CCJV Core ERP V3
 * Description: CCJV venture/workspace ERP with MetaMask/Avalanche wallet connect, on-chain token balance sync, front-end shell, role-based workspace access, invoicing, journals, project boards, payroll, assets, and depreciation.
 * Version: 3.0.0
 * Author: OpenAI
 * Requires at least: 6.0
 * Requires PHP: 7.4
 * Text Domain: ccjv-core-erp-v3
 */
if (!defined('ABSPATH')) { exit; }
define('CCJV3_VERSION', '3.0.0');
define('CCJV3_FILE', __FILE__);
define('CCJV3_PATH', plugin_dir_path(__FILE__));
define('CCJV3_URL', plugin_dir_url(__FILE__));
require_once CCJV3_PATH . 'includes/class-ccjv3-db.php';
require_once CCJV3_PATH . 'includes/class-ccjv3-roles.php';
require_once CCJV3_PATH . 'includes/class-ccjv3-access.php';
require_once CCJV3_PATH . 'includes/class-ccjv3-accounting.php';
require_once CCJV3_PATH . 'includes/class-ccjv3-modules.php';
require_once CCJV3_PATH . 'includes/class-ccjv3-admin.php';
require_once CCJV3_PATH . 'includes/class-ccjv3-frontend.php';
final class CCJV3_Core_ERP {
    private static $instance = null;
    public static function instance(): self {
        if (null === self::$instance) { self::$instance = new self(); }
        return self::$instance;
    }
    private function __construct() {
        add_action('plugins_loaded', [$this, 'boot']);
    }
    public function boot(): void {
        CCJV3_Roles::init();
        CCJV3_Modules::init();
        CCJV3_Admin::init();
        CCJV3_Frontend::init();
    }
}
register_activation_hook(__FILE__, ['CCJV3_DB', 'activate']);
register_activation_hook(__FILE__, ['CCJV3_Roles', 'activate']);
register_deactivation_hook(__FILE__, ['CCJV3_Roles', 'deactivate']);
CCJV3_Core_ERP::instance();
