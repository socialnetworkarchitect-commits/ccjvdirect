<?php
if (!defined('ABSPATH')) exit;
class Cibus_ERP_Admin {
    public function __construct() {
        add_action('admin_menu', [$this, 'menu']);
        add_action('admin_init', [$this, 'register_settings']);
    }
    private function defaults() {
        return [
            'site_url' => 'https://www.cibuscoin.ca',
            'workspace_slug' => 'cibus',
            'sector_token_name' => 'Cibus Coin',
            'sector_token_symbol' => 'CIB',
            'sector_token_contract' => '0xA86AB9663Be3F64ffaE6Ad73aA305d38447f3C80',
            'sector_token_decimals' => 18,
            'core_token_symbol' => 'CJV',
            'core_token_contract' => '',
            'core_token_decimals' => 18,
            'core_token_gate' => 1,
            'sector_token_gate' => 1,
            'core_monthly_fee' => 1,
            'sector_monthly_fee' => 1,
            'rpc_url' => '',
            'chain_id' => '43114',
            'network_name' => 'Avalanche C-Chain',
            'explorer_url' => 'https://snowtrace.io',
            'walletconnect_project_id' => '',
            'treasury_wallet' => '',
            'signer_endpoint' => '',
            'buy_cib_url' => 'https://xmarkets.ca',
            'buy_cjv_url' => 'https://xmarkets.ca',
            'erp_entry_url' => home_url('/cibus-erp/'),
            'omnichain_url' => 'https://omnichain.ca',
            'xmarkets_url' => 'https://xmarkets.ca',
            'hero_title' => 'Agriculture & Food Processing ERP',
            'hero_text' => 'From field to factory to warehouse to market. Cibus ERP operates the food chain while CIB supports sector access and usage.',
            'kicker_text' => 'AGRICULTURE • FOOD PROCESSING • TRACEABILITY • DISTRIBUTION',
            'primary_color' => '#0f5f3d',
            'secondary_color' => '#1f7a53',
            'accent_color' => '#d4a72c',
            'surface_color' => '#ffffff',
            'bg_color' => '#f4f7f4',
            'logo_url' => CIBUS_ERP_URL . 'assets/img/cibus-logo.svg',
            'show_all_modules' => 1,
            'module_crop' => 1,
            'module_livestock' => 1,
            'module_field' => 1,
            'module_traceability' => 1,
            'module_inventory' => 1,
            'module_operations' => 1,
            'module_recipe' => 1,
            'module_production' => 1,
            'module_quality' => 1,
            'module_shelflife' => 1,
            'module_allergen' => 1,
            'module_catchweight' => 1,
        ];
    }
    private function settings() { return wp_parse_args(get_option('cibus_erp_settings', []), $this->defaults()); }
    public function register_settings() {
        register_setting('cibus_erp_settings_group', 'cibus_erp_settings', [$this, 'sanitize_settings']);
    }
    public function sanitize_settings($input) {
        $d = $this->defaults();
        $o = [];
        foreach (['site_url','workspace_slug','sector_token_name','sector_token_symbol','sector_token_contract','core_token_symbol','core_token_contract','rpc_url','chain_id','network_name','explorer_url','walletconnect_project_id','treasury_wallet','signer_endpoint','buy_cib_url','buy_cjv_url','erp_entry_url','omnichain_url','xmarkets_url','hero_title','kicker_text','logo_url'] as $k) {
            $o[$k] = sanitize_text_field($input[$k] ?? $d[$k]);
        }
        foreach (['hero_text'] as $k) $o[$k] = sanitize_textarea_field($input[$k] ?? $d[$k]);
        foreach (['sector_token_decimals','core_token_decimals'] as $k) $o[$k] = max(0, (int)($input[$k] ?? $d[$k]));
        foreach (['core_token_gate','sector_token_gate','core_monthly_fee','sector_monthly_fee'] as $k) $o[$k] = max(0, (float)($input[$k] ?? $d[$k]));
        foreach (['primary_color','secondary_color','accent_color','surface_color','bg_color'] as $k) $o[$k] = sanitize_hex_color($input[$k] ?? $d[$k]) ?: $d[$k];
        foreach (['show_all_modules','module_crop','module_livestock','module_field','module_traceability','module_inventory','module_operations','module_recipe','module_production','module_quality','module_shelflife','module_allergen','module_catchweight'] as $k) $o[$k] = empty($input[$k]) ? 0 : 1;
        foreach (['buy_cib_url','buy_cjv_url','erp_entry_url','omnichain_url','xmarkets_url','logo_url','site_url','explorer_url','signer_endpoint'] as $k) $o[$k] = esc_url_raw($o[$k]);
        return $o;
    }
    public function menu() {
        add_submenu_page('ccjvu', 'Cibus ERP', 'Cibus ERP', 'manage_options', 'cibus-erp-command-center', [$this, 'command_center']);
        add_submenu_page('ccjvu', 'Cibus Portal', 'Cibus Portal', 'manage_options', 'cibus-erp-portal', [$this, 'portal_page']);
    }
    private function stat_card($label, $value, $hint='') {
        echo '<div style="background:#fff;border:1px solid #d9e2df;border-radius:16px;padding:18px;min-width:0;box-shadow:0 10px 30px rgba(15,95,61,.05)">';
        echo '<div style="font-size:12px;text-transform:uppercase;letter-spacing:.08em;color:#5c6d67;font-weight:700">' . esc_html($label) . '</div>';
        echo '<div style="font-size:28px;font-weight:800;margin-top:6px;color:#17332a">' . wp_kses_post($value) . '</div>';
        if ($hint !== '') echo '<div style="margin-top:6px;color:#5c6d67">' . esc_html($hint) . '</div>';
        echo '</div>';
    }
    private function checkbox($name, $label, $s) {
        echo '<label style="display:flex;align-items:center;gap:10px;margin:0 0 12px"><input type="checkbox" name="cibus_erp_settings['.esc_attr($name).']" value="1" '.checked(!empty($s[$name]),1,false).'> '.esc_html($label).'</label>';
    }
    public function portal_page() {
        $page = get_page_by_path('cibus-erp');
        echo '<div class="wrap"><h1>Cibus ERP Portal</h1>';
        if ($page) {
            echo '<p><a class="button button-primary button-hero" href="' . esc_url(get_permalink($page)) . '" target="_blank" rel="noopener">Open Cibus ERP Portal</a> ';
            echo '<a class="button" href="' . esc_url(admin_url('post.php?post=' . $page->ID . '&action=edit')) . '">Edit Portal Page</a></p>';
            echo '<p>Portal slug: <code>/cibus-erp/</code></p>';
        } else {
            echo '<div class="notice notice-warning inline"><p>The Cibus ERP portal page does not exist yet. Re-activate the plugin or create a page with the shortcode <code>[cibus_portal]</code>.</p></div>';
        }
        echo '</div>';
    }
    public function command_center() {
        global $wpdb; $s = $this->settings(); $p = Cibus_ERP_DB::prefix(); $t = function_exists('ccjvu_tables') ? ccjvu_tables() : [];
        $workspace_id = 0; $module_rows = [];
        if (!empty($t['workspaces'])) $workspace_id = (int)$wpdb->get_var($wpdb->prepare("SELECT id FROM {$t['workspaces']} WHERE slug=%s LIMIT 1", 'cibus'));
        if ($workspace_id && !empty($t['modules'])) $module_rows = $wpdb->get_results($wpdb->prepare("SELECT * FROM {$t['modules']} WHERE workspace_id=%d ORDER BY sort_order ASC, id ASC", $workspace_id), ARRAY_A);
        echo '<div class="wrap"><h1>Cibus ERP Command Center</h1>';
        echo '<div style="display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:16px;margin:20px 0">';
        $this->stat_card('Access Gate', esc_html($s['core_token_gate']) . ' ' . esc_html($s['core_token_symbol']) . ' + ' . esc_html($s['sector_token_gate']) . ' ' . esc_html($s['sector_token_symbol']), 'Both required');
        $this->stat_card('Per Module / Month', esc_html($s['core_monthly_fee']) . ' ' . esc_html($s['core_token_symbol']) . ' + ' . esc_html($s['sector_monthly_fee']) . ' ' . esc_html($s['sector_token_symbol']), 'Dual monthly pricing');
        $this->stat_card('Blockchain', esc_html($s['network_name']) . ' #' . esc_html($s['chain_id']), 'Editable in settings');
        $this->stat_card('Enabled Modules', count(array_filter([$s['module_crop'],$s['module_livestock'],$s['module_field'],$s['module_traceability'],$s['module_inventory'],$s['module_operations'],$s['module_recipe'],$s['module_production'],$s['module_quality'],$s['module_shelflife'],$s['module_allergen'],$s['module_catchweight']])), 'Show all modules is '.(!empty($s['show_all_modules'])?'on':'off'));
        echo '</div>';
        echo '<form method="post" action="options.php" style="max-width:1280px">'; settings_fields('cibus_erp_settings_group');
        echo '<div style="display:grid;grid-template-columns:1.1fr .9fr;gap:18px">';
        echo '<div style="display:grid;gap:18px">';
        foreach ([
            'Project & Routing' => [
                ['site_url','Site URL'],['workspace_slug','Workspace Slug'],['erp_entry_url','ERP Entry URL'],['buy_cib_url','Buy CIB URL'],['buy_cjv_url','Buy CJV URL'],['xmarkets_url','XMarkets URL'],['omnichain_url','Omnichain URL']
            ],
            'Blockchain Connection' => [
                ['network_name','Network Name'],['chain_id','Chain ID'],['rpc_url','RPC URL'],['explorer_url','Explorer URL'],['walletconnect_project_id','WalletConnect Project ID'],['signer_endpoint','Signer Endpoint'],['treasury_wallet','Treasury Wallet']
            ],
            'Token Access & Billing' => [
                ['core_token_symbol','Core Token Symbol'],['core_token_contract','Core Token Contract'],['core_token_decimals','Core Token Decimals'],['core_token_gate','Core Token Gate'],['core_monthly_fee','Core Monthly Fee'],['sector_token_name','Sector Token Name'],['sector_token_symbol','Sector Token Symbol'],['sector_token_contract','Sector Token Contract'],['sector_token_decimals','Sector Token Decimals'],['sector_token_gate','Sector Token Gate'],['sector_monthly_fee','Sector Monthly Fee']
            ],
            'Public UI' => [
                ['hero_title','Hero Title'],['kicker_text','Kicker Text'],['hero_text','Hero Text'],['logo_url','Logo URL'],['primary_color','Primary Color'],['secondary_color','Secondary Color'],['accent_color','Accent Color'],['surface_color','Surface Color'],['bg_color','Background Color']
            ]
        ] as $section => $fields) {
            echo '<div style="background:#fff;border:1px solid #d9e2df;border-radius:16px;padding:22px;box-shadow:0 10px 30px rgba(15,95,61,.05)"><h2 style="margin-top:0">'.esc_html($section).'</h2>';
            foreach ($fields as $f) {
                $name = $f[0]; $label = $f[1]; $type = strpos($label, 'Color') !== false ? 'color' : ((strpos($label,'Text')!==false && $name==='hero_text') ? 'textarea':'text');
                echo '<p style="margin:0 0 14px"><label style="display:block;font-weight:700;margin-bottom:6px">'.esc_html($label).'</label>';
                if ($type==='textarea') echo '<textarea name="cibus_erp_settings['.esc_attr($name).']" rows="4" style="width:100%">'.esc_textarea($s[$name]).'</textarea>';
                else echo '<input type="'.esc_attr($type).'" name="cibus_erp_settings['.esc_attr($name).']" value="'.esc_attr($s[$name]).'" style="width:100%">';
                echo '</p>';
            }
            echo '</div>';
        }
        echo '</div>';
        echo '<div style="display:grid;gap:18px">';
        echo '<div style="background:#fff;border:1px solid #d9e2df;border-radius:16px;padding:22px;box-shadow:0 10px 30px rgba(15,95,61,.05)"><h2 style="margin-top:0">Module Visibility & Sales Controls</h2>';
        $this->checkbox('show_all_modules','Show all modules publicly (locked/unlocked state)', $s);
        $this->checkbox('module_crop','Crop Lifecycle', $s); $this->checkbox('module_livestock','Livestock & Health', $s); $this->checkbox('module_field','Field Mapping & GIS', $s); $this->checkbox('module_traceability','Lot Traceability & Recall', $s); $this->checkbox('module_inventory','Inventory & Warehouse', $s); $this->checkbox('module_operations','Operations, Labor & Assets', $s); $this->checkbox('module_recipe','Recipe & Formula Management', $s); $this->checkbox('module_production','Production Scheduling', $s); $this->checkbox('module_quality','Quality, HACCP & Compliance', $s); $this->checkbox('module_shelflife','Expiration, Shelf-Life & FEFO', $s); $this->checkbox('module_allergen','Allergen Tracking', $s); $this->checkbox('module_catchweight','Catch Weight & UOM', $s);
        echo '</div>';
        echo '<div style="background:#fff;border:1px solid #d9e2df;border-radius:16px;padding:22px;box-shadow:0 10px 30px rgba(15,95,61,.05)"><h2 style="margin-top:0">Workspace Sync Notes</h2><p>These settings are designed to control blockchain connection values, token economics, module visibility, routing, hero copy, and the theme palette from one place. This build is launch-ready with balance-based gating presentation and editable blockchain controls.</p><ul style="list-style:disc;padding-left:18px"><li>CCJV remains the platform layer.</li><li>CIB remains the sector access and usage token.</li><li>Cibus is positioned as a full agriculture + food processing ERP.</li><li>Public UI stays ERP-first and lighter in contrast.</li></ul></div>';
        echo '<div style="background:#fff;border:1px solid #d9e2df;border-radius:16px;padding:22px;box-shadow:0 10px 30px rgba(15,95,61,.05)"><h2 style="margin-top:0">Live Workspace Modules</h2>';
        if ($module_rows) { echo '<ol>'; foreach ($module_rows as $m) echo '<li><strong>'.esc_html($m['name']).'</strong> — '.esc_html($m['summary']).'</li>'; echo '</ol>'; } else echo '<p>No CCJV module rows found yet.</p>';
        echo '</div>';
        echo '</div></div>';
        submit_button('Save Cibus ERP Settings');
        echo '</form></div>';
    }
}
