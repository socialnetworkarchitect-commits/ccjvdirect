<?php
if (!defined('ABSPATH')) exit;
class Cibus_ERP_DB {
    public static function activate() {
        global $wpdb;
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        $c = $wpdb->get_charset_collate();
        $p = $wpdb->prefix . 'cibus_erp_';

        dbDelta("CREATE TABLE {$p}crop_cycles (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            crop_name VARCHAR(190) NOT NULL,
            field_name VARCHAR(190) DEFAULT '',
            variety VARCHAR(190) DEFAULT '',
            stage VARCHAR(60) DEFAULT 'planned',
            planting_date DATE NULL,
            harvest_date DATE NULL,
            expected_yield DECIMAL(18,2) DEFAULT 0,
            actual_yield DECIMAL(18,2) DEFAULT 0,
            storage_location VARCHAR(190) DEFAULT '',
            notes LONGTEXT NULL,
            created_by BIGINT UNSIGNED DEFAULT 0,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id)
        ) $c;");
        dbDelta("CREATE TABLE {$p}livestock (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            animal_tag VARCHAR(120) NOT NULL,
            species VARCHAR(120) DEFAULT '',
            breed VARCHAR(120) DEFAULT '',
            birth_date DATE NULL,
            lineage VARCHAR(190) DEFAULT '',
            feed_program VARCHAR(190) DEFAULT '',
            weight_norm DECIMAL(18,2) DEFAULT 0,
            health_status VARCHAR(60) DEFAULT 'active',
            last_treatment DATE NULL,
            notes LONGTEXT NULL,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id)
        ) $c;");
        dbDelta("CREATE TABLE {$p}field_maps (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            zone_name VARCHAR(190) NOT NULL,
            gps_reference VARCHAR(190) DEFAULT '',
            soil_fertility VARCHAR(190) DEFAULT '',
            land_use VARCHAR(190) DEFAULT '',
            water_status VARCHAR(190) DEFAULT '',
            treatment_plan LONGTEXT NULL,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id)
        ) $c;");
        dbDelta("CREATE TABLE {$p}traceability (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            batch_code VARCHAR(120) NOT NULL,
            source_type VARCHAR(80) DEFAULT 'crop',
            source_name VARCHAR(190) DEFAULT '',
            field_or_lot VARCHAR(190) DEFAULT '',
            chemical_inputs LONGTEXT NULL,
            audit_status VARCHAR(60) DEFAULT 'open',
            destination VARCHAR(190) DEFAULT '',
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id)
        ) $c;");
        dbDelta("CREATE TABLE {$p}inventory (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            item_name VARCHAR(190) NOT NULL,
            category VARCHAR(80) DEFAULT 'input',
            location_name VARCHAR(190) DEFAULT '',
            quantity DECIMAL(18,2) DEFAULT 0,
            unit_name VARCHAR(40) DEFAULT '',
            expiry_date DATE NULL,
            reorder_level DECIMAL(18,2) DEFAULT 0,
            notes LONGTEXT NULL,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id)
        ) $c;");
        dbDelta("CREATE TABLE {$p}operations (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            op_date DATE NULL,
            operation_type VARCHAR(120) DEFAULT '',
            crew_name VARCHAR(190) DEFAULT '',
            labor_hours DECIMAL(12,2) DEFAULT 0,
            asset_name VARCHAR(190) DEFAULT '',
            fuel_used DECIMAL(18,2) DEFAULT 0,
            water_used DECIMAL(18,2) DEFAULT 0,
            cost_amount DECIMAL(18,2) DEFAULT 0,
            notes LONGTEXT NULL,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id)
        ) $c;");
        dbDelta("CREATE TABLE {$p}recipes (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            recipe_name VARCHAR(190) NOT NULL,
            version_name VARCHAR(60) DEFAULT '',
            category VARCHAR(120) DEFAULT '',
            ingredients LONGTEXT NULL,
            target_cost DECIMAL(18,2) DEFAULT 0,
            allergen_flags VARCHAR(190) DEFAULT '',
            notes LONGTEXT NULL,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id)
        ) $c;");
        dbDelta("CREATE TABLE {$p}production_runs (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            run_code VARCHAR(120) NOT NULL,
            recipe_name VARCHAR(190) DEFAULT '',
            scheduled_date DATE NULL,
            line_name VARCHAR(190) DEFAULT '',
            planned_qty DECIMAL(18,2) DEFAULT 0,
            actual_qty DECIMAL(18,2) DEFAULT 0,
            status VARCHAR(60) DEFAULT 'planned',
            notes LONGTEXT NULL,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id)
        ) $c;");
        dbDelta("CREATE TABLE {$p}quality_checks (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            lot_code VARCHAR(120) NOT NULL,
            checkpoint_name VARCHAR(190) DEFAULT '',
            result_status VARCHAR(60) DEFAULT 'hold',
            shelf_life_days INT DEFAULT 0,
            allergens_found VARCHAR(190) DEFAULT '',
            catch_weight DECIMAL(18,2) DEFAULT 0,
            unit_name VARCHAR(40) DEFAULT '',
            notes LONGTEXT NULL,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id)
        ) $c;");

        self::seed_workspace_and_modules();
        self::maybe_create_portal_page();
    }
    public static function deactivate() {}
    public static function prefix() { global $wpdb; return $wpdb->prefix . 'cibus_erp_'; }
    private static function settings() {
        return wp_parse_args(get_option('cibus_erp_settings', []), [
            'sector_token_symbol' => 'CIB', 'sector_token_contract' => '0xA86AB9663Be3F64ffaE6Ad73aA305d38447f3C80', 'sector_token_decimals' => 18,
            'sector_token_gate' => 1, 'core_token_symbol' => 'CJV', 'core_token_gate' => 1, 'hero_title' => 'Agriculture & Food Processing ERP',
            'hero_text' => 'From field to factory to warehouse to market.', 'buy_cib_url' => 'https://xmarkets.ca', 'primary_color' => '#0f5f3d'
        ]);
    }
    public static function seed_workspace_and_modules() {
        global $wpdb; $t = ccjvu_tables(); $s = self::settings();
        $workspace = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$t['workspaces']} WHERE slug=%s LIMIT 1", 'cibus'), ARRAY_A);
        $workspace_row = [
            'name' => 'Cibus Coin', 'slug' => 'cibus', 'token_symbol' => $s['sector_token_symbol'], 'token_contract' => $s['sector_token_contract'],
            'token_decimals' => (int)$s['sector_token_decimals'], 'gate_amount' => (float)$s['sector_token_gate'], 'accent_color' => $s['primary_color'],
            'skin' => 'cibus', 'hero_title' => $s['hero_title'], 'hero_text' => $s['hero_text'], 'buy_url' => $s['buy_cib_url'], 'is_core' => 0, 'active' => 1, 'sort_order' => 14,
        ];
        if (!$workspace) { $wpdb->insert($t['workspaces'], $workspace_row); $workspace_id = (int)$wpdb->insert_id; }
        else { $workspace_id = (int)$workspace['id']; $wpdb->update($t['workspaces'], $workspace_row, ['id' => $workspace_id]); }
        $wpdb->replace($t['sector_plugins'], ['slug' => 'cibus','name' => 'Cibus ERP Module','plugin_file' => 'cibus-erp-module/cibus-erp-module.php','workspace_slug' => 'cibus','token_symbol' => $s['sector_token_symbol'],'active' => 1]);
        $modules = [
            ['Crop Lifecycle', 'crop-lifecycle', 'Seed selection, rotations, planting schedules, harvest planning, and storage.', 1],
            ['Livestock & Health', 'livestock-health', 'Animal records, lineage, feed patterns, weight norms, treatments, and health logs.', 2],
            ['Field Mapping & GIS', 'field-mapping-gis', 'GPS zones, fertility visibility, land use, and precision application support.', 3],
            ['Lot Traceability & Recall', 'lot-traceability-recall', 'Ingredient lots, supplier receipt, batch traceability, and targeted recalls.', 4],
            ['Inventory & Warehouse', 'inventory-warehouse', 'Perishables, warehouse stock, input levels, FEFO visibility, and reorder control.', 5],
            ['Operations, Labor & Assets', 'operations-labor-assets', 'Seasonal labor, mobile crews, machinery maintenance, water, fuel, and cost tracking.', 6],
            ['Recipe & Formula Management', 'recipe-formula-management', 'Recipe versions, substitutions, allergen flags, and what-if costing.', 7],
            ['Production Scheduling', 'production-scheduling', 'Batch runs, line scheduling, labor alignment, and planned vs actual throughput.', 8],
            ['Quality, HACCP & Compliance', 'quality-haccp-compliance', 'Inspection checkpoints, holds, pass-fail controls, and compliance records.', 9],
            ['Shelf-Life, FEFO & Expiry', 'shelf-life-fefo-expiry', 'First-expiry-first-out logic, expiry windows, and spoilage reduction.', 10],
            ['Allergen Tracking', 'allergen-tracking', 'Cross-contact control, allergen flags, and label support.', 11],
            ['Catch Weight & UOM', 'catch-weight-uom', 'Variable weights and unit-of-measure conversions for precise costing.', 12],
        ];
        foreach ($modules as $m) {
            $existing = $wpdb->get_var($wpdb->prepare("SELECT id FROM {$t['modules']} WHERE workspace_id=%d AND slug=%s", $workspace_id, $m[1]));
            $row = ['workspace_id' => $workspace_id,'name' => $m[0],'slug' => $m[1],'monthly_fee' => 1,'fee_token_symbol' => $s['sector_token_symbol'],'summary' => $m[2],'active' => 1,'sort_order' => $m[3]];
            if ($existing) $wpdb->update($t['modules'], $row, ['id' => $existing]); else $wpdb->insert($t['modules'], $row);
        }
    }
    public static function maybe_create_portal_page() {
        $page = get_page_by_path('cibus-erp');
        if (!$page) wp_insert_post(['post_title' => 'Cibus ERP','post_name' => 'cibus-erp','post_status' => 'publish','post_type' => 'page','post_content' => '[cibus_portal]']);
    }
}
