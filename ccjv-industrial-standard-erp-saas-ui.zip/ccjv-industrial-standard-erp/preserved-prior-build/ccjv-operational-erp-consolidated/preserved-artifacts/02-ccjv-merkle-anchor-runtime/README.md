Merkle batching and Avalanche anchor runtime.
