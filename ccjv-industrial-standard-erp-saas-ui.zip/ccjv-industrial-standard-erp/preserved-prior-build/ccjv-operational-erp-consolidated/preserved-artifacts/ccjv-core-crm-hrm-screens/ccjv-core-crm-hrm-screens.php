<?php
/*
Plugin Name: CCJV Core CRM + HRM Screens
Description: Adds tenant-aware CRM and HRM data screens on top of the CCJV Core ERP Engine.
Version: 1.0.0
Author: OpenAI
*/

if (!defined('ABSPATH')) exit;

if (!defined('CCJV_CORE_ACTIVE') && !function_exists('ccjv_core_loaded')) {
    add_action('admin_notices', function () {
        echo '<div class="notice notice-error"><p><strong>CCJV Core CRM + HRM Screens</strong> requires the CCJV core stack.</p></div>';
    });
    return;
}

register_activation_hook(__FILE__, function () {
    global $wpdb;
    $charset = $wpdb->get_charset_collate();

    $contacts = $wpdb->prefix . 'ccjv_contacts';
    $employees = $wpdb->prefix . 'ccjv_employees';

    require_once ABSPATH . 'wp-admin/includes/upgrade.php';

    $sql1 = "CREATE TABLE {$contacts} (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        tenant_id VARCHAR(255) NOT NULL,
        name VARCHAR(255) NOT NULL,
        email VARCHAR(255) NULL,
        phone VARCHAR(100) NULL,
        company VARCHAR(255) NULL,
        notes TEXT NULL,
        created_by BIGINT UNSIGNED NULL,
        created_at DATETIME NOT NULL,
        PRIMARY KEY (id),
        KEY tenant_id (tenant_id(191))
    ) {$charset};";

    $sql2 = "CREATE TABLE {$employees} (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        tenant_id VARCHAR(255) NOT NULL,
        full_name VARCHAR(255) NOT NULL,
        email VARCHAR(255) NULL,
        role_title VARCHAR(255) NULL,
        status VARCHAR(50) NULL,
        notes TEXT NULL,
        created_by BIGINT UNSIGNED NULL,
        created_at DATETIME NOT NULL,
        PRIMARY KEY (id),
        KEY tenant_id (tenant_id(191))
    ) {$charset};";

    dbDelta($sql1);
    dbDelta($sql2);
});

function ccjv_core_screens_get_current_tenant($user_id = 0) {
    if (!$user_id) $user_id = get_current_user_id();

    $tenant = get_user_meta($user_id, 'ccjv_tenant', true);
    if (!$tenant && function_exists('ccjvx_get_tenant')) {
        $tenant = ccjvx_get_tenant($user_id);
    }

    return $tenant ?: '';
}

function ccjv_core_screens_user_allowed($module_key) {
    if (!is_user_logged_in()) return false;

    if (function_exists('ccjv_core_module_access_state')) {
        $state = ccjv_core_module_access_state($module_key, get_current_user_id());
        return !empty($state['allowed']);
    }

    return true;
}

function ccjv_core_crm_add_contact($tenant_id, $data) {
    global $wpdb;
    $table = $wpdb->prefix . 'ccjv_contacts';

    return $wpdb->insert($table, [
        'tenant_id' => $tenant_id,
        'name' => sanitize_text_field($data['name'] ?? ''),
        'email' => sanitize_email($data['email'] ?? ''),
        'phone' => sanitize_text_field($data['phone'] ?? ''),
        'company' => sanitize_text_field($data['company'] ?? ''),
        'notes' => sanitize_textarea_field($data['notes'] ?? ''),
        'created_by' => get_current_user_id(),
        'created_at' => current_time('mysql'),
    ]);
}

function ccjv_core_crm_get_contacts($tenant_id) {
    global $wpdb;
    $table = $wpdb->prefix . 'ccjv_contacts';
    return $wpdb->get_results($wpdb->prepare(
        "SELECT * FROM {$table} WHERE tenant_id=%s ORDER BY id DESC",
        $tenant_id
    ));
}

function ccjv_core_hrm_add_employee($tenant_id, $data) {
    global $wpdb;
    $table = $wpdb->prefix . 'ccjv_employees';

    return $wpdb->insert($table, [
        'tenant_id' => $tenant_id,
        'full_name' => sanitize_text_field($data['full_name'] ?? ''),
        'email' => sanitize_email($data['email'] ?? ''),
        'role_title' => sanitize_text_field($data['role_title'] ?? ''),
        'status' => sanitize_text_field($data['status'] ?? 'active'),
        'notes' => sanitize_textarea_field($data['notes'] ?? ''),
        'created_by' => get_current_user_id(),
        'created_at' => current_time('mysql'),
    ]);
}

function ccjv_core_hrm_get_employees($tenant_id) {
    global $wpdb;
    $table = $wpdb->prefix . 'ccjv_employees';
    return $wpdb->get_results($wpdb->prepare(
        "SELECT * FROM {$table} WHERE tenant_id=%s ORDER BY id DESC",
        $tenant_id
    ));
}

add_shortcode('ccjv_core_crm_screen', function () {
    if (!ccjv_core_screens_user_allowed('crm')) {
        return '<p>Access denied.</p>';
    }

    $tenant_id = ccjv_core_screens_get_current_tenant();
    if (!$tenant_id) {
        return '<p>No tenant context found.</p>';
    }

    if (isset($_POST['ccjv_add_contact'])) {
        if (!isset($_POST['_wpnonce']) || !wp_verify_nonce($_POST['_wpnonce'], 'ccjv_add_contact')) {
            return '<p>Security check failed.</p>';
        }
        ccjv_core_crm_add_contact($tenant_id, wp_unslash($_POST));
    }

    $contacts = ccjv_core_crm_get_contacts($tenant_id);

    ob_start(); ?>
    <div style="max-width:1200px;margin:0 auto;padding:24px">
        <div class="ccjv-card">
            <h2>Core CRM</h2>
            <p>Tenant-aware contact management on top of the Core ERP Engine.</p>
            <p><strong>Tenant:</strong> <?php echo esc_html($tenant_id); ?></p>
        </div>

        <div class="ccjv-card">
            <h3>Add Contact</h3>
            <form method="post">
                <?php wp_nonce_field('ccjv_add_contact'); ?>
                <p><input type="text" name="name" placeholder="Full Name" required class="regular-text"></p>
                <p><input type="email" name="email" placeholder="Email" class="regular-text"></p>
                <p><input type="text" name="phone" placeholder="Phone" class="regular-text"></p>
                <p><input type="text" name="company" placeholder="Company" class="regular-text"></p>
                <p><textarea name="notes" placeholder="Notes" rows="4" class="large-text"></textarea></p>
                <p><button class="button button-primary" name="ccjv_add_contact" value="1">Save Contact</button></p>
            </form>
        </div>

        <div class="ccjv-card">
            <h3>Contacts</h3>
            <?php if (!$contacts): ?>
                <p>No contacts yet.</p>
            <?php else: ?>
                <table class="widefat striped">
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Phone</th>
                            <th>Company</th>
                            <th>Created</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($contacts as $contact): ?>
                            <tr>
                                <td><?php echo esc_html($contact->name); ?></td>
                                <td><?php echo esc_html($contact->email); ?></td>
                                <td><?php echo esc_html($contact->phone); ?></td>
                                <td><?php echo esc_html($contact->company); ?></td>
                                <td><?php echo esc_html($contact->created_at); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </div>
    </div>
    <?php
    return ob_get_clean();
});

add_shortcode('ccjv_core_hrm_screen', function () {
    if (!ccjv_core_screens_user_allowed('hrm')) {
        return '<p>Access denied.</p>';
    }

    $tenant_id = ccjv_core_screens_get_current_tenant();
    if (!$tenant_id) {
        return '<p>No tenant context found.</p>';
    }

    if (isset($_POST['ccjv_add_employee'])) {
        if (!isset($_POST['_wpnonce']) || !wp_verify_nonce($_POST['_wpnonce'], 'ccjv_add_employee')) {
            return '<p>Security check failed.</p>';
        }
        ccjv_core_hrm_add_employee($tenant_id, wp_unslash($_POST));
    }

    $employees = ccjv_core_hrm_get_employees($tenant_id);

    ob_start(); ?>
    <div style="max-width:1200px;margin:0 auto;padding:24px">
        <div class="ccjv-card">
            <h2>Core HRM</h2>
            <p>Tenant-aware employee management on top of the Core ERP Engine.</p>
            <p><strong>Tenant:</strong> <?php echo esc_html($tenant_id); ?></p>
        </div>

        <div class="ccjv-card">
            <h3>Add Employee</h3>
            <form method="post">
                <?php wp_nonce_field('ccjv_add_employee'); ?>
                <p><input type="text" name="full_name" placeholder="Full Name" required class="regular-text"></p>
                <p><input type="email" name="email" placeholder="Email" class="regular-text"></p>
                <p><input type="text" name="role_title" placeholder="Role / Title" class="regular-text"></p>
                <p>
                    <select name="status">
                        <option value="active">active</option>
                        <option value="inactive">inactive</option>
                        <option value="leave">leave</option>
                    </select>
                </p>
                <p><textarea name="notes" placeholder="Notes" rows="4" class="large-text"></textarea></p>
                <p><button class="button button-primary" name="ccjv_add_employee" value="1">Save Employee</button></p>
            </form>
        </div>

        <div class="ccjv-card">
            <h3>Employees</h3>
            <?php if (!$employees): ?>
                <p>No employees yet.</p>
            <?php else: ?>
                <table class="widefat striped">
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Role</th>
                            <th>Status</th>
                            <th>Created</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($employees as $employee): ?>
                            <tr>
                                <td><?php echo esc_html($employee->full_name); ?></td>
                                <td><?php echo esc_html($employee->email); ?></td>
                                <td><?php echo esc_html($employee->role_title); ?></td>
                                <td><?php echo esc_html($employee->status); ?></td>
                                <td><?php echo esc_html($employee->created_at); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </div>
    </div>
    <?php
    return ob_get_clean();
});

add_action('admin_menu', function () {
    add_submenu_page(
        'ccjv',
        'Core CRM + HRM Screens',
        'Core CRM + HRM Screens',
        'manage_options',
        'ccjv-core-crm-hrm-screens',
        function () {
            echo '<div class="wrap"><h1>Core CRM + HRM Screens</h1>';
            echo '<p>This layer adds tenant-aware CRM and HRM data screens on top of the Core ERP Engine.</p>';
            echo '<ul>';
            echo '<li><code>[ccjv_core_crm_screen]</code></li>';
            echo '<li><code>[ccjv_core_hrm_screen]</code></li>';
            echo '</ul></div>';
        }
    );
}, 90);
