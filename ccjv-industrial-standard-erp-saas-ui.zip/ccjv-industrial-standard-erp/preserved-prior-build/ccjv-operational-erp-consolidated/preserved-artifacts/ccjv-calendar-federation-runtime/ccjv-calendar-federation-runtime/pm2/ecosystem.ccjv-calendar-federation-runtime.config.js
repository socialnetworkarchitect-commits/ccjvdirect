module.exports = { apps: [{ name: 'ccjv-calendar-federation-runtime-worker', script: './workers/ccjv-calendar-federation-runtime-worker.js' }] };
