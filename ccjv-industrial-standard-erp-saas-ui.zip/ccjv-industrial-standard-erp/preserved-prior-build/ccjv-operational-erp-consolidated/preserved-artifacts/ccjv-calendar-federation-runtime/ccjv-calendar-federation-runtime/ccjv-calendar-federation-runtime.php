<?php
/**
 * Plugin Name: CCJV Calendar Federation Runtime
 * Description: Operational CCJV subsystem package: streaming_calendar, module_events, notifications, treasury_reminders, governance_scheduling, replay_events.
 * Version: 1.0.0
 * Author: CCJV
 */
if (!defined('ABSPATH')) { exit; }
define('CCJV_CALENDARFEDERATIONRUNTIME_PATH', plugin_dir_path(__FILE__));
define('CCJV_CALENDARFEDERATIONRUNTIME_URL', plugin_dir_url(__FILE__));
define('CCJV_CALENDARFEDERATIONRUNTIME_VERSION', '1.0.0');
require_once CCJV_CALENDARFEDERATIONRUNTIME_PATH . 'includes/class-runtime.php';
register_activation_hook(__FILE__, array('CCJV_CalendarFederationRuntime', 'activate'));
register_deactivation_hook(__FILE__, array('CCJV_CalendarFederationRuntime', 'deactivate'));
add_action('plugins_loaded', array('CCJV_CalendarFederationRuntime', 'boot'));
