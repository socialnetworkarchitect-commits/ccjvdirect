const fs = require('fs');
const path = require('path');
const logDir = path.join(__dirname, '..', 'runtime-logs');
if (!fs.existsSync(logDir)) fs.mkdirSync(logDir, { recursive: true });
setInterval(() => {
  const line = JSON.stringify({ runtime: 'ccjv-calendar-federation-runtime', status: 'alive', features: ["streaming_calendar", "module_events", "notifications", "treasury_reminders", "governance_scheduling", "replay_events"], at: new Date().toISOString() }) + '\n';
  fs.appendFileSync(path.join(logDir, 'ccjv-calendar-federation-runtime.log'), line);
  console.log(line.trim());
}, 15000);
