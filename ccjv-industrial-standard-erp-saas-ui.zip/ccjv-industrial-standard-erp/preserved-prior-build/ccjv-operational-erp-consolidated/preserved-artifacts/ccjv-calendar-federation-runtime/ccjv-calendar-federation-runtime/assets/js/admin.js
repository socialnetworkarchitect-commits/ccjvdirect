window.CCJVRuntime = { slug: 'ccjv-calendar-federation-runtime', status: 'loaded' };
