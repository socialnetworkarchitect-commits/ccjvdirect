<?php
/*
Plugin Name: CCJV Access Control Engine (Hard Gate Layer)
Description: Enforces wallet, token, payment, and tenant access before ERP access.
Version: 1.0.0
*/

if (!defined('ABSPATH')) exit;

define('CCJV_ACCESS_ENGINE', true);

add_action('template_redirect', function () {

    $request = trim(parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH), '/');

    if (strpos($request, '-app') !== false) {

        if (!is_user_logged_in()) {
            wp_redirect(wp_login_url(home_url($request)));
            exit;
        }

        $user_id = get_current_user_id();

        $wallet = get_user_meta($user_id, 'ccjv_wallet', true);
        if (!$wallet) {
            wp_redirect(home_url('/connect-wallet'));
            exit;
        }

        $has_token = get_user_meta($user_id, 'ccjv_token_ok', true);
        if (!$has_token) {
            wp_redirect(home_url('/buy-token'));
            exit;
        }

        $paid = get_user_meta($user_id, 'ccjv_paid', true);
        if (!$paid) {
            wp_redirect(home_url('/payment-required'));
            exit;
        }

        $tenant = get_user_meta($user_id, 'ccjv_tenant', true);
        if (!$tenant) {
            wp_redirect(home_url('/create-tenant'));
            exit;
        }
    }
});

add_shortcode('ccjv_connect_wallet', function () {
    if (!is_user_logged_in()) return "<p>Please login first.</p>";

    $user_id = get_current_user_id();

    if (isset($_POST['wallet'])) {
        update_user_meta($user_id, 'ccjv_wallet', sanitize_text_field($_POST['wallet']));
        return "<p>Wallet connected.</p>";
    }

    return '<form method="post">
        <input name="wallet" placeholder="Enter wallet address" />
        <button type="submit">Connect Wallet</button>
    </form>';
});

add_shortcode('ccjv_dashboard_status', function () {
    if (!is_user_logged_in()) return "";

    $user_id = get_current_user_id();

    $wallet = get_user_meta($user_id, 'ccjv_wallet', true);
    $token = get_user_meta($user_id, 'ccjv_token_ok', true);
    $paid = get_user_meta($user_id, 'ccjv_paid', true);

    return "<div>
        <h3>Access Status</h3>
        <p>Wallet: " . ($wallet ? "Connected" : "Missing") . "</p>
        <p>Token: " . ($token ? "OK" : "Missing") . "</p>
        <p>Payment: " . ($paid ? "Paid" : "Unpaid") . "</p>
    </div>";
});
