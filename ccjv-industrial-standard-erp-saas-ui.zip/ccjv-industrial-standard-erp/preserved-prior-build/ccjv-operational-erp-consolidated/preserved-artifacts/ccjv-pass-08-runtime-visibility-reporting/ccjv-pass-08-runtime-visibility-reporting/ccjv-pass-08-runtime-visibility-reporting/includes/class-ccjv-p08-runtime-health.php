<?php
if (!defined('ABSPATH')) { exit; }

class CCJV_P08_Runtime_Health {
    public static function heartbeat(string $source_erp, string $service_key, string $status, array $payload = []): int {
        global $wpdb;
        $score = self::status_score($status);
        $wpdb->insert($wpdb->prefix . 'ccjv_runtime_health', [
            'source_erp' => sanitize_text_field($source_erp),
            'service_key' => sanitize_text_field($service_key),
            'status' => sanitize_text_field($status),
            'health_score' => $score,
            'payload' => wp_json_encode($payload),
            'checked_at' => gmdate('Y-m-d H:i:s'),
        ]);
        return (int) $wpdb->insert_id;
    }

    public static function status_score(string $status): float {
        $map = [
            'healthy' => 100,
            'active' => 95,
            'ok' => 90,
            'degraded' => 60,
            'unknown' => 40,
            'failed' => 0,
            'offline' => 0,
        ];
        return (float)($map[strtolower($status)] ?? 50);
    }

    public static function latest(): array {
        global $wpdb;
        return $wpdb->get_results("SELECT * FROM {$wpdb->prefix}ccjv_runtime_health ORDER BY id DESC LIMIT 300", ARRAY_A);
    }

    public static function compliance_score(string $source_erp, array $signals): float {
        $keys = ['replay','treasury','vault','proof','websocket','observability','reporting'];
        $total = 0;
        foreach ($keys as $key) {
            $total += self::status_score($signals[$key] ?? 'unknown');
        }
        return round($total / count($keys), 2);
    }
}
