<?php
/**
 * Plugin Name: CCJV Pass 08 Runtime Visibility + Reporting Convergence
 * Description: Adds CCJV Core Runtime Visibility: Observability Center, Replay Center, Proof Center, Runtime Health Center, and Universal Data Reporting Registry.
 * Version: 0.8.0
 * Author: CCJV Core
 */

if (!defined('ABSPATH')) { exit; }

define('CCJV_P08_PATH', plugin_dir_path(__FILE__));
define('CCJV_P08_URL', plugin_dir_url(__FILE__));
define('CCJV_P08_VERSION', '0.8.0');

require_once CCJV_P08_PATH . 'includes/class-ccjv-p08-activator.php';
require_once CCJV_P08_PATH . 'includes/class-ccjv-p08-observability.php';
require_once CCJV_P08_PATH . 'includes/class-ccjv-p08-replay.php';
require_once CCJV_P08_PATH . 'includes/class-ccjv-p08-proof.php';
require_once CCJV_P08_PATH . 'includes/class-ccjv-p08-runtime-health.php';
require_once CCJV_P08_PATH . 'includes/class-ccjv-p08-reporting.php';
require_once CCJV_P08_PATH . 'includes/class-ccjv-p08-admin.php';

register_activation_hook(__FILE__, ['CCJV_P08_Activator', 'activate']);

add_action('plugins_loaded', function () {
    CCJV_P08_Admin::boot();
    CCJV_P08_Reporting::boot();
});
