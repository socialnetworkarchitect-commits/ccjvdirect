<?php
if (!defined('ABSPATH')) { exit; }

class CCJV_P08_Admin {
    public static function boot(): void {
        add_action('admin_menu', [__CLASS__, 'menu']);
        add_action('admin_enqueue_scripts', [__CLASS__, 'assets']);
    }

    public static function assets(): void {
        wp_enqueue_style('ccjv-p08-admin', CCJV_P08_URL . 'assets/admin.css', [], CCJV_P08_VERSION);
    }

    public static function menu(): void {
        add_menu_page('CCJV Runtime Centers', 'CCJV Runtime Centers', 'manage_options', 'ccjv-p08-runtime-centers', [__CLASS__, 'runtime_health_page'], 'dashicons-networking', 56);
        add_submenu_page('ccjv-p08-runtime-centers', 'Runtime Health Center', 'Runtime Health Center', 'manage_options', 'ccjv-p08-runtime-centers', [__CLASS__, 'runtime_health_page']);
        add_submenu_page('ccjv-p08-runtime-centers', 'Observability Center', 'Observability Center', 'manage_options', 'ccjv-p08-observability-center', [__CLASS__, 'observability_page']);
        add_submenu_page('ccjv-p08-runtime-centers', 'Replay Center', 'Replay Center', 'manage_options', 'ccjv-p08-replay-center', [__CLASS__, 'replay_page']);
        add_submenu_page('ccjv-p08-runtime-centers', 'Proof Center', 'Proof Center', 'manage_options', 'ccjv-p08-proof-center', [__CLASS__, 'proof_page']);
        add_submenu_page('ccjv-p08-runtime-centers', 'Runtime Reporting Center', 'Runtime Reporting Center', 'manage_options', 'ccjv-p08-reporting-center', [__CLASS__, 'reporting_page']);
    }

    private static function table(array $rows, array $cols): void {
        echo '<table class="widefat striped ccjv-p08-table"><thead><tr>';
        foreach ($cols as $key => $label) { echo '<th>' . esc_html($label) . '</th>'; }
        echo '</tr></thead><tbody>';
        foreach ($rows as $row) {
            echo '<tr>';
            foreach ($cols as $key => $label) {
                echo '<td><code>' . esc_html((string)($row[$key] ?? '')) . '</code></td>';
            }
            echo '</tr>';
        }
        echo '</tbody></table>';
    }

    public static function runtime_health_page(): void {
        echo '<div class="wrap ccjv-p08"><h1>CCJV Runtime Health Center</h1>';
        echo '<p>One Runtime Health Model across all ERPs.</p>';
        self::table(CCJV_P08_Runtime_Health::latest(), [
            'source_erp' => 'ERP',
            'service_key' => 'Service',
            'status' => 'Status',
            'health_score' => 'Score',
            'checked_at' => 'Checked'
        ]);
        echo '</div>';
    }

    public static function observability_page(): void {
        echo '<div class="wrap ccjv-p08"><h1>CCJV Observability Center</h1>';
        echo '<p>One Observability Model: correlation, trace, lineage, replay, treasury, vault, and anchor references.</p>';
        self::table(CCJV_P08_Observability::latest($_GET), [
            'source_erp' => 'ERP',
            'operation' => 'Operation',
            'trace_id' => 'Trace',
            'correlation_id' => 'Correlation',
            'lineage_id' => 'Lineage',
            'status' => 'Status',
            'created_at' => 'Created'
        ]);
        echo '</div>';
    }

    public static function replay_page(): void {
        echo '<div class="wrap ccjv-p08"><h1>CCJV Replay Center</h1>';
        echo '<p>One Replay Visibility Model across CCJV and all ERPs.</p>';
        self::table(CCJV_P08_Replay::search($_GET), [
            'source_erp' => 'ERP',
            'replay_position' => 'Position',
            'event_type' => 'Event',
            'correlation_id' => 'Correlation',
            'lineage_id' => 'Lineage',
            'created_at' => 'Created'
        ]);
        echo '</div>';
    }

    public static function proof_page(): void {
        echo '<div class="wrap ccjv-p08"><h1>CCJV Proof Center</h1>';
        echo '<p>One Proof Visibility Model: proof, anchor, Merkle, and verification lineage.</p>';
        self::table(CCJV_P08_Proof::search($_GET), [
            'source_erp' => 'ERP',
            'proof_id' => 'Proof',
            'record_id' => 'Record',
            'object_hash' => 'Hash',
            'merkle_root' => 'Merkle',
            'tx_hash' => 'TX',
            'verification_status' => 'Status',
            'created_at' => 'Created'
        ]);
        echo '</div>';
    }

    public static function reporting_page(): void {
        global $wpdb;
        echo '<div class="wrap ccjv-p08"><h1>CCJV Runtime Reporting Center</h1>';
        echo '<p>One Reporting Model. Upload ERP AI Runtime Packets here.</p>';
        echo '<form method="post" enctype="multipart/form-data" action="' . esc_url(admin_url('admin-post.php')) . '">';
        wp_nonce_field(CCJV_P08_Reporting::NONCE);
        echo '<input type="hidden" name="action" value="ccjv_p08_upload_runtime_packet" />';
        echo '<input type="file" name="runtime_packet" accept=".zip" required /> ';
        echo '<button class="button button-primary">Upload Runtime Packet</button>';
        echo '</form><hr />';
        $rows = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}ccjv_runtime_packets ORDER BY id DESC LIMIT 100", ARRAY_A);
        self::table($rows, [
            'source_erp' => 'ERP',
            'packet_name' => 'Packet',
            'packet_hash' => 'Hash',
            'compliance_score' => 'Score',
            'replay_status' => 'Replay',
            'treasury_status' => 'Treasury',
            'vault_status' => 'Vault',
            'proof_status' => 'Proof',
            'observability_status' => 'Observability',
            'created_at' => 'Created'
        ]);
        echo '</div>';
    }
}
