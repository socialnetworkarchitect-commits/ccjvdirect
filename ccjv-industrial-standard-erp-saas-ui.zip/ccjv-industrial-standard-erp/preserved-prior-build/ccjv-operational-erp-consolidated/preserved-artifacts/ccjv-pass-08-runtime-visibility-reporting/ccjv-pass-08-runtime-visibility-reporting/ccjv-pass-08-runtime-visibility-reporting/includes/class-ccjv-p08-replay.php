<?php
if (!defined('ABSPATH')) { exit; }

class CCJV_P08_Replay {
    public static function ingest(array $event): int {
        global $wpdb;
        $row = [
            'source_erp' => $event['source_erp'] ?? 'ccjv',
            'tenant_id' => $event['tenant_id'] ?? null,
            'workspace_id' => $event['workspace_id'] ?? null,
            'replay_position' => $event['replay_position'] ?? null,
            'event_type' => $event['event_type'] ?? null,
            'correlation_id' => $event['correlation_id'] ?? null,
            'lineage_id' => $event['lineage_id'] ?? null,
            'replay_reference' => $event['replay_reference'] ?? null,
            'event_payload' => wp_json_encode($event),
            'created_at' => gmdate('Y-m-d H:i:s'),
        ];
        $wpdb->insert($wpdb->prefix . 'ccjv_replay_visibility', $row);
        return (int) $wpdb->insert_id;
    }

    public static function search(array $filters = []): array {
        global $wpdb;
        $where = ['1=1'];
        $params = [];

        foreach (['source_erp','tenant_id','workspace_id','event_type','correlation_id','lineage_id'] as $field) {
            if (!empty($filters[$field])) {
                $where[] = "$field = %s";
                $params[] = sanitize_text_field($filters[$field]);
            }
        }

        $sql = "SELECT * FROM {$wpdb->prefix}ccjv_replay_visibility WHERE " . implode(' AND ', $where) . " ORDER BY replay_position DESC, id DESC LIMIT 300";
        return $params ? $wpdb->get_results($wpdb->prepare($sql, $params), ARRAY_A) : $wpdb->get_results($sql, ARRAY_A);
    }
}
