<?php
if (!defined('ABSPATH')) { exit; }

class CCJV_P08_Observability {
    public static function trace(string $operation, array $context = []): array {
        global $wpdb;

        $trace = [
            'trace_id' => $context['trace_id'] ?? wp_generate_uuid4(),
            'correlation_id' => $context['correlation_id'] ?? wp_generate_uuid4(),
            'lineage_id' => $context['lineage_id'] ?? wp_generate_uuid4(),
            'source_erp' => $context['source_erp'] ?? 'ccjv',
            'tenant_id' => $context['tenant_id'] ?? null,
            'workspace_id' => $context['workspace_id'] ?? null,
            'operation' => $operation,
            'replay_reference' => $context['replay_reference'] ?? null,
            'treasury_reference' => $context['treasury_reference'] ?? null,
            'vault_reference' => $context['vault_reference'] ?? null,
            'anchor_reference' => $context['anchor_reference'] ?? null,
            'status' => $context['status'] ?? 'recorded',
            'payload' => wp_json_encode($context),
            'created_at' => gmdate('Y-m-d H:i:s'),
        ];

        $wpdb->insert($wpdb->prefix . 'ccjv_observability_traces', $trace);
        update_option('ccjv_last_trace_id', $trace['trace_id']);

        return $trace;
    }

    public static function latest(array $filters = []): array {
        global $wpdb;
        $where = ['1=1'];
        $params = [];

        foreach (['source_erp', 'correlation_id', 'lineage_id', 'status'] as $field) {
            if (!empty($filters[$field])) {
                $where[] = "$field = %s";
                $params[] = sanitize_text_field($filters[$field]);
            }
        }

        $sql = "SELECT * FROM {$wpdb->prefix}ccjv_observability_traces WHERE " . implode(' AND ', $where) . " ORDER BY id DESC LIMIT 250";
        return $params ? $wpdb->get_results($wpdb->prepare($sql, $params), ARRAY_A) : $wpdb->get_results($sql, ARRAY_A);
    }
}
