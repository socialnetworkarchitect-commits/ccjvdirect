<?php
if (!defined('ABSPATH')) { exit; }

class CCJV_P08_Proof {
    public static function ingest(array $proof): int {
        global $wpdb;
        $row = [
            'source_erp' => $proof['source_erp'] ?? 'ccjv',
            'tenant_id' => $proof['tenant_id'] ?? null,
            'workspace_id' => $proof['workspace_id'] ?? null,
            'proof_id' => $proof['proof_id'] ?? null,
            'record_id' => $proof['record_id'] ?? null,
            'object_hash' => $proof['object_hash'] ?? ($proof['hash'] ?? null),
            'merkle_root' => $proof['merkle_root'] ?? null,
            'tx_hash' => $proof['tx_hash'] ?? null,
            'block_number' => $proof['block_number'] ?? null,
            'verification_status' => $proof['verification_status'] ?? ($proof['status'] ?? 'unknown'),
            'proof_payload' => wp_json_encode($proof),
            'created_at' => gmdate('Y-m-d H:i:s'),
        ];
        $wpdb->insert($wpdb->prefix . 'ccjv_proof_visibility', $row);
        return (int) $wpdb->insert_id;
    }

    public static function search(array $filters = []): array {
        global $wpdb;
        $where = ['1=1'];
        $params = [];

        foreach (['source_erp','tenant_id','workspace_id','proof_id','record_id','tx_hash','object_hash'] as $field) {
            if (!empty($filters[$field])) {
                $where[] = "$field = %s";
                $params[] = sanitize_text_field($filters[$field]);
            }
        }

        $sql = "SELECT * FROM {$wpdb->prefix}ccjv_proof_visibility WHERE " . implode(' AND ', $where) . " ORDER BY id DESC LIMIT 300";
        return $params ? $wpdb->get_results($wpdb->prepare($sql, $params), ARRAY_A) : $wpdb->get_results($sql, ARRAY_A);
    }
}
