<?php
if (!defined('ABSPATH')) { exit; }

class CCJV_P08_Activator {
    public static function activate(): void {
        global $wpdb;
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        $charset = $wpdb->get_charset_collate();

        $sql = [];

        $sql[] = "CREATE TABLE {$wpdb->prefix}ccjv_observability_traces (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            trace_id VARCHAR(96) NOT NULL,
            correlation_id VARCHAR(96) NOT NULL,
            lineage_id VARCHAR(96) NOT NULL,
            source_erp VARCHAR(96) NULL,
            tenant_id VARCHAR(96) NULL,
            workspace_id VARCHAR(96) NULL,
            operation VARCHAR(191) NOT NULL,
            replay_reference VARCHAR(191) NULL,
            treasury_reference VARCHAR(191) NULL,
            vault_reference VARCHAR(191) NULL,
            anchor_reference VARCHAR(191) NULL,
            status VARCHAR(64) NOT NULL DEFAULT 'recorded',
            payload LONGTEXT NULL,
            created_at DATETIME NOT NULL,
            PRIMARY KEY (id),
            KEY trace_id (trace_id),
            KEY correlation_id (correlation_id),
            KEY lineage_id (lineage_id),
            KEY source_erp (source_erp)
        ) $charset;";

        $sql[] = "CREATE TABLE {$wpdb->prefix}ccjv_runtime_health (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            source_erp VARCHAR(96) NOT NULL,
            service_key VARCHAR(96) NOT NULL,
            status VARCHAR(64) NOT NULL,
            health_score DECIMAL(5,2) NULL,
            payload LONGTEXT NULL,
            checked_at DATETIME NOT NULL,
            PRIMARY KEY (id),
            KEY source_erp (source_erp),
            KEY service_key (service_key),
            KEY status (status)
        ) $charset;";

        $sql[] = "CREATE TABLE {$wpdb->prefix}ccjv_runtime_packets (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            source_erp VARCHAR(96) NOT NULL,
            packet_name VARCHAR(191) NOT NULL,
            packet_hash VARCHAR(128) NULL,
            compliance_score DECIMAL(5,2) NULL,
            replay_status VARCHAR(64) NULL,
            treasury_status VARCHAR(64) NULL,
            vault_status VARCHAR(64) NULL,
            proof_status VARCHAR(64) NULL,
            observability_status VARCHAR(64) NULL,
            packet_payload LONGTEXT NULL,
            created_at DATETIME NOT NULL,
            PRIMARY KEY (id),
            KEY source_erp (source_erp),
            KEY packet_hash (packet_hash)
        ) $charset;";

        $sql[] = "CREATE TABLE {$wpdb->prefix}ccjv_replay_visibility (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            source_erp VARCHAR(96) NULL,
            tenant_id VARCHAR(96) NULL,
            workspace_id VARCHAR(96) NULL,
            replay_position BIGINT NULL,
            event_type VARCHAR(191) NULL,
            correlation_id VARCHAR(96) NULL,
            lineage_id VARCHAR(96) NULL,
            replay_reference VARCHAR(191) NULL,
            event_payload LONGTEXT NULL,
            created_at DATETIME NOT NULL,
            PRIMARY KEY (id),
            KEY source_erp (source_erp),
            KEY replay_position (replay_position),
            KEY correlation_id (correlation_id),
            KEY lineage_id (lineage_id),
            KEY event_type (event_type)
        ) $charset;";

        $sql[] = "CREATE TABLE {$wpdb->prefix}ccjv_proof_visibility (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            source_erp VARCHAR(96) NULL,
            tenant_id VARCHAR(96) NULL,
            workspace_id VARCHAR(96) NULL,
            proof_id VARCHAR(191) NULL,
            record_id VARCHAR(191) NULL,
            object_hash VARCHAR(128) NULL,
            merkle_root VARCHAR(128) NULL,
            tx_hash VARCHAR(191) NULL,
            block_number VARCHAR(64) NULL,
            verification_status VARCHAR(64) NULL,
            proof_payload LONGTEXT NULL,
            created_at DATETIME NOT NULL,
            PRIMARY KEY (id),
            KEY source_erp (source_erp),
            KEY proof_id (proof_id),
            KEY tx_hash (tx_hash),
            KEY object_hash (object_hash)
        ) $charset;";

        $sql[] = "CREATE TABLE {$wpdb->prefix}ccjv_runtime_scores (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            source_erp VARCHAR(96) NOT NULL,
            replay_score DECIMAL(5,2) NULL,
            treasury_score DECIMAL(5,2) NULL,
            vault_score DECIMAL(5,2) NULL,
            proof_score DECIMAL(5,2) NULL,
            websocket_score DECIMAL(5,2) NULL,
            observability_score DECIMAL(5,2) NULL,
            reporting_score DECIMAL(5,2) NULL,
            total_score DECIMAL(5,2) NULL,
            score_payload LONGTEXT NULL,
            scored_at DATETIME NOT NULL,
            PRIMARY KEY (id),
            KEY source_erp (source_erp),
            KEY total_score (total_score)
        ) $charset;";

        foreach ($sql as $statement) {
            dbDelta($statement);
        }

        update_option('ccjv_pass_08_installed', 'yes');
        update_option('ccjv_pass_08_version', CCJV_P08_VERSION);
    }
}
