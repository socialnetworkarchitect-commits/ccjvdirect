<?php
if (!defined('ABSPATH')) { exit; }

class CCJV_P08_Reporting {
    const NONCE = 'ccjv_p08_runtime_packet_nonce';

    public static function boot(): void {
        add_action('admin_post_ccjv_p08_upload_runtime_packet', [__CLASS__, 'upload_packet']);
    }

    public static function upload_packet(): void {
        if (!current_user_can('manage_options')) { wp_die('Unauthorized'); }
        check_admin_referer(self::NONCE);

        if (empty($_FILES['runtime_packet']['tmp_name'])) {
            wp_die('No runtime packet uploaded.');
        }

        $tmp = $_FILES['runtime_packet']['tmp_name'];
        $name = sanitize_file_name($_FILES['runtime_packet']['name']);
        $hash = hash_file('sha256', $tmp);
        $payload = ['files' => [], 'ingested_at' => gmdate('c')];

        $zip = new ZipArchive();
        if ($zip->open($tmp) === true) {
            for ($i = 0; $i < $zip->numFiles; $i++) {
                $stat = $zip->statIndex($i);
                $fname = $stat['name'];
                $raw = $zip->getFromIndex($i);
                if (substr($fname, -5) === '.json') {
                    $payload['files'][$fname] = json_decode($raw, true);
                } else {
                    $payload['files'][$fname] = substr($raw, 0, 2000);
                }
            }
            $zip->close();
        }

        $source_erp = $payload['files']['runtime-health.json']['erp_slug'] ?? $payload['files']['runtime-health.json']['erp'] ?? 'unknown';
        $statuses = [
            'replay' => $payload['files']['replay-summary.json']['status'] ?? 'unknown',
            'treasury' => $payload['files']['treasury-status.json']['status'] ?? 'unknown',
            'vault' => $payload['files']['vault-status.json']['status'] ?? 'unknown',
            'proof' => $payload['files']['proof-status.json']['status'] ?? 'unknown',
            'websocket' => $payload['files']['websocket-health.json']['status'] ?? 'unknown',
            'observability' => $payload['files']['observability-summary.json']['status'] ?? 'unknown',
            'reporting' => 'active',
        ];
        $score = CCJV_P08_Runtime_Health::compliance_score($source_erp, $statuses);

        global $wpdb;
        $wpdb->insert($wpdb->prefix . 'ccjv_runtime_packets', [
            'source_erp' => sanitize_text_field($source_erp),
            'packet_name' => $name,
            'packet_hash' => $hash,
            'compliance_score' => $score,
            'replay_status' => $statuses['replay'],
            'treasury_status' => $statuses['treasury'],
            'vault_status' => $statuses['vault'],
            'proof_status' => $statuses['proof'],
            'observability_status' => $statuses['observability'],
            'packet_payload' => wp_json_encode($payload),
            'created_at' => gmdate('Y-m-d H:i:s'),
        ]);

        wp_safe_redirect(admin_url('admin.php?page=ccjv-p08-reporting-center&uploaded=1'));
        exit;
    }
}
