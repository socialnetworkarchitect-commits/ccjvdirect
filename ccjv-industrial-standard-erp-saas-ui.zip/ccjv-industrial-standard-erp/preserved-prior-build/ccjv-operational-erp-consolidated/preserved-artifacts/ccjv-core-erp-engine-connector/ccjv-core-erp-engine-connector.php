<?php
/*
Plugin Name: CCJV Core ERP Engine Connector
Description: Connects Core ERP Engine to wallet, token gate, payment enforcement, and dashboard access.
Version: 1.0.0
Author: OpenAI
*/

if (!defined('ABSPATH')) exit;

/*
 * Soft requirements only. We extend the existing stack; we do not replace it.
 */
if (!defined('CCJV_CORE_ACTIVE') && !function_exists('ccjv_core_loaded')) {
    add_action('admin_notices', function () {
        echo '<div class="notice notice-error"><p><strong>CCJV Core ERP Engine Connector</strong> requires the CCJV core stack.</p></div>';
    });
    return;
}

/*
 * Register core ERP modules in the normalized ERP registry so the dashboard can see them.
 */
add_action('init', function () {
    $modules = [
        'crm'        => ['name' => 'Core CRM', 'token' => 'CJV', 'portal_slug' => 'core-crm-portal', 'app_slug' => 'core-crm-app'],
        'hrm'        => ['name' => 'Core HRM', 'token' => 'CJV', 'portal_slug' => 'core-hrm-portal', 'app_slug' => 'core-hrm-app'],
        'accounting' => ['name' => 'Core Accounting', 'token' => 'CJV', 'portal_slug' => 'core-accounting-portal', 'app_slug' => 'core-accounting-app'],
        'project'    => ['name' => 'Core Project Management', 'token' => 'CJV', 'portal_slug' => 'core-project-portal', 'app_slug' => 'core-project-app'],
        'asset'      => ['name' => 'Core Asset Management', 'token' => 'CJV', 'portal_slug' => 'core-asset-portal', 'app_slug' => 'core-asset-app'],
    ];

    foreach ($modules as $key => $config) {
        if (function_exists('ccjvx_register_erp')) {
            ccjvx_register_erp($key, $config);
        }
        if (function_exists('ccjv_register_erp')) {
            ccjv_register_erp($key, $config['name'], $config['token']);
        }
    }
}, 40);

/*
 * Central helper: active wallet + token + payment + tenant checks for core modules.
 */
function ccjv_core_module_access_state($module_key, $user_id = 0) {
    if (!$user_id) $user_id = get_current_user_id();

    $wallet = get_user_meta($user_id, 'ccjv_wallet', true);
    $tenant = get_user_meta($user_id, 'ccjv_tenant', true);

    $signer = get_option('ccjv_signer_url', 'http://localhost:3001');
    $gate = (float) get_option('ccjv_gate_CJV', 1);
    $balance = 0;

    if ($wallet) {
        $url = untrailingslashit($signer) . '/balance?wallet=' . rawurlencode($wallet) . '&token=CJV';
        $response = wp_remote_get($url, ['timeout' => 5]);
        if (!is_wp_error($response)) {
            $body = json_decode(wp_remote_retrieve_body($response), true);
            $balance = (float) ($body['balance'] ?? 0);
        }
    }

    $has_token = $wallet && ($balance >= $gate);

    $paid = false;
    if (function_exists('ccjv_payment_user_has_access')) {
        $paid = ccjv_payment_user_has_access($user_id, $module_key);
    } else {
        global $wpdb;
        $table = $wpdb->prefix . 'ccjv_subscriptions_x';
        $row = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$table} WHERE user_id=%d AND erp_key=%s LIMIT 1",
            $user_id, $module_key
        ));
        if ($row && $row->status === 'active' && !empty($row->paid_until) && strtotime($row->paid_until) >= current_time('timestamp')) {
            $paid = true;
        }
    }

    return [
        'wallet' => !empty($wallet),
        'wallet_address' => $wallet ?: '',
        'tenant' => !empty($tenant),
        'tenant_value' => $tenant ?: '',
        'balance' => $balance,
        'gate' => $gate,
        'has_token' => $has_token,
        'paid' => $paid,
        'allowed' => (!empty($wallet) && !empty($tenant) && $has_token && $paid),
    ];
}

/*
 * Hard access enforcement for core module app routes.
 */
add_action('template_redirect', function () {
    $path = trim(parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH), '/');

    $map = [
        'core-crm-app' => 'crm',
        'core-hrm-app' => 'hrm',
        'core-accounting-app' => 'accounting',
        'core-project-app' => 'project',
        'core-asset-app' => 'asset',
    ];

    if (!isset($map[$path])) return;

    if (!is_user_logged_in()) {
        wp_redirect(wp_login_url(home_url('/' . $path)));
        exit;
    }

    $module_key = $map[$path];
    $state = ccjv_core_module_access_state($module_key);

    if (!$state['wallet']) {
        wp_redirect(home_url('/connect-wallet'));
        exit;
    }

    if (!$state['has_token']) {
        wp_redirect(home_url('/buy-token'));
        exit;
    }

    if (!$state['paid']) {
        wp_redirect(home_url('/payment-required'));
        exit;
    }

    if (!$state['tenant']) {
        wp_redirect(home_url('/create-tenant'));
        exit;
    }
}, 20);

/*
 * Shared portal renderer for core modules.
 */
function ccjv_render_core_module_portal($module_key, $label) {
    if (!is_user_logged_in()) {
        return '<div class="ccjv-core-module-wrap"><p>Please log in to continue.</p></div>';
    }

    $state = ccjv_core_module_access_state($module_key);
    $buy_text = get_option('ccjv_cta_buy_text', 'Get Required Token');
    $enter_text = get_option('ccjv_cta_enter_text', 'Enter ERP');
    $inactive_text = get_option('ccjv_cta_inactive_text', 'Access inactive');
    $active_text = get_option('ccjv_cta_active_text', 'Access active');

    $app_slug = 'core-' . $module_key . '-app';

    ob_start(); ?>
    <div class="ccjv-core-module-wrap" style="max-width:960px;margin:0 auto;padding:24px;">
        <div style="border:1px solid #ddd;border-radius:16px;padding:24px;background:#fff;">
            <h2 style="margin-top:0;"><?php echo esc_html($label); ?> Portal</h2>
            <p>Core module access requires 1 CJV token gate and an active monthly module subscription.</p>

            <p><strong>Wallet:</strong> <?php echo $state['wallet_address'] ? esc_html($state['wallet_address']) : 'Not connected'; ?></p>
            <p><strong>Tenant:</strong> <?php echo $state['tenant_value'] ? esc_html($state['tenant_value']) : 'Not created'; ?></p>
            <p><strong>CJV Balance:</strong> <?php echo esc_html((string)$state['balance']); ?></p>
            <p><strong>Required Gate:</strong> <?php echo esc_html((string)$state['gate']); ?> CJV</p>

            <?php if (!$state['allowed']): ?>
                <div style="padding:14px;border-radius:12px;background:#fff7ed;border:1px solid #fdba74;margin:18px 0;">
                    <strong><?php echo esc_html($inactive_text); ?></strong><br>
                    Complete wallet, token, tenant, and payment checks before entering the module.
                </div>

                <?php if (shortcode_exists('ccjv_wallet_button')): ?>
                    <div style="margin:16px 0;"><?php echo do_shortcode('[ccjv_wallet_button]'); ?></div>
                <?php endif; ?>

                <p>
                    <a href="<?php echo esc_url(home_url('/buy-token')); ?>" class="button"><?php echo esc_html($buy_text); ?> (CJV)</a>
                    <a href="<?php echo esc_url(home_url('/payment-required')); ?>" class="button button-secondary" style="margin-left:8px;">Resolve Payment</a>
                </p>
            <?php else: ?>
                <div style="padding:14px;border-radius:12px;background:#ecfdf5;border:1px solid #86efac;margin:18px 0;">
                    <strong><?php echo esc_html($active_text); ?></strong><br>
                    Your wallet, token, tenant, and payment checks passed.
                </div>

                <p>
                    <a href="<?php echo esc_url(home_url('/' . $app_slug)); ?>" class="button button-primary"><?php echo esc_html($enter_text); ?></a>
                </p>
            <?php endif; ?>

            <?php if (shortcode_exists('ccjv_subscription_status')): ?>
                <div style="margin-top:20px;">
                    <?php echo do_shortcode('[ccjv_subscription_status erp="' . esc_attr($module_key) . '"]'); ?>
                </div>
            <?php endif; ?>
        </div>
    </div>
    <?php
    return ob_get_clean();
}

/*
 * Core module shortcodes.
 */
add_shortcode('ccjv_core_crm_portal', function () {
    return ccjv_render_core_module_portal('crm', 'Core CRM');
});
add_shortcode('ccjv_core_hrm_portal', function () {
    return ccjv_render_core_module_portal('hrm', 'Core HRM');
});
add_shortcode('ccjv_core_accounting_portal', function () {
    return ccjv_render_core_module_portal('accounting', 'Core Accounting');
});
add_shortcode('ccjv_core_project_portal', function () {
    return ccjv_render_core_module_portal('project', 'Core Project Management');
});
add_shortcode('ccjv_core_asset_portal', function () {
    return ccjv_render_core_module_portal('asset', 'Core Asset Management');
});

add_shortcode('ccjv_core_crm_app', function () {
    $state = ccjv_core_module_access_state('crm');
    if (!$state['allowed']) return '<p>Access denied.</p>';
    return '<div style="padding:24px"><h2>Core CRM</h2><p>Core CRM working area connected to the Core ERP Engine.</p></div>';
});
add_shortcode('ccjv_core_hrm_app', function () {
    $state = ccjv_core_module_access_state('hrm');
    if (!$state['allowed']) return '<p>Access denied.</p>';
    return '<div style="padding:24px"><h2>Core HRM</h2><p>Core HRM working area connected to the Core ERP Engine.</p></div>';
});
add_shortcode('ccjv_core_accounting_app', function () {
    $state = ccjv_core_module_access_state('accounting');
    if (!$state['allowed']) return '<p>Access denied.</p>';
    return do_shortcode('[ccjv_core_dashboard]');
});
add_shortcode('ccjv_core_project_app', function () {
    $state = ccjv_core_module_access_state('project');
    if (!$state['allowed']) return '<p>Access denied.</p>';
    return '<div style="padding:24px"><h2>Core Project Management</h2><p>Core project management working area connected to the Core ERP Engine.</p></div>';
});
add_shortcode('ccjv_core_asset_app', function () {
    $state = ccjv_core_module_access_state('asset');
    if (!$state['allowed']) return '<p>Access denied.</p>';
    return '<div style="padding:24px"><h2>Core Asset Management</h2><p>Core asset management working area connected to the Core ERP Engine.</p></div>';
});

/*
 * Front-end launcher for core ERP modules.
 */
add_shortcode('ccjv_core_module_launcher', function () {
    if (!is_user_logged_in()) return '<p>Please log in.</p>';

    $modules = [
        'crm' => ['label' => 'Core CRM', 'portal' => '/core-crm-portal'],
        'hrm' => ['label' => 'Core HRM', 'portal' => '/core-hrm-portal'],
        'accounting' => ['label' => 'Core Accounting', 'portal' => '/core-accounting-portal'],
        'project' => ['label' => 'Core Project Management', 'portal' => '/core-project-portal'],
        'asset' => ['label' => 'Core Asset Management', 'portal' => '/core-asset-portal'],
    ];

    ob_start(); ?>
    <div class="ccjv-grid">
        <?php foreach ($modules as $key => $module):
            $state = ccjv_core_module_access_state($key); ?>
            <div class="ccjv-card">
                <h3><?php echo esc_html($module['label']); ?></h3>
                <p>Wallet: <?php echo $state['wallet'] ? 'OK' : 'Missing'; ?></p>
                <p>Token: <?php echo $state['has_token'] ? 'OK' : 'Missing'; ?></p>
                <p>Payment: <?php echo $state['paid'] ? 'OK' : 'Missing'; ?></p>
                <p>Tenant: <?php echo $state['tenant'] ? 'OK' : 'Missing'; ?></p>
                <div class="ccjv-actions">
                    <a class="button" href="<?php echo esc_url(home_url($module['portal'])); ?>">Open Portal</a>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
    <?php return ob_get_clean();
});

/*
 * Admin page for quick visibility
 */
add_action('admin_menu', function () {
    add_submenu_page(
        'ccjv',
        'Core ERP Connector',
        'Core ERP Connector',
        'manage_options',
        'ccjv-core-erp-connector',
        function () {
            echo '<div class="wrap"><h1>Core ERP Engine Connector</h1>';
            echo '<p>This layer connects the Core ERP Engine to wallet, token gate, payment enforcement, and the front-end launcher.</p>';
            echo '<ul>';
            echo '<li>Core CRM Portal shortcode: <code>[ccjv_core_crm_portal]</code></li>';
            echo '<li>Core HRM Portal shortcode: <code>[ccjv_core_hrm_portal]</code></li>';
            echo '<li>Core Accounting Portal shortcode: <code>[ccjv_core_accounting_portal]</code></li>';
            echo '<li>Core Project Portal shortcode: <code>[ccjv_core_project_portal]</code></li>';
            echo '<li>Core Asset Portal shortcode: <code>[ccjv_core_asset_portal]</code></li>';
            echo '<li>Core launcher shortcode: <code>[ccjv_core_module_launcher]</code></li>';
            echo '</ul></div>';
        }
    );
}, 80);
