<?php
/**
 * Plugin Name: CCJV Unified Core X
 * Description: Core X unified ERP system with identity, tenant, venture, and ERP registry.
 * Version: 1.0.0
 */

if (!defined('ABSPATH')) exit;

add_shortcode('ccjvx_shell', function() {
    return '<div style="padding:20px;font-size:20px;">CCJV Core X Shell Active</div>';
});

add_shortcode('ccjvx_account', function() {
    return '<div style="padding:20px;">Account Dashboard</div>';
});

add_shortcode('ccjvx_tenant', function() {
    return '<div style="padding:20px;">Tenant Dashboard</div>';
});

add_shortcode('ccjvx_vault', function() {
    return '<div style="padding:20px;">Vault Panel</div>';
});

add_action('admin_menu', function() {
    add_menu_page('CCJV Core X', 'CCJV Core X', 'manage_options', 'ccjvx', function() {
        echo '<h1>CCJV Core X Active</h1>';
    });
});
