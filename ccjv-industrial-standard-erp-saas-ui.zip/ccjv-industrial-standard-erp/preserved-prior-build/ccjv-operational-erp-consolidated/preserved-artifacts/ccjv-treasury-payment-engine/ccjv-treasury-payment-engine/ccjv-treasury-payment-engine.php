<?php
/**
 * Plugin Name: CCJV Treasury Payment Engine
 * Description: Autonomous treasury-payment engine for CCJV. Handles wallet challenge verification, Avalanche payment synchronization, module subscriptions, and treasury payment records.
 * Version: 1.0.0
 * Author: OpenAI
 */

if (!defined('ABSPATH')) exit;

class CCJVTreasuryPaymentEngine {
    const VERSION = '1.0.0';
    const CHALLENGE_TABLE = 'ccjv_wallet_challenges';
    const PAYMENT_TABLE = 'ccjv_treasury_payments';
    const SUB_TABLE = 'ccjv_module_subscriptions';
    const WORKSPACE_TABLE = 'ccjv_treasury_workspaces';
    const MODULE_TABLE = 'ccjv_treasury_modules';
    const SYNC_OPTION = 'ccjv_treasury_last_synced_block';
    const SETTINGS_OPTION = 'ccjv_treasury_settings';
    const RECOVER_SELECTOR = '5a76f1cf';
    const PAYMENT_STATUS_SELECTOR = '36dd4744';
    const PAYMENT_EVENT_TOPIC0 = '0x73da3c53a559cd1a84a5c26d2af5307a111b5d2edfc0ec3ea3eedfb5d9bdabd1';

    public function __construct() {
        register_activation_hook(__FILE__, [$this, 'activate']);
        add_action('admin_menu', [$this, 'admin_menu']);
        add_action('admin_init', [$this, 'register_settings']);
        add_action('rest_api_init', [$this, 'register_rest']);
        add_action('wp_enqueue_scripts', [$this, 'enqueue_assets']);
        add_shortcode('ccjv_treasury_portal', [$this, 'portal_shortcode']);
        add_action('ccjv_treasury_sync_event', [$this, 'sync_chain_payments']);
        add_filter('cron_schedules', [$this, 'cron_schedules']);
        if (!wp_next_scheduled('ccjv_treasury_sync_event')) {
            wp_schedule_event(time() + 60, 'ccjv_five_minutes', 'ccjv_treasury_sync_event');
        }
    }

    public function cron_schedules($schedules) {
        $schedules['ccjv_five_minutes'] = [
            'interval' => 300,
            'display' => 'Every 5 Minutes'
        ];
        return $schedules;
    }

    public static function settings() {
        $defaults = [
            'rpc_url' => 'https://api.avax.network/ext/bc/C/rpc',
            'chain_id_hex' => '0xa86a',
            'chain_name' => 'Avalanche C-Chain',
            'native_symbol' => 'AVAX',
            'block_explorer' => 'https://snowtrace.io',
            'treasury_contract' => '',
            'verifier_contract' => '',
            'treasury_wallet' => '',
            'core_token_symbol' => 'CJV',
            'buy_direct_url' => 'https://xmarkets.ca',
        ];
        return wp_parse_args(get_option(self::SETTINGS_OPTION, []), $defaults);
    }

    public function activate() {
        global $wpdb;
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        $charset = $wpdb->get_charset_collate();
        $challenge = $wpdb->prefix . self::CHALLENGE_TABLE;
        $payments = $wpdb->prefix . self::PAYMENT_TABLE;
        $subs = $wpdb->prefix . self::SUB_TABLE;
        $workspaces = $wpdb->prefix . self::WORKSPACE_TABLE;
        $modules = $wpdb->prefix . self::MODULE_TABLE;

        dbDelta("CREATE TABLE $challenge (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            wallet_address VARCHAR(64) NOT NULL,
            nonce VARCHAR(128) NOT NULL,
            message TEXT NOT NULL,
            verified TINYINT(1) NOT NULL DEFAULT 0,
            created_at DATETIME NOT NULL,
            expires_at DATETIME NOT NULL,
            PRIMARY KEY (id),
            KEY wallet_address (wallet_address)
        ) $charset;");

        dbDelta("CREATE TABLE $workspaces (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            slug VARCHAR(64) NOT NULL,
            name VARCHAR(128) NOT NULL,
            token_symbol VARCHAR(32) NOT NULL,
            token_address VARCHAR(64) NOT NULL,
            token_decimals INT NOT NULL DEFAULT 18,
            gate_token_amount DECIMAL(36,18) NOT NULL DEFAULT 1,
            monthly_element_fee DECIMAL(36,18) NOT NULL DEFAULT 1,
            active TINYINT(1) NOT NULL DEFAULT 1,
            created_at DATETIME NOT NULL,
            PRIMARY KEY (id),
            UNIQUE KEY slug (slug)
        ) $charset;");

        dbDelta("CREATE TABLE $modules (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            workspace_slug VARCHAR(64) NOT NULL,
            module_key VARCHAR(64) NOT NULL,
            module_name VARCHAR(128) NOT NULL,
            active TINYINT(1) NOT NULL DEFAULT 1,
            created_at DATETIME NOT NULL,
            PRIMARY KEY (id),
            UNIQUE KEY ws_module (workspace_slug, module_key)
        ) $charset;");

        dbDelta("CREATE TABLE $payments (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            tx_hash VARCHAR(90) NOT NULL,
            payer_wallet VARCHAR(64) NOT NULL,
            workspace_slug VARCHAR(64) NOT NULL,
            module_key VARCHAR(64) NOT NULL,
            periods INT NOT NULL DEFAULT 1,
            amount_raw VARCHAR(120) NOT NULL,
            amount_display DECIMAL(36,18) NOT NULL DEFAULT 0,
            paid_until DATETIME NULL,
            status VARCHAR(32) NOT NULL DEFAULT 'pending',
            block_number BIGINT UNSIGNED NULL,
            event_index INT NULL,
            created_at DATETIME NOT NULL,
            updated_at DATETIME NOT NULL,
            PRIMARY KEY (id),
            UNIQUE KEY tx_hash (tx_hash),
            KEY payer_wallet (payer_wallet),
            KEY workspace_slug (workspace_slug)
        ) $charset;");

        dbDelta("CREATE TABLE $subs (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            user_id BIGINT UNSIGNED NULL,
            wallet_address VARCHAR(64) NOT NULL,
            workspace_slug VARCHAR(64) NOT NULL,
            module_key VARCHAR(64) NOT NULL,
            status VARCHAR(32) NOT NULL DEFAULT 'inactive',
            active_from DATETIME NULL,
            active_until DATETIME NULL,
            last_payment_id BIGINT UNSIGNED NULL,
            created_at DATETIME NOT NULL,
            updated_at DATETIME NOT NULL,
            PRIMARY KEY (id),
            UNIQUE KEY sub_unique (wallet_address, workspace_slug, module_key),
            KEY user_id (user_id)
        ) $charset;");

        $now = current_time('mysql');
        // Seed core workspace and modules if not present.
        $wpdb->query($wpdb->prepare("INSERT IGNORE INTO $workspaces (slug,name,token_symbol,token_address,gate_token_amount,monthly_element_fee,created_at) VALUES (%s,%s,%s,%s,%s,%s,%s)", 'core', 'CCJV Core ERP', 'CJV', '', '1', '1', $now));
        foreach ([['crm','CRM'],['hrm','HRM'],['accounting','Accounting'],['project-management','Project Management'],['asset-management','Asset Management']] as $m) {
            $wpdb->query($wpdb->prepare("INSERT IGNORE INTO $modules (workspace_slug,module_key,module_name,created_at) VALUES (%s,%s,%s,%s)", 'core', $m[0], $m[1], $now));
        }
    }

    public function admin_menu() {
        add_menu_page('CCJV Treasury Engine', 'CCJV Treasury', 'manage_options', 'ccjv-treasury', [$this, 'settings_page'], 'dashicons-shield-alt', 58);
        add_submenu_page('ccjv-treasury', 'Settings', 'Settings', 'manage_options', 'ccjv-treasury', [$this, 'settings_page']);
        add_submenu_page('ccjv-treasury', 'Workspaces', 'Workspaces', 'manage_options', 'ccjv-treasury-workspaces', [$this, 'workspaces_page']);
        add_submenu_page('ccjv-treasury', 'Modules', 'Modules', 'manage_options', 'ccjv-treasury-modules', [$this, 'modules_page']);
        add_submenu_page('ccjv-treasury', 'Payments', 'Payments', 'manage_options', 'ccjv-treasury-payments', [$this, 'payments_page']);
        add_submenu_page('ccjv-treasury', 'Subscriptions', 'Subscriptions', 'manage_options', 'ccjv-treasury-subscriptions', [$this, 'subscriptions_page']);
    }

    public function register_settings() {
        register_setting('ccjv_treasury_settings_group', self::SETTINGS_OPTION);
    }

    private function admin_wrap($title, $callback) {
        echo '<div class="wrap"><h1>' . esc_html($title) . '</h1>';
        call_user_func($callback);
        echo '</div>';
    }

    public function settings_page() {
        $this->admin_wrap('CCJV Treasury Payment Engine Settings', function() {
            $s = self::settings();
            echo '<form method="post" action="options.php">';
            settings_fields('ccjv_treasury_settings_group');
            echo '<table class="form-table">';
            foreach ([
                'rpc_url' => 'Avalanche RPC URL',
                'chain_id_hex' => 'Chain ID (hex)',
                'chain_name' => 'Chain Name',
                'native_symbol' => 'Native Symbol',
                'block_explorer' => 'Block Explorer URL',
                'treasury_contract' => 'Treasury Contract Address',
                'verifier_contract' => 'Verifier Contract Address (optional; falls back to treasury contract)',
                'treasury_wallet' => 'Treasury Wallet Address',
                'core_token_symbol' => 'Core Token Symbol',
                'buy_direct_url' => 'Buy Direct URL',
            ] as $key => $label) {
                printf('<tr><th scope="row">%s</th><td><input type="text" class="regular-text" name="%s[%s]" value="%s"></td></tr>', esc_html($label), esc_attr(self::SETTINGS_OPTION), esc_attr($key), esc_attr($s[$key]));
            }
            echo '</table>';
            submit_button();
            echo '</form>';
            echo '<p><strong>Note:</strong> Deploy the Solidity contract in the contracts folder, then paste its address here. The engine syncs payment events every 5 minutes.</p>';
        });
    }

    public function workspaces_page() {
        global $wpdb;
        $table = $wpdb->prefix . self::WORKSPACE_TABLE;
        if (!empty($_POST['ccjv_workspace_nonce']) && wp_verify_nonce($_POST['ccjv_workspace_nonce'], 'ccjv_save_workspace')) {
            $data = [
                'slug' => sanitize_title($_POST['slug']),
                'name' => sanitize_text_field($_POST['name']),
                'token_symbol' => sanitize_text_field($_POST['token_symbol']),
                'token_address' => sanitize_text_field($_POST['token_address']),
                'token_decimals' => intval($_POST['token_decimals']),
                'gate_token_amount' => sanitize_text_field($_POST['gate_token_amount']),
                'monthly_element_fee' => sanitize_text_field($_POST['monthly_element_fee']),
                'active' => empty($_POST['active']) ? 0 : 1,
                'created_at' => current_time('mysql'),
            ];
            $wpdb->replace($table, $data);
            echo '<div class="updated"><p>Workspace saved.</p></div>';
        }
        $rows = $wpdb->get_results("SELECT * FROM $table ORDER BY name ASC");
        $this->admin_wrap('Workspaces', function() use ($rows) {
            echo '<h2>Add / Update Workspace</h2><form method="post"><input type="hidden" name="ccjv_workspace_nonce" value="' . esc_attr(wp_create_nonce('ccjv_save_workspace')) . '"><table class="form-table">';
            foreach ([['slug','Slug'],['name','Name'],['token_symbol','Token Symbol'],['token_address','Token Address'],['token_decimals','Token Decimals'],['gate_token_amount','Gate Token Amount'],['monthly_element_fee','Monthly Fee Per Element']] as $f) {
                printf('<tr><th>%s</th><td><input name="%s" class="regular-text"></td></tr>', esc_html($f[1]), esc_attr($f[0]));
            }
            echo '<tr><th>Active</th><td><label><input type="checkbox" name="active" value="1" checked> Active</label></td></tr>';
            echo '</table>'; submit_button('Save Workspace'); echo '</form>';
            echo '<h2>Existing Workspaces</h2><table class="widefat striped"><thead><tr><th>Slug</th><th>Name</th><th>Token</th><th>Gate</th><th>Monthly Fee</th></tr></thead><tbody>';
            foreach ($rows as $r) {
                echo '<tr><td>' . esc_html($r->slug) . '</td><td>' . esc_html($r->name) . '</td><td>' . esc_html($r->token_symbol) . '</td><td>' . esc_html($r->gate_token_amount) . '</td><td>' . esc_html($r->monthly_element_fee) . '</td></tr>';
            }
            echo '</tbody></table>';
        });
    }

    public function modules_page() {
        global $wpdb;
        $table = $wpdb->prefix . self::MODULE_TABLE;
        if (!empty($_POST['ccjv_module_nonce']) && wp_verify_nonce($_POST['ccjv_module_nonce'], 'ccjv_save_module')) {
            $wpdb->replace($table, [
                'workspace_slug' => sanitize_title($_POST['workspace_slug']),
                'module_key' => sanitize_title($_POST['module_key']),
                'module_name' => sanitize_text_field($_POST['module_name']),
                'active' => empty($_POST['active']) ? 0 : 1,
                'created_at' => current_time('mysql')
            ]);
            echo '<div class="updated"><p>Module saved.</p></div>';
        }
        $rows = $wpdb->get_results("SELECT * FROM $table ORDER BY workspace_slug, module_name ASC");
        $this->admin_wrap('Modules', function() use ($rows) {
            echo '<h2>Add / Update Module</h2><form method="post"><input type="hidden" name="ccjv_module_nonce" value="' . esc_attr(wp_create_nonce('ccjv_save_module')) . '"><table class="form-table">';
            foreach ([['workspace_slug','Workspace Slug'],['module_key','Module Key'],['module_name','Module Name']] as $f) {
                printf('<tr><th>%s</th><td><input name="%s" class="regular-text"></td></tr>', esc_html($f[1]), esc_attr($f[0]));
            }
            echo '<tr><th>Active</th><td><label><input type="checkbox" name="active" value="1" checked> Active</label></td></tr>';
            echo '</table>'; submit_button('Save Module'); echo '</form>';
            echo '<h2>Existing Modules</h2><table class="widefat striped"><thead><tr><th>Workspace</th><th>Key</th><th>Name</th></tr></thead><tbody>';
            foreach ($rows as $r) {
                echo '<tr><td>' . esc_html($r->workspace_slug) . '</td><td>' . esc_html($r->module_key) . '</td><td>' . esc_html($r->module_name) . '</td></tr>';
            }
            echo '</tbody></table>';
        });
    }

    public function payments_page() {
        global $wpdb;
        $table = $wpdb->prefix . self::PAYMENT_TABLE;
        if (!empty($_POST['sync_now']) && check_admin_referer('ccjv_sync_now')) {
            $this->sync_chain_payments();
            echo '<div class="updated"><p>Sync complete.</p></div>';
        }
        $rows = $wpdb->get_results("SELECT * FROM $table ORDER BY id DESC LIMIT 200");
        $this->admin_wrap('Payments', function() use ($rows) {
            echo '<form method="post">'; wp_nonce_field('ccjv_sync_now'); submit_button('Sync From Avalanche Now', 'secondary', 'sync_now', false); echo '</form>';
            echo '<table class="widefat striped"><thead><tr><th>TX</th><th>Wallet</th><th>Workspace</th><th>Module</th><th>Periods</th><th>Amount</th><th>Paid Until</th><th>Status</th></tr></thead><tbody>';
            foreach ($rows as $r) {
                echo '<tr><td><code>' . esc_html($r->tx_hash) . '</code></td><td><code>' . esc_html($r->payer_wallet) . '</code></td><td>' . esc_html($r->workspace_slug) . '</td><td>' . esc_html($r->module_key) . '</td><td>' . esc_html($r->periods) . '</td><td>' . esc_html($r->amount_display) . '</td><td>' . esc_html($r->paid_until) . '</td><td>' . esc_html($r->status) . '</td></tr>';
            }
            echo '</tbody></table>';
        });
    }

    public function subscriptions_page() {
        global $wpdb;
        $table = $wpdb->prefix . self::SUB_TABLE;
        $rows = $wpdb->get_results("SELECT * FROM $table ORDER BY active_until DESC LIMIT 200");
        $this->admin_wrap('Subscriptions', function() use ($rows) {
            echo '<table class="widefat striped"><thead><tr><th>Wallet</th><th>Workspace</th><th>Module</th><th>Status</th><th>Active Until</th></tr></thead><tbody>';
            foreach ($rows as $r) {
                echo '<tr><td><code>' . esc_html($r->wallet_address) . '</code></td><td>' . esc_html($r->workspace_slug) . '</td><td>' . esc_html($r->module_key) . '</td><td>' . esc_html($r->status) . '</td><td>' . esc_html($r->active_until) . '</td></tr>';
            }
            echo '</tbody></table>';
        });
    }

    public function enqueue_assets() {
        if (!is_singular() && !is_page()) return;
        wp_enqueue_style('ccjv-treasury-css', plugin_dir_url(__FILE__) . 'assets/css/portal.css', [], self::VERSION);
        wp_enqueue_script('ccjv-treasury-js', plugin_dir_url(__FILE__) . 'assets/js/portal.js', [], self::VERSION, true);
        wp_localize_script('ccjv-treasury-js', 'CCJVTreasury', [
            'rest' => esc_url_raw(rest_url('ccjv-treasury/v1')),
            'nonce' => wp_create_nonce('wp_rest'),
            'settings' => self::settings(),
            'paymentAbi' => [
                ['name'=>'approve','type'=>'function','stateMutability'=>'nonpayable','inputs'=>[['name'=>'spender','type'=>'address'],['name'=>'amount','type'=>'uint256']], 'outputs'=>[['name'=>'','type'=>'bool']]],
                ['name'=>'anchorPayment','type'=>'function','stateMutability'=>'nonpayable','inputs'=>[['name'=>'payer','type'=>'address'],['name'=>'workspace','type'=>'bytes32'],['name'=>'moduleKey','type'=>'bytes32'],['name'=>'periods','type'=>'uint256'],['name'=>'amount','type'=>'uint256'],['name'=>'validUntil','type'=>'uint256'],['name'=>'paymentType','type'=>'uint8']], 'outputs'=>[]],
                ['name'=>'balanceOf','type'=>'function','stateMutability'=>'view','inputs'=>[['name'=>'account','type'=>'address']], 'outputs'=>[['name'=>'','type'=>'uint256']]],
            ],
        ]);
    }

    public function portal_shortcode() {
        ob_start();
        global $wpdb;
        $ws = $wpdb->prefix . self::WORKSPACE_TABLE;
        $mods = $wpdb->prefix . self::MODULE_TABLE;
        $workspaces = $wpdb->get_results("SELECT * FROM $ws WHERE active=1 ORDER BY name ASC");
        echo '<div class="ccjv-treasury-shell">';
        echo '<div class="ccjv-treasury-hero"><h2>CCJV Treasury Portal</h2><p>Connect MetaMask, verify your wallet, pay the monthly module fee, and activate access automatically.</p><button class="ccjv-btn" id="ccjv-connect-wallet">Connect MetaMask</button> <span id="ccjv-wallet-status">Not connected</span></div>';
        echo '<div id="ccjv-wallet-verification" class="ccjv-card"></div>';
        foreach ($workspaces as $w) {
            echo '<div class="ccjv-card workspace-card" data-workspace="' . esc_attr($w->slug) . '" data-token="' . esc_attr($w->token_address) . '" data-decimals="' . esc_attr($w->token_decimals) . '" data-symbol="' . esc_attr($w->token_symbol) . '" data-gate="' . esc_attr($w->gate_token_amount) . '" data-monthly-fee="' . esc_attr($w->monthly_element_fee) . '">';
            echo '<h3>' . esc_html($w->name) . ' <small>(' . esc_html($w->token_symbol) . ')</small></h3>';
            echo '<p>Token gate: <strong>' . esc_html($w->gate_token_amount) . ' ' . esc_html($w->token_symbol) . '</strong> held in wallet.</p>';
            echo '<p>Monthly fee: <strong>' . esc_html($w->monthly_element_fee) . ' ' . esc_html($w->token_symbol) . '</strong> per element.</p>';
            echo '<div class="gate-status" id="gate-status-' . esc_attr($w->slug) . '">Connect wallet to check access.</div>';
            $list = $wpdb->get_results($wpdb->prepare("SELECT * FROM $mods WHERE workspace_slug=%s AND active=1 ORDER BY module_name ASC", $w->slug));
            echo '<div class="module-grid">';
            foreach ($list as $m) {
                echo '<div class="module-card" data-module="' . esc_attr($m->module_key) . '">';
                echo '<h4>' . esc_html($m->module_name) . '</h4>';
                echo '<p>Fee: 1 token / month</p>';
                echo '<button class="ccjv-btn pay-module" data-workspace="' . esc_attr($w->slug) . '" data-module="' . esc_attr($m->module_key) . '" data-periods="1">Pay 1 Month</button> ';
                echo '<button class="ccjv-btn secondary pay-module" data-workspace="' . esc_attr($w->slug) . '" data-module="' . esc_attr($m->module_key) . '" data-periods="12">Pay 12 Months</button>';
                echo '<div class="module-status" id="module-status-' . esc_attr($w->slug . '-' . $m->module_key) . '">Inactive</div>';
                echo '</div>';
            }
            echo '</div></div>';
        }
        echo '</div>';
        return ob_get_clean();
    }

    public function register_rest() {
        register_rest_route('ccjv-treasury/v1', '/challenge', [
            'methods' => 'POST',
            'callback' => [$this, 'rest_challenge'],
            'permission_callback' => '__return_true',
        ]);
        register_rest_route('ccjv-treasury/v1', '/verify', [
            'methods' => 'POST',
            'callback' => [$this, 'rest_verify'],
            'permission_callback' => '__return_true',
        ]);
        register_rest_route('ccjv-treasury/v1', '/quote', [
            'methods' => 'POST',
            'callback' => [$this, 'rest_quote'],
            'permission_callback' => '__return_true',
        ]);
        register_rest_route('ccjv-treasury/v1', '/record-tx', [
            'methods' => 'POST',
            'callback' => [$this, 'rest_record_tx'],
            'permission_callback' => '__return_true',
        ]);
        register_rest_route('ccjv-treasury/v1', '/subscription-status', [
            'methods' => 'GET',
            'callback' => [$this, 'rest_subscription_status'],
            'permission_callback' => '__return_true',
        ]);
    }

    public function rest_challenge(WP_REST_Request $request) {
        global $wpdb;
        $wallet = strtolower(sanitize_text_field($request->get_param('wallet')));
        if (!$this->is_valid_address($wallet)) {
            return new WP_REST_Response(['error' => 'Invalid wallet'], 400);
        }
        $nonce = wp_generate_password(32, false, false);
        $message = "CCJV Wallet Verification\nWallet: {$wallet}\nNonce: {$nonce}\nDomain: " . home_url() . "\nIssued: " . gmdate('c');
        $wpdb->insert($wpdb->prefix . self::CHALLENGE_TABLE, [
            'wallet_address' => $wallet,
            'nonce' => $nonce,
            'message' => $message,
            'verified' => 0,
            'created_at' => current_time('mysql', 1),
            'expires_at' => gmdate('Y-m-d H:i:s', time()+900),
        ]);
        return ['message' => $message, 'nonce' => $nonce];
    }

    public function rest_verify(WP_REST_Request $request) {
        global $wpdb;
        $wallet = strtolower(sanitize_text_field($request->get_param('wallet')));
        $message = (string)$request->get_param('message');
        $signature = strtolower((string)$request->get_param('signature'));
        if (!$this->is_valid_address($wallet) || empty($message) || empty($signature)) {
            return new WP_REST_Response(['verified' => false, 'error' => 'Missing fields'], 400);
        }
        $table = $wpdb->prefix . self::CHALLENGE_TABLE;
        $row = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table WHERE wallet_address=%s AND message=%s ORDER BY id DESC LIMIT 1", $wallet, $message));
        if (!$row) return new WP_REST_Response(['verified' => false, 'error' => 'Challenge not found'], 404);
        if (strtotime($row->expires_at . ' UTC') < time()) return new WP_REST_Response(['verified' => false, 'error' => 'Challenge expired'], 400);

        $recovered = $this->recover_address_via_contract_call($message, $signature);
        if (!$recovered || strtolower($recovered) !== strtolower($wallet)) {
            return ['verified' => false, 'error' => 'Signature did not verify'];
        }
        $wpdb->update($table, ['verified' => 1], ['id' => $row->id]);
        if (is_user_logged_in()) {
            update_user_meta(get_current_user_id(), 'ccjv_verified_wallet', $wallet);
            update_user_meta(get_current_user_id(), 'ccjv_wallet_verified_at', current_time('mysql', 1));
        }
        return ['verified' => true, 'wallet' => $wallet];
    }

    public function rest_quote(WP_REST_Request $request) {
        global $wpdb;
        $workspace = sanitize_title($request->get_param('workspace'));
        $module = sanitize_title($request->get_param('module'));
        $periods = max(1, intval($request->get_param('periods')));
        $wallet = strtolower(sanitize_text_field($request->get_param('wallet')));
        $wsTable = $wpdb->prefix . self::WORKSPACE_TABLE;
        $modTable = $wpdb->prefix . self::MODULE_TABLE;
        $ws = $wpdb->get_row($wpdb->prepare("SELECT * FROM $wsTable WHERE slug=%s AND active=1", $workspace));
        $mod = $wpdb->get_row($wpdb->prepare("SELECT * FROM $modTable WHERE workspace_slug=%s AND module_key=%s AND active=1", $workspace, $module));
        if (!$ws || !$mod) return new WP_REST_Response(['error' => 'Workspace/module not found'], 404);
        $fee = (float)$ws->monthly_element_fee;
        $displayAmount = $fee * $periods;
        $amountRaw = $this->decimal_to_uint($displayAmount, intval($ws->token_decimals));
        return [
            'workspace' => $workspace,
            'module' => $module,
            'periods' => $periods,
            'wallet' => $wallet,
            'tokenAddress' => $ws->token_address,
            'tokenSymbol' => $ws->token_symbol,
            'tokenDecimals' => intval($ws->token_decimals),
            'amountDisplay' => rtrim(rtrim(number_format($displayAmount, 18, '.', ''), '0'), '.'),
            'amountRaw' => $amountRaw,
            'validUntil' => time() + 1800,
            'paymentType' => 2,
        ];
    }

    public function rest_record_tx(WP_REST_Request $request) {
        global $wpdb;
        $tx = strtolower(sanitize_text_field($request->get_param('txHash')));
        $wallet = strtolower(sanitize_text_field($request->get_param('wallet')));
        $workspace = sanitize_title($request->get_param('workspace'));
        $module = sanitize_title($request->get_param('module'));
        $periods = max(1, intval($request->get_param('periods')));
        $amountDisplay = sanitize_text_field($request->get_param('amountDisplay'));
        if (empty($tx)) return new WP_REST_Response(['error' => 'Missing txHash'], 400);
        $wpdb->replace($wpdb->prefix . self::PAYMENT_TABLE, [
            'tx_hash' => $tx,
            'payer_wallet' => $wallet,
            'workspace_slug' => $workspace,
            'module_key' => $module,
            'periods' => $periods,
            'amount_raw' => sanitize_text_field($request->get_param('amountRaw')),
            'amount_display' => $amountDisplay,
            'status' => 'pending',
            'created_at' => current_time('mysql', 1),
            'updated_at' => current_time('mysql', 1),
        ]);
        return ['ok' => true];
    }

    public function rest_subscription_status(WP_REST_Request $request) {
        global $wpdb;
        $wallet = strtolower(sanitize_text_field($request->get_param('wallet')));
        $table = $wpdb->prefix . self::SUB_TABLE;
        $rows = $wpdb->get_results($wpdb->prepare("SELECT workspace_slug,module_key,status,active_until FROM $table WHERE wallet_address=%s", $wallet), ARRAY_A);
        return ['wallet' => $wallet, 'subscriptions' => $rows];
    }

    private function is_valid_address($address) {
        return (bool) preg_match('/^0x[a-fA-F0-9]{40}$/', $address);
    }

    private function decimal_to_uint($amount, $decimals) {
        $parts = explode('.', (string)$amount);
        $whole = preg_replace('/\D/', '', $parts[0]);
        $frac = isset($parts[1]) ? preg_replace('/\D/', '', $parts[1]) : '';
        $frac = substr(str_pad($frac, $decimals, '0'), 0, $decimals);
        $whole = ltrim($whole, '0'); if ($whole === '') $whole = '0';
        return ltrim($whole . $frac, '0') ?: '0';
    }

    private function wp_remote_post_json($url, $body) {
        $resp = wp_remote_post($url, [
            'headers' => ['Content-Type' => 'application/json'],
            'body' => wp_json_encode($body),
            'timeout' => 20,
        ]);
        if (is_wp_error($resp)) return $resp;
        $json = json_decode(wp_remote_retrieve_body($resp), true);
        return is_array($json) ? $json : new WP_Error('rpc', 'Invalid RPC response');
    }

    private function rpc_call($method, $params) {
        $settings = self::settings();
        return $this->wp_remote_post_json($settings['rpc_url'], ['jsonrpc'=>'2.0','id'=>1,'method'=>$method,'params'=>$params]);
    }

    private function eth_signed_message_hash($message) {
        $msgHex = bin2hex($message);
        $prefix = "\x19Ethereum Signed Message:\n" . strlen($message);
        $prefixHex = bin2hex($prefix);
        return '0x' . hash('sha3-256', hex2bin($prefixHex . $msgHex)); // informational fallback only
    }

    private function recover_address_via_contract_call($message, $signature) {
        // This uses the deployed contract's pure recoverSignerString(string,bytes) view function via eth_call.
        // The server sends the original challenge string and the signature; the contract recomputes keccak256(message)
        // inside the EVM and returns the recovered address. That avoids trusting any browser-supplied digest.
        $settings = self::settings();
        $contract = !empty($settings['verifier_contract']) ? $settings['verifier_contract'] : $settings['treasury_contract'];
        if (!$this->is_valid_address($contract)) return false;

        $msgHex = bin2hex($message);
        $msgLen = strlen($msgHex) / 2;
        $sig = preg_replace('/^0x/', '', $signature);
        $sigLen = strlen($sig) / 2;
        $head1 = str_pad(dechex(64), 64, '0', STR_PAD_LEFT);
        $msgDataLenPaddedBytes = ceil($msgLen / 32) * 32;
        $head2 = str_pad(dechex(64 + 32 + $msgDataLenPaddedBytes), 64, '0', STR_PAD_LEFT);
        $msgHexLen = str_pad(dechex($msgLen), 64, '0', STR_PAD_LEFT);
        $msgPadded = str_pad($msgHex, $msgDataLenPaddedBytes * 2, '0', STR_PAD_RIGHT);
        $sigHexLen = str_pad(dechex($sigLen), 64, '0', STR_PAD_LEFT);
        $sigPadded = str_pad($sig, ceil($sigLen / 32) * 64, '0', STR_PAD_RIGHT);
        $data = '0x' . self::RECOVER_SELECTOR . $head1 . $head2 . $msgHexLen . $msgPadded . $sigHexLen . $sigPadded;
        $result = $this->rpc_call('eth_call', [[ 'to' => $contract, 'data' => $data ], 'latest']);
        if (is_wp_error($result) || empty($result['result'])) return false;
        $hex = strtolower(preg_replace('/^0x/', '', $result['result']));
        if (strlen($hex) < 64) return false;
        return '0x' . substr($hex, 24);
    }

    private function bytes32_from_slug($slug) {
        $hex = bin2hex($slug);
        return '0x' . str_pad(substr($hex, 0, 64), 64, '0', STR_PAD_RIGHT);
    }

    public function sync_chain_payments() {
        global $wpdb;
        $settings = self::settings();
        if (!$this->is_valid_address($settings['treasury_contract'])) return;
        $fromBlock = get_option(self::SYNC_OPTION);
        if (!$fromBlock) {
            $block = $this->rpc_call('eth_blockNumber', []);
            if (is_wp_error($block) || empty($block['result'])) return;
            $fromBlock = hexdec($block['result']);
            update_option(self::SYNC_OPTION, max(0, $fromBlock - 500));
            $fromBlock = max(0, $fromBlock - 500);
        }
        $latest = $this->rpc_call('eth_blockNumber', []);
        if (is_wp_error($latest) || empty($latest['result'])) return;
        $latestBlock = hexdec($latest['result']);
        $logs = $this->rpc_call('eth_getLogs', [[
            'fromBlock' => '0x' . dechex((int)$fromBlock),
            'toBlock' => '0x' . dechex((int)$latestBlock),
            'address' => $settings['treasury_contract'],
            'topics' => [self::PAYMENT_EVENT_TOPIC0],
        ]]);
        if (is_wp_error($logs) || empty($logs['result']) || !is_array($logs['result'])) {
            update_option(self::SYNC_OPTION, $latestBlock + 1);
            return;
        }
        foreach ($logs['result'] as $log) {
            $this->ingest_payment_log($log);
        }
        update_option(self::SYNC_OPTION, $latestBlock + 1);
    }

    private function ingest_payment_log($log) {
        global $wpdb;
        $payments = $wpdb->prefix . self::PAYMENT_TABLE;
        $subs = $wpdb->prefix . self::SUB_TABLE;
        $topics = $log['topics'];
        if (count($topics) < 4) return;
        $payer = '0x' . substr($topics[1], -40);
        $workspaceBytes = strtolower($topics[2]);
        $moduleBytes = strtolower($topics[3]);
        $workspaceSlug = $this->decode_bytes32_ascii($workspaceBytes);
        $moduleKey = $this->decode_bytes32_ascii($moduleBytes);
        $data = preg_replace('/^0x/', '', $log['data']);
        if (strlen($data) < 64 * 4) return;
        $periods = hexdec(substr($data, 0, 64));
        $amountRaw = $this->hex_to_decstr(substr($data, 64, 64));
        $validUntil = hexdec(substr($data, 128, 64));
        $paymentType = hexdec(substr($data, 192, 64));
        $txHash = strtolower($log['transactionHash']);
        $blockNumber = hexdec($log['blockNumber']);
        $eventIndex = hexdec($log['logIndex']);
        $workspace = $this->get_workspace($workspaceSlug);
        $display = $workspace ? $this->uint_to_decimal_string($amountRaw, intval($workspace->token_decimals)) : '0';
        $paidUntil = gmdate('Y-m-d H:i:s', $validUntil);

        $wpdb->replace($payments, [
            'tx_hash' => $txHash,
            'payer_wallet' => strtolower($payer),
            'workspace_slug' => $workspaceSlug,
            'module_key' => $moduleKey,
            'periods' => $periods,
            'amount_raw' => $amountRaw,
            'amount_display' => $display,
            'paid_until' => $paidUntil,
            'status' => 'confirmed',
            'block_number' => $blockNumber,
            'event_index' => $eventIndex,
            'created_at' => current_time('mysql', 1),
            'updated_at' => current_time('mysql', 1),
        ]);
        $paymentId = $wpdb->get_var($wpdb->prepare("SELECT id FROM $payments WHERE tx_hash=%s", $txHash));
        $userId = $this->user_id_for_wallet($payer);
        $wpdb->replace($subs, [
            'user_id' => $userId,
            'wallet_address' => strtolower($payer),
            'workspace_slug' => $workspaceSlug,
            'module_key' => $moduleKey,
            'status' => 'active',
            'active_from' => current_time('mysql', 1),
            'active_until' => $paidUntil,
            'last_payment_id' => $paymentId,
            'created_at' => current_time('mysql', 1),
            'updated_at' => current_time('mysql', 1),
        ]);
    }

    private function get_workspace($slug) {
        global $wpdb;
        return $wpdb->get_row($wpdb->prepare("SELECT * FROM {$wpdb->prefix}" . self::WORKSPACE_TABLE . " WHERE slug=%s", $slug));
    }

    private function user_id_for_wallet($wallet) {
        $users = get_users(['meta_key' => 'ccjv_verified_wallet', 'meta_value' => strtolower($wallet), 'number' => 1, 'fields' => 'ids']);
        return !empty($users) ? intval($users[0]) : null;
    }

    private function decode_bytes32_ascii($hex) {
        $hex = preg_replace('/^0x/', '', $hex);
        $bin = hex2bin($hex);
        return trim(str_replace("\0", '', $bin));
    }

    private function hex_to_decstr($hex) {
        $hex = ltrim($hex, '0');
        if ($hex === '') return '0';
        $dec = '0';
        foreach (str_split($hex) as $c) {
            $n = hexdec($c);
            $dec = $this->dec_mul($dec, 16);
            $dec = $this->dec_add($dec, $n);
        }
        return $dec;
    }
    private function dec_add($dec, $n) {
        $carry = $n; $out = '';
        for ($i=strlen($dec)-1; $i>=0 || $carry>0; $i--) {
            $d = $i>=0 ? intval($dec[$i]) : 0;
            $sum = $d + $carry;
            $out = ($sum % 10) . $out;
            $carry = intdiv($sum, 10);
        }
        if ($i>=0) $out = substr($dec,0,$i+1).$out;
        return ltrim($out,'0') ?: '0';
    }
    private function dec_mul($dec, $n) {
        if ($dec==='0' || $n===0) return '0';
        $carry = 0; $out = '';
        for ($i=strlen($dec)-1; $i>=0; $i--) {
            $prod = intval($dec[$i]) * $n + $carry;
            $out = ($prod % 10) . $out;
            $carry = intdiv($prod, 10);
        }
        while ($carry>0) { $out = ($carry % 10) . $out; $carry = intdiv($carry,10); }
        return ltrim($out,'0') ?: '0';
    }
    private function uint_to_decimal_string($raw, $decimals) {
        $raw = ltrim((string)$raw, '0'); if ($raw==='') return '0';
        if (strlen($raw) <= $decimals) {
            $raw = str_pad($raw, $decimals + 1, '0', STR_PAD_LEFT);
        }
        $whole = substr($raw, 0, -$decimals);
        $frac = rtrim(substr($raw, -$decimals), '0');
        return $frac === '' ? $whole : $whole . '.' . $frac;
    }
}

new CCJVTreasuryPaymentEngine();
