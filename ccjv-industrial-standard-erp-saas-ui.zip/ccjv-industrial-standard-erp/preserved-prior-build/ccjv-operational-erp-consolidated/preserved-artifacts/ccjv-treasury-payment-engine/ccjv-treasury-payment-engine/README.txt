CCJV Treasury Payment Engine
===========================

Shortcode:
[ccjv_treasury_portal]

What this plugin does:
- Wallet challenge generation
- Signature verification request/response
- Workspace + module treasury catalog
- MetaMask payment flow for module fees
- On-chain payment event sync from Avalanche
- Automatic subscription activation after confirmed payment

Deployment steps:
1. Deploy contracts/CCJVTreasuryEngine.sol on Avalanche C-Chain.
2. In plugin settings, enter:
   - Avalanche RPC URL
   - Treasury contract address
   - Treasury wallet address
3. Add workspaces and modules.
4. In the contract, call setWorkspace(bytes32,address,uint8,uint256,bool) for each workspace.
5. Put [ccjv_treasury_portal] on a page.

Notes:
- The portal expects ethers.js to be present on the front end. If your theme does not already load it, add it globally or bundle it in your shell plugin.
- Signature verification is performed via eth_call to the deployed contract's recoverSignerString(string,bytes) helper.
- The server stores files and metadata; this plugin handles treasury payment automation, not the file vault itself.
