(function(){
  let currentAccount = null;
  const $ = (s) => document.querySelector(s);
  async function rpc(method, params={}, httpMethod='POST') {
    const url = CCJVTreasury.rest + method;
    const opt = { method: httpMethod, headers: {'Content-Type':'application/json', 'X-WP-Nonce': CCJVTreasury.nonce} };
    if (httpMethod !== 'GET') opt.body = JSON.stringify(params);
    const res = await fetch(url, opt);
    return res.json();
  }
  function setStatus(msg){ const el = $('#ccjv-wallet-status'); if (el) el.textContent = msg; }
  async function connect() {
    if (!window.ethereum) { alert('MetaMask not found.'); return; }
    const accounts = await ethereum.request({method:'eth_requestAccounts'});
    currentAccount = accounts[0];
    try {
      await ethereum.request({method:'wallet_switchEthereumChain', params:[{ chainId: CCJVTreasury.settings.chain_id_hex }]});
    } catch (e) {}
    setStatus(currentAccount);
    await verifyWallet();
    await refreshSubscriptions();
    await refreshGateChecks();
  }
  async function verifyWallet() {
    const box = $('#ccjv-wallet-verification');
    const challenge = await rpc('/challenge', {wallet: currentAccount});
    const signature = await ethereum.request({method:'personal_sign', params:[challenge.message, currentAccount]});
    const result = await rpc('/verify', {wallet: currentAccount, message: challenge.message, signature});
    box.innerHTML = result.verified ? '<strong>Wallet verified:</strong> ' + result.wallet : '<strong>Verification failed</strong>';
  }
  function getWorkspaceCard(slug){ return document.querySelector('.workspace-card[data-workspace="'+slug+'"]'); }
  async function refreshGateChecks() {
    if (!currentAccount || !window.ethers) return;
    const provider = new ethers.BrowserProvider(window.ethereum);
    for (const card of document.querySelectorAll('.workspace-card')) {
      const token = card.dataset.token;
      const gate = card.dataset.gate;
      const symbol = card.dataset.symbol;
      const decimals = parseInt(card.dataset.decimals || '18', 10);
      const status = card.querySelector('.gate-status');
      if (!token || token.length < 42) { status.textContent = 'Configure token address in settings.'; continue; }
      try {
        const erc20 = new ethers.Contract(token, CCJVTreasury.paymentAbi, provider);
        const bal = await erc20.balanceOf(currentAccount);
        const human = Number(ethers.formatUnits(bal, decimals));
        status.textContent = human >= parseFloat(gate) ? 'Gate met: ' + human + ' ' + symbol : 'Gate not met: ' + human + ' ' + symbol;
      } catch (e) {
        status.textContent = 'Unable to read token balance.';
      }
    }
  }
  async function refreshSubscriptions() {
    if (!currentAccount) return;
    const data = await fetch(CCJVTreasury.rest + '/subscription-status?wallet=' + encodeURIComponent(currentAccount), {headers:{'X-WP-Nonce': CCJVTreasury.nonce}}).then(r=>r.json());
    (data.subscriptions || []).forEach((row)=>{
      const el = document.getElementById('module-status-' + row.workspace_slug + '-' + row.module_key);
      if (el) el.textContent = row.status + (row.active_until ? ' until ' + row.active_until : '');
    });
  }
  async function payModule(btn) {
    if (!currentAccount) { alert('Connect wallet first.'); return; }
    if (!window.ethers) { alert('ethers.js required on page.'); return; }
    const workspace = btn.dataset.workspace;
    const moduleKey = btn.dataset.module;
    const periods = parseInt(btn.dataset.periods || '1', 10);
    const quote = await rpc('/quote', {workspace, module: moduleKey, periods, wallet: currentAccount});
    if (quote.error) { alert(quote.error); return; }
    const provider = new ethers.BrowserProvider(window.ethereum);
    const signer = await provider.getSigner();
    const token = new ethers.Contract(quote.tokenAddress, CCJVTreasury.paymentAbi, signer);
    const engine = new ethers.Contract(CCJVTreasury.settings.treasury_contract, CCJVTreasury.paymentAbi, signer);
    const approveTx = await token.approve(CCJVTreasury.settings.treasury_contract, quote.amountRaw);
    await approveTx.wait();
    const workspaceBytes = ethers.encodeBytes32String(workspace).slice(0,66);
    const moduleBytes = ethers.encodeBytes32String(moduleKey).slice(0,66);
    const tx = await engine.anchorPayment(currentAccount, workspaceBytes, moduleBytes, quote.periods, quote.amountRaw, quote.validUntil, quote.paymentType);
    await rpc('/record-tx', {txHash: tx.hash, wallet: currentAccount, workspace, module: moduleKey, periods, amountDisplay: quote.amountDisplay, amountRaw: quote.amountRaw});
    const el = document.getElementById('module-status-' + workspace + '-' + moduleKey);
    if (el) el.textContent = 'Payment sent. Awaiting confirmation.';
  }
  document.addEventListener('click', (e)=>{
    if (e.target && e.target.id === 'ccjv-connect-wallet') connect();
    if (e.target && e.target.classList.contains('pay-module')) payModule(e.target);
  });
})();
