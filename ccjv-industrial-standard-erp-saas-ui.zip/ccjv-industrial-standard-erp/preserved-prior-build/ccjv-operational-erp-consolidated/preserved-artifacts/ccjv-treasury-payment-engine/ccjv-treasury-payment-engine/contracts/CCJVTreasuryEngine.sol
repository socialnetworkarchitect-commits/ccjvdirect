// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

interface IERC20 {
    function transferFrom(address from, address to, uint256 amount) external returns (bool);
}

library ECDSA {
    function toEthSignedMessageHash(bytes32 hash) internal pure returns (bytes32) {
        return keccak256(abi.encodePacked("\x19Ethereum Signed Message:\n32", hash));
    }
    function recover(bytes32 hash, bytes memory signature) internal pure returns (address) {
        require(signature.length == 65, "bad sig");
        bytes32 r; bytes32 s; uint8 v;
        assembly {
            r := mload(add(signature, 32))
            s := mload(add(signature, 64))
            v := byte(0, mload(add(signature, 96)))
        }
        if (v < 27) v += 27;
        require(v == 27 || v == 28, "bad v");
        return ecrecover(hash, v, r, s);
    }
}

contract CCJVTreasuryEngine {
    address public owner;
    address public treasuryWallet;

    struct WorkspaceConfig {
        address token;
        uint8 decimals;
        uint256 monthlyFeeRaw;
        bool active;
    }

    mapping(bytes32 => WorkspaceConfig) public workspaceConfig;
    mapping(address => mapping(bytes32 => mapping(bytes32 => uint256))) public paidUntil;

    event PaymentRecorded(address indexed payer, bytes32 indexed workspace, bytes32 indexed moduleKey, uint256 periods, uint256 amount, uint256 validUntil, uint8 paymentType);

    modifier onlyOwner() {
        require(msg.sender == owner, "owner only");
        _;
    }

    constructor(address _treasuryWallet) {
        owner = msg.sender;
        treasuryWallet = _treasuryWallet;
    }

    function setTreasuryWallet(address wallet) external onlyOwner {
        treasuryWallet = wallet;
    }

    function setWorkspace(bytes32 workspace, address token, uint8 decimals, uint256 monthlyFeeRaw, bool active) external onlyOwner {
        workspaceConfig[workspace] = WorkspaceConfig(token, decimals, monthlyFeeRaw, active);
    }

    function anchorPayment(address payer, bytes32 workspace, bytes32 moduleKey, uint256 periods, uint256 amount, uint256 validUntil, uint8 paymentType) external {
        WorkspaceConfig memory cfg = workspaceConfig[workspace];
        require(cfg.active, "workspace inactive");
        require(cfg.token != address(0), "token not set");
        require(periods > 0, "periods > 0");
        require(validUntil >= block.timestamp, "quote expired");
        require(amount == cfg.monthlyFeeRaw * periods, "bad amount");
        require(IERC20(cfg.token).transferFrom(msg.sender, treasuryWallet, amount), "transfer failed");

        uint256 start = paidUntil[payer][workspace][moduleKey] > block.timestamp ? paidUntil[payer][workspace][moduleKey] : block.timestamp;
        uint256 end = start + (periods * 30 days);
        paidUntil[payer][workspace][moduleKey] = end;

        emit PaymentRecorded(payer, workspace, moduleKey, periods, amount, end, paymentType);
    }

    function paymentStatus(address payer, bytes32 workspace, bytes32 moduleKey) external view returns (bool active, uint256 activeUntil) {
        activeUntil = paidUntil[payer][workspace][moduleKey];
        active = activeUntil >= block.timestamp;
    }

    function recoverSignerString(string calldata message, bytes calldata signature) external pure returns (address) {
        bytes32 hash = keccak256(bytes(message));
        return ECDSA.recover(ECDSA.toEthSignedMessageHash(hash), signature);
    }
}
