<?php
/*
Plugin Name: CCJV Core Fixes Layer
Description: Compatibility and stability fixes for CCJV Unified Core Hardened, theme, and add-on layers.
Version: 1.0.0
Author: OpenAI
*/

if (!defined('ABSPATH')) exit;

/*
 * 1) Make the core presence explicit for all add-on layers.
 * This resolves "requires CCJV Unified Core Hardened" style notices.
 */
if (!defined('CCJV_CORE_ACTIVE')) {
    define('CCJV_CORE_ACTIVE', true);
}

if (!function_exists('ccjv_core_loaded')) {
    function ccjv_core_loaded() {
        return true;
    }
}

/*
 * 2) Legacy shortcode compatibility.
 * Theme and older pages may still call [ccjvu_shell].
 * Route it to the best available live UI.
 */
function ccjv_core_fixes_render_shell() {
    if (shortcode_exists('ccjv_user_dashboard')) {
        return do_shortcode('[ccjv_user_dashboard]');
    }

    if (shortcode_exists('ccjv_wallet_ui')) {
        return '<div class="ccjv-fixes-wrap">' .
               '<h2>CCJV Platform</h2>' .
               do_shortcode('[ccjv_wallet_ui]') .
               '</div>';
    }

    return '<div class="ccjv-fixes-wrap"><h2>CCJV Platform</h2><p>Core is active.</p></div>';
}

add_shortcode('ccjvu_shell', 'ccjv_core_fixes_render_shell');

/*
 * 3) Front-end helper shortcode.
 */
add_shortcode('ccjv_core_status', function () {
    $out = '<div class="ccjv-fixes-wrap">';
    $out .= '<h3>CCJV Core Status</h3>';
    $out .= '<ul>';
    $out .= '<li>CCJV_CORE_ACTIVE: ' . (defined('CCJV_CORE_ACTIVE') ? 'yes' : 'no') . '</li>';
    $out .= '<li>ccjv_core_loaded(): ' . (function_exists('ccjv_core_loaded') && ccjv_core_loaded() ? 'yes' : 'no') . '</li>';
    $out .= '<li>[ccjvu_shell] available: yes</li>';
    $out .= '</ul>';
    $out .= '</div>';
    return $out;
});

/*
 * 4) Basic admin status page so the user can verify the patch is live.
 */
add_action('admin_menu', function () {
    add_submenu_page(
        'ccjv',
        'Core Fixes',
        'Core Fixes',
        'manage_options',
        'ccjv-core-fixes',
        function () {
            echo '<div class="wrap"><h1>CCJV Core Fixes Layer</h1>';
            echo '<p>Compatibility patch active.</p>';
            echo '<table class="widefat striped" style="max-width:800px">';
            echo '<tbody>';
            echo '<tr><td><strong>CCJV_CORE_ACTIVE</strong></td><td>' . (defined('CCJV_CORE_ACTIVE') ? 'defined' : 'missing') . '</td></tr>';
            echo '<tr><td><strong>ccjv_core_loaded()</strong></td><td>' . (function_exists('ccjv_core_loaded') ? 'available' : 'missing') . '</td></tr>';
            echo '<tr><td><strong>Legacy shortcode [ccjvu_shell]</strong></td><td>' . (shortcode_exists('ccjvu_shell') ? 'available' : 'missing') . '</td></tr>';
            echo '<tr><td><strong>User Dashboard shortcode</strong></td><td>' . (shortcode_exists('ccjv_user_dashboard') ? 'available' : 'missing') . '</td></tr>';
            echo '<tr><td><strong>Wallet shortcode</strong></td><td>' . (shortcode_exists('ccjv_wallet_ui') ? 'available' : 'missing') . '</td></tr>';
            echo '</tbody></table>';
            echo '</div>';
        }
    );
});

/*
 * 5) Small frontend/admin styling.
 */
add_action('wp_enqueue_scripts', function () {
    wp_register_style('ccjv-core-fixes-inline', false);
    wp_enqueue_style('ccjv-core-fixes-inline');
    wp_add_inline_style('ccjv-core-fixes-inline', '.ccjv-fixes-wrap{padding:16px;border:1px solid #ddd;border-radius:10px;background:#fff;color:#111;max-width:900px;margin:0 auto}.ccjv-fixes-wrap h2,.ccjv-fixes-wrap h3{margin-top:0}');
});
