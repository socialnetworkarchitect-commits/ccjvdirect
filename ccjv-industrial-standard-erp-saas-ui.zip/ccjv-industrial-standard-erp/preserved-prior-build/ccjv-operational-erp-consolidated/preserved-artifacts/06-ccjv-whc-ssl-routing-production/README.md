WHC/cPanel SSL routing configuration.
