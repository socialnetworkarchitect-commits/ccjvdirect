(function($){
  let provider, signer, currentWallet='';
  async function ensureChain(){
    if(!window.ethereum) throw new Error('MetaMask not detected');
    const s = CCJVLive.settings;
    try{ await ethereum.request({method:'wallet_switchEthereumChain', params:[{chainId:s.chainId}]}); }
    catch(err){ if(err.code===4902){ await ethereum.request({method:'wallet_addEthereumChain', params:[{chainId:s.chainId, chainName:s.chainName, rpcUrls:[s.rpcUrl], nativeCurrency:{name:'AVAX',symbol:'AVAX',decimals:18}, blockExplorerUrls:[s.explorerUrl]}]}); } else { throw err; } }
  }
  async function connect(){
    if(!window.ethereum){ alert('MetaMask not installed'); return; }
    await ensureChain();
    provider = new ethers.providers.Web3Provider(window.ethereum);
    await provider.send('eth_requestAccounts',[]);
    signer = provider.getSigner();
    currentWallet = await signer.getAddress();
    const chainId = await signer.getChainId();
    const message = 'CCJV wallet verification for '+window.location.host+' at '+new Date().toISOString();
    const signature = await signer.signMessage(message);
    await $.post(CCJVLive.ajaxurl,{action:'ccjv_save_wallet',nonce:CCJVLive.nonce,wallet_address:currentWallet,chain_id:chainId,signature_message:message,signature_value:signature});
    $('#ccjv-connect-wallet').text(currentWallet.slice(0,6)+'...'+currentWallet.slice(-4));
    await refreshWorkspace();
  }
  function drawChart(id, vals){
    const c=document.getElementById(id); if(!c) return; const ctx=c.getContext('2d'); ctx.clearRect(0,0,c.width,c.height); ctx.lineWidth=3; ctx.strokeStyle='#2563eb'; ctx.beginPath(); const max=Math.max(...vals), min=Math.min(...vals); vals.forEach((v,i)=>{ const x=(i/(vals.length-1))*c.width; const y=c.height-20-((v-min)/(Math.max(1,max-min)))*(c.height-40); if(i===0) ctx.moveTo(x,y); else ctx.lineTo(x,y); }); ctx.stroke(); }
  async function refreshWorkspace(){
    const workspace = $('.ccjv-shell').data('workspace') || 'core';
    const resp = await $.post(CCJVLive.ajaxurl,{action:'ccjv_get_workspace_config',nonce:CCJVLive.nonce,workspace});
    if(!resp.success) return;
    const w=resp.data.workspace;
    let balanceText='Connect wallet to check live gate'; let gateHtml='';
    if(window.ethereum && currentWallet){
      provider = provider || new ethers.providers.Web3Provider(window.ethereum);
      if(w.token_contract){
        const abi=['function balanceOf(address owner) view returns (uint256)','function decimals() view returns (uint8)'];
        const token=new ethers.Contract(w.token_contract, abi, provider);
        try{
          const raw=await token.balanceOf(currentWallet); const dec=w.token_decimals || await token.decimals(); const bal=parseFloat(ethers.utils.formatUnits(raw, dec));
          $('#ccjv-wallet-balance').text(bal.toFixed(4));
          const enough = bal >= parseFloat(w.gate_amount || 1);
          balanceText = enough ? 'Gate passed' : 'Need '+w.gate_amount+' '+w.token_symbol;
          gateHtml = '<span class="ccjv-gate-chip">Wallet: '+currentWallet+'</span><span class="ccjv-gate-chip">Balance: '+bal.toFixed(4)+' '+w.token_symbol+'</span><span class="ccjv-gate-chip">Gate: '+w.gate_amount+' '+w.token_symbol+'</span><a class="ccjv-btn" target="_blank" href="'+(w.buy_url || CCJVLive.settings.buyUrl)+'">'+CCJVLive.settings.buyLabel+'</a>';
        }catch(e){ balanceText='Token check failed'; gateHtml='<span class="ccjv-gate-chip">Could not read contract balance. Check contract address and decimals.</span>'; }
      } else {
        balanceText='Workspace token contract not configured'; gateHtml='<span class="ccjv-gate-chip">Add token contract in admin settings for live gate checks.</span>';
      }
    }
    $('#ccjv-gate-status').text(balanceText); $('#ccjv-gate-panel').html(gateHtml);
  }
  $(document).on('click','#ccjv-connect-wallet', async function(){ try{ await connect(); }catch(e){ alert(e.message || 'Wallet connection failed'); } });
  $(document).on('click','.ccjv-activate-module', async function(){
    const card=$(this).closest('.ccjv-module-card');
    const moduleId=card.data('module-id');
    if(!CCJVLive.isLoggedIn){ alert('Please log in first'); return; }
    if(!currentWallet && window.ethereum){ try{ await connect(); }catch(e){ return; } }
    const txHash = prompt('Optional: paste payment tx hash if you already paid the monthly fee. Leave blank to request activation.','') || '';
    const r = await $.post(CCJVLive.ajaxurl,{action:'ccjv_request_module_activation',nonce:CCJVLive.nonce,module_id:moduleId,payment_tx_hash:txHash});
    alert(r.success ? r.data.message : (r.data || 'Request failed'));
    if(r.success){ card.find('.ccjv-status').removeClass('warn').text('Pending'); }
  });
  $(document).on('submit','#ccjv-start-venture-form', async function(e){
    e.preventDefault(); if(!CCJVLive.isLoggedIn){ alert('Please log in'); return; }
    const data = $(this).serializeArray().reduce((a,x)=>{a[x.name]=x.value; return a;},{});
    data.action='ccjv_create_venture'; data.nonce=CCJVLive.nonce; data.workspace=$('.ccjv-shell').data('workspace');
    const r = await $.post(CCJVLive.ajaxurl, data); if(r.success) window.location.reload(); else alert(r.data || 'Could not create venture');
  });
  $(function(){ drawChart('ccjvChartA',[3,5,4,7,6,8,11]); drawChart('ccjvChartB',[10,8,9,7,8,6,5]); refreshWorkspace(); if(window.ethereum){ ethereum.on('accountsChanged',()=>window.location.reload()); ethereum.on('chainChanged',()=>window.location.reload()); } });
})(jQuery);
