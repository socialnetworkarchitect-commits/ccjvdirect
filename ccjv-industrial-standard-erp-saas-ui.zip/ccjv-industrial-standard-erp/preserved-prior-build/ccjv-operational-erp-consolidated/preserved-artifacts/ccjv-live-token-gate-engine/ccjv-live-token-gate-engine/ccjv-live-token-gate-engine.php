<?php
/*
Plugin Name: CCJV Live Token Gate Engine
Description: Live front-end shell, wallet connect, token-gated workspaces, ventures, monthly module subscriptions, and role-based access for CCJV.
Version: 1.0.0
Author: OpenAI
*/
if (!defined('ABSPATH')) exit;
define('CCJV_LIVE_VER', '1.0.0');
define('CCJV_LIVE_PATH', plugin_dir_path(__FILE__));
define('CCJV_LIVE_URL', plugin_dir_url(__FILE__));
require_once CCJV_LIVE_PATH.'includes/helpers.php';
require_once CCJV_LIVE_PATH.'includes/db.php';
require_once CCJV_LIVE_PATH.'includes/admin.php';
require_once CCJV_LIVE_PATH.'includes/front.php';
require_once CCJV_LIVE_PATH.'includes/ajax.php';
register_activation_hook(__FILE__, ['CCJV_Live_DB','activate']);
add_action('plugins_loaded', function(){
  new CCJV_Live_Admin();
  new CCJV_Live_Front();
  new CCJV_Live_Ajax();
});
