<?php
if (!defined('ABSPATH')) exit;
function ccjv_live_tables(){
  global $wpdb; $p=$wpdb->prefix;
  return [
    'workspaces'=>$p.'ccjv_workspaces',
    'modules'=>$p.'ccjv_modules',
    'ventures'=>$p.'ccjv_ventures',
    'venture_workspaces'=>$p.'ccjv_venture_workspaces',
    'wallets'=>$p.'ccjv_wallets',
    'subscriptions'=>$p.'ccjv_subscriptions',
    'access_overrides'=>$p.'ccjv_access_overrides',
    'audit'=>$p.'ccjv_audit',
  ];
}
function ccjv_live_option($key,$default=''){ $opts=get_option('ccjv_live_settings',[]); return $opts[$key] ?? $default; }
function ccjv_live_user_wallet($user_id){ global $wpdb; $t=ccjv_live_tables()['wallets']; return $wpdb->get_row($wpdb->prepare("SELECT * FROM $t WHERE user_id=%d ORDER BY id DESC LIMIT 1", $user_id), ARRAY_A); }
function ccjv_live_get_workspaces(){ global $wpdb; $t=ccjv_live_tables()['workspaces']; return $wpdb->get_results("SELECT * FROM $t ORDER BY sort_order ASC, name ASC", ARRAY_A); }
function ccjv_live_get_workspace($slug){ global $wpdb; $t=ccjv_live_tables()['workspaces']; return $wpdb->get_row($wpdb->prepare("SELECT * FROM $t WHERE slug=%s", sanitize_title($slug)), ARRAY_A); }
function ccjv_live_get_modules($workspace_id=0){ global $wpdb; $t=ccjv_live_tables()['modules']; if($workspace_id){ return $wpdb->get_results($wpdb->prepare("SELECT * FROM $t WHERE workspace_id=%d ORDER BY name ASC", $workspace_id), ARRAY_A);} return $wpdb->get_results("SELECT * FROM $t ORDER BY name ASC", ARRAY_A); }
function ccjv_live_get_user_subscription($user_id,$module_id){ global $wpdb; $t=ccjv_live_tables()['subscriptions']; return $wpdb->get_row($wpdb->prepare("SELECT * FROM $t WHERE user_id=%d AND module_id=%d ORDER BY id DESC LIMIT 1",$user_id,$module_id), ARRAY_A); }
function ccjv_live_user_can_module($user_id,$module, $workspace){
  if(user_can($user_id,'manage_options')) return ['allowed'=>true,'reason'=>'admin'];
  global $wpdb; $tables=ccjv_live_tables();
  $override = $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$tables['access_overrides']} WHERE user_id=%d AND workspace_id=%d AND module_id=%d AND status='active'",$user_id,(int)$workspace['id'],(int)$module['id']));
  if($override) return ['allowed'=>true,'reason'=>'override'];
  $roles = array_keys(get_userdata($user_id)->roles ?: []);
  if(!empty($module['allowed_roles'])){
    $allowed = array_filter(array_map('trim', explode(',', $module['allowed_roles'])));
    if($allowed && !array_intersect($roles,$allowed)) return ['allowed'=>false,'reason'=>'role'];
  }
  $sub = ccjv_live_get_user_subscription($user_id, $module['id']);
  if(!$sub || $sub['status']!=='active' || (!empty($sub['active_until']) && strtotime($sub['active_until']) < current_time('timestamp'))){
    return ['allowed'=>false,'reason'=>'subscription'];
  }
  return ['allowed'=>true,'reason'=>'subscription'];
}
function ccjv_live_audit($user_id,$action,$context='',$payload=[]){ global $wpdb; $t=ccjv_live_tables()['audit']; $wpdb->insert($t,['user_id'=>(int)$user_id,'action'=>sanitize_text_field($action),'context'=>sanitize_text_field($context),'payload'=>wp_json_encode($payload),'created_at'=>current_time('mysql')]); }
