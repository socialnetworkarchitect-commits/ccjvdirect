<?php
if (!defined('ABSPATH')) exit;
class CCJV_Live_Admin{
  public function __construct(){
    add_action('admin_menu', [$this,'menu']);
    add_action('admin_init', [$this,'settings']);
  }
  public function menu(){
    add_menu_page('CCJV Engine','CCJV Engine','manage_options','ccjv-live-engine',[$this,'settings_page'],'dashicons-shield-alt',26);
    add_submenu_page('ccjv-live-engine','Settings','Settings','manage_options','ccjv-live-engine',[$this,'settings_page']);
    add_submenu_page('ccjv-live-engine','Workspaces','Workspaces','manage_options','ccjv-live-workspaces',[$this,'workspaces_page']);
    add_submenu_page('ccjv-live-engine','Modules','Modules','manage_options','ccjv-live-modules',[$this,'modules_page']);
    add_submenu_page('ccjv-live-engine','Ventures','Ventures','manage_options','ccjv-live-ventures',[$this,'ventures_page']);
    add_submenu_page('ccjv-live-engine','Subscriptions','Subscriptions','manage_options','ccjv-live-subscriptions',[$this,'subscriptions_page']);
  }
  public function settings(){ register_setting('ccjv_live_settings_group','ccjv_live_settings'); }
  private function admin_header($title){ echo '<div class="wrap"><h1>'.esc_html($title).'</h1>'; }
  private function admin_footer(){ echo '</div>'; }
  public function settings_page(){
    if(!current_user_can('manage_options')) return; $this->admin_header('CCJV Live Engine Settings');
    $opts=get_option('ccjv_live_settings',[]);
    echo '<form method="post" action="options.php"><table class="form-table">'; settings_fields('ccjv_live_settings_group');
    $fields=[
      'site_logo_url'=>'Logo URL','header_bg'=>'Header Background','header_bg_image'=>'Header Background Image URL','hero_bg_image'=>'Hero Background Image URL','footer_bg'=>'Footer Background','footer_bg_image'=>'Footer Background Image URL','buy_direct_label'=>'Buy Direct Label','buy_direct_url'=>'Buy Direct URL','wallet_connect_label'=>'Wallet Button Label','avalanche_chain_id'=>'Avalanche Chain ID (hex)','avalanche_chain_name'=>'Avalanche Chain Name','avalanche_rpc_url'=>'Avalanche RPC URL','avalanche_explorer_url'=>'Explorer URL','token_gate_treasury_wallet'=>'Treasury Wallet','siwe_domain'=>'Sign Message Domain'
    ];
    $defaults=['site_logo_url'=>'http://ccjv.ca/wp-content/uploads/2024/04/ccjv-logo.jpeg','header_bg'=>'linear-gradient(135deg,#0f172a,#111827)','footer_bg'=>'linear-gradient(135deg,#0f172a,#020617)','buy_direct_label'=>'Buy Direct','buy_direct_url'=>'https://xmarkets.ca','wallet_connect_label'=>'Connect MetaMask','avalanche_chain_id'=>'0xa86a','avalanche_chain_name'=>'Avalanche C-Chain','avalanche_rpc_url'=>'https://api.avax.network/ext/bc/C/rpc','avalanche_explorer_url'=>'https://snowtrace.io','siwe_domain'=>parse_url(home_url(),PHP_URL_HOST)];
    foreach($fields as $k=>$label){ $v=esc_attr($opts[$k] ?? $defaults[$k] ?? ''); echo "<tr><th scope='row'>$label</th><td><input type='text' name='ccjv_live_settings[$k]' value='$v' class='regular-text' /></td></tr>"; }
    echo '</table>'; submit_button(); echo '</form>';
    $this->admin_footer();
  }
  public function workspaces_page(){ if(!current_user_can('manage_options')) return; global $wpdb; $t=ccjv_live_tables()['workspaces'];
    if(isset($_POST['ccjv_save_workspace']) && check_admin_referer('ccjv_save_workspace')){
      $data=['name'=>sanitize_text_field($_POST['name']),'slug'=>sanitize_title($_POST['slug']),'token_symbol'=>sanitize_text_field($_POST['token_symbol']),'token_contract'=>sanitize_text_field($_POST['token_contract']),'token_decimals'=>(int)$_POST['token_decimals'],'gate_amount'=>(float)$_POST['gate_amount'],'accent_color'=>sanitize_hex_color($_POST['accent_color']) ?: '#2563eb','skin'=>sanitize_text_field($_POST['skin']),'hero_title'=>sanitize_text_field($_POST['hero_title']),'hero_text'=>sanitize_textarea_field($_POST['hero_text']),'buy_url'=>esc_url_raw($_POST['buy_url']),'is_core'=>empty($_POST['is_core'])?0:1,'sort_order'=>(int)$_POST['sort_order']];
      if(!empty($_POST['id'])) $wpdb->update($t,$data,['id'=>(int)$_POST['id']]); else $wpdb->insert($t,$data);
    }
    if(isset($_GET['delete'])) $wpdb->delete($t,['id'=>(int)$_GET['delete']]);
    $edit = !empty($_GET['edit']) ? $wpdb->get_row($wpdb->prepare("SELECT * FROM $t WHERE id=%d",(int)$_GET['edit']),ARRAY_A) : [];
    $this->admin_header('Workspaces');
    echo '<form method="post">'; wp_nonce_field('ccjv_save_workspace'); echo '<input type="hidden" name="id" value="'.esc_attr($edit['id'] ?? '').'" /><table class="form-table">';
    foreach(['name','slug','token_symbol','token_contract','token_decimals','gate_amount','accent_color','skin','hero_title','hero_text','buy_url','sort_order'] as $f){
      $v=esc_attr($edit[$f] ?? ($f==='token_decimals'?18:($f==='gate_amount'?1:($f==='accent_color'?'#2563eb':''))));
      $input=$f==='hero_text' ? "<textarea name='$f' rows='3' class='large-text'>$v</textarea>" : "<input name='$f' value='$v' class='regular-text' />";
      echo "<tr><th>$f</th><td>$input</td></tr>";
    }
    $checked=!empty($edit['is_core'])?'checked':''; echo "<tr><th>is_core</th><td><label><input type='checkbox' name='is_core' value='1' $checked /> core workspace</label></td></tr>";
    echo '</table><p><button class="button button-primary" name="ccjv_save_workspace" value="1">Save Workspace</button></p></form>';
    $rows=$wpdb->get_results("SELECT * FROM $t ORDER BY sort_order ASC,name ASC",ARRAY_A); echo '<hr><table class="widefat striped"><thead><tr><th>ID</th><th>Name</th><th>Slug</th><th>Token</th><th>Gate</th><th>Actions</th></tr></thead><tbody>';
    foreach($rows as $r){ echo '<tr><td>'.$r['id'].'</td><td>'.$r['name'].'</td><td>'.$r['slug'].'</td><td>'.$r['token_symbol'].'</td><td>'.$r['gate_amount'].'</td><td><a href="?page=ccjv-live-workspaces&edit='.$r['id'].'">Edit</a> | <a href="?page=ccjv-live-workspaces&delete='.$r['id'].'">Delete</a></td></tr>'; }
    echo '</tbody></table>';
    $this->admin_footer();
  }
  public function modules_page(){ if(!current_user_can('manage_options')) return; global $wpdb; $tables=ccjv_live_tables(); $t=$tables['modules']; $ws=$wpdb->get_results("SELECT id,name FROM {$tables['workspaces']} ORDER BY name ASC",ARRAY_A);
    if(isset($_POST['ccjv_save_module']) && check_admin_referer('ccjv_save_module')){
      $data=['workspace_id'=>(int)$_POST['workspace_id'],'name'=>sanitize_text_field($_POST['name']),'slug'=>sanitize_title($_POST['slug']),'monthly_fee'=>(float)$_POST['monthly_fee'],'fee_token_symbol'=>sanitize_text_field($_POST['fee_token_symbol']),'allowed_roles'=>sanitize_text_field($_POST['allowed_roles']),'summary'=>sanitize_textarea_field($_POST['summary']),'sort_order'=>(int)$_POST['sort_order']];
      if(!empty($_POST['id'])) $wpdb->update($t,$data,['id'=>(int)$_POST['id']]); else $wpdb->insert($t,$data);
    }
    if(isset($_GET['delete'])) $wpdb->delete($t,['id'=>(int)$_GET['delete']]);
    $edit = !empty($_GET['edit']) ? $wpdb->get_row($wpdb->prepare("SELECT * FROM $t WHERE id=%d",(int)$_GET['edit']),ARRAY_A) : [];
    $this->admin_header('Modules');
    echo '<form method="post">'; wp_nonce_field('ccjv_save_module'); echo '<input type="hidden" name="id" value="'.esc_attr($edit['id'] ?? '').'" /><table class="form-table"><tr><th>workspace_id</th><td><select name="workspace_id">'; foreach($ws as $w){ $sel=selected($edit['workspace_id'] ?? '', $w['id'], false); echo "<option value='{$w['id']}' $sel>{$w['name']}</option>"; } echo '</select></td></tr>';
    foreach(['name','slug','monthly_fee','fee_token_symbol','allowed_roles','summary','sort_order'] as $f){ $v=esc_attr($edit[$f] ?? ($f==='monthly_fee'?1:'')); $input=$f==='summary' ? "<textarea name='$f' rows='3' class='large-text'>$v</textarea>" : "<input name='$f' value='$v' class='regular-text' />"; echo "<tr><th>$f</th><td>$input</td></tr>"; }
    echo '</table><p><button class="button button-primary" name="ccjv_save_module" value="1">Save Module</button></p></form>';
    $rows=$wpdb->get_results("SELECT m.*,w.name workspace_name FROM {$t} m LEFT JOIN {$tables['workspaces']} w ON w.id=m.workspace_id ORDER BY w.name,m.sort_order,m.name",ARRAY_A); echo '<hr><table class="widefat striped"><thead><tr><th>ID</th><th>Workspace</th><th>Name</th><th>Fee</th><th>Token</th><th>Roles</th><th>Actions</th></tr></thead><tbody>';
    foreach($rows as $r){ echo '<tr><td>'.$r['id'].'</td><td>'.$r['workspace_name'].'</td><td>'.$r['name'].'</td><td>'.$r['monthly_fee'].'</td><td>'.$r['fee_token_symbol'].'</td><td>'.$r['allowed_roles'].'</td><td><a href="?page=ccjv-live-modules&edit='.$r['id'].'">Edit</a> | <a href="?page=ccjv-live-modules&delete='.$r['id'].'">Delete</a></td></tr>'; }
    echo '</tbody></table>';
    $this->admin_footer(); }
  public function ventures_page(){ if(!current_user_can('manage_options')) return; global $wpdb; $tables=ccjv_live_tables();
    if(isset($_POST['ccjv_save_venture']) && check_admin_referer('ccjv_save_venture')){
      $data=['name'=>sanitize_text_field($_POST['name']),'slug'=>sanitize_title($_POST['slug']),'summary'=>sanitize_textarea_field($_POST['summary']),'created_by'=>get_current_user_id()];
      if(!empty($_POST['id'])){$wpdb->update($tables['ventures'],$data,['id'=>(int)$_POST['id']]); $id=(int)$_POST['id']; $wpdb->delete($tables['venture_workspaces'],['venture_id'=>$id]);}
      else {$wpdb->insert($tables['ventures'],$data); $id=$wpdb->insert_id;}
      foreach((array)($_POST['workspace_ids'] ?? []) as $wid){ $wpdb->insert($tables['venture_workspaces'],['venture_id'=>$id,'workspace_id'=>(int)$wid]); }
    }
    if(isset($_GET['delete'])){ $wpdb->delete($tables['ventures'],['id'=>(int)$_GET['delete']]); $wpdb->delete($tables['venture_workspaces'],['venture_id'=>(int)$_GET['delete']]); }
    $edit=!empty($_GET['edit']) ? $wpdb->get_row($wpdb->prepare("SELECT * FROM {$tables['ventures']} WHERE id=%d",(int)$_GET['edit']),ARRAY_A):[];
    $selected=[]; if($edit){ $selected=$wpdb->get_col($wpdb->prepare("SELECT workspace_id FROM {$tables['venture_workspaces']} WHERE venture_id=%d",(int)$edit['id'])); }
    $ws=$wpdb->get_results("SELECT id,name FROM {$tables['workspaces']} ORDER BY name ASC",ARRAY_A); $this->admin_header('Ventures');
    echo '<form method="post">'; wp_nonce_field('ccjv_save_venture'); echo '<input type="hidden" name="id" value="'.esc_attr($edit['id'] ?? '').'" /><table class="form-table">';
    foreach(['name','slug','summary'] as $f){ $v=esc_attr($edit[$f] ?? ''); $input=$f==='summary' ? "<textarea name='$f' rows='3' class='large-text'>$v</textarea>" : "<input name='$f' value='$v' class='regular-text' />"; echo "<tr><th>$f</th><td>$input</td></tr>"; }
    echo '<tr><th>workspace_ids</th><td>'; foreach($ws as $w){ $checked=in_array($w['id'],$selected)?'checked':''; echo "<label style='display:block'><input type='checkbox' name='workspace_ids[]' value='{$w['id']}' $checked /> {$w['name']}</label>"; } echo '</td></tr>';
    echo '</table><p><button class="button button-primary" name="ccjv_save_venture" value="1">Save Venture</button></p></form>';
    $rows=$wpdb->get_results("SELECT * FROM {$tables['ventures']} ORDER BY created_at DESC",ARRAY_A); echo '<hr><table class="widefat striped"><thead><tr><th>ID</th><th>Name</th><th>Slug</th><th>Actions</th></tr></thead><tbody>';
    foreach($rows as $r){ echo '<tr><td>'.$r['id'].'</td><td>'.$r['name'].'</td><td>'.$r['slug'].'</td><td><a href="?page=ccjv-live-ventures&edit='.$r['id'].'">Edit</a> | <a href="?page=ccjv-live-ventures&delete='.$r['id'].'">Delete</a></td></tr>'; }
    echo '</tbody></table>'; $this->admin_footer(); }
  public function subscriptions_page(){ if(!current_user_can('manage_options')) return; global $wpdb; $tables=ccjv_live_tables();
    if(isset($_GET['activate'])){ $id=(int)$_GET['activate']; $wpdb->update($tables['subscriptions'],['status'=>'active','started_at'=>current_time('mysql'),'active_until'=>date('Y-m-d H:i:s', strtotime('+30 days', current_time('timestamp')))],['id'=>$id]); }
    if(isset($_GET['expire'])){ $id=(int)$_GET['expire']; $wpdb->update($tables['subscriptions'],['status'=>'expired','active_until'=>current_time('mysql')],['id'=>$id]); }
    $this->admin_header('Subscriptions');
    $rows=$wpdb->get_results("SELECT s.*,u.user_login,m.name module_name,w.name workspace_name FROM {$tables['subscriptions']} s LEFT JOIN {$wpdb->users} u ON u.ID=s.user_id LEFT JOIN {$tables['modules']} m ON m.id=s.module_id LEFT JOIN {$tables['workspaces']} w ON w.id=s.workspace_id ORDER BY s.created_at DESC",ARRAY_A);
    echo '<table class="widefat striped"><thead><tr><th>ID</th><th>User</th><th>Workspace</th><th>Module</th><th>Fee</th><th>Status</th><th>Until</th><th>TX</th><th>Actions</th></tr></thead><tbody>';
    foreach($rows as $r){ echo '<tr><td>'.$r['id'].'</td><td>'.$r['user_login'].'</td><td>'.$r['workspace_name'].'</td><td>'.$r['module_name'].'</td><td>'.$r['monthly_fee'].' '.$r['fee_token_symbol'].'</td><td>'.$r['status'].'</td><td>'.$r['active_until'].'</td><td style="max-width:180px;word-break:break-all">'.$r['payment_tx_hash'].'</td><td><a href="?page=ccjv-live-subscriptions&activate='.$r['id'].'">Activate</a> | <a href="?page=ccjv-live-subscriptions&expire='.$r['id'].'">Expire</a></td></tr>'; }
    echo '</tbody></table>'; $this->admin_footer(); }
}
