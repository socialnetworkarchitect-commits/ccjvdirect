<?php
if (!defined('ABSPATH')) exit;
class CCJV_Live_Front{
  public function __construct(){ add_shortcode('ccjv_live_shell',[$this,'shell']); add_action('wp_enqueue_scripts',[$this,'assets']); }
  public function assets(){
    wp_register_style('ccjv-live', CCJV_LIVE_URL.'assets/css/style.css', [], CCJV_LIVE_VER);
    wp_register_script('ethers','https://cdn.jsdelivr.net/npm/ethers@5.7.2/dist/ethers.umd.min.js',[],null,true);
    wp_register_script('ccjv-live', CCJV_LIVE_URL.'assets/js/app.js', ['jquery','ethers'], CCJV_LIVE_VER, true);
    wp_localize_script('ccjv-live','CCJVLive',[
      'ajaxurl'=>admin_url('admin-ajax.php'),'nonce'=>wp_create_nonce('ccjv_live_nonce'),'isLoggedIn'=>is_user_logged_in(),'settings'=>[
        'logo'=>ccjv_live_option('site_logo_url','http://ccjv.ca/wp-content/uploads/2024/04/ccjv-logo.jpeg'),
        'buyLabel'=>ccjv_live_option('buy_direct_label','Buy Direct'),'buyUrl'=>ccjv_live_option('buy_direct_url','https://xmarkets.ca'),
        'chainId'=>ccjv_live_option('avalanche_chain_id','0xa86a'),'chainName'=>ccjv_live_option('avalanche_chain_name','Avalanche C-Chain'),'rpcUrl'=>ccjv_live_option('avalanche_rpc_url','https://api.avax.network/ext/bc/C/rpc'),'explorerUrl'=>ccjv_live_option('avalanche_explorer_url','https://snowtrace.io'),
      ]
    ]);
  }
  public function shell($atts=[]){
    wp_enqueue_style('ccjv-live'); wp_enqueue_script('ccjv-live');
    $user_id=get_current_user_id(); $wallet=$user_id ? ccjv_live_user_wallet($user_id) : null; $workspaces=ccjv_live_get_workspaces();
    $slug=sanitize_title($_GET['workspace'] ?? 'core'); $current=ccjv_live_get_workspace($slug); if(!$current && $workspaces) $current=$workspaces[0];
    $modules=$current ? ccjv_live_get_modules($current['id']) : [];
    $ventures=[]; if($user_id){ global $wpdb; $tables=ccjv_live_tables(); $ventures=$wpdb->get_results("SELECT * FROM {$tables['ventures']} ORDER BY created_at DESC LIMIT 6",ARRAY_A); }
    ob_start(); ?>
    <div class="ccjv-shell" data-workspace="<?php echo esc_attr($current['slug'] ?? 'core'); ?>">
      <header class="ccjv-topbar" style="background:<?php echo esc_attr(ccjv_live_option('header_bg','linear-gradient(135deg,#0f172a,#111827)')); ?>;<?php if(ccjv_live_option('header_bg_image')) echo 'background-image:url('.esc_url(ccjv_live_option('header_bg_image')).');background-size:cover;'; ?>">
        <div class="ccjv-brand"><img src="<?php echo esc_url(ccjv_live_option('site_logo_url','http://ccjv.ca/wp-content/uploads/2024/04/ccjv-logo.jpeg')); ?>" alt="CCJV" /><div><strong>CCJV</strong><span>Live Token Gate Engine</span></div></div>
        <nav class="ccjv-actions">
          <select class="ccjv-workspace-switcher" onchange="if(this.value) window.location='?workspace='+this.value;">
            <?php foreach($workspaces as $w): ?><option value="<?php echo esc_attr($w['slug']); ?>" <?php selected($current['slug'] ?? '',$w['slug']); ?>><?php echo esc_html($w['name']); ?></option><?php endforeach; ?>
          </select>
          <a class="ccjv-btn ccjv-btn-ghost" href="<?php echo esc_url(ccjv_live_option('buy_direct_url','https://xmarkets.ca')); ?>" target="_blank"><?php echo esc_html(ccjv_live_option('buy_direct_label','Buy Direct')); ?></a>
          <button class="ccjv-btn" id="ccjv-connect-wallet"><?php echo esc_html(ccjv_live_option('wallet_connect_label','Connect MetaMask')); ?></button>
        </nav>
      </header>
      <section class="ccjv-hero" style="--accent:<?php echo esc_attr($current['accent_color'] ?? '#2563eb'); ?>;<?php if(ccjv_live_option('hero_bg_image')) echo 'background-image:url('.esc_url(ccjv_live_option('hero_bg_image')).');background-size:cover;'; ?>">
        <div class="ccjv-hero-copy"><p class="eyebrow"><?php echo esc_html(($current['is_core']??0)?'Core ERP':'Sector ERP'); ?></p><h1><?php echo esc_html($current['hero_title'] ?? 'Operate Through CCJV'); ?></h1><p><?php echo esc_html($current['hero_text'] ?? 'Start a JV. Join a JV. Operate through the core ERP. Scale through sector ERPs.'); ?></p>
          <div class="ccjv-pill-row">
            <span class="ccjv-pill">1 <?php echo esc_html($current['token_symbol'] ?? 'CJV'); ?> token gate</span>
            <span class="ccjv-pill">1 <?php echo esc_html($current['token_symbol'] ?? 'CJV'); ?> token / month / element</span>
          </div>
        </div>
        <div class="ccjv-hero-panel">
          <div class="stat"><strong><?php echo count($modules); ?></strong><span>Elements</span></div>
          <div class="stat"><strong><?php echo count($ventures); ?></strong><span>Recent Ventures</span></div>
          <div class="stat"><strong id="ccjv-wallet-balance">0.0000</strong><span><?php echo esc_html($current['token_symbol'] ?? 'CJV'); ?> Balance</span></div>
        </div>
      </section>
      <div class="ccjv-layout">
        <aside class="ccjv-sidebar">
          <a href="?workspace=<?php echo esc_attr($current['slug'] ?? 'core'); ?>">Dashboard</a>
          <a href="?workspace=<?php echo esc_attr($current['slug'] ?? 'core'); ?>&view=start-jv">Start a JV</a>
          <a href="?workspace=<?php echo esc_attr($current['slug'] ?? 'core'); ?>&view=join-jv">Join a JV</a>
          <a href="?workspace=<?php echo esc_attr($current['slug'] ?? 'core'); ?>&view=operate">Operate</a>
          <a href="?workspace=<?php echo esc_attr($current['slug'] ?? 'core'); ?>&view=scale">Scale</a>
          <a href="?workspace=<?php echo esc_attr($current['slug'] ?? 'core'); ?>&view=ventures">Ventures</a>
        </aside>
        <main class="ccjv-main">
          <section class="ccjv-card"><div class="ccjv-section-head"><h2>Workspace Access</h2><span class="ccjv-badge" id="ccjv-gate-status">Checking token gate…</span></div><div id="ccjv-gate-panel" class="ccjv-gate-panel"></div></section>
          <section class="ccjv-card"><div class="ccjv-section-head"><h2>Elements</h2><span>Activate monthly access by module</span></div><div class="ccjv-grid modules"><?php foreach($modules as $m): $access = $user_id ? ccjv_live_user_can_module($user_id,$m,$current) : ['allowed'=>false,'reason'=>'login']; ?><article class="ccjv-module-card" data-module-id="<?php echo esc_attr($m['id']); ?>" data-workspace-id="<?php echo esc_attr($current['id']); ?>"><h3><?php echo esc_html($m['name']); ?></h3><p><?php echo esc_html($m['summary']); ?></p><div class="pricing">1 <strong><?php echo esc_html($m['fee_token_symbol'] ?: $current['token_symbol']); ?></strong> / month</div><div class="module-actions"><?php if($access['allowed']): ?><span class="ccjv-status ok">Active</span><button class="ccjv-btn ccjv-open-module">Open</button><?php else: ?><span class="ccjv-status warn"><?php echo esc_html(ucfirst($access['reason'])); ?></span><button class="ccjv-btn ccjv-activate-module" data-token="<?php echo esc_attr($m['fee_token_symbol'] ?: $current['token_symbol']); ?>">Activate</button><?php endif; ?></div></article><?php endforeach; ?></div></section>
          <section class="ccjv-card"><div class="ccjv-section-head"><h2>Venture Routing</h2><span>Multi-workspace deal flow</span></div><div class="ccjv-grid ventures"><?php if($ventures): foreach($ventures as $v): ?><article class="ccjv-venture-card"><h3><?php echo esc_html($v['name']); ?></h3><p><?php echo esc_html($v['summary']); ?></p><a class="ccjv-link" href="?workspace=<?php echo esc_attr($current['slug'] ?? 'core'); ?>&venture=<?php echo esc_attr($v['id']); ?>">Open Venture</a></article><?php endforeach; else: ?><div class="empty">No ventures yet. Start a JV to begin routing across workspaces.</div><?php endif; ?></div>
            <?php if(is_user_logged_in()): ?><form class="ccjv-inline-form" id="ccjv-start-venture-form"><input type="text" name="name" placeholder="Venture Name" required /><input type="text" name="slug" placeholder="venture-slug" required /><input type="text" name="summary" placeholder="Short summary" /><button class="ccjv-btn" type="submit">Start a JV</button></form><?php else: ?><p>Please log in to create ventures.</p><?php endif; ?>
          </section>
          <section class="ccjv-card charts"><div class="ccjv-section-head"><h2>Executive Snapshot</h2><span>Flagship shell indicators</span></div><div class="ccjv-chart-row"><div class="chart-box"><canvas id="ccjvChartA" width="340" height="160"></canvas></div><div class="chart-box"><canvas id="ccjvChartB" width="340" height="160"></canvas></div></div></section>
        </main>
      </div>
      <footer class="ccjv-footer" style="background:<?php echo esc_attr(ccjv_live_option('footer_bg','linear-gradient(135deg,#0f172a,#020617)')); ?>;<?php if(ccjv_live_option('footer_bg_image')) echo 'background-image:url('.esc_url(ccjv_live_option('footer_bg_image')).');background-size:cover;'; ?>"><div><strong>CCJV</strong><span>Start a JV. Join a JV. Operate. Scale.</span></div><a class="ccjv-btn ccjv-btn-ghost" href="<?php echo esc_url(ccjv_live_option('buy_direct_url','https://xmarkets.ca')); ?>" target="_blank"><?php echo esc_html(ccjv_live_option('buy_direct_label','Buy Direct')); ?></a></footer>
    </div>
    <?php return ob_get_clean();
  }
}
