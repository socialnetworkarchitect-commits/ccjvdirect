<?php
if (!defined('ABSPATH')) exit;
class CCJV_Live_DB{
  public static function activate(){
    global $wpdb; require_once ABSPATH.'wp-admin/includes/upgrade.php'; $c=$wpdb->get_charset_collate(); $t=ccjv_live_tables();
    dbDelta("CREATE TABLE {$t['workspaces']} (
      id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
      name VARCHAR(120) NOT NULL,
      slug VARCHAR(120) NOT NULL,
      token_symbol VARCHAR(20) NOT NULL,
      token_contract VARCHAR(80) DEFAULT '',
      token_decimals INT DEFAULT 18,
      gate_amount DECIMAL(24,8) DEFAULT 1,
      accent_color VARCHAR(20) DEFAULT '#2563eb',
      skin VARCHAR(60) DEFAULT 'default',
      hero_title VARCHAR(255) DEFAULT '',
      hero_text TEXT,
      buy_url VARCHAR(255) DEFAULT '',
      is_core TINYINT(1) DEFAULT 0,
      sort_order INT DEFAULT 0,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      PRIMARY KEY (id), UNIQUE KEY slug (slug)
    ) $c;");
    dbDelta("CREATE TABLE {$t['modules']} (
      id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
      workspace_id BIGINT UNSIGNED NOT NULL,
      name VARCHAR(120) NOT NULL,
      slug VARCHAR(120) NOT NULL,
      monthly_fee DECIMAL(24,8) DEFAULT 1,
      fee_token_symbol VARCHAR(20) DEFAULT '',
      allowed_roles VARCHAR(255) DEFAULT '',
      summary TEXT,
      sort_order INT DEFAULT 0,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      PRIMARY KEY (id), KEY workspace_id (workspace_id)
    ) $c;");
    dbDelta("CREATE TABLE {$t['ventures']} (
      id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
      name VARCHAR(190) NOT NULL,
      slug VARCHAR(190) NOT NULL,
      summary TEXT,
      created_by BIGINT UNSIGNED DEFAULT 0,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      PRIMARY KEY (id), UNIQUE KEY slug (slug)
    ) $c;");
    dbDelta("CREATE TABLE {$t['venture_workspaces']} (
      id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
      venture_id BIGINT UNSIGNED NOT NULL,
      workspace_id BIGINT UNSIGNED NOT NULL,
      PRIMARY KEY (id), KEY venture_id (venture_id), KEY workspace_id (workspace_id)
    ) $c;");
    dbDelta("CREATE TABLE {$t['wallets']} (
      id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
      user_id BIGINT UNSIGNED NOT NULL,
      wallet_address VARCHAR(80) NOT NULL,
      chain_id VARCHAR(30) DEFAULT '',
      signature_message TEXT,
      signature_value TEXT,
      nonce VARCHAR(128) DEFAULT '',
      verified_at DATETIME DEFAULT NULL,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      PRIMARY KEY (id), KEY user_id (user_id)
    ) $c;");
    dbDelta("CREATE TABLE {$t['subscriptions']} (
      id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
      user_id BIGINT UNSIGNED NOT NULL,
      workspace_id BIGINT UNSIGNED NOT NULL,
      module_id BIGINT UNSIGNED NOT NULL,
      wallet_address VARCHAR(80) DEFAULT '',
      fee_token_symbol VARCHAR(20) DEFAULT '',
      monthly_fee DECIMAL(24,8) DEFAULT 0,
      status VARCHAR(20) DEFAULT 'pending',
      started_at DATETIME DEFAULT NULL,
      active_until DATETIME DEFAULT NULL,
      payment_tx_hash VARCHAR(120) DEFAULT '',
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      PRIMARY KEY (id), KEY user_id (user_id), KEY module_id (module_id)
    ) $c;");
    dbDelta("CREATE TABLE {$t['access_overrides']} (
      id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
      user_id BIGINT UNSIGNED NOT NULL,
      workspace_id BIGINT UNSIGNED NOT NULL,
      module_id BIGINT UNSIGNED NOT NULL,
      status VARCHAR(20) DEFAULT 'active',
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      PRIMARY KEY (id)
    ) $c;");
    dbDelta("CREATE TABLE {$t['audit']} (
      id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
      user_id BIGINT UNSIGNED DEFAULT 0,
      action VARCHAR(120) NOT NULL,
      context VARCHAR(190) DEFAULT '',
      payload LONGTEXT,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      PRIMARY KEY (id)
    ) $c;");
    if(!$wpdb->get_var("SELECT COUNT(*) FROM {$t['workspaces']}")){
      $wpdb->insert($t['workspaces'], ['name'=>'CCJV Core','slug'=>'core','token_symbol'=>'CJV','gate_amount'=>1,'accent_color'=>'#2563eb','skin'=>'core','hero_title'=>'Operate Your Business Through CCJV','hero_text'=>'Start a JV. Join a JV. Operate through the core ERP. Scale through sector ERPs.','buy_url'=>'https://xmarkets.ca','is_core'=>1,'sort_order'=>1]);
      $core_id=$wpdb->insert_id;
      foreach([['CRM','crm'],['HRM','hrm'],['Accounting','accounting'],['Project Management','project-management'],['Asset Management','asset-management']] as $i=>$m){
        $wpdb->insert($t['modules'],['workspace_id'=>$core_id,'name'=>$m[0],'slug'=>$m[1],'monthly_fee'=>1,'fee_token_symbol'=>'CJV','summary'=>'1 token/month per element','sort_order'=>$i+1]);
      }
      foreach([
        ['Constructum','constructum','CST','#ea580c','construction'],
        ['EnergyChain','energychain','ENRC','#16a34a','energy'],
        ['LandBank','landbank','LBC','#a16207','land']
      ] as $i=>$w){
        $wpdb->insert($t['workspaces'], ['name'=>$w[0],'slug'=>$w[1],'token_symbol'=>$w[2],'gate_amount'=>1,'accent_color'=>$w[3],'skin'=>$w[4],'hero_title'=>$w[0].' Workspace','hero_text'=>'1 '.$w[2].' token gate, 1 '.$w[2].' token/month per element.','buy_url'=>'https://xmarkets.ca','sort_order'=>$i+2]);
        $wid=$wpdb->insert_id;
        foreach([['Dashboard','dashboard'],['Operations','operations'],['Documents','documents']] as $j=>$m){
          $wpdb->insert($t['modules'],['workspace_id'=>$wid,'name'=>$m[0],'slug'=>$m[1],'monthly_fee'=>1,'fee_token_symbol'=>$w[2],'summary'=>'1 token/month per element','sort_order'=>$j+1]);
        }
      }
    }
  }
}
