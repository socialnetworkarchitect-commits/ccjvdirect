if (!(defined('CCJV_CORE_ACTIVE') || function_exists('ccjv_core_loaded'))) { return; }
<?php
if (!defined('ABSPATH')) exit;
class Cibus_ERP_Frontend {
    public function __construct() {
        add_shortcode('cibus_portal', [$this, 'portal']);
        add_action('wp_enqueue_scripts', [$this, 'assets']);
        add_action('admin_post_cibus_erp_save', [$this, 'handle_save']);
        add_action('admin_post_nopriv_cibus_erp_save', [$this, 'handle_save']);
    }
    private function defaults() { return wp_parse_args(get_option('cibus_erp_settings', []), [
        'sector_token_name'=>'Cibus Coin','sector_token_symbol'=>'CIB','sector_token_contract'=>'0xA86AB9663Be3F64ffaE6Ad73aA305d38447f3C80','core_token_symbol'=>'CJV','core_token_gate'=>1,'sector_token_gate'=>1,'core_monthly_fee'=>1,'sector_monthly_fee'=>1,
        'buy_cib_url'=>'https://xmarkets.ca','buy_cjv_url'=>'https://xmarkets.ca','hero_title'=>'Agriculture & Food Processing ERP','hero_text'=>'From field to factory to warehouse to market.','kicker_text'=>'AGRICULTURE • FOOD PROCESSING • TRACEABILITY • DISTRIBUTION',
        'primary_color'=>'#0f5f3d','secondary_color'=>'#1f7a53','accent_color'=>'#d4a72c','surface_color'=>'#ffffff','bg_color'=>'#f4f7f4','logo_url'=>CIBUS_ERP_URL.'assets/img/cibus-logo.svg','show_all_modules'=>1,
        'module_crop'=>1,'module_livestock'=>1,'module_field'=>1,'module_traceability'=>1,'module_inventory'=>1,'module_operations'=>1,'module_recipe'=>1,'module_production'=>1,'module_quality'=>1,'module_shelflife'=>1,'module_allergen'=>1,'module_catchweight'=>1,
        'network_name'=>'Avalanche C-Chain','chain_id'=>'43114','rpc_url'=>'','explorer_url'=>'https://snowtrace.io','walletconnect_project_id'=>'','treasury_wallet'=>'','signer_endpoint'=>'','xmarkets_url'=>'https://xmarkets.ca'
    ]); }
    public function assets() {
        wp_register_style('cibus-erp-style', CIBUS_ERP_URL . 'assets/css/cibus-erp.css', [], CIBUS_ERP_VER);
        wp_register_script('cibus-erp-js', CIBUS_ERP_URL . 'assets/js/cibus-erp.js', [], CIBUS_ERP_VER, true);
    }
    public function handle_save() {
        if (!is_user_logged_in() || !wp_verify_nonce($_POST['_wpnonce'] ?? '', 'cibus_erp_save')) wp_die('Not allowed');
        global $wpdb; $action = sanitize_key($_POST['cibus_action'] ?? ''); $p = Cibus_ERP_DB::prefix();
        $map = [
            'save_crop' => [$p.'crop_cycles',['crop_name','field_name','variety','stage','planting_date','harvest_date','expected_yield','actual_yield','storage_location','notes']],
            'save_livestock' => [$p.'livestock',['animal_tag','species','breed','birth_date','lineage','feed_program','weight_norm','health_status','last_treatment','notes']],
            'save_field' => [$p.'field_maps',['zone_name','gps_reference','soil_fertility','land_use','water_status','treatment_plan']],
            'save_trace' => [$p.'traceability',['batch_code','source_type','source_name','field_or_lot','chemical_inputs','audit_status','destination']],
            'save_inventory' => [$p.'inventory',['item_name','category','location_name','quantity','unit_name','expiry_date','reorder_level','notes']],
            'save_operation' => [$p.'operations',['op_date','operation_type','crew_name','labor_hours','asset_name','fuel_used','water_used','cost_amount','notes']],
            'save_recipe' => [$p.'recipes',['recipe_name','version_name','category','ingredients','target_cost','allergen_flags','notes']],
            'save_run' => [$p.'production_runs',['run_code','recipe_name','scheduled_date','line_name','planned_qty','actual_qty','status','notes']],
            'save_quality' => [$p.'quality_checks',['lot_code','checkpoint_name','result_status','shelf_life_days','allergens_found','catch_weight','unit_name','notes']],
        ];
        if (isset($map[$action])) {
            [$table,$fields] = $map[$action]; $row = [];
            foreach ($fields as $f) {
                $v = $_POST[$f] ?? '';
                if (in_array($f,['expected_yield','actual_yield','weight_norm','quantity','reorder_level','labor_hours','fuel_used','water_used','cost_amount','target_cost','planned_qty','actual_qty','catch_weight'])) $row[$f] = (float)$v;
                elseif ($f==='shelf_life_days') $row[$f] = (int)$v;
                else $row[$f] = in_array($f,['notes','ingredients','chemical_inputs','treatment_plan']) ? sanitize_textarea_field($v) : sanitize_text_field($v);
            }
            $wpdb->insert($table, $row);
        }
        wp_safe_redirect(wp_get_referer() ?: home_url('/cibus-erp/')); exit;
    }
    private function fetch($table,$limit=8){ global $wpdb; return $wpdb->get_results("SELECT * FROM {$table} ORDER BY id DESC LIMIT ".intval($limit), ARRAY_A); }
    private function money($n){ return '$'.number_format((float)$n,2); }
    private function enabled_modules($s){
        $all = [
            'crop'=>['Crop Lifecycle','Plan rotations, planting, harvest, and storage'],
            'livestock'=>['Livestock & Health','Animal records, feed, lineage, treatments'],
            'field'=>['Field Mapping & GIS','Zone-level land, soil, water, and treatment control'],
            'traceability'=>['Lot Traceability & Recall','Lot history, supplier receipt, batch recall precision'],
            'inventory'=>['Inventory & Warehouse','Perishables, FEFO, stock levels, and reorder visibility'],
            'operations'=>['Operations, Labor & Assets','Crews, machinery, fuel, water, and cost logs'],
            'recipe'=>['Recipe & Formula Management','Recipe versions, substitutions, cost simulation'],
            'production'=>['Production Scheduling','Batch runs, line scheduling, planned vs actual'],
            'quality'=>['Quality, HACCP & Compliance','Checks, holds, pass-fail, and audit evidence'],
            'shelflife'=>['Shelf-Life, FEFO & Expiry','Expiry windows, FEFO, spoilage reduction'],
            'allergen'=>['Allergen Tracking','Allergen flags and cross-contact control'],
            'catchweight'=>['Catch Weight & UOM','Variable weight and UOM conversions'],
        ];
        if (!empty($s['show_all_modules'])) return $all;
        $out=[]; foreach($all as $k=>$v){ if(!empty($s['module_'.$k])) $out[$k]=$v; } return $out;
    }
    public function portal() {
        $s = $this->defaults();
        wp_enqueue_style('cibus-erp-style'); wp_enqueue_script('cibus-erp-js');
        $css='--cibus-primary:'.$s['primary_color'].';--cibus-secondary:'.$s['secondary_color'].';--cibus-accent:'.$s['accent_color'].';--cibus-surface:'.$s['surface_color'].';--cibus-bg:'.$s['bg_color'].';';
        $p = Cibus_ERP_DB::prefix();
        $crop=$this->fetch($p.'crop_cycles'); $livestock=$this->fetch($p.'livestock'); $recipes=$this->fetch($p.'recipes'); $runs=$this->fetch($p.'production_runs'); $quality=$this->fetch($p.'quality_checks');
        $inventory=$this->fetch($p.'inventory'); $ops=$this->fetch($p.'operations'); $trace=$this->fetch($p.'traceability');
        $mods = $this->enabled_modules($s);
        ob_start(); ?>
        <div class="cibus-portal" style="<?php echo esc_attr($css); ?>">
          <section class="cibus-hero light">
            <div class="cibus-hero-copy">
              <div class="cibus-kicker"><?php echo esc_html($s['kicker_text']); ?></div>
              <h1><?php echo esc_html($s['hero_title']); ?></h1>
              <p><?php echo esc_html($s['hero_text']); ?></p>
              <div class="cibus-hero-actions">
                <a class="cibus-btn primary" href="#workspace">Enter ERP</a>
                <a class="cibus-btn secondary" href="<?php echo esc_url($s['buy_cjv_url']); ?>" target="_blank" rel="noopener">Buy <?php echo esc_html($s['core_token_symbol']); ?></a>
                <a class="cibus-btn secondary" href="<?php echo esc_url($s['buy_cib_url']); ?>" target="_blank" rel="noopener">Buy <?php echo esc_html($s['sector_token_symbol']); ?></a>
              </div>
              <div class="cibus-inline-pricing"><strong>Access:</strong> <?php echo esc_html($s['core_token_gate'].' '.$s['core_token_symbol'].' + '.$s['sector_token_gate'].' '.$s['sector_token_symbol']); ?> <span><strong>Monthly per module:</strong> <?php echo esc_html($s['core_monthly_fee'].' '.$s['core_token_symbol'].' + '.$s['sector_monthly_fee'].' '.$s['sector_token_symbol']); ?></span></div>
            </div>
            <div class="cibus-hero-panel">
              <div class="stat"><span>Network</span><strong><?php echo esc_html($s['network_name']); ?></strong></div>
              <div class="stat"><span>Chain</span><strong>#<?php echo esc_html($s['chain_id']); ?></strong></div>
              <div class="stat"><span>Sector token</span><strong><?php echo esc_html($s['sector_token_symbol']); ?></strong></div>
              <div class="stat wide"><span>Contract</span><code><?php echo esc_html($s['sector_token_contract']); ?></code></div>
            </div>
          </section>
          <section class="cibus-module-grid">
            <?php foreach($mods as $key=>$mod): $enabled = !empty($s['module_'.$key]); ?>
              <article class="module-card <?php echo $enabled?'':'locked'; ?>">
                <div class="module-top"><h3><?php echo esc_html($mod[0]); ?></h3><span><?php echo $enabled?'Live':'Hidden by settings'; ?></span></div>
                <p><?php echo esc_html($mod[1]); ?></p>
              </article>
            <?php endforeach; ?>
          </section>
          <section class="cibus-access-card"><h2>Access Required</h2><p>Hold at least <?php echo esc_html($s['core_token_gate'].' '.$s['core_token_symbol']); ?> and <?php echo esc_html($s['sector_token_gate'].' '.$s['sector_token_symbol']); ?> in your connected wallet to enter the sector workspace. Monthly usage is charged per active module in both tokens under your current model.</p><div class="access-actions"><a class="cibus-btn secondary" href="<?php echo esc_url($s['buy_cjv_url']); ?>" target="_blank" rel="noopener">Buy <?php echo esc_html($s['core_token_symbol']); ?></a><a class="cibus-btn secondary" href="<?php echo esc_url($s['buy_cib_url']); ?>" target="_blank" rel="noopener">Buy <?php echo esc_html($s['sector_token_symbol']); ?></a><a class="cibus-btn ghost" href="#workspace">Retry Access</a></div></section>
          <section id="workspace" class="cibus-workspace">
            <div class="cibus-tabs">
              <button class="tab-btn active" data-tab="overview">Overview</button><button class="tab-btn" data-tab="farm">Farm</button><button class="tab-btn" data-tab="processing">Processing</button><button class="tab-btn" data-tab="quality">Quality</button>
            </div>
            <div class="tab-panel active" id="tab-overview">
              <div class="overview-grid">
                <div class="overview-card"><h3>Recent crop records</h3><strong><?php echo count($crop); ?></strong></div>
                <div class="overview-card"><h3>Recent livestock records</h3><strong><?php echo count($livestock); ?></strong></div>
                <div class="overview-card"><h3>Recent recipes</h3><strong><?php echo count($recipes); ?></strong></div>
                <div class="overview-card"><h3>Recent production runs</h3><strong><?php echo count($runs); ?></strong></div>
                <div class="overview-card"><h3>Recent quality checks</h3><strong><?php echo count($quality); ?></strong></div>
                <div class="overview-card"><h3>Recent traceability batches</h3><strong><?php echo count($trace); ?></strong></div>
              </div>
            </div>
            <div class="tab-panel" id="tab-farm">
              <div class="cibus-split">
                <div class="cibus-panel"><h3>Crop Lifecycle</h3><form class="cibus-form" method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>"><?php wp_nonce_field('cibus_erp_save'); ?><input type="hidden" name="action" value="cibus_erp_save"><input type="hidden" name="cibus_action" value="save_crop"><div class="field-grid"><input name="crop_name" placeholder="Crop name" required><input name="field_name" placeholder="Field"><input name="variety" placeholder="Variety"><input name="stage" placeholder="Stage"><input type="date" name="planting_date"><input type="date" name="harvest_date"></div><textarea name="notes" placeholder="Notes"></textarea><button class="cibus-btn primary" type="submit">Save Crop Record</button></form></div>
                <div class="cibus-panel"><h3>Recent farm entries</h3><ul class="record-list"><?php foreach(array_slice($crop,0,4) as $r) echo '<li><strong>'.esc_html($r['crop_name']).'</strong><span>'.esc_html($r['field_name']).'</span></li>'; foreach(array_slice($livestock,0,4) as $r) echo '<li><strong>'.esc_html($r['animal_tag']).'</strong><span>'.esc_html($r['species']).'</span></li>'; if(!$crop && !$livestock) echo '<li>No farm records yet.</li>'; ?></ul></div>
              </div>
            </div>
            <div class="tab-panel" id="tab-processing">
              <div class="cibus-split">
                <div class="cibus-panel"><h3>Recipe & Formula</h3><form class="cibus-form" method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>"><?php wp_nonce_field('cibus_erp_save'); ?><input type="hidden" name="action" value="cibus_erp_save"><input type="hidden" name="cibus_action" value="save_recipe"><div class="field-grid"><input name="recipe_name" placeholder="Recipe name" required><input name="version_name" placeholder="Version"><input name="category" placeholder="Category"><input type="number" step="0.01" name="target_cost" placeholder="Target cost"><input name="allergen_flags" placeholder="Allergen flags"></div><textarea name="ingredients" placeholder="Ingredients / formula"></textarea><button class="cibus-btn primary" type="submit">Save Recipe</button></form></div>
                <div class="cibus-panel"><h3>Production Scheduling</h3><form class="cibus-form" method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>"><?php wp_nonce_field('cibus_erp_save'); ?><input type="hidden" name="action" value="cibus_erp_save"><input type="hidden" name="cibus_action" value="save_run"><div class="field-grid"><input name="run_code" placeholder="Run code" required><input name="recipe_name" placeholder="Recipe"><input type="date" name="scheduled_date"><input name="line_name" placeholder="Line"><input type="number" step="0.01" name="planned_qty" placeholder="Planned qty"><input type="number" step="0.01" name="actual_qty" placeholder="Actual qty"><input name="status" placeholder="Status"></div><button class="cibus-btn primary" type="submit">Save Production Run</button></form></div>
              </div>
              <div class="cibus-split">
                <div class="cibus-panel"><h3>Recent recipes</h3><ul class="record-list"><?php foreach(array_slice($recipes,0,5) as $r) echo '<li><strong>'.esc_html($r['recipe_name']).'</strong><span>'.esc_html($r['version_name']).'</span></li>'; if(!$recipes) echo '<li>No recipe records yet.</li>'; ?></ul></div>
                <div class="cibus-panel"><h3>Recent production runs</h3><ul class="record-list"><?php foreach(array_slice($runs,0,5) as $r) echo '<li><strong>'.esc_html($r['run_code']).'</strong><span>'.esc_html($r['status']).'</span></li>'; if(!$runs) echo '<li>No production runs yet.</li>'; ?></ul></div>
              </div>
            </div>
            <div class="tab-panel" id="tab-quality">
              <div class="cibus-split">
                <div class="cibus-panel"><h3>Quality, HACCP & Shelf-Life</h3><form class="cibus-form" method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>"><?php wp_nonce_field('cibus_erp_save'); ?><input type="hidden" name="action" value="cibus_erp_save"><input type="hidden" name="cibus_action" value="save_quality"><div class="field-grid"><input name="lot_code" placeholder="Lot code" required><input name="checkpoint_name" placeholder="Checkpoint"><input name="result_status" placeholder="Result"><input type="number" name="shelf_life_days" placeholder="Shelf life days"><input name="allergens_found" placeholder="Allergens"><input type="number" step="0.01" name="catch_weight" placeholder="Catch weight"><input name="unit_name" placeholder="Unit"></div><textarea name="notes" placeholder="Notes"></textarea><button class="cibus-btn primary" type="submit">Save Quality Check</button></form></div>
                <div class="cibus-panel"><h3>Recent quality records</h3><ul class="record-list"><?php foreach(array_slice($quality,0,5) as $r) echo '<li><strong>'.esc_html($r['lot_code']).'</strong><span>'.esc_html($r['result_status']).' • '.esc_html($r['shelf_life_days']).' days</span></li>'; if(!$quality) echo '<li>No quality checks yet.</li>'; ?></ul></div>
              </div>
            </div>
          </section>
        </div>
        <?php return ob_get_clean();
    }
}
