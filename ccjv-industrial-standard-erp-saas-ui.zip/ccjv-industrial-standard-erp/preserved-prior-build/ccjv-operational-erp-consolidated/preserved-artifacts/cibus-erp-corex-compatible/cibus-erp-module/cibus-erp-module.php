if (!(defined('CCJV_CORE_ACTIVE') || function_exists('ccjv_core_loaded'))) { return; }
<?php
/*
Plugin Name: Cibus ERP Module
Description: Cibus ERP sector layer for CCJV. Agriculture + food processing ERP with dual-token access, editable blockchain settings, and ERP-first UI.
Version: 2.0.0
Author: OpenAI
*/
if (!defined('ABSPATH')) exit;
if (!defined('CCJVU_PATH')) {
    add_action('admin_notices', function(){ echo '<div class="notice notice-error"><p>Cibus ERP Module requires the CCJV Unified Core plugin to be active first.</p></div>'; });
    return;
}
define('CIBUS_ERP_VER', '2.0.0');
define('CIBUS_ERP_PATH', plugin_dir_path(__FILE__));
define('CIBUS_ERP_URL', plugin_dir_url(__FILE__));
require_once CIBUS_ERP_PATH . 'includes/class-cibus-erp-db.php';
require_once CIBUS_ERP_PATH . 'includes/class-cibus-erp-admin.php';
require_once CIBUS_ERP_PATH . 'includes/class-cibus-erp-frontend.php';
register_activation_hook(__FILE__, ['Cibus_ERP_DB', 'activate']);
register_deactivation_hook(__FILE__, ['Cibus_ERP_DB', 'deactivate']);
add_action('plugins_loaded', function(){ new Cibus_ERP_Admin(); new Cibus_ERP_Frontend(); });
add_filter('ccjvu_registered_sector_plugins', function($plugins){
    $s = wp_parse_args(get_option('cibus_erp_settings', []), [
        'sector_token_symbol' => 'CIB',
        'sector_token_contract' => '0xA86AB9663Be3F64ffaE6Ad73aA305d38447f3C80',
        'sector_token_decimals' => 18,
        'sector_token_gate' => 1,
        'primary_color' => '#0f5f3d',
        'hero_title' => 'Agriculture & Food Processing ERP',
        'hero_text' => 'Operate agriculture, food processing, traceability, inventory, compliance, and distribution from one workspace.',
        'buy_cib_url' => 'https://xmarkets.ca',
    ]);
    $plugins[] = [
        'id' => 0,
        'name' => 'Cibus Coin',
        'slug' => 'cibus',
        'token_symbol' => $s['sector_token_symbol'],
        'token_contract' => $s['sector_token_contract'],
        'token_decimals' => (int)$s['sector_token_decimals'],
        'gate_amount' => (float)$s['sector_token_gate'],
        'accent_color' => $s['primary_color'],
        'skin' => 'cibus',
        'hero_title' => $s['hero_title'],
        'hero_text' => $s['hero_text'],
        'buy_url' => $s['buy_cib_url'],
        'is_core' => 0,
        'active' => 1,
        'sort_order' => 14,
    ];
    return $plugins;
});
