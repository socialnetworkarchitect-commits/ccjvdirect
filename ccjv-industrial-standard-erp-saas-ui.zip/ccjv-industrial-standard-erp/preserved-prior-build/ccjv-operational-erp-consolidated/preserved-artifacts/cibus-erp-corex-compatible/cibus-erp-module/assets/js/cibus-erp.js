document.addEventListener('DOMContentLoaded', function(){
  document.querySelectorAll('.cibus-tabs .tab-btn').forEach(function(btn){
    btn.addEventListener('click', function(){
      var key = this.getAttribute('data-tab');
      document.querySelectorAll('.cibus-tabs .tab-btn').forEach(function(b){ b.classList.remove('active'); });
      document.querySelectorAll('.tab-panel').forEach(function(p){ p.classList.remove('active'); });
      this.classList.add('active');
      var panel = document.getElementById('tab-' + key);
      if (panel) panel.classList.add('active');
    });
  });
});
