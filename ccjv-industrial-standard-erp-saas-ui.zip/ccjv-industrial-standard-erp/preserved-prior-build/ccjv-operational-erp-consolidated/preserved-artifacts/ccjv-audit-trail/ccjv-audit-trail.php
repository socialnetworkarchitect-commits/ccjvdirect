<?php
/*
Plugin Name: CCJV Audit Trail
*/
function ccjv_log_tx($data){
 global $wpdb;
 $wpdb->insert($wpdb->prefix.'ccjv_tx_log',[
  'data'=>json_encode($data),
  'created'=>current_time('mysql')
 ]);
}
