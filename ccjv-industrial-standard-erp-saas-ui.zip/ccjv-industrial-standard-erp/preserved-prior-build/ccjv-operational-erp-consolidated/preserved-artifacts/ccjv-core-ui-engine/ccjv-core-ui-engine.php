<?php
/*
Plugin Name: CCJV Core UI Engine
Description: Provides the live CCJV dashboard shortcodes required by the CCJV WorldClass theme.
Version: 1.0.0
Author: CCJV
*/

if (!defined('ABSPATH')) exit;

function ccjv_ui_wallet() {
    $uid = get_current_user_id();
    $wallet = get_user_meta($uid, 'ccjv_wallet', true);
    if (!$wallet) $wallet = get_user_meta($uid, 'wallet_address', true);
    return $wallet;
}

function ccjv_ui_tenant() {
    return get_user_meta(get_current_user_id(), 'tenant_id', true);
}

function ccjv_ui_workspace() {
    return get_user_meta(get_current_user_id(), 'workspace_id', true);
}

function ccjv_ui_active_subscriptions() {
    global $wpdb;
    if (!is_user_logged_in()) return array();

    $table = $wpdb->prefix . 'ccjv_subscriptions';
    $exists = $wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $table));
    if (!$exists) return array();

    return $wpdb->get_results($wpdb->prepare(
        "SELECT * FROM {$table}
         WHERE user_id=%d AND status='active' AND expires_at > NOW()
         ORDER BY expires_at DESC LIMIT 50",
        get_current_user_id()
    ));
}

function ccjv_ui_vault_stats() {
    global $wpdb;
    $out = array('files'=>0,'bytes'=>0,'rewards'=>0,'fees'=>0);

    $vault = $wpdb->prefix . 'ccjv_vault';
    $log = $wpdb->prefix . 'ccjv_vault_access_log';

    if ($wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $vault))) {
        $where = '';
        if (is_user_logged_in() && !current_user_can('manage_options')) {
            $where = $wpdb->prepare(" WHERE user_id=%d", get_current_user_id());
        }
        $out['files'] = (int)$wpdb->get_var("SELECT COUNT(*) FROM {$vault}{$where}");
        $out['bytes'] = (int)$wpdb->get_var("SELECT COALESCE(SUM(file_size),0) FROM {$vault}{$where}");
    }

    if ($wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $log))) {
        $where = '';
        if (is_user_logged_in() && !current_user_can('manage_options')) {
            $where = $wpdb->prepare(" WHERE user_id=%d", get_current_user_id());
        }
        $out['rewards'] = (float)$wpdb->get_var("SELECT COALESCE(SUM(reward),0) FROM {$log}{$where}");
        $out['fees'] = (float)$wpdb->get_var("SELECT COALESCE(SUM(fee),0) FROM {$log}{$where}");
    }

    return $out;
}

function ccjv_ui_erp_cards() {
    $erps = array(
        array('key'=>'ccjv','name'=>'CCJV Core ERP','token'=>'CJV','url'=>'/ccjv-erp','desc'=>'CRM, HRM, accounting, projects, assets, and vault.'),
        array('key'=>'constructum','name'=>'Constructum ERP','token'=>'CST','url'=>'/constructum','desc'=>'Construction CRM, projects, estimating, accounting, and assets.'),
        array('key'=>'cibus','name'=>'Cibus ERP','token'=>'CIB','url'=>'/cibus','desc'=>'Food production, traceability, inventory, and compliance.'),
        array('key'=>'iter','name'=>'Iter ERP','token'=>'ITC','url'=>'/iter','desc'=>'Travel bookings, ticketing, yield, and capacity.'),
        array('key'=>'surge','name'=>'Surge Symposia ERP','token'=>'SYS','url'=>'/surge','desc'=>'Events, ticketing, sponsors, and speakers.')
    );

    $html = '<div class="ccjv-ui-grid">';
    foreach ($erps as $erp) {
        $html .= '<a class="ccjv-ui-card" href="' . esc_url($erp['url']) . '">';
        $html .= '<div class="ccjv-ui-token">' . esc_html($erp['token']) . '</div>';
        $html .= '<h3>' . esc_html($erp['name']) . '</h3>';
        $html .= '<p>' . esc_html($erp['desc']) . '</p>';
        $html .= '<span>Open Workspace →</span>';
        $html .= '</a>';
    }
    $html .= '</div>';
    return $html;
}

function ccjv_ui_dashboard_html() {
    if (!is_user_logged_in()) {
        return '<section class="ccjv-ui-shell"><div class="ccjv-ui-hero"><h1>CCJV ERP Platform</h1><p>Please log in to access your token-gated ERP workspace.</p><a class="ccjv-ui-btn" href="' . esc_url(wp_login_url(get_permalink())) . '">Log In</a></div></section>';
    }

    $wallet = ccjv_ui_wallet();
    $tenant = ccjv_ui_tenant();
    $workspace = ccjv_ui_workspace();
    $subs = ccjv_ui_active_subscriptions();
    $vault = ccjv_ui_vault_stats();

    ob_start(); ?>
    <section class="ccjv-ui-shell">
        <div class="ccjv-ui-hero">
            <div class="ccjv-ui-eyebrow">CCJV Command Workspace</div>
            <h1>Token-Gated ERP Platform</h1>
            <p>Access Core ERP and sector ERPs through one wallet, one tenant workspace, and one vault-backed record system.</p>
            <div class="ccjv-ui-actions">
                <a class="ccjv-ui-btn" href="/bind-wallet">Bind Wallet</a>
                <a class="ccjv-ui-btn secondary" href="/my-access">My Access</a>
                <a class="ccjv-ui-btn secondary" href="/vault">Vault</a>
            </div>
        </div>

        <div class="ccjv-ui-kpis">
            <div><strong>Wallet</strong><span><?php echo esc_html($wallet ?: 'Not bound'); ?></span></div>
            <div><strong>Tenant</strong><span><?php echo esc_html($tenant ?: 'Default'); ?></span></div>
            <div><strong>Workspace</strong><span><?php echo esc_html($workspace ?: 'Default'); ?></span></div>
            <div><strong>Active Modules</strong><span><?php echo esc_html(count($subs)); ?></span></div>
        </div>

        <h2>ERP Workspaces</h2>
        <?php echo ccjv_ui_erp_cards(); ?>

        <div class="ccjv-ui-two">
            <div class="ccjv-ui-panel">
                <h2>Active Subscriptions</h2>
                <?php if (!$subs): ?>
                    <p>No active module subscriptions yet.</p>
                <?php else: ?>
                    <?php foreach ($subs as $s): ?>
                        <div class="ccjv-ui-row">
                            <strong><?php echo esc_html($s->erp); ?> / <?php echo esc_html($s->module); ?></strong>
                            <span>Until <?php echo esc_html($s->expires_at); ?></span>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>

            <div class="ccjv-ui-panel">
                <h2>Vault Summary</h2>
                <div class="ccjv-ui-row"><strong>Files</strong><span><?php echo esc_html($vault['files']); ?></span></div>
                <div class="ccjv-ui-row"><strong>Storage</strong><span><?php echo esc_html(round($vault['bytes']/1000000, 2)); ?> MB</span></div>
                <div class="ccjv-ui-row"><strong>Rewards</strong><span><?php echo esc_html($vault['rewards']); ?></span></div>
                <div class="ccjv-ui-row"><strong>Fees</strong><span><?php echo esc_html($vault['fees']); ?></span></div>
            </div>
        </div>
    </section>
    <?php return ob_get_clean();
}

function ccjv_ui_vault_html() {
    $vault = ccjv_ui_vault_stats();
    return '<section class="ccjv-ui-shell"><h1>CCJV Vault</h1><div class="ccjv-ui-kpis"><div><strong>Files</strong><span>' . esc_html($vault['files']) . '</span></div><div><strong>Storage</strong><span>' . esc_html(round($vault['bytes']/1000000,2)) . ' MB</span></div><div><strong>Rewards</strong><span>' . esc_html($vault['rewards']) . '</span></div><div><strong>Fees</strong><span>' . esc_html($vault['fees']) . '</span></div></div><p>All ERP activity and uploads are recorded, hashed, and prepared for Avalanche anchoring.</p></section>';
}

add_shortcode('ccjv_dashboard', 'ccjv_ui_dashboard_html');
add_shortcode('ccjv_live', 'ccjv_ui_dashboard_html');
add_shortcode('ccjv_final_system', 'ccjv_ui_dashboard_html');
add_shortcode('ccjv_core', 'ccjv_ui_dashboard_html');
add_shortcode('ccjv_app', 'ccjv_ui_dashboard_html');
add_shortcode('ccjv_vault_page', 'ccjv_ui_vault_html');

add_action('wp_head', function(){ ?>
<style>
.ccjv-ui-shell{max-width:1180px;margin:0 auto;padding:24px;color:#0f172a;font-family:Inter,Arial,sans-serif}
.ccjv-ui-hero{background:linear-gradient(135deg,#0f172a,#111827);color:#fff;border-radius:28px;padding:34px;margin:20px 0;box-shadow:0 20px 60px rgba(0,0,0,.25)}
.ccjv-ui-eyebrow{display:inline-block;padding:7px 12px;background:rgba(56,189,248,.15);color:#7dd3fc;border-radius:999px;font-size:12px;font-weight:800;text-transform:uppercase;letter-spacing:.05em}
.ccjv-ui-hero h1{font-size:clamp(34px,6vw,64px);line-height:1;margin:16px 0 12px;color:#fff}
.ccjv-ui-hero p{font-size:18px;color:#cbd5e1;max-width:780px}
.ccjv-ui-actions{display:flex;gap:12px;flex-wrap:wrap;margin-top:22px}
.ccjv-ui-btn{display:inline-flex;padding:13px 18px;border-radius:14px;background:#38bdf8;color:#06121f!important;text-decoration:none!important;font-weight:900}
.ccjv-ui-btn.secondary{background:#1f2937;color:#fff!important;border:1px solid rgba(255,255,255,.12)}
.ccjv-ui-kpis{display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:14px;margin:20px 0}
.ccjv-ui-kpis div,.ccjv-ui-card,.ccjv-ui-panel{background:#fff;border:1px solid #e5e7eb;border-radius:18px;padding:18px;box-shadow:0 10px 30px rgba(15,23,42,.08)}
.ccjv-ui-kpis strong{display:block;color:#475569;font-size:13px;text-transform:uppercase;letter-spacing:.04em}
.ccjv-ui-kpis span{display:block;font-size:18px;font-weight:800;word-break:break-word}
.ccjv-ui-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:16px;margin:16px 0 28px}
.ccjv-ui-card{text-decoration:none!important;color:#0f172a!important;display:block}
.ccjv-ui-card h3{margin:10px 0 8px;font-size:22px;color:#0f172a}
.ccjv-ui-card p{color:#475569;min-height:55px}
.ccjv-ui-card span{font-weight:900;color:#0369a1}
.ccjv-ui-token{display:inline-flex;background:#e0f2fe;color:#0369a1;padding:6px 10px;border-radius:999px;font-weight:900}
.ccjv-ui-two{display:grid;grid-template-columns:repeat(auto-fit,minmax(280px,1fr));gap:16px;margin-top:20px}
.ccjv-ui-row{display:flex;justify-content:space-between;gap:12px;border-top:1px solid #e5e7eb;padding:12px 0}
@media(max-width:640px){.ccjv-ui-shell{padding:12px}.ccjv-ui-hero{padding:24px;border-radius:20px}.ccjv-ui-row{display:block}.ccjv-ui-actions{flex-direction:column}.ccjv-ui-btn{justify-content:center}}
</style>
<?php });
