CCJV Operational Substrate — Build 18

Build 18 transitions from runtime topology expansion into executable orchestration cohesion.

Primary additions:
- event causality continuity
- runtime dependency DAG continuity
- replay determinism continuity
- operational memory hydration
- treasury→vault→proof lineage continuity
- federation heartbeat synchronization
- replay-linked observability traces
- runtime reconciliation workers
