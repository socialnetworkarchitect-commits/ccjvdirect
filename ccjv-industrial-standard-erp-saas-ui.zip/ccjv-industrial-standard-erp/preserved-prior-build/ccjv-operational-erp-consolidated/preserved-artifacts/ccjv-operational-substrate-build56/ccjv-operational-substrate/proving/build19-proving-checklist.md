# Build 19 Proving Checklist

Required proving artifacts:
- PM2 starts all Build 19 runtime workers.
- BullMQ connects to Redis and processes continuity jobs.
- Replay execution engine emits deterministic replay signature.
- Treasury pipeline emits transferFrom execution plan.
- Vault/proof worker emits Merkle root.
- Federation worker emits ERP heartbeat events.
- Observability worker emits replay-linked trace event.
- Operational memory hydrator emits lineage hydration event.
- No Build 18 subsystem removed.
