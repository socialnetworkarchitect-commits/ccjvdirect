module.exports = {
  apps: [
    {
      name: 'ccjv-avalanche-runtime',
      script: './api/server.js',
      env: {
        PORT: 4030
      }
    },
    {
      name: 'ccjv-treasury-runtime',
      script: './api/server.js',
      env: {
        PORT: 4020
      }
    },
    {
      name: 'ccjv-replay-worker',
      script: './queues/workers/replay-worker.js'
    },
    {
      name: 'ccjv-treasury-worker',
      script: './queues/workers/treasury-worker.js'
    },
    {
      name: 'ccjv-websocket-runtime',
      script: './api/server.js',
      env: {
        PORT: 4010
      }
    },
    { name: 'ccjv-migrations-b21', script: './persistence/run-migrations.js' },
    { name: 'ccjv-api-b20', script: './api/server.js', env: { API_PORT: 3100 } },
    { name: 'ccjv-orchestrator-b19', script: './orchestrator/orchestration-engine.js' },
    { name: 'ccjv-queues-b19', script: './queues/queue-execution-runtime.js' },
    { name: 'ccjv-replay-b19', script: './replay/replay-execution-engine.js' },
    { name: 'ccjv-treasury-b19', script: './treasury/treasury-execution-pipeline.js' },
    { name: 'ccjv-vault-proof-b19', script: './vault-proof/vault-proof-execution-worker.js' },
    { name: 'ccjv-federation-b19', script: './federation/federation-sync-worker.js' },
    { name: 'ccjv-observability-b19', script: './observability/trace-emitter.js' },
    { name: 'ccjv-memory-b19', script: './memory/operational-memory-hydrator.js' }
  ]
};
