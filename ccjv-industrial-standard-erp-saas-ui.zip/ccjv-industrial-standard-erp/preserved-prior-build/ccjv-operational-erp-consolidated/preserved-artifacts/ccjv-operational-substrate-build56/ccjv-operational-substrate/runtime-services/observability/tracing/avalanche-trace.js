function avalancheTrace(event) {
  return {
    trace_id: event.trace_id,
    avalanche_event: true,
    tx_hash: event.tx_hash,
    correlation_id: event.correlation_id,
    timestamp: new Date().toISOString()
  };
}

module.exports = {
  avalancheTrace
};
