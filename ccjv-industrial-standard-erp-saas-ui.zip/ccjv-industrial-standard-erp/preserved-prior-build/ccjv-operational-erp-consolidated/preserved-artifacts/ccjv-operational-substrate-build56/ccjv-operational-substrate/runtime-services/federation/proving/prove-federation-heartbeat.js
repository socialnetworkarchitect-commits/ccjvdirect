const {
  FederationHeartbeatRuntime
} = require('../runtime/heartbeat-runtime');

async function proveFederationHeartbeat() {
  const runtime = new FederationHeartbeatRuntime();

  runtime.registerNode({
    id: 'node-1',
    erp: 'impensa'
  });

  const verified = runtime.verifyContinuity();

  console.log(JSON.stringify({
    federation_heartbeat: true,
    continuity_verified: verified.length > 0
  }, null, 2));
}

proveFederationHeartbeat();
