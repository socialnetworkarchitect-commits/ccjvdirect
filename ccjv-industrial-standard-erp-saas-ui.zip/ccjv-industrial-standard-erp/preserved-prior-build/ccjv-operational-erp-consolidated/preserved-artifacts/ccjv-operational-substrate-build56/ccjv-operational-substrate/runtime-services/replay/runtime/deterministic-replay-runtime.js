class DeterministicReplayRuntime {
  replay(events) {
    const ordered =
      [...events].sort(
        (a, b) => a.ts - b.ts
      );

    return {
      deterministic: true,
      replayed: ordered.length,
      hash:
        'replay-' + ordered.length
    };
  }
}

module.exports = {
  DeterministicReplayRuntime
};
