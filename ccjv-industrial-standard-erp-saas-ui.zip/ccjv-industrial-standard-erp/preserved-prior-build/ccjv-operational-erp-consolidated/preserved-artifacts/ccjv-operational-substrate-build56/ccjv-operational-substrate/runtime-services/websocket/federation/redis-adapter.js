const { createAdapter } = require('@socket.io/redis-adapter');
const { createClient } = require('redis');

async function buildRedisAdapter(io) {
  const pubClient = createClient({
    url: process.env.REDIS_URL || 'redis://127.0.0.1:6379'
  });

  const subClient = pubClient.duplicate();

  await pubClient.connect();
  await subClient.connect();

  io.adapter(createAdapter(pubClient, subClient));

  return {
    pubClient,
    subClient
  };
}

module.exports = {
  buildRedisAdapter
};
