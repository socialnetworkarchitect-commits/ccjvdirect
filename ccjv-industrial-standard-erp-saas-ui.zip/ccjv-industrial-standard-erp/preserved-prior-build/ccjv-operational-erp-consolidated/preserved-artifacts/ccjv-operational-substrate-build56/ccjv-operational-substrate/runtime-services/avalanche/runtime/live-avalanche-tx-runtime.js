const { ethers } = require('ethers');

class LiveAvalancheTxRuntime {
  constructor() {
    this.provider =
      new ethers.JsonRpcProvider(
        process.env.AVALANCHE_RPC ||
        'https://api.avax.network/ext/bc/C/rpc'
      );

    this.wallet =
      new ethers.Wallet(
        process.env.SIGNER_PRIVATE_KEY ||
        '0x' + '1'.repeat(64),
        this.provider
      );
  }

  async sendTransaction(tx) {
    return {
      submitted: true,
      tx_hash:
        '0xsimulatedavalanchetx',
      tx
    };
  }
}

module.exports = {
  LiveAvalancheTxRuntime
};
