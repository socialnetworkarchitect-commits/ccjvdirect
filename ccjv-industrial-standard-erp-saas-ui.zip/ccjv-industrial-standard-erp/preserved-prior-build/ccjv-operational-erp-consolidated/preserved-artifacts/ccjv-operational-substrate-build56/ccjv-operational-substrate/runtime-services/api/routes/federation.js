const express = require('express');
const router = express.Router();
const store = require('../lib/runtime-store');

router.post('/heartbeat', async (req, res) => {
  const erp = req.body.erp_slug || 'unknown';
  const event = await store.emitEvent({
    tenant_id: req.tenant_id,
    workspace_id: req.workspace_id,
    correlation_id: req.correlation_id,
    causality_id: req.causality_id,
    replay_id: req.replay_id,
    event_type: 'federation.erp.heartbeat',
    payload: {
      erp_slug: erp,
      status: req.body.status || 'ONLINE',
      endpoints: req.body.endpoints || ['/health','/modules','/workspaces','/events','/replay','/vault','/treasury']
    }
  });
  res.json({ ok: true, event });
});

module.exports = router;
