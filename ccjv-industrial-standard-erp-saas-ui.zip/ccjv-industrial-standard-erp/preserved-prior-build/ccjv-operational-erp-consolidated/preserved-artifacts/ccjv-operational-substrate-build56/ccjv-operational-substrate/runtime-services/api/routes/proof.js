const express = require('express');
const router = express.Router();
const crypto = require('crypto');
const store = require('../lib/runtime-store');

function merkleRoot(hashes) {
  if (!hashes.length) return '';
  let layer = hashes.sort();
  while (layer.length > 1) {
    const next = [];
    for (let i=0; i<layer.length; i+=2) {
      const left = layer[i];
      const right = layer[i+1] || left;
      next.push(crypto.createHash('sha256').update(left + right).digest('hex'));
    }
    layer = next;
  }
  return layer[0];
}

router.post('/merkle', async (req, res) => {
  const hashes = req.body.hashes || [];
  const root = merkleRoot(hashes);
  const event = await store.emitEvent({
    tenant_id: req.tenant_id,
    workspace_id: req.workspace_id,
    correlation_id: req.correlation_id,
    causality_id: req.causality_id,
    replay_id: req.replay_id,
    event_type: 'proof.merkle.root.generated',
    payload: { hashes, merkle_root: root }
  });
  res.json({ ok: true, merkle_root: root, event });
});

module.exports = router;
