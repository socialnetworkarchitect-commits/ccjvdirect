const {
  SignerIsolationRuntime
} = require('../runtime/signer-isolation-runtime');

async function proveSigning() {
  const runtime =
    new SignerIsolationRuntime();

  const signature =
    await runtime.sign({
      type: 'TREASURY_PROOF'
    });

  console.log(JSON.stringify({
    signed: true,
    signer:
      runtime.address(),
    signature
  }, null, 2));
}

proveSigning();
