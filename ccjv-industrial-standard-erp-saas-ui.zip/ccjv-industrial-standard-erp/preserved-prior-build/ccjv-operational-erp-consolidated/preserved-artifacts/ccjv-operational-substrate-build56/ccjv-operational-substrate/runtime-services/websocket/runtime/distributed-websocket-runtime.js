class DistributedWebsocketRuntime {
  constructor() {
    this.nodes = [];
  }

  registerNode(node) {
    this.nodes.push(node);

    return {
      clustered: true,
      nodes: this.nodes.length
    };
  }
}

module.exports = {
  DistributedWebsocketRuntime
};
