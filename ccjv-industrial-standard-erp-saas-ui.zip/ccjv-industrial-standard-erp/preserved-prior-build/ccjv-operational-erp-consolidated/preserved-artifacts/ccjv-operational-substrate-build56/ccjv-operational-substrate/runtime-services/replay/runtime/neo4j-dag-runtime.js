class Neo4JDAGRuntime {
  constructor() {
    this.nodes = [];
    this.edges = [];
  }

  async persistNode(node) {
    this.nodes.push(node);

    return {
      persisted: true,
      node_id: node.id
    };
  }

  async persistEdge(edge) {
    this.edges.push(edge);

    return {
      persisted: true
    };
  }
}

module.exports = {
  Neo4JDAGRuntime
};
