const { Worker } = require('bullmq');
const connection = require('../redis-runtime');

const replayWorker = new Worker(
  'ccjv-replay',
  async job => {
    console.log('[CCJV Build23] replay worker processing', job.id);

    return {
      replay_processed: true,
      replay_id: job.data.replay_id
    };
  },
  { connection }
);

replayWorker.on('completed', (job) => {
  console.log('[CCJV Build23] replay completed', job.id);
});

module.exports = replayWorker;
