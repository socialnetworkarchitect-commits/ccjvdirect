const fs = require('fs');
const path = require('path');

class QueuePersistenceAdapter {
  constructor() {
    this.base = path.join(process.cwd(), 'queue-storage');

    if (!fs.existsSync(this.base)) {
      fs.mkdirSync(this.base, { recursive: true });
    }
  }

  persist(queueName, payload) {
    const file = path.join(this.base, `${queueName}.json`);

    let data = [];

    if (fs.existsSync(file)) {
      data = JSON.parse(fs.readFileSync(file));
    }

    data.push(payload);

    fs.writeFileSync(file, JSON.stringify(data, null, 2));

    return true;
  }

  recover(queueName) {
    const file = path.join(this.base, `${queueName}.json`);

    if (!fs.existsSync(file)) {
      return [];
    }

    return JSON.parse(fs.readFileSync(file));
  }
}

module.exports = {
  QueuePersistenceAdapter
};
