const {
  DeterministicReplayRuntime
} = require('../runtime/deterministic-replay-runtime');

async function proveReplay() {
  const runtime =
    new DeterministicReplayRuntime();

  const correlation_id =
    'corr_test_runtime';

  runtime.append({
    type: 'vault.persisted',
    correlation_id
  });

  runtime.append({
    type: 'treasury.executed',
    correlation_id
  });

  const verification =
    runtime.verifyDeterminism(
      correlation_id
    );

  console.log(JSON.stringify({
    deterministic:
      verification.deterministic,
    replay_length:
      verification.replay_length
  }, null, 2));
}

proveReplay();
