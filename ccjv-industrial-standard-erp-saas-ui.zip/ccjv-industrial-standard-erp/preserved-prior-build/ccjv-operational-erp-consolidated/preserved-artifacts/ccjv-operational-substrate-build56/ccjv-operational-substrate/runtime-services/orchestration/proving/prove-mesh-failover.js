const {
  MeshFailoverRuntime
} = require('../runtime/mesh-failover-runtime');

async function proveMesh() {
  const runtime =
    new MeshFailoverRuntime();

  const result =
    runtime.failover([
      { active: true },
      { active: true },
      { active: false }
    ]);

  console.log(JSON.stringify(
    result,
    null,
    2
  ));
}

proveMesh();
