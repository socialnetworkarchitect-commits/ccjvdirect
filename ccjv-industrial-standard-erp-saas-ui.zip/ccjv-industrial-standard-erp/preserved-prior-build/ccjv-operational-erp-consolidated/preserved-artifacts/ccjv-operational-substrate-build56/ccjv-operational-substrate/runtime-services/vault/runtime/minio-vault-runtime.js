const crypto = require('crypto');

class MinIOVaultRuntime {
  constructor() {
    this.objects = [];
  }

  storeObject(payload) {
    const hash = crypto
      .createHash('sha256')
      .update(JSON.stringify(payload))
      .digest('hex');

    const object = {
      object_id: `obj_${Date.now()}`,
      hash,
      payload,
      stored_at: new Date().toISOString()
    };

    this.objects.push(object);

    return object;
  }

  retrieveObject(objectId) {
    return this.objects.find(
      (o) => o.object_id === objectId
    );
  }

  verifyIntegrity(objectId) {
    const object = this.retrieveObject(objectId);

    return {
      verified: !!object,
      hash: object ? object.hash : null
    };
  }
}

module.exports = {
  MinIOVaultRuntime
};
