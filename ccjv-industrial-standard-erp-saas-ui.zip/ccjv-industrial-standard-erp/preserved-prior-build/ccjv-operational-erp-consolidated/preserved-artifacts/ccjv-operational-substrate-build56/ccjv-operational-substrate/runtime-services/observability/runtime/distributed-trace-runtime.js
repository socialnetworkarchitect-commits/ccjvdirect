const crypto = require('crypto');

class DistributedTraceRuntime {
  constructor() {
    this.traces = [];
  }

  startTrace(service, operation) {
    const trace = {
      trace_id: crypto.randomUUID(),
      service,
      operation,
      started_at: new Date().toISOString(),
      spans: []
    };

    this.traces.push(trace);

    return trace;
  }

  addSpan(traceId, span) {
    const trace = this.traces.find(
      t => t.trace_id === traceId
    );

    if (!trace) {
      return null;
    }

    trace.spans.push({
      ...span,
      created_at: new Date().toISOString()
    });

    return trace;
  }

  getTrace(traceId) {
    return this.traces.find(
      t => t.trace_id === traceId
    );
  }
}

module.exports = {
  DistributedTraceRuntime
};
