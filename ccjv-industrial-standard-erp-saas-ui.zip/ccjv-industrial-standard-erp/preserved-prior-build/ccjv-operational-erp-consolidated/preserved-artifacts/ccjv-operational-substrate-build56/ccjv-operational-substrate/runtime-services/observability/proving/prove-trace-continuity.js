const {
  DistributedTraceRuntime
} = require('../runtime/distributed-trace-runtime');

async function proveTraceContinuity() {
  const traces = new DistributedTraceRuntime();

  const trace = traces.startTrace(
    'treasury-runtime',
    'transferFrom'
  );

  traces.addSpan(trace.trace_id, {
    action: 'allowance_verification'
  });

  const verified = traces.getTrace(trace.trace_id);

  console.log(JSON.stringify({
    trace_created: !!verified,
    spans: verified.spans.length
  }, null, 2));
}

proveTraceContinuity();
