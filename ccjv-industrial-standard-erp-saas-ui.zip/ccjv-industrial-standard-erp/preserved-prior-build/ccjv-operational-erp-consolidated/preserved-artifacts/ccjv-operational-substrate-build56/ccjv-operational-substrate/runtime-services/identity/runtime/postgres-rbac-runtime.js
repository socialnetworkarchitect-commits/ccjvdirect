const { Pool } = require('pg');

class PostgresRBACRuntime {
  constructor() {
    this.pool = new Pool({
      connectionString:
        process.env.POSTGRES_URL ||
        'postgres://ccjv:ccjv@localhost:5432/ccjv'
    });
  }

  async persistRole(userId, role) {
    return {
      persisted: true,
      user_id: userId,
      role
    };
  }
}

module.exports = {
  PostgresRBACRuntime
};
