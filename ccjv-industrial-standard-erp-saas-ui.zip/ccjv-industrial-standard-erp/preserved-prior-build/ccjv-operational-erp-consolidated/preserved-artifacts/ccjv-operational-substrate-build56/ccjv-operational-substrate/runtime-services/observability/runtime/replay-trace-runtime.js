class ReplayTraceRuntime {
  traceReplay(replayId) {
    return {
      trace_id:
        `trace_${Date.now()}`,
      replay_id: replayId,
      traced_at:
        new Date().toISOString()
    };
  }
}

module.exports = {
  ReplayTraceRuntime
};
