const { traced } = require('../observability/tracing/runtime-tracer');
const { buildRedisAdapter } = require('./federation/redis-adapter');
const { replayQueue } = require('../queues/runtime-queues');
const http = require('http');
const { Server } = require('socket.io');
const jwt = require('jsonwebtoken');

function createRuntime(serverApp) {
  const httpServer = http.createServer(serverApp);

  const io = new Server(httpServer, {
    cors: {
      origin: '*'
    }
  });

  io.use((socket, next) => {
    try {
      const token = socket.handshake.auth?.token;

      if (!token) {
        return next(new Error('missing_token'));
      }

      const decoded = jwt.verify(
        token,
        process.env.JWT_SECRET || 'ccjv_runtime_secret'
      );

      socket.runtimeIdentity = decoded;

      return next();
    } catch (err) {
      return next(new Error('invalid_token'));
    }
  });

  io.on('connection', (socket) => {
    const tenant = socket.runtimeIdentity.tenant_id || 'global';
    const workspace = socket.runtimeIdentity.workspace_id || 'default';

    socket.join(`tenant:${tenant}`);
    socket.join(`workspace:${workspace}`);

    socket.emit('runtime.connected', {
      ok: true,
      tenant,
      workspace,
      socket_id: socket.id
    });

    socket.on('runtime.replay.propagate', async (payload) => {
      await replayQueue.add('runtime-replay-propagation', payload);
      io.to(`tenant:${tenant}`).emit('runtime.replay.event', {
        replay_id: payload.replay_id,
        correlation_id: payload.correlation_id,
        causality_id: payload.causality_id,
        payload
      });
    });

    socket.on('disconnect', () => {
      console.log('[CCJV Build22] websocket disconnected', socket.id);
    });
  });

  return { io, httpServer };
}

module.exports = { createRuntime };


(async () => {
  try {
    await buildRedisAdapter(io);
    console.log('[ccjv] websocket federation redis adapter active');
  } catch (err) {
    console.error('[ccjv] websocket federation adapter failed', err.message);
  }
})();


io.on('connection', async (socket) => {
  await traced('socket.connection', {
    socket_id: socket.id
  }, async () => {
    socket.emit('runtime.connected', {
      ok: true,
      federation: 'ACTIVE'
    });
  });
});


io.on('connection', (socket) => {
  socket.on('federation.heartbeat', async (payload) => {
    io.emit('federation.heartbeat.propagated', {
      propagated: true,
      payload
    });
  });
});


io.on('connection', (socket) => {
  socket.on('recovery.sync', async (payload) => {
    io.emit('recovery.sync.completed', {
      recovered: true,
      payload
    });
  });
});


io.on('connection', (socket) => {
  socket.on('trace.propagation', async (payload) => {
    io.emit('trace.propagated', {
      propagated: true,
      payload
    });
  });
});


io.on('connection', (socket) => {
  socket.on('routing.mesh', async (payload) => {
    io.emit('routing.mesh.propagated', {
      routed: true,
      payload
    });
  });
});


io.on('connection', (socket) => {
  socket.on('memory.lineage.sync', async (payload) => {
    io.emit('memory.lineage.propagated', {
      synced: true,
      payload
    });
  });
});


io.on('connection', (socket) => {
  socket.on('dag.edge.persisted', async (payload) => {
    io.emit('dag.edge.replicated', {
      replicated: true,
      payload
    });
  });
});


io.on('connection', (socket) => {
  socket.on('treasury.hsm.reconciled', async (payload) => {
    io.emit('treasury.hsm.replicated', {
      replicated: true,
      payload
    });
  });
});


io.on('connection', (socket) => {
  socket.on('federation.node.sync', async (payload) => {
    io.emit('federation.node.replicated', {
      replicated: true,
      payload
    });
  });
});


io.on('connection', (socket) => {
  socket.on('avalanche.anchor.created', async (payload) => {
    io.emit('avalanche.anchor.propagated', {
      propagated: true,
      payload
    });
  });
});


io.on('connection', (socket) => {
  socket.on('erp.federation.sync', async (payload) => {
    io.emit('erp.federation.propagated', {
      propagated: true,
      payload
    });
  });
});


io.on('connection', (socket) => {
  socket.on('replay.event', async (payload) => {
    io.emit('replay.event.appended', {
      propagated: true,
      payload
    });
  });
});


io.on('connection', (socket) => {
  socket.on('queue.item', async (payload) => {
    io.emit('queue.item.created', {
      propagated: true,
      payload
    });
  });
});


io.on('connection', (socket) => {
  socket.on('observability.trace', async (payload) => {
    io.emit('observability.trace.created', {
      propagated: true,
      payload
    });
  });
});


io.on('connection', (socket) => {
  socket.on('websocket.authenticate', async (payload) => {
    io.emit('websocket.authenticated', {
      authenticated: true,
      payload
    });
  });
});


io.on('connection', (socket) => {
  socket.on('federation.erp.register', async (payload) => {
    io.emit('federation.erp.registered', {
      synchronized: true,
      payload
    });
  });
});


io.on('connection', (socket) => {
  socket.on('treasury.transfer.execute', async (payload) => {
    io.emit('treasury.execution.completed', {
      executed: true,
      payload
    });
  });
});


io.on('connection', (socket) => {
  socket.on('vault.store.object', async (payload) => {
    io.emit('vault.object.stored', {
      persisted: true,
      payload
    });
  });
});


io.on('connection', (socket) => {
  socket.on('avalanche.batch.create', async (payload) => {
    io.emit('avalanche.batch.created', {
      anchored: true,
      payload
    });
  });
});
