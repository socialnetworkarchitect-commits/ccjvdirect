class ReplayCausalityRuntime {
  buildGraph(events) {
    return {
      nodes: events.map((e) => ({
        id: e.replay_id
      })),
      edges: events.slice(1).map((e, i) => ({
        from: events[i].replay_id,
        to: e.replay_id
      }))
    };
  }
}

module.exports = {
  ReplayCausalityRuntime
};
