class CausalityRuntime {
  constructor() {
    this.graph = [];
  }

  connect(parent, child) {
    this.graph.push({
      parent,
      child,
      timestamp: new Date().toISOString()
    });
  }

  topology() {
    return this.graph;
  }
}

module.exports = {
  CausalityRuntime
};
