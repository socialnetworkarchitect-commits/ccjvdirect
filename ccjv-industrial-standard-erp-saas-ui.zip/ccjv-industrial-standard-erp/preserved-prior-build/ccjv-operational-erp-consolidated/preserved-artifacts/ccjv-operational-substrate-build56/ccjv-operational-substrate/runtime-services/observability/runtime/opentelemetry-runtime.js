const {
  NodeSDK
} = require('@opentelemetry/sdk-node');

class OpenTelemetryRuntime {
  constructor() {
    this.sdk = new NodeSDK({});
  }

  async start() {
    await this.sdk.start();

    return {
      telemetry_started: true
    };
  }
}

module.exports = {
  OpenTelemetryRuntime
};
