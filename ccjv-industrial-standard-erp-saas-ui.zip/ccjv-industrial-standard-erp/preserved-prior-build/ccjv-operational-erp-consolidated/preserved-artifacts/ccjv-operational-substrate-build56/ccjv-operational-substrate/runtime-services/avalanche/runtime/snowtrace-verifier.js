const axios = require('axios');

async function verifySnowtrace(txHash, apiKey) {
  const response = await axios.get(
    `https://api.snowtrace.io/api?module=transaction&action=gettxreceiptstatus&txhash=${txHash}&apikey=${apiKey}`
  );

  return {
    verified: response.data.status === '1',
    payload: response.data
  };
}

module.exports = {
  verifySnowtrace
};
