const {
  MerkleProofRuntime
} = require('../runtime/merkle-proof-runtime');

async function proveAvalanche() {
  const runtime = new MerkleProofRuntime();

  const batch = runtime.createBatch([
    { id: 1, event: 'vault.persisted' }
  ]);

  const proof =
    runtime.generateProof(batch.batch_id);

  const reconciliation =
    runtime.reconcile(batch.batch_id);

  console.log(JSON.stringify({
    batch_created: !!batch.batch_id,
    proof_generated:
      proof.proof_generated,
    reconciled:
      reconciliation.reconciled
  }, null, 2));
}

proveAvalanche();
