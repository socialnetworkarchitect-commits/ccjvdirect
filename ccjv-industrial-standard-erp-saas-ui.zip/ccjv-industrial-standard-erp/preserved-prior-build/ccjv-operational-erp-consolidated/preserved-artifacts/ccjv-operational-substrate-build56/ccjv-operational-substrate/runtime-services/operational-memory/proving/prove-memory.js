const { LineageRuntime } = require('../runtime/lineage-runtime');
const { CausalityRuntime } = require('../runtime/causality-runtime');

async function proveOperationalMemory() {
  const lineage = new LineageRuntime();
  const causality = new CausalityRuntime();

  lineage.append({
    id: 'evt-1',
    correlation_id: 'corr-1',
    treasury_ref: 'treasury-1',
    vault_ref: 'vault-1',
    proof_ref: 'proof-1'
  });

  causality.connect('evt-1', 'evt-2');

  console.log(JSON.stringify({
    operational_memory: true,
    lineage_entries: lineage.list().length,
    causality_edges: causality.topology().length
  }, null, 2));
}

proveOperationalMemory();
