class TenantRBACRuntime {
  constructor() {
    this.roles = new Map();
  }

  assign(user, role) {
    this.roles.set(user, role);

    return {
      assigned: true
    };
  }

  verify(user, role) {
    return this.roles.get(user) === role;
  }
}

module.exports = {
  TenantRBACRuntime
};
