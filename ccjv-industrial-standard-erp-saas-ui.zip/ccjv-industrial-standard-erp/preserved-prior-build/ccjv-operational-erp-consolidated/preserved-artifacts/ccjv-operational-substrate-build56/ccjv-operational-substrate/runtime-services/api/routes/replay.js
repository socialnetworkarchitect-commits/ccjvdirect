const express = require('express');
const router = express.Router();
const store = require('../lib/runtime-store');

router.get('/:replay_id', async (req, res) => {
  const timeline = await store.replay(req.params.replay_id);
  const signature = Buffer.from(timeline.map(e => `${e.event_type}:${e.event_id}`).join('|')).toString('base64');
  res.json({
    ok: true,
    replay_id: req.params.replay_id,
    event_count: timeline.length,
    deterministic_signature: signature,
    timeline
  });
});

module.exports = router;
