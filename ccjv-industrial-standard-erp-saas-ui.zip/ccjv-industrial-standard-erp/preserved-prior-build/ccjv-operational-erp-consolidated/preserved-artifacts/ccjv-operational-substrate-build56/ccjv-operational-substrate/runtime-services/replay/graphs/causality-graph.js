function buildCausalityGraph(events = []) {
  const nodes = [];
  const edges = [];

  events.forEach((event, idx) => {
    nodes.push({
      id: event.correlation_id,
      event_type: event.event_type
    });

    if (idx > 0) {
      edges.push({
        from: events[idx - 1].correlation_id,
        to: event.correlation_id
      });
    }
  });

  return {
    nodes,
    edges
  };
}

function deterministicReplay(events = []) {
  return events
    .sort((a, b) =>
      new Date(a.created_at) - new Date(b.created_at)
    )
    .map(event => ({
      correlation_id: event.correlation_id,
      event_type: event.event_type
    }));
}

module.exports = {
  buildCausalityGraph,
  deterministicReplay
};
