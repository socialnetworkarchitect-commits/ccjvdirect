const { Pool } = require('pg');

const pool = new Pool({
  host: process.env.PGHOST || '127.0.0.1',
  port: Number(process.env.PGPORT || 5432),
  database: process.env.PGDATABASE || 'ccjv_runtime',
  user: process.env.PGUSER || 'ccjv',
  password: process.env.PGPASSWORD || 'ccjv_secure',
  max: 20,
  idleTimeoutMillis: 30000,
  connectionTimeoutMillis: 5000
});

pool.on('error', (err) => {
  console.error('[CCJV Build21] PostgreSQL pool error', err.message);
});

module.exports = pool;
