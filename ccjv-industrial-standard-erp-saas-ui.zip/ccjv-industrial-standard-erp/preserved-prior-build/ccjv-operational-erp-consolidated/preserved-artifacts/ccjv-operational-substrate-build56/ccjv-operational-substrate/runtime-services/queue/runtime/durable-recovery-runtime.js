class DurableRecoveryRuntime {
  constructor() {
    this.failed = [];
  }

  persistFailure(job) {
    this.failed.push({
      ...job,
      persisted_at: new Date().toISOString()
    });
  }

  recoverFailedJobs() {
    return this.failed.map((job) => ({
      ...job,
      recovered: true
    }));
  }
}

module.exports = {
  DurableRecoveryRuntime
};
