const { ethers } = require('ethers');
const pool = require('../persistence/db');

const provider = new ethers.JsonRpcProvider(
  process.env.AVALANCHE_RPC || 'https://api.avax.network/ext/bc/C/rpc'
);

const signer = new ethers.Wallet(
  process.env.RUNTIME_SIGNER_PRIVATE_KEY ||
  '0x1111111111111111111111111111111111111111111111111111111111111111',
  provider
);

const erc20Abi = [
  'function allowance(address owner, address spender) view returns (uint256)',
  'function transferFrom(address from, address to, uint256 value) returns (bool)'
];

async function verifyAllowance(tokenAddress, owner, spender) {
  const contract = new ethers.Contract(tokenAddress, erc20Abi, provider);
  const allowance = await contract.allowance(owner, spender);

  return allowance.toString();
}

async function executeTransferFrom({
  token_address,
  from_wallet,
  to_wallet,
  amount
}) {
  const contract = new ethers.Contract(token_address, erc20Abi, signer);

  const tx = await contract.transferFrom(
    from_wallet,
    to_wallet,
    amount
  );

  await pool.query(`
    INSERT INTO institutional_runtime.treasury_transactions
      (transaction_id, wallet_address, token_address,
       transaction_state, tx_hash, metadata)
    VALUES (gen_random_uuid(), $1, $2, $3, $4, $5)
  `, [
    from_wallet,
    token_address,
    'SUBMITTED',
    tx.hash,
    {
      amount,
      to_wallet
    }
  ]);

  return {
    tx_hash: tx.hash
  };
}

module.exports = {
  verifyAllowance,
  executeTransferFrom
};
