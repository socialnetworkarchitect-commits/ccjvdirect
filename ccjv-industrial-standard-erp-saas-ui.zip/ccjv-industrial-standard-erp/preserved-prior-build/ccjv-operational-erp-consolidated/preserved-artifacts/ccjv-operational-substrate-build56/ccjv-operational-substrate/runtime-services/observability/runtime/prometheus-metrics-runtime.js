class PrometheusMetricsRuntime {
  constructor() {
    this.metrics = [];
  }

  emit(metric, value) {
    const payload = {
      metric,
      value,
      emitted_at: new Date().toISOString()
    };

    this.metrics.push(payload);

    return payload;
  }

  export() {
    return this.metrics
      .map(m => `${m.metric} ${m.value}`)
      .join('\n');
  }
}

module.exports = {
  PrometheusMetricsRuntime
};
