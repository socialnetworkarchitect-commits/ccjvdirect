class HeartbeatRuntime {
  constructor() {
    this.beats = [];
  }

  beat(service) {
    const payload = {
      service,
      heartbeat_at: new Date().toISOString(),
      healthy: true
    };

    this.beats.push(payload);

    return payload;
  }

  list() {
    return this.beats;
  }
}

module.exports = {
  HeartbeatRuntime
};
