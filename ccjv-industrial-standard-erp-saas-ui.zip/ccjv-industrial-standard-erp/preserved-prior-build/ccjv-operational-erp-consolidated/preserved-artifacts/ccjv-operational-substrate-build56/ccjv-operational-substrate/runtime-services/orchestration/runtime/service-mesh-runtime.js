function serviceMeshTopology() {
  return {
    mesh: 'istio',
    mtls: true,
    distributed_routing: true,
    observability_hooks: true
  };
}

module.exports = {
  serviceMeshTopology
};
