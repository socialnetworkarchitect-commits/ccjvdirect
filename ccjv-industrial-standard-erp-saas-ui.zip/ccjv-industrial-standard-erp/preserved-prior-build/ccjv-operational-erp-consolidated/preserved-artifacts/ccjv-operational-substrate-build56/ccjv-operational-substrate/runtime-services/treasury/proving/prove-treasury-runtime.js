const {
  ERC20ExecutionRuntime
} = require('../runtime/erc20-execution-runtime');

async function proveTreasury() {
  const runtime = new ERC20ExecutionRuntime();

  const allowance = runtime.verifyAllowance(
    '0xwallet',
    100
  );

  const tx = runtime.transferFrom({
    from: '0xwallet',
    to: '0xtreasury',
    amount: 100
  });

  const reconciliation =
    runtime.reconcile(tx.tx_id);

  console.log(JSON.stringify({
    allowance_verified: allowance.verified,
    treasury_executed: tx.status === 'executed',
    treasury_reconciled:
      reconciliation.reconciled
  }, null, 2));
}

proveTreasury();
