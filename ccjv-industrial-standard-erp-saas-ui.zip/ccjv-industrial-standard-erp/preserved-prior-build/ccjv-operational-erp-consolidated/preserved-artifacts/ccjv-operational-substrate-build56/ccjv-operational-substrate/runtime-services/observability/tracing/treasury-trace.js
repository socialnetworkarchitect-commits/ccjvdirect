function treasuryTrace(event) {
  return {
    trace_id: event.trace_id,
    treasury_event: true,
    correlation_id: event.correlation_id,
    timestamp: new Date().toISOString()
  };
}

module.exports = {
  treasuryTrace
};
