const crypto = require('crypto');

class DeterministicReplayEngine {
  constructor() {
    this.events = [];
  }

  append(event) {
    const replayEvent = {
      ...event,
      correlation_id: event.correlation_id || crypto.randomUUID(),
      deterministic_hash: crypto
        .createHash('sha256')
        .update(JSON.stringify(event))
        .digest('hex'),
      appended_at: new Date().toISOString()
    };

    this.events.push(replayEvent);

    return replayEvent;
  }

  reconstruct(correlationId) {
    return this.events.filter(
      e => e.correlation_id === correlationId
    );
  }

  verify(hash) {
    return this.events.find(
      e => e.deterministic_hash === hash
    );
  }
}

module.exports = {
  DeterministicReplayEngine
};
