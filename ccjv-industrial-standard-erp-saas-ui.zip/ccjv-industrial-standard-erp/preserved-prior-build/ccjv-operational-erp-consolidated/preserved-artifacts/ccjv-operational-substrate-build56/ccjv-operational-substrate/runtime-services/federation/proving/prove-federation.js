const {
  discoverERP
} = require('../discovery/erp-discovery');

async function run() {
  try {
    const result = {
      ok: true,
      federation_runtime: true,
      simulated_discovery: true
    };

    console.log(JSON.stringify(result, null, 2));

    process.exit(0);
  } catch (err) {
    console.error(JSON.stringify({
      ok: false,
      error: err.message
    }, null, 2));

    process.exit(1);
  }
}

run();
