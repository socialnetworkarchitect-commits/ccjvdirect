const {
  DurableQueueRuntime
} = require('../runtime/durable-queue-runtime');

const {
  QueuePersistenceAdapter
} = require('../runtime/queue-persistence-adapter');

async function proveQueueDurability() {
  const queue = new DurableQueueRuntime();
  const persistence = new QueuePersistenceAdapter();

  const item = queue.enqueue('treasury', {
    amount: 100
  });

  persistence.persist('treasury', item);

  const recovered = persistence.recover('treasury');

  console.log(JSON.stringify({
    queued: !!item,
    recovered: recovered.length > 0
  }, null, 2));
}

proveQueueDurability();
