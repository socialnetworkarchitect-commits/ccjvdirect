function tenantMiddleware(req, res, next) {
  req.tenant_id = req.headers['x-tenant-id'] || req.body?.tenant_id || req.query?.tenant_id || 'system';
  req.workspace_id = req.headers['x-workspace-id'] || req.body?.workspace_id || req.query?.workspace_id || 'runtime';
  next();
}

module.exports = tenantMiddleware;
