const { Worker } = require('bullmq');
const connection = require('../redis-runtime');

const treasuryWorker = new Worker(
  'ccjv-treasury',
  async job => {
    console.log('[CCJV Build23] treasury worker processing', job.id);

    return {
      treasury_processed: true,
      transaction_id: job.data.transaction_id
    };
  },
  { connection }
);

treasuryWorker.on('completed', (job) => {
  console.log('[CCJV Build23] treasury completed', job.id);
});

module.exports = treasuryWorker;
