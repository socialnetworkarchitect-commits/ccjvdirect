const {
  LiveAvalancheTxRuntime
} = require('../runtime/live-avalanche-tx-runtime');

async function proveExecution() {
  const runtime =
    new LiveAvalancheTxRuntime();

  const result =
    await runtime.sendTransaction({
      to: '0x000000000000000000000000000000000000dead',
      value: '1000000000000000'
    });

  console.log(JSON.stringify(result, null, 2));
}

proveExecution();
