const {
  ReplayShardRecoveryRuntime
} = require('../runtime/replay-shard-recovery-runtime');

async function proveReplayRecovery() {
  const runtime =
    new ReplayShardRecoveryRuntime();

  const result =
    runtime.recover([
      'shard-a',
      'shard-b',
      'shard-c'
    ]);

  console.log(JSON.stringify(
    result,
    null,
    2
  ));
}

proveReplayRecovery();
