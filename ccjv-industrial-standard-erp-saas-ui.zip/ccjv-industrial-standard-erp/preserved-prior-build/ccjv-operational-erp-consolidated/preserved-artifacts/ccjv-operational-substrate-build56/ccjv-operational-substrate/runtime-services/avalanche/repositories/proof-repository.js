const pool = require('../../persistence/db');

async function persistProof(record) {
  const result = await pool.query(`
    INSERT INTO institutional_runtime.avalanche_proofs
      (merkle_root, tx_hash, proof_payload, verification_state)
    VALUES ($1,$2,$3,$4)
    RETURNING *
  `, [
    record.merkle_root,
    record.tx_hash,
    record.proof_payload,
    record.verification_state
  ]);

  return result.rows[0];
}

module.exports = {
  persistProof
};
