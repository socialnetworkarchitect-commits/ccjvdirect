class LokiRuntime {
  constructor(endpoint) {
    this.endpoint = endpoint;
  }

  async pushLog(stream, values) {
    return {
      pushed: true,
      endpoint: this.endpoint,
      stream,
      values
    };
  }
}

module.exports = LokiRuntime;
