const crypto = require('crypto');
const { event } = require('../common');

function sha256(input) {
  return crypto.createHash('sha256').update(JSON.stringify(input)).digest('hex');
}

function merkleRoot(hashes) {
  if (!hashes.length) return '';
  let layer = hashes.sort();
  while (layer.length > 1) {
    const next = [];
    for (let i = 0; i < layer.length; i += 2) {
      const left = layer[i];
      const right = layer[i + 1] || left;
      next.push(crypto.createHash('sha256').update(left + right).digest('hex'));
    }
    layer = next;
  }
  return layer[0];
}

function runProofContinuity() {
  const records = [
    { type: 'treasury', id: 'execution-demo' },
    { type: 'vault', id: 'record-demo' },
    { type: 'replay', id: 'replay-demo' }
  ];
  const hashes = records.map(sha256);
  const root = merkleRoot(hashes);
  console.log(JSON.stringify(event('proof.merkle.batch.generated', { hashes, merkle_root: root })));
}

console.log('[CCJV Build19] vault/proof execution worker online');
runProofContinuity();
setInterval(runProofContinuity, 22000);
