const fs = require('fs');
const path = require('path');
const pool = require('./db');

async function run() {
  const migrationsDir = path.join(__dirname, 'migrations');
  const files = fs.readdirSync(migrationsDir).filter(f => f.endsWith('.sql')).sort();

  for (const file of files) {
    const sql = fs.readFileSync(path.join(migrationsDir, file), 'utf8');
    console.log('[CCJV Build21] Running migration:', file);
    await pool.query(sql);
  }

  console.log('[CCJV Build21] Runtime migrations complete');
  process.exit(0);
}

run().catch(err => {
  console.error('[CCJV Build21] Migration failure', err);
  process.exit(1);
});
