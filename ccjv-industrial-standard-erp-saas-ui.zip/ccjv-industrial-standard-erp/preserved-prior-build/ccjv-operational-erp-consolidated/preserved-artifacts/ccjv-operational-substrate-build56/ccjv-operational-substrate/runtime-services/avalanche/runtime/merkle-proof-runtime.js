const crypto = require('crypto');

class MerkleProofRuntime {
  constructor() {
    this.batches = [];
  }

  createBatch(records) {
    const root = crypto
      .createHash('sha256')
      .update(JSON.stringify(records))
      .digest('hex');

    const batch = {
      batch_id: `batch_${Date.now()}`,
      root,
      records,
      created_at: new Date().toISOString()
    };

    this.batches.push(batch);

    return batch;
  }

  generateProof(batchId) {
    const batch = this.batches.find(
      (b) => b.batch_id === batchId
    );

    if (!batch) {
      return null;
    }

    return {
      batch_id: batch.batch_id,
      merkle_root: batch.root,
      proof_generated: true
    };
  }

  reconcile(batchId) {
    const batch = this.batches.find(
      (b) => b.batch_id === batchId
    );

    return {
      reconciled: !!batch,
      batch
    };
  }
}

module.exports = {
  MerkleProofRuntime
};
