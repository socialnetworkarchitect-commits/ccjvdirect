class DurableQueueRuntime {
  constructor() {
    this.queues = new Map();
  }

  createQueue(name) {
    if (!this.queues.has(name)) {
      this.queues.set(name, []);
    }

    return this.queues.get(name);
  }

  enqueue(name, payload) {
    const queue = this.createQueue(name);

    const item = {
      id: `${Date.now()}-${Math.random()}`,
      payload,
      created_at: new Date().toISOString(),
      status: 'QUEUED'
    };

    queue.push(item);

    return item;
  }

  dequeue(name) {
    const queue = this.createQueue(name);

    if (!queue.length) {
      return null;
    }

    const item = queue.shift();
    item.status = 'PROCESSED';

    return item;
  }

  recover(name) {
    return this.createQueue(name);
  }
}

module.exports = {
  DurableQueueRuntime
};
