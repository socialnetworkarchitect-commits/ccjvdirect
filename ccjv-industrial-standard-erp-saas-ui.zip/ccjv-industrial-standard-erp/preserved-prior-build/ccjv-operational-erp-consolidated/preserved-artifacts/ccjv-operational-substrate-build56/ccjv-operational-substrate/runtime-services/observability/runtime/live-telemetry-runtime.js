class LiveTelemetryRuntime {
  emit(metric, value) {
    return {
      emitted: true,
      metric,
      value,
      timestamp:
        new Date().toISOString()
    };
  }
}

module.exports = {
  LiveTelemetryRuntime
};
