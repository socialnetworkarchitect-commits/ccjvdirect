const {
  persistDagEdge,
  listDagEdges
} = require('../runtime/dag-persistence-runtime');

async function proveDagPersistence() {
  await persistDagEdge(
    'treasury-event',
    'proof-event',
    'corr-proof-1'
  );

  const edges = await listDagEdges();

  console.log(JSON.stringify({
    dag_persistence: true,
    edges: edges.length
  }, null, 2));
}

proveDagPersistence();
