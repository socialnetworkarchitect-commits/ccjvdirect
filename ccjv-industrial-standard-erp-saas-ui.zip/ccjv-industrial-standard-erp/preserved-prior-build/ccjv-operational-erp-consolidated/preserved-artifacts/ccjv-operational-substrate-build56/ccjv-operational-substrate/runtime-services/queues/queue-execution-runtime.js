const { Queue, Worker } = require('bullmq');
const IORedis = require('ioredis');
const { event } = require('../common');

const connection = new IORedis({
  host: process.env.REDIS_HOST || '127.0.0.1',
  port: Number(process.env.REDIS_PORT || 6379),
  maxRetriesPerRequest: null
});

const queues = ['replay', 'treasury', 'websocket', 'federation', 'anchor', 'orchestration'];
const instances = Object.fromEntries(queues.map(q => [q, new Queue(`ccjv:${q}`, { connection })]));

async function seedContinuityJobs() {
  for (const q of queues) {
    await instances[q].add('continuity-check', event(`queue.${q}.continuity`, { queue: q }), {
      attempts: 5,
      backoff: { type: 'exponential', delay: 1000 },
      removeOnComplete: 100,
      removeOnFail: 100
    });
  }
}

queues.forEach(q => {
  new Worker(`ccjv:${q}`, async job => {
    const runtimeEvent = event(`queue.${q}.executed`, {
      job_id: job.id,
      job_name: job.name,
      payload: job.data
    });
    console.log(JSON.stringify(runtimeEvent));
    return runtimeEvent;
  }, { connection });
});

console.log('[CCJV Build19] durable BullMQ queue runtime online');
seedContinuityJobs().catch(err => console.error('[CCJV queue seed error]', err.message));
setInterval(() => seedContinuityJobs().catch(err => console.error(err.message)), 30000);
