class ReplayDAGPersistenceRuntime {
  constructor() {
    this.graph = [];
  }

  persist(node) {
    this.graph.push(node);

    return {
      persisted: true,
      total_nodes:
        this.graph.length
    };
  }

  lineage() {
    return this.graph;
  }
}

module.exports = {
  ReplayDAGPersistenceRuntime
};
