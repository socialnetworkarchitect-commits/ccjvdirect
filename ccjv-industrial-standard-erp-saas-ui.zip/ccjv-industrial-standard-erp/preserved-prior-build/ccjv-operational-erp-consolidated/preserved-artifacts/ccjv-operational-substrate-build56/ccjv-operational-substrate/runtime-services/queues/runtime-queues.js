const { Queue } = require('bullmq');
const connection = require('./redis-runtime');

const replayQueue = new Queue('ccjv-replay', { connection });
const treasuryQueue = new Queue('ccjv-treasury', { connection });
const websocketQueue = new Queue('ccjv-websocket', { connection });
const federationQueue = new Queue('ccjv-federation', { connection });

module.exports = {
  replayQueue,
  treasuryQueue,
  websocketQueue,
  federationQueue
};
