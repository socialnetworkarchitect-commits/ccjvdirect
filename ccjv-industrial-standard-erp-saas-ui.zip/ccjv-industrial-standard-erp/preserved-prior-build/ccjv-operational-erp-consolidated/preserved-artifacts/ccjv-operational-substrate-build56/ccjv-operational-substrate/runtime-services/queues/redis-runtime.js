const IORedis = require('ioredis');

const connection = new IORedis({
  host: process.env.REDIS_HOST || '127.0.0.1',
  port: Number(process.env.REDIS_PORT || 6379),
  maxRetriesPerRequest: null
});

connection.on('connect', () => {
  console.log('[CCJV Build23] Redis runtime connected');
});

connection.on('error', (err) => {
  console.error('[CCJV Build23] Redis runtime error', err.message);
});

module.exports = connection;
