const Redis = require('ioredis');

class RedisRuntime {
  constructor() {
    this.redis = new Redis({
      host: process.env.REDIS_HOST || '127.0.0.1',
      port: process.env.REDIS_PORT || 6379
    });
  }

  async enqueue(queue, payload) {
    await this.redis.rpush(
      queue,
      JSON.stringify(payload)
    );

    return {
      queued: true
    };
  }

  async recover(queue) {
    const jobs =
      await this.redis.lrange(
        queue,
        0,
        -1
      );

    return jobs.map(JSON.parse);
  }
}

module.exports = {
  RedisRuntime
};
