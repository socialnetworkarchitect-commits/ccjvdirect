const express = require('express');
const router = express.Router();
const crypto = require('crypto');
const store = require('../lib/runtime-store');

router.post('/hash', async (req, res) => {
  const sha256_hash = crypto.createHash('sha256').update(JSON.stringify(req.body.payload || req.body)).digest('hex');
  const event = await store.emitEvent({
    tenant_id: req.tenant_id,
    workspace_id: req.workspace_id,
    correlation_id: req.correlation_id,
    causality_id: req.causality_id,
    replay_id: req.replay_id,
    event_type: 'vault.record.hashed',
    payload: { sha256_hash, record_type: req.body.record_type || 'api-record' }
  });
  res.json({ ok: true, sha256_hash, event });
});

module.exports = router;
