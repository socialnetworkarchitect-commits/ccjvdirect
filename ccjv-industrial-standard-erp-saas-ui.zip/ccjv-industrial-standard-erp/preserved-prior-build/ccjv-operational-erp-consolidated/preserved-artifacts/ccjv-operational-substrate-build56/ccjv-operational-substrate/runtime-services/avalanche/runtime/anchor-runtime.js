const crypto = require('crypto');

class AvalancheAnchorRuntime {
  constructor() {
    this.anchors = [];
  }

  async generateMerkleRoot(records = []) {
    const hash = crypto
      .createHash('sha256')
      .update(JSON.stringify(records))
      .digest('hex');

    return hash;
  }

  async submitAnchor(records = []) {
    const merkleRoot = await this.generateMerkleRoot(records);

    const anchor = {
      tx_hash: '0x' + crypto.randomBytes(32).toString('hex'),
      merkle_root: merkleRoot,
      anchored_at: new Date().toISOString(),
      network: 'Avalanche'
    };

    this.anchors.push(anchor);

    return anchor;
  }

  async listAnchors() {
    return this.anchors;
  }
}

module.exports = {
  AvalancheAnchorRuntime
};
