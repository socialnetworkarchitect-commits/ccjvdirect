class LineageRuntime {
  constructor() {
    this.lineages = [];
  }

  append(event) {
    const lineage = {
      id: event.id,
      correlation_id: event.correlation_id,
      treasury_ref: event.treasury_ref,
      vault_ref: event.vault_ref,
      proof_ref: event.proof_ref,
      created_at: new Date().toISOString()
    };

    this.lineages.push(lineage);
    return lineage;
  }

  list() {
    return this.lineages;
  }
}

module.exports = {
  LineageRuntime
};
