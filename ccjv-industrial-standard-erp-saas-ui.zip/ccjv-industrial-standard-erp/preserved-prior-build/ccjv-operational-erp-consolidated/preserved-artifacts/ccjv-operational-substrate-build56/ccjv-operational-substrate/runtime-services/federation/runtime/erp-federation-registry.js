class ERPFederationRegistry {
  constructor() {
    this.erps = new Map();
  }

  registerERP(erp) {
    this.erps.set(erp.id, {
      ...erp,
      registered_at: new Date().toISOString(),
      status: 'ACTIVE'
    });

    return this.erps.get(erp.id);
  }

  listERPs() {
    return Array.from(this.erps.values());
  }

  getERP(id) {
    return this.erps.get(id);
  }
}

module.exports = {
  ERPFederationRegistry
};
