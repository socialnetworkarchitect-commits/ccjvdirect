const { Pool } = require('pg');

const pool = new Pool({
  connectionString: process.env.CCJV_POSTGRES_URL
});

async function ensureDagTable() {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS ccjv_operational_dag (
      id SERIAL PRIMARY KEY,
      parent_event TEXT NOT NULL,
      child_event TEXT NOT NULL,
      correlation_id TEXT,
      created_at TIMESTAMP DEFAULT NOW()
    )
  `);
}

async function persistDagEdge(parent, child, correlationId) {
  await ensureDagTable();

  const result = await pool.query(
    `INSERT INTO ccjv_operational_dag
    (parent_event, child_event, correlation_id)
    VALUES ($1,$2,$3)
    RETURNING *`,
    [parent, child, correlationId]
  );

  return result.rows[0];
}

async function listDagEdges() {
  await ensureDagTable();

  const result = await pool.query(
    `SELECT * FROM ccjv_operational_dag
     ORDER BY created_at DESC
     LIMIT 500`
  );

  return result.rows;
}

module.exports = {
  persistDagEdge,
  listDagEdges
};
