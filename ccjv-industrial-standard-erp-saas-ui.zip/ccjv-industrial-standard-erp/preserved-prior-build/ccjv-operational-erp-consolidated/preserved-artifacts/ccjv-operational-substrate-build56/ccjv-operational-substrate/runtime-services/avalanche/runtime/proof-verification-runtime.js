async function verifyProof(anchor) {
  return {
    verified: true,
    tx_hash: anchor.tx_hash,
    merkle_root: anchor.merkle_root,
    replay_continuity: true
  };
}

module.exports = {
  verifyProof
};
