class OpenTelemetryRuntime {
  constructor(serviceName) {
    this.serviceName = serviceName;
  }

  trace(event) {
    return {
      traced: true,
      service: this.serviceName,
      trace_id: event.trace_id,
      correlation_id: event.correlation_id
    };
  }
}

module.exports = OpenTelemetryRuntime;
