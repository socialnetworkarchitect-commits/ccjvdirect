class ReplayShardRecoveryRuntime {
  recover(shards) {
    return {
      recovered: true,
      shard_count:
        shards.length
    };
  }
}

module.exports = {
  ReplayShardRecoveryRuntime
};
