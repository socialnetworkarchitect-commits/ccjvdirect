const pool = require('../db');

async function persistEvent(event) {
  const result = await pool.query(`
    INSERT INTO institutional_runtime.event_store
      (event_id, correlation_id, causality_id, replay_id,
       tenant_id, workspace_id, event_type, payload)
    VALUES ($1,$2,$3,$4,$5,$6,$7,$8)
    RETURNING *
  `, [
    event.event_id,
    event.correlation_id,
    event.causality_id,
    event.replay_id,
    event.tenant_id,
    event.workspace_id,
    event.event_type,
    event.payload || {}
  ]);
  return result.rows[0];
}

async function replayTimeline(replayId) {
  const result = await pool.query(`
    SELECT * FROM institutional_runtime.event_store
    WHERE replay_id=$1
    ORDER BY created_at ASC, id ASC
  `, [replayId]);

  return result.rows;
}

module.exports = { persistEvent, replayTimeline };
