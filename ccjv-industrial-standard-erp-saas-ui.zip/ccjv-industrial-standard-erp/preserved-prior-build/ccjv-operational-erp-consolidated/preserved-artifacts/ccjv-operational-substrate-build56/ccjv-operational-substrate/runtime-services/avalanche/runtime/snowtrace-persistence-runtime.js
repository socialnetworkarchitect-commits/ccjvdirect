class SnowtracePersistenceRuntime {
  constructor() {
    this.records = [];
  }

  persist(record) {
    this.records.push(record);

    return {
      persisted: true,
      total:
        this.records.length
    };
  }
}

module.exports = {
  SnowtracePersistenceRuntime
};
