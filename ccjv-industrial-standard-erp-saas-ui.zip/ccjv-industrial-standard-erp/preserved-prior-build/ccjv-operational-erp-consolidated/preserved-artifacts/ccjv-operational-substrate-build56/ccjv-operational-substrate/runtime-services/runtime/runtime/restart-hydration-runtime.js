class RestartHydrationRuntime {
  hydrate(snapshot) {
    return {
      hydrated: true,
      snapshot
    };
  }
}

module.exports = {
  RestartHydrationRuntime
};
