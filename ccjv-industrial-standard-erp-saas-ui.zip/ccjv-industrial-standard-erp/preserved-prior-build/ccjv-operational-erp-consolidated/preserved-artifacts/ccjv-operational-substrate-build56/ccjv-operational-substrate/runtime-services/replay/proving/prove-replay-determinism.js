const {
  DeterministicReplayRuntime
} = require('../runtime/deterministic-replay-runtime');

async function proveReplay() {
  const runtime =
    new DeterministicReplayRuntime();

  const result =
    runtime.replay([
      { ts: 3 },
      { ts: 1 },
      { ts: 2 }
    ]);

  console.log(JSON.stringify(
    result,
    null,
    2
  ));
}

proveReplay();
