class SecretsRotationRuntime {
  rotate(secretName) {
    return {
      rotated: true,
      secret: secretName,
      rotated_at: new Date().toISOString()
    };
  }
}

module.exports = {
  SecretsRotationRuntime
};
