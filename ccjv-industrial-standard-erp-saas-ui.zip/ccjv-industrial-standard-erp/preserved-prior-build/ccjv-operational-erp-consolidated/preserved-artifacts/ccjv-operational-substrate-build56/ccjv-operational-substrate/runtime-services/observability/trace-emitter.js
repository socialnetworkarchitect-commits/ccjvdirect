const { trace } = require('@opentelemetry/api');
const { event } = require('../common');

function emitTrace() {
  const tracer = trace.getTracer('ccjv-runtime-build19');
  tracer.startActiveSpan('ccjv.replay.lineage.trace', span => {
    span.setAttribute('ccjv.runtime', 'operational-substrate');
    span.setAttribute('ccjv.trace.class', 'replay-linked-causality');
    span.end();
  });
  console.log(JSON.stringify(event('observability.trace.emitted', {
    trace_class: 'replay-linked-causality',
    spans: ['runtime','queue','replay','treasury','vault-proof','federation']
  })));
}

console.log('[CCJV Build19] observability trace emitter online');
emitTrace();
setInterval(emitTrace, 21000);
