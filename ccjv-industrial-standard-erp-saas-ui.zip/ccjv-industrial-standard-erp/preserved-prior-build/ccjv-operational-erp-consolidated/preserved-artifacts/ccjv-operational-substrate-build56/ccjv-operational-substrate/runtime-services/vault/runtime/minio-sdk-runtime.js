const Minio = require('minio');

class MinioSDKRuntime {
  constructor() {
    this.client = new Minio.Client({
      endPoint:
        process.env.MINIO_ENDPOINT || 'localhost',
      port:
        Number(process.env.MINIO_PORT) || 9000,
      useSSL: false,
      accessKey:
        process.env.MINIO_ACCESS_KEY || 'minio',
      secretKey:
        process.env.MINIO_SECRET_KEY || 'minio123'
    });
  }

  async upload(bucket, object, file) {
    return this.client.fPutObject(
      bucket,
      object,
      file
    );
  }
}

module.exports = {
  MinioSDKRuntime
};
