const { Server } = require('socket.io');
const http = require('http');

async function run() {
  const server = http.createServer();

  const io = new Server(server, {
    cors: {
      origin: '*'
    }
  });

  io.on('connection', (socket) => {
    socket.emit('runtime.proof', {
      ok: true,
      continuity: 'websocket-runtime'
    });
  });

  server.listen(4900, () => {
    console.log(JSON.stringify({
      ok: true,
      websocket_runtime: true,
      port: 4900
    }, null, 2));

    setTimeout(() => {
      io.close();
      server.close();
      process.exit(0);
    }, 1000);
  });
}

run().catch(err => {
  console.error(JSON.stringify({
    ok: false,
    error: err.message
  }, null, 2));

  process.exit(1);
});
