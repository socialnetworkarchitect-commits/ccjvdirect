const pool = require('../../persistence/db');

async function persistReconciliation(record) {
  const result = await pool.query(`
    INSERT INTO institutional_runtime.treasury_reconciliation
      (tx_hash, wallet_address, token_address, amount, status)
    VALUES ($1,$2,$3,$4,$5)
    RETURNING *
  `, [
    record.tx_hash,
    record.wallet_address,
    record.token_address,
    record.amount,
    record.status
  ]);

  return result.rows[0];
}

module.exports = {
  persistReconciliation
};
