const crypto = require('crypto');
const {
  replayQueue,
  treasuryQueue
} = require('../runtime-queues');

async function run() {
  const replayJob = await replayQueue.add('replay-proof', {
    replay_id: crypto.randomUUID()
  });

  const treasuryJob = await treasuryQueue.add('treasury-proof', {
    transaction_id: crypto.randomUUID()
  });

  console.log(JSON.stringify({
    ok: true,
    replay_job: replayJob.id,
    treasury_job: treasuryJob.id
  }, null, 2));

  process.exit(0);
}

run().catch(err => {
  console.error(JSON.stringify({
    ok: false,
    error: err.message
  }, null, 2));

  process.exit(1);
});
