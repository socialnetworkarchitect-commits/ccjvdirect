const { discoverERP, negotiateCapabilities } = require('../federation/discovery/erp-discovery');
const { persistHeartbeat } = require('../federation/repositories/federation-repository');
const { buildCausalityGraph } = require('../replay/graphs/causality-graph');
const { replayEvents } = require('../replay/repositories/replay-repository');
const { register } = require('../observability/exporters/runtime-metrics');
const { submitAnchor } = require('../avalanche/anchor-runtime');
const { merkleRoot } = require('../avalanche/merkle-runtime');
const { executeTransferFrom, verifyAllowance } = require('../treasury/execution-runtime');
const { createRuntime } = require('../websocket/runtime');
const { persistRuntimeState } = require('../persistence/repositories/runtime-state-repository');
const express = require('express');
const cors = require('cors');
const store = require('./lib/runtime-store');
const correlation = require('./middleware/correlation');
const tenant = require('./middleware/tenant');
const auth = require('./middleware/auth');

const app = express();
const runtime = createRuntime(app);
const PORT = Number(process.env.API_PORT || 3100);

app.use(cors());
app.use(express.json({ limit: '25mb' }));
app.use(correlation);
app.use(tenant);
app.use(auth);


app.post('/treasury/allowance', async (req, res) => {
  try {
    const result = await verifyAllowance(req.body.token_address,
      req.body.owner,
      req.body.spender
    );

    res.json({
      ok: true,
      allowance: result
    });
  } catch (err) {
    res.status(500).json({
      ok: false,
      error: err.message
    });
  }
});

app.post('/treasury/transfer-from', async (req, res) => {
  try {
    const result = await executeTransferFrom(req.body);

    res.json({
      ok: true,
      result
    });
  } catch (err) {
    res.status(500).json({
      ok: false,
      error: err.message
    });
  }
});


app.post('/proof/anchor', async (req, res) => {
  try {
    const root = merkleRoot(req.body.items || []);
    const anchor = await submitAnchor(root);

    res.json({
      ok: true,
      merkle_root: root,
      anchor
    });
  } catch (err) {
    res.status(500).json({
      ok: false,
      error: err.message
    });
  }
});


app.get('/federation/runtime-health', async (req, res) => {
  res.json({
    ok: true,
    runtime: 'ccjv-operational-substrate',
    federation: 'ACTIVE',
    websocket: 'ACTIVE',
    treasury: 'ACTIVE',
    avalanche: 'ACTIVE'
  });
});


app.get('/observability/metrics', async (req, res) => {
  res.set('Content-Type', register.contentType);
  res.end(await register.metrics());
});


app.get('/replay/causality-graph', async (req, res) => {
  try {
    const events = await replayEvents(100);
    const graph = buildCausalityGraph(events);

    res.json({
      ok: true,
      graph
    });
  } catch (err) {
    res.status(500).json({
      ok: false,
      error: err.message
    });
  }
});


app.post('/treasury/reconcile', async (req, res) => {
  try {
    const runtime = require('../treasury/runtime/execution-runtime');

    const result = await runtime.persistExecutionReconciliation(req.body);

    res.json({
      ok: true,
      result
    });
  } catch (err) {
    res.status(500).json({
      ok: false,
      error: err.message
    });
  }
});


app.post('/avalanche/proof', async (req, res) => {
  try {
    const runtime = require('../avalanche/runtime/anchor-runtime');

    const result = await runtime.persistAnchoredProof(req.body);

    res.json({
      ok: true,
      result
    });
  } catch (err) {
    res.status(500).json({
      ok: false,
      error: err.message
    });
  }
});


app.get('/runtime/recovery', async (req, res) => {
  try {
    const recovery = require('../recovery/runtime/restart-recovery');

    const result = recovery.recoverRuntimeState();

    res.json({
      ok: true,
      result
    });
  } catch (err) {
    res.status(500).json({
      ok: false,
      error: err.message
    });
  }
});


app.get('/observability/runtime-health', async (req, res) => {
  try {
    const runtime = require('../observability/runtime/metrics-runtime');

    const result = runtime.runtimeHealthScore({
      websocket: 'ACTIVE',
      replay: 'ACTIVE',
      treasury: 'ACTIVE'
    });

    res.json({
      ok: true,
      result
    });
  } catch (err) {
    res.status(500).json({
      ok: false,
      error: err.message
    });
  }
});


app.get('/orchestration/topology', async (req, res) => {
  try {
    const pm2 = require('../orchestration/runtime/pm2-runtime');
    const kube = require('../orchestration/runtime/kubernetes-runtime');
    const mesh = require('../orchestration/runtime/service-mesh-runtime');

    res.json({
      ok: true,
      topology: {
        pm2: pm2.pm2Topology(),
        kubernetes: kube.kubernetesTopology(),
        service_mesh: mesh.serviceMeshTopology()
      }
    });
  } catch (err) {
    res.status(500).json({
      ok: false,
      error: err.message
    });
  }
});


app.get('/memory/lineage', async (req, res) => {
  try {
    const { LineageRuntime } = require('../operational-memory/runtime/lineage-runtime');
    const runtime = new LineageRuntime();

    runtime.append({
      id: 'evt-runtime',
      correlation_id: 'corr-runtime',
      treasury_ref: 'treasury-runtime',
      vault_ref: 'vault-runtime',
      proof_ref: 'proof-runtime'
    });

    res.json({
      ok: true,
      lineage: runtime.list()
    });
  } catch (err) {
    res.status(500).json({
      ok: false,
      error: err.message
    });
  }
});

app.get('/memory/causality', async (req, res) => {
  try {
    const { CausalityRuntime } = require('../operational-memory/runtime/causality-runtime');
    const runtime = new CausalityRuntime();

    runtime.connect('runtime-a', 'runtime-b');

    res.json({
      ok: true,
      graph: runtime.topology()
    });
  } catch (err) {
    res.status(500).json({
      ok: false,
      error: err.message
    });
  }
});


app.get('/memory/dag', async (req, res) => {
  try {
    const {
      listDagEdges
    } = require('../operational-memory/runtime/dag-persistence-runtime');

    const edges = await listDagEdges();

    res.json({
      ok: true,
      edges
    });
  } catch (err) {
    res.status(500).json({
      ok: false,
      error: err.message
    });
  }
});

app.post('/replay/determinism', async (req, res) => {
  try {
    const {
      deterministicReplayHash
    } = require('../replay/runtime/determinism-runtime');

    const hash = deterministicReplayHash(req.body.events || []);

    res.json({
      ok: true,
      replay_hash: hash
    });
  } catch (err) {
    res.status(500).json({
      ok: false,
      error: err.message
    });
  }
});


app.post('/treasury/hsm/isolate', async (req, res) => {
  try {
    const {
      HSMSignerRuntime
    } = require('../treasury/runtime/hsm-signer-runtime');

    const runtime = new HSMSignerRuntime();

    const result = await runtime.isolateSigner({
      request_id: req.body.request_id || 'runtime-request'
    });

    res.json({
      ok: true,
      result
    });
  } catch (err) {
    res.status(500).json({
      ok: false,
      error: err.message
    });
  }
});

app.post('/queue/recovery', async (req, res) => {
  try {
    const {
      DurableRecoveryRuntime
    } = require('../queue/runtime/durable-recovery-runtime');

    const runtime = new DurableRecoveryRuntime();

    runtime.persistFailure({
      job_id: 'job-1'
    });

    const recovered = runtime.recoverFailedJobs();

    res.json({
      ok: true,
      recovered
    });
  } catch (err) {
    res.status(500).json({
      ok: false,
      error: err.message
    });
  }
});


app.post('/federation/register', async (req, res) => {
  try {
    const {
      FederationHeartbeatRuntime
    } = require('../federation/runtime/heartbeat-runtime');

    const runtime = new FederationHeartbeatRuntime();

    const node = runtime.registerNode({
      id: req.body.id || 'runtime-node',
      erp: req.body.erp || 'ccjv'
    });

    res.json({
      ok: true,
      node
    });
  } catch (err) {
    res.status(500).json({
      ok: false,
      error: err.message
    });
  }
});

app.post('/federation/sync', async (req, res) => {
  try {
    const {
      synchronizeFederation
    } = require('../federation/runtime/synchronization-runtime');

    const result = await synchronizeFederation(req.body);

    res.json({
      ok: true,
      result
    });
  } catch (err) {
    res.status(500).json({
      ok: false,
      error: err.message
    });
  }
});


app.post('/replay/append', async (req, res) => {
  try {
    const {
      DeterministicReplayEngine
    } = require('../replay/runtime/deterministic-replay-engine');

    global.replayEngine =
      global.replayEngine || new DeterministicReplayEngine();

    const event = global.replayEngine.append(req.body);

    res.json({
      ok: true,
      event
    });
  } catch (err) {
    res.status(500).json({
      ok: false,
      error: err.message
    });
  }
});

app.get('/replay/reconstruct/:correlation', async (req, res) => {
  try {
    const events = global.replayEngine
      ? global.replayEngine.reconstruct(req.params.correlation)
      : [];

    res.json({
      ok: true,
      events
    });
  } catch (err) {
    res.status(500).json({
      ok: false,
      error: err.message
    });
  }
});


app.post('/queues/enqueue/:queue', async (req, res) => {
  try {
    const {
      DurableQueueRuntime
    } = require('../queues/runtime/durable-queue-runtime');

    const {
      QueuePersistenceAdapter
    } = require('../queues/runtime/queue-persistence-adapter');

    global.queueRuntime =
      global.queueRuntime || new DurableQueueRuntime();

    global.queuePersistence =
      global.queuePersistence || new QueuePersistenceAdapter();

    const item = global.queueRuntime.enqueue(
      req.params.queue,
      req.body
    );

    global.queuePersistence.persist(
      req.params.queue,
      item
    );

    res.json({
      ok: true,
      item
    });
  } catch (err) {
    res.status(500).json({
      ok: false,
      error: err.message
    });
  }
});

app.get('/queues/recover/:queue', async (req, res) => {
  try {
    const recovered = global.queuePersistence
      ? global.queuePersistence.recover(req.params.queue)
      : [];

    res.json({
      ok: true,
      recovered
    });
  } catch (err) {
    res.status(500).json({
      ok: false,
      error: err.message
    });
  }
});


app.post('/observability/traces/start', async (req, res) => {
  try {
    const {
      DistributedTraceRuntime
    } = require('../observability/runtime/distributed-trace-runtime');

    global.traceRuntime =
      global.traceRuntime || new DistributedTraceRuntime();

    const trace = global.traceRuntime.startTrace(
      req.body.service,
      req.body.operation
    );

    res.json({
      ok: true,
      trace
    });
  } catch (err) {
    res.status(500).json({
      ok: false,
      error: err.message
    });
  }
});

app.post('/observability/traces/:trace/spans', async (req, res) => {
  try {
    const trace = global.traceRuntime.addSpan(
      req.params.trace,
      req.body
    );

    res.json({
      ok: true,
      trace
    });
  } catch (err) {
    res.status(500).json({
      ok: false,
      error: err.message
    });
  }
});

app.post('/observability/metrics', async (req, res) => {
  try {
    const {
      PrometheusMetricsRuntime
    } = require('../observability/runtime/prometheus-metrics-runtime');

    global.metricsRuntime =
      global.metricsRuntime || new PrometheusMetricsRuntime();

    const metric = global.metricsRuntime.emit(
      req.body.metric,
      req.body.value
    );

    res.json({
      ok: true,
      metric
    });
  } catch (err) {
    res.status(500).json({
      ok: false,
      error: err.message
    });
  }
});


app.post('/identity/nonce', async (req, res) => {
  try {
    const {
      SIWERuntime
    } = require('../identity/runtime/siwe-runtime');

    global.siweRuntime =
      global.siweRuntime || new SIWERuntime();

    const nonce = global.siweRuntime.issueNonce(
      req.body.wallet
    );

    res.json({
      ok: true,
      nonce
    });
  } catch (err) {
    res.status(500).json({
      ok: false,
      error: err.message
    });
  }
});

app.post('/identity/verify', async (req, res) => {
  try {
    const session = global.siweRuntime.verify(
      req.body.wallet,
      req.body.signature
    );

    res.json({
      ok: true,
      session
    });
  } catch (err) {
    res.status(500).json({
      ok: false,
      error: err.message
    });
  }
});

app.get('/identity/session/:id', async (req, res) => {
  try {
    const session = global.siweRuntime.validateSession(
      req.params.id
    );

    res.json({
      ok: true,
      session
    });
  } catch (err) {
    res.status(500).json({
      ok: false,
      error: err.message
    });
  }
});


app.post('/treasury/allowance/verify', async (req, res) => {
  try {
    const {
      ERC20ExecutionRuntime
    } = require('../treasury/runtime/erc20-execution-runtime');

    global.treasuryRuntime =
      global.treasuryRuntime ||
      new ERC20ExecutionRuntime();

    const result =
      global.treasuryRuntime.verifyAllowance(
        req.body.wallet,
        req.body.amount
      );

    res.json({
      ok: true,
      result
    });
  } catch (err) {
    res.status(500).json({
      ok: false,
      error: err.message
    });
  }
});

app.post('/treasury/transferFrom', async (req, res) => {
  try {
    const tx =
      global.treasuryRuntime.transferFrom(
        req.body
      );

    res.json({
      ok: true,
      tx
    });
  } catch (err) {
    res.status(500).json({
      ok: false,
      error: err.message
    });
  }
});

app.get('/treasury/reconcile/:txId', async (req, res) => {
  try {
    const reconciliation =
      global.treasuryRuntime.reconcile(
        req.params.txId
      );

    res.json({
      ok: true,
      reconciliation
    });
  } catch (err) {
    res.status(500).json({
      ok: false,
      error: err.message
    });
  }
});


app.post('/vault/store', async (req, res) => {
  try {
    const {
      MinIOVaultRuntime
    } = require('../vault/runtime/minio-vault-runtime');

    global.vaultRuntime =
      global.vaultRuntime ||
      new MinIOVaultRuntime();

    const object =
      global.vaultRuntime.storeObject(
        req.body
      );

    res.json({
      ok: true,
      object
    });
  } catch (err) {
    res.status(500).json({
      ok: false,
      error: err.message
    });
  }
});

app.get('/vault/object/:objectId', async (req, res) => {
  try {
    const object =
      global.vaultRuntime.retrieveObject(
        req.params.objectId
      );

    res.json({
      ok: true,
      object
    });
  } catch (err) {
    res.status(500).json({
      ok: false,
      error: err.message
    });
  }
});

app.get('/vault/verify/:objectId', async (req, res) => {
  try {
    const verification =
      global.vaultRuntime.verifyIntegrity(
        req.params.objectId
      );

    res.json({
      ok: true,
      verification
    });
  } catch (err) {
    res.status(500).json({
      ok: false,
      error: err.message
    });
  }
});


app.post('/avalanche/batch', async (req, res) => {
  try {
    const {
      MerkleProofRuntime
    } = require('../avalanche/runtime/merkle-proof-runtime');

    global.avalancheRuntime =
      global.avalancheRuntime ||
      new MerkleProofRuntime();

    const batch =
      global.avalancheRuntime.createBatch(
        req.body.records || []
      );

    res.json({
      ok: true,
      batch
    });
  } catch (err) {
    res.status(500).json({
      ok: false,
      error: err.message
    });
  }
});

app.get('/avalanche/proof/:batchId', async (req, res) => {
  try {
    const proof =
      global.avalancheRuntime.generateProof(
        req.params.batchId
      );

    res.json({
      ok: true,
      proof
    });
  } catch (err) {
    res.status(500).json({
      ok: false,
      error: err.message
    });
  }
});

app.get('/avalanche/reconcile/:batchId', async (req, res) => {
  try {
    const reconciliation =
      global.avalancheRuntime.reconcile(
        req.params.batchId
      );

    res.json({
      ok: true,
      reconciliation
    });
  } catch (err) {
    res.status(500).json({
      ok: false,
      error: err.message
    });
  }
});


app.get('/runtime/persistence/health', async (req, res) => {
  try {
    const {
      PostgresRuntime
    } = require('../persistence/runtime/postgres-runtime');

    const runtime =
      new PostgresRuntime();

    const health =
      await runtime.health();

    res.json({
      ok: true,
      health
    });
  } catch (err) {
    res.status(500).json({
      ok: false,
      error: err.message
    });
  }
});

app.get('/runtime/avalanche/block', async (req, res) => {
  try {
    const {
      AvalancheRPCRuntime
    } = require('../avalanche/runtime/avalanche-rpc-runtime');

    const runtime =
      new AvalancheRPCRuntime();

    const block =
      await runtime.latestBlock();

    res.json({
      ok: true,
      block
    });
  } catch (err) {
    res.status(500).json({
      ok: false,
      error: err.message
    });
  }
});


app.get('/runtime/snowtrace/:txHash', async (req, res) => {
  try {
    const {
      SnowtraceReconciliationRuntime
    } = require('../avalanche/runtime/snowtrace-reconciliation-runtime');

    const runtime =
      new SnowtraceReconciliationRuntime();

    const result =
      await runtime.reconcile(
        req.params.txHash
      );

    res.json({
      ok: true,
      result
    });
  } catch (err) {
    res.status(500).json({
      ok: false,
      error: err.message
    });
  }
});

app.post('/runtime/rbac/assign', async (req, res) => {
  try {
    const {
      TenantRBACRuntime
    } = require('../identity/runtime/tenant-rbac-runtime');

    global.rbacRuntime =
      global.rbacRuntime ||
      new TenantRBACRuntime();

    const result =
      global.rbacRuntime.assign(
        req.body.user,
        req.body.role
      );

    res.json({
      ok: true,
      result
    });
  } catch (err) {
    res.status(500).json({
      ok: false,
      error: err.message
    });
  }
});


app.post('/runtime/avalanche/send', async (req, res) => {
  try {
    const {
      LiveAvalancheTxRuntime
    } = require('../avalanche/runtime/live-avalanche-tx-runtime');

    const runtime =
      new LiveAvalancheTxRuntime();

    const tx =
      await runtime.sendTransaction(
        req.body
      );

    res.json({
      ok: true,
      tx
    });
  } catch (err) {
    res.status(500).json({
      ok: false,
      error: err.message
    });
  }
});

app.post('/runtime/rbac/persist', async (req, res) => {
  try {
    const {
      PersistentRBACRuntime
    } = require('../identity/runtime/persistent-rbac-runtime');

    global.persistentRBAC =
      global.persistentRBAC ||
      new PersistentRBACRuntime();

    const result =
      global.persistentRBAC.persistRole(
        req.body.user,
        req.body.role
      );

    res.json({
      ok: true,
      result
    });
  } catch (err) {
    res.status(500).json({
      ok: false,
      error: err.message
    });
  }
});


app.post('/runtime/rbac/postgres', async (req, res) => {
  try {
    const {
      PostgresRBACRuntime
    } = require('../identity/runtime/postgres-rbac-runtime');

    const runtime =
      new PostgresRBACRuntime();

    const result =
      await runtime.persistRole(
        req.body.user_id,
        req.body.role
      );

    res.json({
      ok: true,
      result
    });
  } catch (err) {
    res.status(500).json({
      ok: false,
      error: err.message
    });
  }
});


app.post('/runtime/hsm/sign', async (req, res) => {
  try {
    const {
      HSMSignerRuntime
    } = require('../treasury/runtime/hsm-signer-runtime');

    const runtime =
      new HSMSignerRuntime();

    const result =
      await runtime.signTransaction(req.body);

    res.json({
      ok: true,
      result
    });
  } catch (err) {
    res.status(500).json({
      ok: false,
      error: err.message
    });
  }
});


app.post('/runtime/replay/deterministic', async (req, res) => {
  try {
    const {
      DeterministicReplayRuntime
    } = require('../replay/runtime/deterministic-replay-runtime');

    const runtime =
      new DeterministicReplayRuntime();

    const result =
      runtime.replay(
        req.body.events || []
      );

    res.json({
      ok: true,
      result
    });
  } catch (err) {
    res.status(500).json({
      ok: false,
      error: err.message
    });
  }
});

app.get('/health', async (req, res) => {
  res.json({
    ok: true,
    runtime: 'ccjv-operational-substrate-api',
    build: 20,
    status: 'RUNNING',
    tenant_id: req.tenant_id,
    workspace_id: req.workspace_id,
    correlation_id: req.correlation_id
  });
});

app.use('/runtime', require('./routes/runtime'));
app.use('/events', require('./routes/events'));
app.use('/replay', require('./routes/replay'));
app.use('/federation', require('./routes/federation'));
app.use('/treasury', require('./routes/treasury'));
app.use('/vault', require('./routes/vault'));
app.use('/proof', require('./routes/proof'));

store.ensureTables().then(async () => {
  await store.registerService({
    service_key: 'runtime-api',
    service_name: 'CCJV Runtime API',
    service_url: `http://127.0.0.1:${PORT}`,
    capability_class: 'A',
    service_status: 'ONLINE',
    metadata: { build: 20 }
  });

  persistRuntimeState('runtime-api', {
    runtime_state: 'ONLINE',
    metadata: { build: 21, api_port: PORT }
  }).then(() => {
    runtime.httpServer.listen(PORT, () => {
      console.log(`[CCJV Build22] runtime API + websocket runtime online on ${PORT}`);
    });
  });
}).catch(err => {
  console.error('[CCJV Build20] API startup failed', err);
  process.exit(1);
});
