const {
  DeterministicReplayRuntime
} = require('../runtime/deterministic-replay-runtime');

async function proveReplay() {
  const runtime = new DeterministicReplayRuntime();

  const event = runtime.append({
    type: 'treasury.transfer.executed',
    correlation_id: 'corr-123'
  });

  const reconstruction =
    runtime.reconstruct('corr-123');

  console.log(JSON.stringify({
    replay_written: !!event,
    replay_reconstructed:
      reconstruction.event_count === 1
  }, null, 2));
}

proveReplay();
