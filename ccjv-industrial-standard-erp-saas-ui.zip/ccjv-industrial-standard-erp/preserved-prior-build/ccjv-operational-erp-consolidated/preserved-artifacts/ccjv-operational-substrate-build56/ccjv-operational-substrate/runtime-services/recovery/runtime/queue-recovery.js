async function recoverQueues(redis) {
  const queues = [
    'replay',
    'treasury',
    'websocket',
    'anchor'
  ];

  const recovered = [];

  for (const queue of queues) {
    recovered.push({
      queue,
      recovered: true
    });
  }

  return recovered;
}

module.exports = {
  recoverQueues
};
