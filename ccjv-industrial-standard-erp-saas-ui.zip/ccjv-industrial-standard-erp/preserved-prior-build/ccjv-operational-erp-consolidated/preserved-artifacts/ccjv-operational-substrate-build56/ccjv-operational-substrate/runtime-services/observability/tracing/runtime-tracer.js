const { trace, context } = require('@opentelemetry/api');

const tracer = trace.getTracer('ccjv-runtime');

function runtimeSpan(name, metadata = {}) {
  const span = tracer.startSpan(name);

  Object.keys(metadata).forEach(key => {
    span.setAttribute(key, String(metadata[key]));
  });

  return span;
}

async function traced(name, metadata, fn) {
  const span = runtimeSpan(name, metadata);

  try {
    const result = await context.with(
      trace.setSpan(context.active(), span),
      fn
    );

    span.end();
    return result;
  } catch (err) {
    span.recordException(err);
    span.end();
    throw err;
  }
}

module.exports = {
  runtimeSpan,
  traced
};
