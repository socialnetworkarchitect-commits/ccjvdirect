const client = require('prom-client');

const runtimeEvents = new client.Counter({
  name: 'ccjv_runtime_events_total',
  help: 'Total runtime events'
});

const replayEvents = new client.Counter({
  name: 'ccjv_replay_events_total',
  help: 'Total replay events'
});

function emitRuntimeMetric() {
  runtimeEvents.inc();
}

function emitReplayMetric() {
  replayEvents.inc();
}

module.exports = {
  emitRuntimeMetric,
  emitReplayMetric,
  register: client.register
};
