const { Pool } = require('pg');

class PostgresRuntime {
  constructor() {
    this.pool = new Pool({
      host: process.env.PG_HOST || 'localhost',
      port: process.env.PG_PORT || 5432,
      user: process.env.PG_USER || 'ccjv',
      password: process.env.PG_PASSWORD || 'ccjv',
      database: process.env.PG_DATABASE || 'ccjv_runtime'
    });
  }

  async query(sql, params = []) {
    return this.pool.query(sql, params);
  }

  async health() {
    const result =
      await this.query('SELECT NOW()');

    return {
      ok: true,
      server_time: result.rows[0]
    };
  }
}

module.exports = {
  PostgresRuntime
};
