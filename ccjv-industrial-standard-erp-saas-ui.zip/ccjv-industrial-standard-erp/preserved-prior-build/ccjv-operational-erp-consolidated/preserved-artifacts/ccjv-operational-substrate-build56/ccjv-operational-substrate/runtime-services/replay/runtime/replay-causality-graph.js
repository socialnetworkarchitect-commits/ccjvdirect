class ReplayCausalityGraph {
  constructor() {
    this.graph = [];
  }

  link(parent, child) {
    const edge = {
      parent,
      child,
      linked_at: new Date().toISOString()
    };

    this.graph.push(edge);

    return edge;
  }

  edges() {
    return this.graph;
  }
}

module.exports = {
  ReplayCausalityGraph
};
