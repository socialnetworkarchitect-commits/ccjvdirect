function pm2Topology() {
  return {
    runtime_services: [
      'api',
      'websocket',
      'treasury',
      'replay',
      'avalanche',
      'observability'
    ],
    clustered: true
  };
}

module.exports = {
  pm2Topology
};
