const { HSMSignerRuntime } = require('../runtime/hsm-signer-runtime');

async function proveHSMRuntime() {
  const runtime = new HSMSignerRuntime();

  const isolated = await runtime.isolateSigner({
    request_id: 'req-hsm-1'
  });

  const gas = await runtime.estimateGas({
    type: 'erc20'
  });

  console.log(JSON.stringify({
    signer_isolation: isolated.isolated,
    gas_estimation: gas.estimated_gas > 0
  }, null, 2));
}

proveHSMRuntime();
