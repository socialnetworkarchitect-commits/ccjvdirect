CREATE SCHEMA IF NOT EXISTS institutional_runtime;

CREATE TABLE IF NOT EXISTS institutional_runtime.event_store (
    id BIGSERIAL PRIMARY KEY,
    event_id UUID NOT NULL,
    correlation_id UUID,
    causality_id UUID,
    replay_id UUID,
    tenant_id VARCHAR(64),
    workspace_id VARCHAR(64),
    event_type VARCHAR(255),
    payload JSONB,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_event_store_replay
ON institutional_runtime.event_store(replay_id);

CREATE TABLE IF NOT EXISTS institutional_runtime.runtime_state (
    id BIGSERIAL PRIMARY KEY,
    runtime_key VARCHAR(191) UNIQUE,
    runtime_state VARCHAR(64),
    metadata JSONB,
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS institutional_runtime.treasury_transactions (
    id BIGSERIAL PRIMARY KEY,
    transaction_id UUID,
    wallet_address VARCHAR(255),
    token_address VARCHAR(255),
    transaction_state VARCHAR(64),
    tx_hash VARCHAR(255),
    metadata JSONB,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS institutional_runtime.federation_heartbeats (
    id BIGSERIAL PRIMARY KEY,
    erp_slug VARCHAR(191),
    heartbeat_state VARCHAR(64),
    metadata JSONB,
    created_at TIMESTAMPTZ DEFAULT NOW()
);
