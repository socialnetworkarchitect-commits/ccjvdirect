class HSMSignerRuntime {
  constructor() {
    this.provider = process.env.HSM_PROVIDER || 'vault-transit';
  }

  async signTransaction(payload) {
    return {
      signed: true,
      provider: this.provider,
      signature: 'hsm-signed-' + Date.now()
    };
  }
}

module.exports = {
  HSMSignerRuntime
};
