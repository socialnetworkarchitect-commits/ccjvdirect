function emitFederationHeartbeat(io, erpSlug, metadata = {}) {
  io.emit('federation.heartbeat', {
    erp_slug: erpSlug,
    metadata,
    timestamp: new Date().toISOString()
  });
}

module.exports = { emitFederationHeartbeat };
