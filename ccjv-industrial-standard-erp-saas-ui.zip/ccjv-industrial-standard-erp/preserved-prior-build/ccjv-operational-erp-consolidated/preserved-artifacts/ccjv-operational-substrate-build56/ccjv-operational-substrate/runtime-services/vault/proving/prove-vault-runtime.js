const {
  MinIOVaultRuntime
} = require('../runtime/minio-vault-runtime');

async function proveVault() {
  const runtime = new MinIOVaultRuntime();

  const object = runtime.storeObject({
    filename: 'evidence.pdf',
    tenant: 'tenant-a'
  });

  const integrity =
    runtime.verifyIntegrity(object.object_id);

  console.log(JSON.stringify({
    object_stored: !!object.object_id,
    integrity_verified:
      integrity.verified
  }, null, 2));
}

proveVault();
