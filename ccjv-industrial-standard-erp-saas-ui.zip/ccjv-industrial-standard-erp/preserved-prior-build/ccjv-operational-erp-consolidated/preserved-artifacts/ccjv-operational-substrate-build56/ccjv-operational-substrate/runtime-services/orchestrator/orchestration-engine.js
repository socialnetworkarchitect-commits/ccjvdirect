const { event, now } = require('../common');

const runtimeDAG = {
  core: ['queues', 'replay', 'federation'],
  queues: ['treasury', 'vaultProof', 'websocket'],
  treasury: ['vaultProof', 'observability'],
  vaultProof: ['avalanche', 'observability'],
  federation: ['replay', 'observability'],
  replay: ['memory', 'observability']
};

function resolveExecutionOrder(graph) {
  const visited = new Set();
  const order = [];
  function visit(node) {
    if (visited.has(node)) return;
    visited.add(node);
    (graph[node] || []).forEach(visit);
    order.push(node);
  }
  Object.keys(graph).forEach(visit);
  return order.reverse();
}

function reconcileRuntimeState() {
  const order = resolveExecutionOrder(runtimeDAG);
  const orchestrationEvent = event('runtime.orchestration.reconciled', {
    runtimeDAG,
    executionOrder: order,
    reconciled_at: now()
  });
  console.log(JSON.stringify(orchestrationEvent));
}

console.log('[CCJV Build19] orchestration engine online');
reconcileRuntimeState();
setInterval(reconcileRuntimeState, 15000);
