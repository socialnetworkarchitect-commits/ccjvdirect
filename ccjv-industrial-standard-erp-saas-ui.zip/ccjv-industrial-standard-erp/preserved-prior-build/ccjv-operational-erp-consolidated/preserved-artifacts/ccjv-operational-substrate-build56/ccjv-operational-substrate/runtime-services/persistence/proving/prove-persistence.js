const crypto = require('crypto');
const { persistEvent, replayTimeline } = require('../repositories/event-repository');
const { persistRuntimeState, allRuntimeState } = require('../repositories/runtime-state-repository');

function uuid() {
  return crypto.randomUUID();
}

async function run() {
  const replayId = uuid();

  const event = await persistEvent({
    event_id: uuid(),
    correlation_id: uuid(),
    causality_id: uuid(),
    replay_id: replayId,
    tenant_id: 'system',
    workspace_id: 'runtime',
    event_type: 'build21.persistence.proof',
    payload: { ok: true, build: 21 }
  });

  const state = await persistRuntimeState('build21-runtime', {
    runtime_state: 'ONLINE',
    metadata: { proof: true }
  });

  const replay = await replayTimeline(replayId);
  const runtime = await allRuntimeState();

  console.log(JSON.stringify({
    ok: true,
    persisted_event: event.event_id,
    replay_count: replay.length,
    runtime_count: runtime.length,
    persisted_runtime: state.runtime_key
  }, null, 2));

  process.exit(0);
}

run().catch(err => {
  console.error(JSON.stringify({
    ok: false,
    error: err.message
  }, null, 2));
  process.exit(1);
});
