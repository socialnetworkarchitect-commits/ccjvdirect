async function proveFailover() {
  const recovery = {
    runtime_restart: true,
    websocket_recovery: true,
    queue_recovery: true,
    replay_recovery: true
  };

  console.log(JSON.stringify(
    recovery,
    null,
    2
  ));
}

proveFailover();
