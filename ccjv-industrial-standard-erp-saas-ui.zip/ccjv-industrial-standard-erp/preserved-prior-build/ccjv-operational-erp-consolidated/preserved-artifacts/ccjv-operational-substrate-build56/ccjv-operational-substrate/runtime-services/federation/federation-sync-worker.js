const { event } = require('../common');

const erps = [
  { slug: 'impensa', required: ['/health','/modules','/workspaces','/events','/replay','/vault','/treasury'] },
  { slug: 'manufactura', required: ['/health','/modules','/workspaces','/events','/replay','/vault','/treasury'] },
  { slug: 'omnichain', required: ['/health','/modules','/workspaces','/events','/replay','/vault','/treasury'] },
  { slug: 'xmarkets', required: ['/health','/modules','/workspaces','/events','/replay','/vault','/treasury'] }
];

function synchronizeFederation() {
  erps.forEach(erp => {
    console.log(JSON.stringify(event('federation.erp.heartbeat', {
      erp_slug: erp.slug,
      contract_endpoints: erp.required,
      liveness_state: 'SYNC_REQUESTED'
    })));
  });
}

console.log('[CCJV Build19] federation synchronization worker online');
synchronizeFederation();
setInterval(synchronizeFederation, 18000);
