const express = require('express');
const router = express.Router();
const store = require('../lib/runtime-store');

router.get('/services', async (req, res) => {
  res.json({ ok: true, services: await store.services() });
});

router.post('/register', async (req, res) => {
  if (!req.body.service_key) {
    return res.status(400).json({ ok: false, error: 'service_key required' });
  }
  const service = await store.registerService(req.body);
  await store.emitEvent({
    tenant_id: req.tenant_id,
    workspace_id: req.workspace_id,
    correlation_id: req.correlation_id,
    causality_id: req.causality_id,
    replay_id: req.replay_id,
    event_type: 'runtime.service.registered',
    payload: service
  });
  res.json({ ok: true, service });
});

router.get('/diagnostics', async (req, res) => {
  res.json({
    ok: true,
    runtime: 'ccjv-operational-substrate-api',
    uptime: process.uptime(),
    memory: process.memoryUsage(),
    tenant_id: req.tenant_id,
    workspace_id: req.workspace_id,
    correlation_id: req.correlation_id
  });
});

module.exports = router;
