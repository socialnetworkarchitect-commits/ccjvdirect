const {
  SIWERuntime
} = require('../runtime/siwe-runtime');

async function proveSIWE() {
  const siwe = new SIWERuntime();

  const nonce = siwe.issueNonce('0xABC');

  const session = siwe.verify(
    '0xABC',
    'signed-message'
  );

  console.log(JSON.stringify({
    nonce_issued: !!nonce,
    verified: session.verified
  }, null, 2));
}

proveSIWE();
