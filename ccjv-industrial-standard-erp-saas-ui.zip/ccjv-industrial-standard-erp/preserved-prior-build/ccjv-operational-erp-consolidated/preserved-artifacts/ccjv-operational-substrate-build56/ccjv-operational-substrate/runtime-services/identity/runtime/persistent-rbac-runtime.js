class PersistentRBACRuntime {
  constructor() {
    this.roles = [];
  }

  persistRole(user, role) {
    const entry = {
      user,
      role,
      persisted_at:
        new Date().toISOString()
    };

    this.roles.push(entry);

    return entry;
  }

  all() {
    return this.roles;
  }
}

module.exports = {
  PersistentRBACRuntime
};
