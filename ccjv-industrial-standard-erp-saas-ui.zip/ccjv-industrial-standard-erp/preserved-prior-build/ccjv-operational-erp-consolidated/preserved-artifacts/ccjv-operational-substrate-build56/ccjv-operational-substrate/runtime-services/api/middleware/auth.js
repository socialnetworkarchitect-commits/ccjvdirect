const jwt = require('jsonwebtoken');

function authMiddleware(req, res, next) {
  const publicPaths = ['/health', '/diagnostics'];
  if (publicPaths.includes(req.path)) return next();

  const auth = req.headers.authorization || '';
  const token = auth.startsWith('Bearer ') ? auth.slice(7) : null;

  if (!token && process.env.CCJV_REQUIRE_JWT === 'true') {
    return res.status(401).json({ ok: false, error: 'JWT required' });
  }

  if (token) {
    try {
      req.identity = jwt.verify(token, process.env.JWT_SECRET || 'CHANGE_ME');
    } catch (err) {
      if (process.env.CCJV_REQUIRE_JWT === 'true') {
        return res.status(401).json({ ok: false, error: 'Invalid JWT' });
      }
      req.identity = { warning: 'jwt_not_verified', error: err.message };
    }
  } else {
    req.identity = { mode: 'development_unenforced' };
  }

  next();
}

module.exports = authMiddleware;
