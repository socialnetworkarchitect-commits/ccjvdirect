const { ethers } = require('ethers');
const pool = require('../persistence/db');

const provider = new ethers.JsonRpcProvider(
  process.env.AVALANCHE_RPC || 'https://api.avax.network/ext/bc/C/rpc'
);

const signer = new ethers.Wallet(
  process.env.RUNTIME_SIGNER_PRIVATE_KEY ||
  '0x1111111111111111111111111111111111111111111111111111111111111111',
  provider
);

async function persistAnchor(anchor) {
  await pool.query(`
    INSERT INTO institutional_runtime.federation_heartbeats
      (erp_slug, heartbeat_state, metadata)
    VALUES ($1,$2,$3)
  `, [
    'avalanche-anchor-runtime',
    'ANCHORED',
    anchor
  ]);
}

async function submitAnchor(rootHash) {
  const tx = await signer.sendTransaction({
    to: signer.address,
    value: 0,
    data: ethers.hexlify(
      ethers.toUtf8Bytes(rootHash)
    )
  });

  const receipt = await tx.wait();

  await persistAnchor({
    merkle_root: rootHash,
    tx_hash: tx.hash,
    block_number: receipt.blockNumber
  });

  return {
    tx_hash: tx.hash,
    block_number: receipt.blockNumber
  };
}

module.exports = {
  submitAnchor
};
