class ReplayDAGDBRuntime {
  constructor() {
    this.nodes = [];
  }

  save(node) {
    this.nodes.push(node);

    return {
      saved: true,
      node
    };
  }

  graph() {
    return this.nodes;
  }
}

module.exports = {
  ReplayDAGDBRuntime
};
