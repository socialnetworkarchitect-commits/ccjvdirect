const jwt = require('jsonwebtoken');

function runtimeAuth(req, res, next) {
  try {
    const auth = req.headers.authorization || '';
    const token = auth.replace('Bearer ', '');

    const decoded = jwt.verify(
      token,
      process.env.JWT_SECRET || 'ccjv_runtime_secret'
    );

    req.runtimeIdentity = decoded;
    next();
  } catch (err) {
    res.status(401).json({
      ok: false,
      error: 'runtime_auth_failed'
    });
  }
}

module.exports = runtimeAuth;
