const pool = require('../../persistence/db');

async function treasuryHistory() {
  const result = await pool.query(`
    SELECT *
    FROM institutional_runtime.treasury_transactions
    ORDER BY created_at DESC
    LIMIT 100
  `);

  return result.rows;
}

module.exports = { treasuryHistory };
