const {
  AvalancheAnchorRuntime
} = require('../runtime/anchor-runtime');

const {
  verifyProof
} = require('../runtime/proof-verification-runtime');

async function proveAvalancheAnchor() {
  const runtime = new AvalancheAnchorRuntime();

  const anchor = await runtime.submitAnchor([
    { id: 'record-1' }
  ]);

  const verification = await verifyProof(anchor);

  console.log(JSON.stringify({
    anchor_created: !!anchor.tx_hash,
    proof_verified: verification.verified
  }, null, 2));
}

proveAvalancheAnchor();
