class WebsocketAuthRuntime {
  constructor() {
    this.connections = [];
  }

  authenticate(connection) {
    const authenticated = {
      ...connection,
      authenticated: true,
      authenticated_at: new Date().toISOString()
    };

    this.connections.push(authenticated);

    return authenticated;
  }

  list() {
    return this.connections;
  }
}

module.exports = {
  WebsocketAuthRuntime
};
