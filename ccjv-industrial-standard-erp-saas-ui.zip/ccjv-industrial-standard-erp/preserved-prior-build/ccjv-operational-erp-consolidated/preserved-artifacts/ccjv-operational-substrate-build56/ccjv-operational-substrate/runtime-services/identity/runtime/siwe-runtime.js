const crypto = require('crypto');

class SIWERuntime {
  constructor() {
    this.nonces = new Map();
    this.sessions = new Map();
  }

  issueNonce(wallet) {
    const nonce = crypto.randomBytes(16).toString('hex');

    this.nonces.set(wallet, {
      nonce,
      issued_at: new Date().toISOString()
    });

    return nonce;
  }

  verify(wallet, signature) {
    const nonceData = this.nonces.get(wallet);

    if (!nonceData) {
      return {
        verified: false
      };
    }

    const session = {
      wallet,
      signature,
      session_id: crypto.randomUUID(),
      created_at: new Date().toISOString(),
      verified: true
    };

    this.sessions.set(session.session_id, session);

    return session;
  }

  validateSession(sessionId) {
    return this.sessions.get(sessionId);
  }
}

module.exports = {
  SIWERuntime
};
