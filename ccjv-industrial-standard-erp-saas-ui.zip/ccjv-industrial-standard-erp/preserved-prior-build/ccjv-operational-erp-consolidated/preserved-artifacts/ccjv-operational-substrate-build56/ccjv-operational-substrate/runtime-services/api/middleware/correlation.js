const { randomUUID } = require('crypto');

function correlationMiddleware(req, res, next) {
  req.correlation_id = req.headers['x-correlation-id'] || randomUUID();
  req.causality_id = req.headers['x-causality-id'] || randomUUID();
  req.replay_id = req.headers['x-replay-id'] || randomUUID();

  res.setHeader('X-Correlation-ID', req.correlation_id);
  res.setHeader('X-Causality-ID', req.causality_id);
  res.setHeader('X-Replay-ID', req.replay_id);

  next();
}

module.exports = correlationMiddleware;
