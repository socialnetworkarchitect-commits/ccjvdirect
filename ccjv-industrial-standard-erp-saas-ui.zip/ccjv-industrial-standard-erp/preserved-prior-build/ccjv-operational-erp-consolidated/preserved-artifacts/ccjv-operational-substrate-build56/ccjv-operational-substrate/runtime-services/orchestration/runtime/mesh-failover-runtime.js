class MeshFailoverRuntime {
  failover(nodes) {
    return {
      recovered: true,
      active_nodes:
        nodes.filter(
          (n) => n.active
        ).length
    };
  }
}

module.exports = {
  MeshFailoverRuntime
};
