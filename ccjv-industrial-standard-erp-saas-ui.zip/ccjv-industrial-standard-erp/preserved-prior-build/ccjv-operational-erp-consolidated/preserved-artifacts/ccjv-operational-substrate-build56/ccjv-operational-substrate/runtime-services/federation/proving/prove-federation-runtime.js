const {
  ERPFederationRuntime
} = require('../runtime/erp-federation-runtime');

async function proveFederation() {
  const runtime = new ERPFederationRuntime();

  runtime.registerERP({
    erp_id: 'manufactura',
    capabilities: ['vault', 'replay', 'treasury']
  });

  const sync = runtime.synchronizeERP('manufactura');

  console.log(JSON.stringify({
    federation_registered: true,
    federation_synced: !!sync
  }, null, 2));
}

proveFederation();
