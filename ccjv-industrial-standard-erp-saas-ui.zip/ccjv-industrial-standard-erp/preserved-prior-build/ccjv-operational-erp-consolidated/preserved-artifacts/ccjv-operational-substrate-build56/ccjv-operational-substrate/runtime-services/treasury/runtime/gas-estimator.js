async function estimateGas(provider, transaction) {
  const estimate = await provider.estimateGas(transaction);

  return {
    gas_limit: estimate.toString(),
    estimated: true
  };
}

module.exports = {
  estimateGas
};
