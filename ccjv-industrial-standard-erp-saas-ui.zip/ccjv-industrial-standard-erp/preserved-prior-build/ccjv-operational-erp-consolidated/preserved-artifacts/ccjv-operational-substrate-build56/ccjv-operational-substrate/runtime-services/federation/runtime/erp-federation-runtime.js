class ERPFederationRuntime {
  constructor() {
    this.erps = new Map();
  }

  registerERP(payload) {
    const erp = {
      ...payload,
      registered_at: new Date().toISOString(),
      healthy: true
    };

    this.erps.set(payload.erp_id, erp);

    return erp;
  }

  listERPs() {
    return Array.from(this.erps.values());
  }

  synchronizeERP(erpId) {
    const erp = this.erps.get(erpId);

    if (!erp) {
      return null;
    }

    erp.last_sync = new Date().toISOString();

    return erp;
  }
}

module.exports = {
  ERPFederationRuntime
};
