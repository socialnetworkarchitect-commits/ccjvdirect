const express = require('express');
const router = express.Router();
const store = require('../lib/runtime-store');

router.post('/execution-plan', async (req, res) => {
  const event = await store.emitEvent({
    tenant_id: req.tenant_id,
    workspace_id: req.workspace_id,
    correlation_id: req.correlation_id,
    causality_id: req.causality_id,
    replay_id: req.replay_id,
    event_type: 'treasury.execution.plan.created',
    payload: {
      execution_type: 'ERC20_TRANSFER_FROM',
      wallet_address: req.body.wallet_address || '',
      token_address: req.body.token_address || '',
      amount: req.body.amount || '0',
      steps: ['balanceOf','allowance','gasEstimate','transferFrom','receipt','reconciliation']
    }
  });
  res.json({ ok: true, event });
});

module.exports = router;
