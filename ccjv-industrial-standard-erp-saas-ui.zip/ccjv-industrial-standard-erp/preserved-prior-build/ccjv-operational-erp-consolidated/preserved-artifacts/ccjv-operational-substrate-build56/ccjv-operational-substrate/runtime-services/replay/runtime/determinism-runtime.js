const crypto = require('crypto');

function deterministicReplayHash(events = []) {
  const normalized = JSON.stringify(events);
  return crypto.createHash('sha256').update(normalized).digest('hex');
}

function verifyReplayDeterminism(eventsA, eventsB) {
  return deterministicReplayHash(eventsA) === deterministicReplayHash(eventsB);
}

module.exports = {
  deterministicReplayHash,
  verifyReplayDeterminism
};
