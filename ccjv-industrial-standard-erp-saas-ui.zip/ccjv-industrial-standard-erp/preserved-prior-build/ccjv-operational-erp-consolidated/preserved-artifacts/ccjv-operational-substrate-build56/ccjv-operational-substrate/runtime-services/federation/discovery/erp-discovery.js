const axios = require('axios');

async function discoverERP(url) {
  const health = await axios.get(`${url}/health`);

  return {
    url,
    reachable: true,
    health: health.data
  };
}

async function negotiateCapabilities(url) {
  const modules = await axios.get(`${url}/modules`);

  return {
    url,
    modules: modules.data
  };
}

module.exports = {
  discoverERP,
  negotiateCapabilities
};
