const fetch = require('node-fetch');

const base = process.env.CCJV_API_BASE || 'http://127.0.0.1:3100';

async function call(path, options={}) {
  const res = await fetch(`${base}${path}`, {
    headers: {
      'Content-Type': 'application/json',
      'X-Tenant-ID': 'system',
      'X-Workspace-ID': 'runtime',
      ...(options.headers || {})
    },
    ...options
  });
  const json = await res.json();
  return { status: res.status, json };
}

(async () => {
  const proof = [];
  proof.push(['health', await call('/health')]);
  proof.push(['register', await call('/runtime/register', {
    method: 'POST',
    body: JSON.stringify({ service_key: 'proof-service', service_name: 'Proof Service', capability_class: 'A' })
  })]);
  proof.push(['event', await call('/events', {
    method: 'POST',
    body: JSON.stringify({ event_type: 'proof.api.event', payload: { ok: true } })
  })]);
  proof.push(['federation', await call('/federation/heartbeat', {
    method: 'POST',
    body: JSON.stringify({ erp_slug: 'impensa', status: 'ONLINE' })
  })]);
  proof.push(['treasury', await call('/treasury/execution-plan', {
    method: 'POST',
    body: JSON.stringify({ wallet_address: '0x0000000000000000000000000000000000000000', amount: '1' })
  })]);
  proof.push(['vault', await call('/vault/hash', {
    method: 'POST',
    body: JSON.stringify({ payload: { record: 'proof' } })
  })]);
  proof.push(['proof', await call('/proof/merkle', {
    method: 'POST',
    body: JSON.stringify({ hashes: ['a','b','c'].map(x => require('crypto').createHash('sha256').update(x).digest('hex')) })
  })]);
  console.log(JSON.stringify({ ok: true, base, proof }, null, 2));
})().catch(err => {
  console.error(JSON.stringify({ ok: false, error: err.message }, null, 2));
  process.exit(1);
});
