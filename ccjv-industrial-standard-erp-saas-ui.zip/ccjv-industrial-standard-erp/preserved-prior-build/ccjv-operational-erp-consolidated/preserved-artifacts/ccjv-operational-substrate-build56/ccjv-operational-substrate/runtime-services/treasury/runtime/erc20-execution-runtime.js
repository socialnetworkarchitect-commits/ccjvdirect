class ERC20ExecutionRuntime {
  constructor() {
    this.executions = [];
  }

  verifyAllowance(wallet, amount) {
    return {
      wallet,
      amount,
      verified: true,
      checked_at: new Date().toISOString()
    };
  }

  transferFrom(payload) {
    const execution = {
      tx_id: `tx_${Date.now()}`,
      ...payload,
      status: 'executed',
      executed_at: new Date().toISOString()
    };

    this.executions.push(execution);

    return execution;
  }

  reconcile(txId) {
    const tx = this.executions.find(
      (e) => e.tx_id === txId
    );

    return {
      reconciled: !!tx,
      tx
    };
  }
}

module.exports = {
  ERC20ExecutionRuntime
};
