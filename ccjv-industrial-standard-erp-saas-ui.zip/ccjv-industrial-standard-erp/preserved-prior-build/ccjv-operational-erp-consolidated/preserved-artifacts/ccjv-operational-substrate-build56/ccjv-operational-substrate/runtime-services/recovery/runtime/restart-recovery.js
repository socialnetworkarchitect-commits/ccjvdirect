const fs = require('fs');
const path = require('path');

const recoveryFile = path.join(__dirname, '../../storage/runtime-recovery.json');

function persistRuntimeState(state) {
  fs.mkdirSync(path.dirname(recoveryFile), { recursive: true });

  fs.writeFileSync(
    recoveryFile,
    JSON.stringify(state, null, 2)
  );

  return {
    persisted: true
  };
}

function recoverRuntimeState() {
  if (!fs.existsSync(recoveryFile)) {
    return {
      recovered: false
    };
  }

  return JSON.parse(
    fs.readFileSync(recoveryFile, 'utf8')
  );
}

module.exports = {
  persistRuntimeState,
  recoverRuntimeState
};
