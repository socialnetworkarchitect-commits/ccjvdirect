const { randomUUID } = require('crypto');

function now() { return new Date().toISOString(); }

function env(name, fallback='') { return process.env[name] || fallback; }

function event(type, payload={}) {
  return {
    event_id: randomUUID(),
    correlation_id: payload.correlation_id || randomUUID(),
    causality_id: payload.causality_id || randomUUID(),
    replay_id: payload.replay_id || randomUUID(),
    tenant_id: payload.tenant_id || 'system',
    workspace_id: payload.workspace_id || 'runtime',
    event_type: type,
    payload,
    created_at: now()
  };
}

module.exports = { now, env, event };
