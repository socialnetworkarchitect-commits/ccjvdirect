const { ethers } = require('ethers');

class SignerIsolationRuntime {
  constructor() {
    this.wallet =
      new ethers.Wallet(
        process.env.SIGNER_PRIVATE_KEY ||
        '0x' + '1'.repeat(64)
      );
  }

  address() {
    return this.wallet.address;
  }

  async sign(payload) {
    return this.wallet.signMessage(
      JSON.stringify(payload)
    );
  }
}

module.exports = {
  SignerIsolationRuntime
};
