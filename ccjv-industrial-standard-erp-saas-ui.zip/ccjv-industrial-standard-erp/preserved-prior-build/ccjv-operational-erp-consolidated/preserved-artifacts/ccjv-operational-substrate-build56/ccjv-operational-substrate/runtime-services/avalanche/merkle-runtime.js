const crypto = require('crypto');

function sha(data) {
  return crypto.createHash('sha256').update(data).digest('hex');
}

function merkleRoot(items = []) {
  if (!items.length) {
    return null;
  }

  let level = items.map(i => sha(JSON.stringify(i)));

  while (level.length > 1) {
    const next = [];

    for (let i = 0; i < level.length; i += 2) {
      const left = level[i];
      const right = level[i + 1] || left;
      next.push(sha(left + right));
    }

    level = next;
  }

  return level[0];
}

module.exports = {
  merkleRoot
};
