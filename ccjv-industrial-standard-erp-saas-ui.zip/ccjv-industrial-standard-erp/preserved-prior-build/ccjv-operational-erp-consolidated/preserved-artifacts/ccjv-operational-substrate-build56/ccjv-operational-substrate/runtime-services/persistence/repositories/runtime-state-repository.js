const pool = require('../db');

async function persistRuntimeState(runtimeKey, state) {
  const result = await pool.query(`
    INSERT INTO institutional_runtime.runtime_state
      (runtime_key, runtime_state, metadata)
    VALUES ($1,$2,$3)
    ON CONFLICT (runtime_key) DO UPDATE SET
      runtime_state=EXCLUDED.runtime_state,
      metadata=EXCLUDED.metadata,
      updated_at=NOW()
    RETURNING *
  `, [
    runtimeKey,
    state.runtime_state || 'ONLINE',
    state.metadata || {}
  ]);

  return result.rows[0];
}

async function allRuntimeState() {
  const result = await pool.query(`
    SELECT * FROM institutional_runtime.runtime_state
    ORDER BY runtime_key ASC
  `);

  return result.rows;
}

module.exports = { persistRuntimeState, allRuntimeState };
