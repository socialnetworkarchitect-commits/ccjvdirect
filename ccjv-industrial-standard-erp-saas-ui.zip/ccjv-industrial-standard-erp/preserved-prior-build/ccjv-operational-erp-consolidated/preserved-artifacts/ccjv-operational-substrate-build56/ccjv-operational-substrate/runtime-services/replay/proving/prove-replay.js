const {
  buildCausalityGraph,
  deterministicReplay
} = require('../graphs/causality-graph');

async function run() {
  const sample = [
    {
      correlation_id: 'alpha',
      event_type: 'TREASURY',
      created_at: '2026-01-01T00:00:00Z'
    },
    {
      correlation_id: 'beta',
      event_type: 'VAULT',
      created_at: '2026-01-01T00:00:01Z'
    }
  ];

  const graph = buildCausalityGraph(sample);
  const replay = deterministicReplay(sample);

  console.log(JSON.stringify({
    ok: true,
    graph_nodes: graph.nodes.length,
    replay_events: replay.length
  }, null, 2));

  process.exit(0);
}

run().catch(err => {
  console.error(JSON.stringify({
    ok: false,
    error: err.message
  }, null, 2));

  process.exit(1);
});
