const pool = require('../../persistence/db');

async function persistHeartbeat(runtime, state, metadata) {
  await pool.query(`
    INSERT INTO institutional_runtime.federation_heartbeats
      (erp_slug, heartbeat_state, metadata)
    VALUES ($1,$2,$3)
  `, [
    runtime,
    state,
    metadata
  ]);
}

async function federationHistory() {
  const result = await pool.query(`
    SELECT *
    FROM institutional_runtime.federation_heartbeats
    ORDER BY created_at DESC
    LIMIT 100
  `);

  return result.rows;
}

module.exports = {
  persistHeartbeat,
  federationHistory
};
