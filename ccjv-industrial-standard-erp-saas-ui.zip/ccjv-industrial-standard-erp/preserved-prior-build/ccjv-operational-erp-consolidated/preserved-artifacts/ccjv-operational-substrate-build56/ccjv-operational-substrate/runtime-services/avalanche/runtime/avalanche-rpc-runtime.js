const { ethers } = require('ethers');

class AvalancheRPCRuntime {
  constructor() {
    this.provider =
      new ethers.JsonRpcProvider(
        process.env.AVALANCHE_RPC ||
        'https://api.avax.network/ext/bc/C/rpc'
      );
  }

  async latestBlock() {
    return this.provider.getBlockNumber();
  }
}

module.exports = {
  AvalancheRPCRuntime
};
