function kubernetesTopology() {
  return {
    namespace: 'ccjv-runtime',
    deployments: [
      'api-runtime',
      'websocket-runtime',
      'replay-runtime',
      'treasury-runtime'
    ],
    autoscaling: true
  };
}

module.exports = {
  kubernetesTopology
};
