const {
  RedisRuntime
} = require('../../queue/runtime/redis-runtime');

async function provePersistence() {
  const redis = new RedisRuntime();

  await redis.enqueue(
    'runtime.queue',
    {
      event: 'runtime.started'
    }
  );

  const recovered =
    await redis.recover(
      'runtime.queue'
    );

  console.log(JSON.stringify({
    queue_recovered:
      recovered.length > 0
  }, null, 2));
}

provePersistence();
