const express = require('express');
const router = express.Router();
const store = require('../lib/runtime-store');

router.get('/', async (req, res) => {
  res.json({ ok: true, events: await store.events(Number(req.query.limit || 50)) });
});

router.post('/', async (req, res) => {
  const event = await store.emitEvent({
    ...req.body,
    tenant_id: req.tenant_id,
    workspace_id: req.workspace_id,
    correlation_id: req.correlation_id,
    causality_id: req.causality_id,
    replay_id: req.replay_id
  });
  res.json({ ok: true, event });
});

module.exports = router;
