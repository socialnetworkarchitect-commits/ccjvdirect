function recoveryTrace(event) {
  return {
    recovery_event: true,
    trace_id: event.trace_id,
    correlation_id: event.correlation_id,
    timestamp: new Date().toISOString()
  };
}

module.exports = {
  recoveryTrace
};
