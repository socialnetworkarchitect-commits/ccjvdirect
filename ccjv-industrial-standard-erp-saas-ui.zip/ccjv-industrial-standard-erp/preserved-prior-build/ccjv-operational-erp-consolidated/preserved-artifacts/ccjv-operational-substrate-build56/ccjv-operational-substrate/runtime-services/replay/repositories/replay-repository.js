const pool = require('../../persistence/db');

async function replayEvents(limit = 100) {
  const result = await pool.query(`
    SELECT *
    FROM institutional_runtime.runtime_events
    ORDER BY created_at ASC
    LIMIT $1
  `, [limit]);

  return result.rows;
}

module.exports = {
  replayEvents
};
