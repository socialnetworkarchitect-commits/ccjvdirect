# Build 36 Additions

## Exact Files Added
- runtime-services/operational-memory/runtime/dag-persistence-runtime.js
- runtime-services/replay/runtime/determinism-runtime.js
- runtime-services/operational-memory/proving/prove-dag-persistence.js
- docs/BUILD36-ADDITIONS.md

## Exact Files Modified
- runtime-services/package.json
- runtime-services/api/server.js
- runtime-services/websocket/runtime.js

## Executable Capability Added
- PostgreSQL DAG persistence runtime
- replay determinism verification runtime
- operational DAG API
- replay hash API
- websocket DAG replication
- DAG persistence proving

## Regression Verification
Preserved:
- orchestration runtime
- replay runtime
- websocket federation
- observability federation
- treasury execution runtime
- Avalanche continuity runtime
- federation synchronization
- operational memory runtime
- lineage runtime
- persistence continuity
- proving runtimes

## Remaining Gaps
- signer custody isolation still env-based
- HSM-backed signing not yet integrated
