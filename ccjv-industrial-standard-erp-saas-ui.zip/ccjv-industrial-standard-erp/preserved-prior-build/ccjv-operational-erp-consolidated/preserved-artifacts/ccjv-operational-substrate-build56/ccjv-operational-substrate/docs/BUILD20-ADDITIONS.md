# Build 20 Additions

## Exact Files Added
- runtime-services/api/server.js
- runtime-services/api/lib/runtime-store.js
- runtime-services/api/middleware/auth.js
- runtime-services/api/middleware/correlation.js
- runtime-services/api/middleware/tenant.js
- runtime-services/api/routes/runtime.js
- runtime-services/api/routes/events.js
- runtime-services/api/routes/replay.js
- runtime-services/api/routes/federation.js
- runtime-services/api/routes/treasury.js
- runtime-services/api/routes/vault.js
- runtime-services/api/routes/proof.js
- runtime-services/api/proving/prove-api.js
- database/build20-api-runtime.sql
- docs/BUILD20-ADDITIONS.md

## Exact Files Modified
- runtime-services/package.json
- runtime-services/ecosystem.config.js

## Executable Capability Added
- Express runtime API server
- PostgreSQL-backed runtime service registry
- PostgreSQL-backed API event persistence
- executable /health
- executable /runtime/register
- executable /runtime/services
- executable /runtime/diagnostics
- executable /events GET/POST
- executable /replay/:replay_id
- executable /federation/heartbeat
- executable /treasury/execution-plan
- executable /vault/hash
- executable /proof/merkle
- JWT middleware enforcement point
- tenant/workspace middleware
- correlation/causality/replay ID middleware
- API proving script

## Regression Verification
Build 19 was unpacked first and preserved.
Verified files:
- BUILD18-README.md
- runtime-services/package.json
- runtime-services/ecosystem.config.js
- database/build19-runtime-execution.sql
- docs/BUILD19-ADDITIONS.md

## Remaining Gaps
- SIWE cryptographic endpoint still needs full EIP-4361 verify API.
- Treasury transferFrom execution still dry-run/planning endpoint.
- MinIO upload endpoint not yet wired into API.
- Avalanche anchor tx execution not yet wired into API.
- Websocket server auth runtime not yet integrated into API session layer.
