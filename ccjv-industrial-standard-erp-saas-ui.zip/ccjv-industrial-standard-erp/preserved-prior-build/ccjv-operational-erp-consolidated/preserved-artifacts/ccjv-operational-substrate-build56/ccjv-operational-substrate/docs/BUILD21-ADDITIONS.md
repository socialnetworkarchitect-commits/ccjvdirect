# Build 21 Additions

## Exact Files Added
- runtime-services/persistence/db.js
- runtime-services/persistence/repositories/event-repository.js
- runtime-services/persistence/repositories/runtime-state-repository.js
- runtime-services/persistence/migrations/001_runtime_persistence.sql
- runtime-services/persistence/run-migrations.js
- runtime-services/persistence/proving/prove-persistence.js
- docs/BUILD21-ADDITIONS.md

## Exact Files Modified
- runtime-services/package.json
- runtime-services/api/server.js
- runtime-services/ecosystem.config.js

## Executable Capability Added
- PostgreSQL runtime persistence layer
- runtime migrations
- event store persistence
- replay persistence
- runtime state persistence
- treasury transaction persistence table
- federation heartbeat persistence table
- persistence proof script
- PM2 migration process

## Regression Verification
Preserved:
- Build18 README
- Build19 runtime workers
- Build20 API runtime
- API proving script
- PM2 ecosystem
- runtime SQL layers

## Remaining Gaps
- Timescale hypertables not yet enabled automatically
- Redis queue durability proving still separate from persistence proving
- SIWE nonce persistence not yet integrated
- Websocket session persistence not yet integrated
