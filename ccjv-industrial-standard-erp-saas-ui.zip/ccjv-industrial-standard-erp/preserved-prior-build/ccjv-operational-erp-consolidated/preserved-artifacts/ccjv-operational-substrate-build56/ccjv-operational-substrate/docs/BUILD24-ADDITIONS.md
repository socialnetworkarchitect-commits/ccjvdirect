# Build 24 Additions

## Exact Files Added
- runtime-services/treasury/execution-runtime.js
- runtime-services/treasury/repositories/treasury-repository.js
- runtime-services/treasury/proving/prove-treasury.js
- docs/BUILD24-ADDITIONS.md

## Exact Files Modified
- runtime-services/package.json
- runtime-services/api/server.js
- runtime-services/ecosystem.config.js

## Executable Capability Added
- ethers.js treasury runtime
- ERC20 allowance verification
- transferFrom execution runtime
- Avalanche RPC integration
- treasury persistence linkage
- treasury execution APIs
- treasury proof script
- PM2 treasury runtime orchestration

## Regression Verification
Preserved:
- Build18 README
- Build19 runtime workers
- Build20 API runtime
- Build21 persistence runtime
- Build22 websocket runtime
- Build23 queue runtime
- migrations
- proving scripts
- PM2 ecosystem

## Remaining Gaps
- signer custody isolation still env-based
- nonce reconciliation not yet persisted
- gas estimation persistence pending
- Avalanche anchoring worker pending
- deterministic replay graph persistence incomplete
