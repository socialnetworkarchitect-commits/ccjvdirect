# Build 37 Additions

## Exact Files Added
- runtime-services/treasury/runtime/hsm-signer-runtime.js
- runtime-services/queue/runtime/durable-recovery-runtime.js
- runtime-services/treasury/proving/prove-hsm-runtime.js
- docs/BUILD37-ADDITIONS.md

## Exact Files Modified
- runtime-services/package.json
- runtime-services/api/server.js
- runtime-services/websocket/runtime.js

## Executable Capability Added
- signer isolation runtime
- gas estimation runtime
- transaction reconciliation runtime
- durable queue recovery runtime
- HSM proving runtime
- treasury isolation API
- queue recovery API

## Regression Verification
Preserved:
- DAG persistence runtime
- replay determinism runtime
- orchestration runtime
- websocket federation
- observability federation
- treasury execution runtime
- Avalanche continuity runtime
- federation synchronization
- operational memory runtime
- proving runtimes
- persistence continuity

## Remaining Gaps
- full external HSM integration pending
- distributed multi-node reconciliation incomplete
