module.exports = {
  apps: [{
    name: 'ccjv-runtime',
    script: './runtime-services/api/server.js',
    instances: 2,
    exec_mode: 'cluster'
  }]
};
