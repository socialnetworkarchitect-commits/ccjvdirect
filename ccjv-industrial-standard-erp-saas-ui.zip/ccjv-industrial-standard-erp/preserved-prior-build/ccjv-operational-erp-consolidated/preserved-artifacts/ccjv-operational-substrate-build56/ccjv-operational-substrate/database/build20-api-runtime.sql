CREATE TABLE IF NOT EXISTS institutional_runtime.runtime_services (
    id BIGSERIAL PRIMARY KEY,
    service_id UUID NOT NULL,
    service_key VARCHAR(191) NOT NULL UNIQUE,
    service_name VARCHAR(255),
    service_url VARCHAR(500),
    capability_class VARCHAR(50),
    service_status VARCHAR(50),
    metadata JSONB,
    registered_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS institutional_runtime.api_events (
    id BIGSERIAL PRIMARY KEY,
    event_id UUID NOT NULL,
    correlation_id UUID,
    causality_id UUID,
    replay_id UUID,
    tenant_id VARCHAR(64),
    workspace_id VARCHAR(64),
    event_type VARCHAR(255),
    payload JSONB,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS institutional_runtime.api_replay_records (
    id BIGSERIAL PRIMARY KEY,
    replay_id UUID NOT NULL,
    correlation_id UUID,
    tenant_id VARCHAR(64),
    workspace_id VARCHAR(64),
    replay_state VARCHAR(50),
    payload JSONB,
    created_at TIMESTAMPTZ DEFAULT NOW()
);
