CREATE TABLE IF NOT EXISTS institutional_runtime.event_lineage (
    id BIGSERIAL PRIMARY KEY,
    correlation_id UUID,
    causality_id UUID,
    replay_id UUID,
    treasury_id UUID,
    vault_id UUID,
    proof_id UUID,
    lineage_payload JSONB,
    created_at TIMESTAMPTZ DEFAULT NOW()
);
