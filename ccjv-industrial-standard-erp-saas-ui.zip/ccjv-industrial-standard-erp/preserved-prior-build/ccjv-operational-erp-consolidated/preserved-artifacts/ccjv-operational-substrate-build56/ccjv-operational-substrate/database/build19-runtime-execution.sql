CREATE TABLE IF NOT EXISTS institutional_runtime.orchestration_executions (
    id BIGSERIAL PRIMARY KEY,
    execution_id UUID,
    correlation_id UUID,
    causality_id UUID,
    replay_id UUID,
    execution_type VARCHAR(255),
    execution_state VARCHAR(50),
    execution_payload JSONB,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS institutional_runtime.runtime_dependency_edges (
    id BIGSERIAL PRIMARY KEY,
    source_runtime VARCHAR(255),
    target_runtime VARCHAR(255),
    dependency_state VARCHAR(50),
    reconciled_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS institutional_runtime.deterministic_replay_proofs (
    id BIGSERIAL PRIMARY KEY,
    replay_id UUID,
    replay_signature TEXT,
    deterministic BOOLEAN DEFAULT FALSE,
    verified_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS institutional_runtime.operational_memory (
    id BIGSERIAL PRIMARY KEY,
    memory_id UUID,
    tenant_id VARCHAR(64),
    workspace_id VARCHAR(64),
    lineage_payload JSONB,
    hydrated_at TIMESTAMPTZ DEFAULT NOW()
);
