CREATE TABLE IF NOT EXISTS institutional_runtime.federation_heartbeats (
    id BIGSERIAL PRIMARY KEY,
    erp_name VARCHAR(255),
    heartbeat_status VARCHAR(50),
    capabilities JSONB,
    synchronized_at TIMESTAMPTZ DEFAULT NOW()
);
