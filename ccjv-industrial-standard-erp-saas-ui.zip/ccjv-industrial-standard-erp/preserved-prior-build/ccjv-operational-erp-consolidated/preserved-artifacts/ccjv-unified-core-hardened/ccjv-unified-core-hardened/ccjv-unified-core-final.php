<?php
/*
Plugin Name: CCJV Unified Core Hardened
Description: Hardened CCJV unified core with flagship shell, confirmed-payment activation, Avalanche event sync, live token balance reads, vault anchoring, reconciliation screens, and server-side signature re-derivation workflow.
Version: 1.2.0
Author: OpenAI
*/
if (!defined('ABSPATH')) exit;
define('CCJVU_VER', '1.2.0');
define('CCJVU_PATH', plugin_dir_path(__FILE__));
define('CCJVU_URL', plugin_dir_url(__FILE__));
require_once CCJVU_PATH . 'includes/helpers.php';
require_once CCJVU_PATH . 'includes/db.php';
require_once CCJVU_PATH . 'includes/admin.php';
require_once CCJVU_PATH . 'includes/frontend.php';
require_once CCJVU_PATH . 'includes/rest.php';
register_activation_hook(__FILE__, ['CCJVU_DB', 'activate']);
register_activation_hook(__FILE__, ['CCJVU_DB', 'seed']);
register_activation_hook(__FILE__, ['CCJVU_DB', 'schedule']);
register_deactivation_hook(__FILE__, ['CCJVU_DB', 'unschedule']);
add_action('ccjvu_hardened_sync', ['CCJVU_DB','run_scheduled_sync']);
add_action('plugins_loaded', function () {
    new CCJVU_Admin();
    new CCJVU_Frontend();
    new CCJVU_REST();
});
