#!/usr/bin/env python3
import sys, json
P = 0xFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFEFFFFFC2F
N = 0xFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFEBAAEDCE6AF48A03BBFD25E8CD0364141
GX = 55066263022277343669578718895168534326250603453777594175500187360389116729240
GY = 32670510020758816978083085130507043184471273380659243275938904335757337482424

def inv(a, n=P):
    return pow(a, -1, n)

def sqrt_mod(a):
    return pow(a, (P + 1) // 4, P)

def is_inf(pt):
    return pt is None

def point_add(p, q):
    if p is None: return q
    if q is None: return p
    x1,y1 = p; x2,y2 = q
    if x1 == x2 and (y1 + y2) % P == 0:
        return None
    if p == q:
        l = (3 * x1 * x1) * inv(2 * y1 % P, P) % P
    else:
        l = (y2 - y1) * inv((x2 - x1) % P, P) % P
    x3 = (l*l - x1 - x2) % P
    y3 = (l*(x1 - x3) - y1) % P
    return (x3,y3)

def point_mul(k, pt):
    k %= N
    result = None
    addend = pt
    while k:
        if k & 1:
            result = point_add(result, addend)
        addend = point_add(addend, addend)
        k >>= 1
    return result

def recover(msg_hash_hex, sig_hex):
    sig = bytes.fromhex(sig_hex[2:] if sig_hex.startswith('0x') else sig_hex)
    if len(sig) != 65:
        raise ValueError('Signature must be 65 bytes')
    r = int.from_bytes(sig[0:32], 'big')
    s = int.from_bytes(sig[32:64], 'big')
    v = sig[64]
    recid = v - 27 if v >= 27 else v
    if recid < 0 or recid > 3:
        raise ValueError('Bad recovery id')
    e = int((msg_hash_hex[2:] if msg_hash_hex.startswith('0x') else msg_hash_hex), 16)
    x = r + (recid // 2) * N
    if x >= P:
        raise ValueError('x out of range')
    alpha = (pow(x, 3, P) + 7) % P
    beta = sqrt_mod(alpha)
    y = beta if (beta % 2) == (recid % 2) else P - beta
    R = (x, y)
    if point_mul(N, R) is not None:
        raise ValueError('nR != infinity')
    r_inv = inv(r, N)
    e_neg = (-e) % N
    Q = point_mul(r_inv, point_add(point_mul(s, R), point_mul(e_neg, (GX, GY))))
    if Q is None:
        raise ValueError('Recovery failed')
    pub = ('%064x%064x' % (Q[0], Q[1]))
    return {'ok': True, 'recovery_id': recid, 'public_key_hex': pub}

def main():
    try:
        msg_hash_hex = sys.argv[1]
        sig_hex = sys.argv[2]
        print(json.dumps(recover(msg_hash_hex, sig_hex)))
    except Exception as e:
        print(json.dumps({'ok': False, 'error': str(e)}))
        sys.exit(1)
if __name__ == '__main__':
    main()
