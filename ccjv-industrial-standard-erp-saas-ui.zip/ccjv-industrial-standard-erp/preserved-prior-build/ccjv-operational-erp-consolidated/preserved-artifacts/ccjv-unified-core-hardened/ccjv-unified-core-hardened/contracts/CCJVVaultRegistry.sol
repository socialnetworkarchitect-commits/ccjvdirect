// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;
contract CCJVVaultRegistry {
    event FileAnchored(bytes32 indexed fileHash, bytes32 indexed fileIdHash, bytes32 indexed workspaceHash, bytes32 metadataHash, address anchoredBy, uint256 anchoredAt);
    mapping(bytes32 => bool) public anchored;
    function anchor(bytes32 fileHash, bytes32 fileIdHash, bytes32 workspaceHash, bytes32 metadataHash) external {
        anchored[fileHash] = true;
        emit FileAnchored(fileHash, fileIdHash, workspaceHash, metadataHash, msg.sender, block.timestamp);
    }
}
