// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;
contract CCJVTreasuryEngine {
    event ModulePaid(address indexed payer, bytes32 indexed workspaceKey, bytes32 indexed moduleKey, address token, uint256 amount, uint256 periods);
    function payModule(bytes32 workspaceKey, bytes32 moduleKey, address token, uint256 amount, uint256 periods) external {
        emit ModulePaid(msg.sender, workspaceKey, moduleKey, token, amount, periods);
    }
}
