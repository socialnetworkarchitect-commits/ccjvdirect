<?php
if (!defined('ABSPATH')) exit;
class CCJVU_REST {
  public function __construct() { add_action('rest_api_init', [$this,'routes']); }
  public function routes() {
    register_rest_route('ccjvu/v1', '/challenge', ['methods'=>'POST','callback'=>[$this,'challenge'],'permission_callback'=>function(){ return is_user_logged_in(); }]);
    register_rest_route('ccjvu/v1', '/verify-wallet', ['methods'=>'POST','callback'=>[$this,'verify_wallet'],'permission_callback'=>function(){ return is_user_logged_in(); }]);
    register_rest_route('ccjvu/v1', '/workspace-balance', ['methods'=>'GET','callback'=>[$this,'workspace_balance'],'permission_callback'=>function(){ return is_user_logged_in(); }]);
    register_rest_route('ccjvu/v1', '/sync-balances', ['methods'=>'POST','callback'=>[$this,'sync_balances'],'permission_callback'=>function(){ return is_user_logged_in(); }]);
    register_rest_route('ccjvu/v1', '/start-venture', ['methods'=>'POST','callback'=>[$this,'start_venture'],'permission_callback'=>function(){ return is_user_logged_in(); }]);
    register_rest_route('ccjvu/v1', '/activate-module', ['methods'=>'POST','callback'=>[$this,'activate_module'],'permission_callback'=>function(){ return is_user_logged_in(); }]);
    register_rest_route('ccjvu/v1', '/sync-payment', ['methods'=>'POST','callback'=>[$this,'sync_payment'],'permission_callback'=>function(){ return is_user_logged_in(); }]);
    register_rest_route('ccjvu/v1', '/vault-upload', ['methods'=>'POST','callback'=>[$this,'vault_upload'],'permission_callback'=>function(){ return is_user_logged_in(); }]);
    register_rest_route('ccjvu/v1', '/vault-anchor', ['methods'=>'POST','callback'=>[$this,'vault_anchor'],'permission_callback'=>function(){ return is_user_logged_in(); }]);
    register_rest_route('ccjvu/v1', '/sync-vault', ['methods'=>'POST','callback'=>[$this,'sync_vault'],'permission_callback'=>function(){ return is_user_logged_in(); }]);
  }
  public function challenge(WP_REST_Request $r) {
    global $wpdb; $t = ccjvu_tables(); $wallet = sanitize_text_field($r->get_param('wallet')); $nonce = wp_generate_password(24, false, false); $msg = 'CCJV wallet verification nonce: ' . $nonce; $wpdb->insert($t['wallet_challenges'], ['user_id'=>get_current_user_id(),'wallet_address'=>$wallet,'nonce'=>$nonce,'message'=>$msg,'verified'=>0,'expires_at'=>date('Y-m-d H:i:s', strtotime('+15 minutes', current_time('timestamp')))]); return ['success'=>true,'message'=>$msg,'nonce'=>$nonce,'wallet'=>$wallet];
  }
  public function verify_wallet(WP_REST_Request $r) {
    global $wpdb; $t = ccjvu_tables(); $user_id = get_current_user_id(); $wallet = strtolower(sanitize_text_field($r->get_param('wallet'))); $message = sanitize_text_field($r->get_param('message')); $signature = sanitize_text_field($r->get_param('signature')); $challenge = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$t['wallet_challenges']} WHERE user_id=%d AND wallet_address=%s ORDER BY id DESC LIMIT 1", $user_id, $wallet), ARRAY_A); if (!$challenge || strtotime($challenge['expires_at']) < current_time('timestamp') || $challenge['message'] !== $message) return new WP_Error('invalid_nonce', 'Wallet challenge mismatch', ['status'=>400]);
    $verify = ccjvu_verify_signature_server_side($wallet, $message, $signature);
    if (is_wp_error($verify)) return new WP_Error('verify_failed', $verify->get_error_message(), ['status'=>400]);
    if (empty($verify['wallet_match'])) return new WP_Error('verify_failed', 'Recovered wallet does not match signer', ['status'=>400]);
    $wpdb->insert($t['wallets'], ['user_id'=>$user_id,'wallet_address'=>$wallet,'chain_id'=>sanitize_text_field($r->get_param('chain_id')),'signature_message'=>$message,'signature_value'=>$signature,'nonce'=>$challenge['nonce'],'verified_at'=>current_time('mysql'),'verified_mode'=>$verify['mode'],'message_hash'=>$verify['message_hash'],'public_key_hex'=>$verify['public_key_hex'],'created_at'=>current_time('mysql')]);
    $wpdb->update($t['wallet_challenges'], ['verified'=>1], ['id'=>$challenge['id']]);
    $balances = ccjvu_sync_live_balances_for_user($user_id);
    ccjvu_audit('wallet_verified','wallet',['wallet'=>$wallet,'mode'=>$verify['mode'],'derived_wallet'=>$verify['derived_wallet']]);
    return ['success'=>true,'verified'=>true,'wallet'=>$wallet,'mode'=>$verify['mode'],'derived_wallet'=>$verify['derived_wallet'],'balances'=>$balances];
  }
  public function workspace_balance(WP_REST_Request $r) {
    $workspace = ccjvu_get_workspace(sanitize_key($r->get_param('workspace')));
    if (!$workspace) return new WP_Error('not_found', 'Workspace not found', ['status'=>404]);
    $wallet = ccjvu_user_wallet(get_current_user_id()); if (!$wallet) return new WP_Error('wallet_missing','Connect wallet first',['status'=>400]);
    $raw = ccjvu_get_live_token_balance_raw($wallet['wallet_address'], $workspace['token_contract']);
    return ['success'=>true,'workspace'=>$workspace['slug'],'symbol'=>$workspace['token_symbol'],'balance_raw'=>$raw,'balance'=>ccjvu_format_token_balance($raw, (int)$workspace['token_decimals']),'gate_amount'=>$workspace['gate_amount']];
  }
  public function sync_balances(WP_REST_Request $r) {
    $balances = ccjvu_sync_live_balances_for_user(get_current_user_id());
    return ['success'=>true,'balances'=>$balances];
  }
  public function start_venture(WP_REST_Request $r) { global $wpdb; $t=ccjvu_tables(); $name=sanitize_text_field($r->get_param('name')); $slug=sanitize_title($r->get_param('slug')); $summary=sanitize_text_field($r->get_param('summary')); if (!$name || !$slug) return new WP_Error('missing','Name and slug required',['status'=>400]); $wpdb->insert($t['ventures'], ['name'=>$name,'slug'=>$slug,'summary'=>$summary,'created_by'=>get_current_user_id()]); ccjvu_audit('venture_created','venture',['name'=>$name,'slug'=>$slug]); return ['success'=>true,'id'=>$wpdb->insert_id]; }
  public function activate_module(WP_REST_Request $r) {
    global $wpdb; $t=ccjvu_tables(); $user_id=get_current_user_id(); $workspace_id=intval($r->get_param('workspace_id')); $module_id=intval($r->get_param('module_id')); $tx=sanitize_text_field($r->get_param('tx_hash')); $workspace=$wpdb->get_row($wpdb->prepare("SELECT * FROM {$t['workspaces']} WHERE id=%d",$workspace_id),ARRAY_A); $module=$wpdb->get_row($wpdb->prepare("SELECT * FROM {$t['modules']} WHERE id=%d",$module_id),ARRAY_A); if(!$workspace || !$module) return new WP_Error('missing','Workspace or module not found',['status'=>404]); $wallet=ccjvu_user_wallet($user_id); if(!$wallet) return new WP_Error('wallet_missing','Connect wallet first',['status'=>400]);
    $gate = ccjvu_can_access_workspace($user_id, $workspace); if (!$gate['allowed']) return new WP_Error('gate','Workspace token gate not met',['status'=>403]);
    $amount = (string)$module['monthly_fee']; $amount_raw = ccjvu_decimal_to_int_string($amount, 18);
    $wpdb->insert($t['payments'], ['user_id'=>$user_id,'workspace_id'=>$workspace_id,'module_id'=>$module_id,'wallet_address'=>$wallet['wallet_address'],'token_symbol'=>$module['fee_token_symbol'] ?: $workspace['token_symbol'],'token_contract'=>$workspace['token_contract'],'amount'=>$amount,'amount_raw'=>$amount_raw,'tx_hash'=>$tx,'status'=>'submitted','paid_for_months'=>1,'created_at'=>current_time('mysql')]);
    $payment_id = $wpdb->insert_id;
    $sync = self::sync_payment_record($wpdb->get_row($wpdb->prepare("SELECT * FROM {$t['payments']} WHERE id=%d", $payment_id), ARRAY_A));
    return ['success'=>true,'payment_id'=>$payment_id,'status'=>$sync['status'],'message'=>$sync['message'] ?? 'Payment submitted for confirmation'];
  }
  public static function sync_payment_record($payment) {
    global $wpdb; $t = ccjvu_tables();
    if (empty($payment['tx_hash'])) return ['status'=>'pending','message'=>'Missing tx hash'];
    $receipt = ccjvu_tx_receipt($payment['tx_hash']);
    if (is_wp_error($receipt) || empty($receipt)) return ['status'=>'pending','message'=>'Receipt not found yet'];
    if (!ccjvu_tx_status_success($receipt)) {
      $wpdb->update($t['payments'], ['status'=>'failed','receipt_json'=>wp_json_encode($receipt),'failure_reason'=>'Transaction failed'], ['id'=>$payment['id']]);
      return ['status'=>'failed','message'=>'Transaction failed'];
    }
    $match = ccjvu_find_payment_log($receipt, $payment);
    if (empty($match['matched'])) {
      $wpdb->update($t['payments'], ['status'=>'pending','receipt_json'=>wp_json_encode($receipt),'block_number'=>hexdec($receipt['blockNumber'] ?? '0x0'),'failure_reason'=>'Receipt found but payment log did not match treasury rules'], ['id'=>$payment['id']]);
      return ['status'=>'pending','message'=>'Receipt found but payment event not matched'];
    }
    $wpdb->update($t['payments'], ['status'=>'confirmed','receipt_json'=>wp_json_encode($receipt),'block_number'=>hexdec($receipt['blockNumber'] ?? '0x0'),'confirmed_at'=>current_time('mysql'),'failure_reason'=>''], ['id'=>$payment['id']]);
    $sub = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$t['subscriptions']} WHERE payment_tx_hash=%s ORDER BY id DESC LIMIT 1", $payment['tx_hash']), ARRAY_A);
    $active_until = date('Y-m-d H:i:s', strtotime('+1 month', current_time('timestamp')));
    if ($sub) {
      $wpdb->update($t['subscriptions'], ['status'=>'active','started_at'=>current_time('mysql'),'active_until'=>$active_until], ['id'=>$sub['id']]);
    } else {
      $wpdb->insert($t['subscriptions'], ['user_id'=>$payment['user_id'],'workspace_id'=>$payment['workspace_id'],'module_id'=>$payment['module_id'],'wallet_address'=>$payment['wallet_address'],'fee_token_symbol'=>$payment['token_symbol'],'monthly_fee'=>$payment['amount'],'status'=>'active','started_at'=>current_time('mysql'),'active_until'=>$active_until,'payment_tx_hash'=>$payment['tx_hash'],'created_at'=>current_time('mysql')]);
    }
    ccjvu_audit('payment_confirmed','payment',['payment_id'=>$payment['id'],'tx_hash'=>$payment['tx_hash'],'mode'=>$match['mode'] ?? 'unknown']);
    return ['status'=>'confirmed','message'=>'Payment confirmed and module activated','active_until'=>$active_until];
  }
  public function sync_payment(WP_REST_Request $r) {
    global $wpdb; $t = ccjvu_tables(); $payment_id = intval($r->get_param('payment_id')); $payment = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$t['payments']} WHERE id=%d", $payment_id), ARRAY_A); if (!$payment) return new WP_Error('not_found','Payment not found',['status'=>404]); return self::sync_payment_record($payment);
  }
  public function vault_upload(WP_REST_Request $r) {
    global $wpdb; $t=ccjvu_tables(); if (empty($_FILES['file'])) return new WP_Error('missing_file','No file uploaded',['status'=>400]); $file = $_FILES['file']; if ($file['error'] !== UPLOAD_ERR_OK) return new WP_Error('upload_error','Upload failed',['status'=>400]); $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION)); if (!in_array($ext, ccjvu_allowed_exts(), true)) return new WP_Error('forbidden_ext','File type not allowed',['status'=>400]); $workspace = sanitize_key($r->get_param('workspace') ?: 'core'); $entity_type = sanitize_key($r->get_param('entity_type') ?: 'general'); $entity_id = sanitize_text_field($r->get_param('entity_id') ?: '0'); $group = sanitize_key($r->get_param('file_group') ?: 'general'); $folder = ccjvu_storage_path($workspace, $entity_type, $entity_id, $group); $stored = wp_unique_filename($folder, sanitize_file_name($file['name'])); $target = trailingslashit($folder) . $stored; if (!move_uploaded_file($file['tmp_name'], $target)) return new WP_Error('move_failed','Could not store file',['status'=>500]); $hashes = ccjvu_hash_file($target); $root = untrailingslashit(ccjvu_option('vault_root')); $relative = ltrim(str_replace($root, '', $target), DIRECTORY_SEPARATOR); $wallet = ccjvu_user_wallet(get_current_user_id()); $file_id_hash = hash('sha256', $workspace.'|'.$entity_type.'|'.$entity_id.'|'.$stored.'|'.$hashes['sha256']); $metadata_hash = hash('sha256', wp_json_encode(['workspace'=>$workspace,'entity_type'=>$entity_type,'entity_id'=>$entity_id,'group'=>$group,'file'=>$file['name']]));
    $wpdb->insert($t['vault'], ['workspace_slug'=>$workspace,'module_slug'=>'vault','entity_type'=>$entity_type,'entity_id'=>$entity_id,'file_group'=>$group,'original_filename'=>$file['name'],'stored_filename'=>$stored,'mime_type'=>$file['type'],'file_ext'=>$ext,'file_size'=>filesize($target),'relative_path'=>$relative,'sha256_hash'=>$hashes['sha256'],'sha3_hash'=>$hashes['sha3'],'file_id_hash'=>$file_id_hash,'metadata_hash'=>$metadata_hash,'wallet_address'=>$wallet['wallet_address'] ?? '','created_by'=>get_current_user_id(),'created_at'=>current_time('mysql')]); ccjvu_audit('vault_upload','vault',['file'=>$file['name'],'workspace'=>$workspace,'entity_type'=>$entity_type,'entity_id'=>$entity_id]); return ['success'=>true,'id'=>$wpdb->insert_id,'sha256'=>$hashes['sha256'],'sha3'=>$hashes['sha3'],'file_id_hash'=>$file_id_hash,'metadata_hash'=>$metadata_hash,'vault_contract'=>ccjvu_option('vault_contract')];
  }
  public function vault_anchor(WP_REST_Request $r) {
    global $wpdb; $t = ccjvu_tables(); $id=intval($r->get_param('id')); $tx=sanitize_text_field($r->get_param('tx_hash')); $wallet=sanitize_text_field($r->get_param('wallet_address')); if(!$id || !$tx) return new WP_Error('missing','id and tx_hash required',['status'=>400]); $wpdb->update($t['vault'], ['tx_hash'=>$tx,'tx_status'=>'submitted','wallet_address'=>$wallet], ['id'=>$id]); $row = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$t['vault']} WHERE id=%d", $id), ARRAY_A); $sync = self::sync_vault_record($row); return ['success'=>true,'id'=>$id,'tx_hash'=>$tx,'status'=>$sync['status'],'message'=>$sync['message'] ?? 'Anchor submitted'];
  }
  public static function sync_vault_record($row) {
    global $wpdb; $t = ccjvu_tables(); if (!$row || empty($row['tx_hash'])) return ['status'=>'pending','message'=>'Missing vault tx hash'];
    $receipt = ccjvu_tx_receipt($row['tx_hash']);
    if (is_wp_error($receipt) || empty($receipt)) return ['status'=>'pending','message'=>'Vault receipt not found yet'];
    if (!ccjvu_tx_status_success($receipt)) {
      $wpdb->update($t['vault'], ['tx_status'=>'failed','anchor_receipt_json'=>wp_json_encode($receipt)], ['id'=>$row['id']]);
      return ['status'=>'failed','message'=>'Vault transaction failed'];
    }
    $match = ccjvu_find_vault_log($receipt, $row);
    if (empty($match['matched'])) {
      $wpdb->update($t['vault'], ['tx_status'=>'pending','anchor_receipt_json'=>wp_json_encode($receipt)], ['id'=>$row['id']]);
      return ['status'=>'pending','message'=>'Vault receipt found but anchor event not matched'];
    }
    $wpdb->update($t['vault'], ['tx_status'=>'anchored','anchor_receipt_json'=>wp_json_encode($receipt),'anchored_at'=>current_time('mysql')], ['id'=>$row['id']]);
    ccjvu_audit('vault_confirmed','vault',['id'=>$row['id'],'tx_hash'=>$row['tx_hash']]);
    return ['status'=>'anchored','message'=>'Vault anchor confirmed'];
  }
  public function sync_vault(WP_REST_Request $r) {
    global $wpdb; $t = ccjvu_tables(); $id = intval($r->get_param('id')); $row = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$t['vault']} WHERE id=%d", $id), ARRAY_A); if (!$row) return new WP_Error('not_found','Vault record not found',['status'=>404]); return self::sync_vault_record($row);
  }
}
