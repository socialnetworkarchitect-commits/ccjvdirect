<?php
if (!defined('ABSPATH')) exit;
function ccjvu_tables() {
    global $wpdb;
    return [
        'workspaces' => $wpdb->prefix . 'ccjvu_workspaces',
        'modules' => $wpdb->prefix . 'ccjvu_modules',
        'ventures' => $wpdb->prefix . 'ccjvu_ventures',
        'venture_workspaces' => $wpdb->prefix . 'ccjvu_venture_workspaces',
        'wallets' => $wpdb->prefix . 'ccjvu_wallets',
        'subscriptions' => $wpdb->prefix . 'ccjvu_subscriptions',
        'payments' => $wpdb->prefix . 'ccjvu_payments',
        'vault' => $wpdb->prefix . 'ccjvu_vault_files',
        'access_overrides' => $wpdb->prefix . 'ccjvu_access_overrides',
        'sector_plugins' => $wpdb->prefix . 'ccjvu_sector_plugins',
        'audit' => $wpdb->prefix . 'ccjvu_audit',
        'wallet_challenges' => $wpdb->prefix . 'ccjvu_wallet_challenges',
        'sync_runs' => $wpdb->prefix . 'ccjvu_sync_runs',
    ];
}
function ccjvu_default_settings() {
    return [
        'site_logo_url' => 'http://ccjv.ca/wp-content/uploads/2024/04/ccjv-logo.jpeg',
        'header_bg' => 'linear-gradient(135deg,#0f172a,#111827)',
        'header_bg_image' => '',
        'hero_bg_image' => '',
        'footer_bg' => 'linear-gradient(135deg,#0f172a,#020617)',
        'footer_bg_image' => '',
        'buy_direct_label' => 'Buy Direct',
        'buy_direct_url' => 'https://xmarkets.ca',
        'hero_title' => 'Start a JV. Join a JV. Operate. Scale.',
        'hero_text' => 'CCJV is the front door. Use 1 CJV token to access the core ERP, then 1 CJV token/month per core element. Each sector ERP has its own token gate and 1 token/month per element.',
        'wallet_connect_label' => 'Connect MetaMask',
        'avalanche_chain_id' => '0xa86a',
        'avalanche_chain_name' => 'Avalanche C-Chain',
        'avalanche_rpc_url' => 'https://api.avax.network/ext/bc/C/rpc',
        'avalanche_explorer_url' => 'https://snowtrace.io',
        'treasury_contract' => '',
        'vault_contract' => '',
        'verifier_contract' => '',
        'treasury_wallet' => '',
        'treasury_payment_topic0' => '',
        'vault_anchor_topic0' => '',
        'vault_root' => '',
        'vault_public_downloads' => 0,
        'vault_allowed_extensions' => 'pdf,doc,docx,xls,xlsx,csv,jpg,jpeg,png,webp,mp4,mp3,txt,zip',
        'vault_max_upload_mb' => 64,
        'sync_batch_size' => 20,
    ];
}
function ccjvu_settings() {
    $opt = get_option('ccjvu_settings', []);
    $defaults = ccjvu_default_settings();
    if (empty($opt['vault_root'])) {
        $upload = wp_upload_dir();
        $defaults['vault_root'] = trailingslashit($upload['basedir']) . 'ccjv-unified-vault';
    }
    return wp_parse_args($opt, $defaults);
}
function ccjvu_option($key, $default = '') { $s = ccjvu_settings(); return isset($s[$key]) ? $s[$key] : $default; }
function ccjvu_allowed_exts() { return array_values(array_filter(array_map('trim', explode(',', strtolower(ccjvu_option('vault_allowed_extensions')))))); }
function ccjvu_get_workspaces($active_only = true) {
    global $wpdb; $t = ccjvu_tables();
    $sql = "SELECT * FROM {$t['workspaces']}" . ($active_only ? " WHERE active=1" : '') . " ORDER BY sort_order ASC, name ASC";
    $rows = $wpdb->get_results($sql, ARRAY_A);
    $registered = apply_filters('ccjvu_registered_sector_plugins', []);
    if ($registered) foreach ($registered as $reg) { $exists=false; foreach($rows as $row) if($row['slug']===$reg['slug']) $exists=true; if(!$exists) $rows[]=$reg; }
    return $rows;
}
function ccjvu_get_workspace($slug) { foreach (ccjvu_get_workspaces(false) as $w) if ($w['slug'] === $slug) return $w; return null; }
function ccjvu_get_modules($workspace_id) { global $wpdb; $t = ccjvu_tables(); return $wpdb->get_results($wpdb->prepare("SELECT * FROM {$t['modules']} WHERE workspace_id=%d AND active=1 ORDER BY sort_order ASC, name ASC", $workspace_id), ARRAY_A); }
function ccjvu_user_wallet($user_id) { global $wpdb; $t = ccjvu_tables(); return $wpdb->get_row($wpdb->prepare("SELECT * FROM {$t['wallets']} WHERE user_id=%d ORDER BY id DESC LIMIT 1", $user_id), ARRAY_A); }
function ccjvu_storage_path($workspace_slug, $entity_type, $entity_id, $group = 'general') {
    $root = untrailingslashit(ccjvu_option('vault_root'));
    $parts = [$root, sanitize_key($workspace_slug ?: 'core'), sanitize_key($entity_type ?: 'general'), sanitize_file_name((string)($entity_id ?: '0')), sanitize_key($group ?: 'general')];
    $path = join(DIRECTORY_SEPARATOR, $parts); if (!file_exists($path)) wp_mkdir_p($path); return $path;
}
function ccjvu_hash_file($filepath) {
    $sha3 = in_array('sha3-256', hash_algos(), true) ? hash_file('sha3-256', $filepath) : hash_file('sha256', $filepath);
    return ['sha256' => hash_file('sha256', $filepath), 'sha3' => $sha3];
}
function ccjvu_audit($action, $context = '', $payload = null, $user_id = 0) { global $wpdb; $t = ccjvu_tables(); $wpdb->insert($t['audit'], ['user_id' => $user_id ?: get_current_user_id(), 'action' => sanitize_text_field($action), 'context' => sanitize_text_field($context), 'payload' => $payload ? wp_json_encode($payload) : null, 'created_at' => current_time('mysql')]); }
function ccjvu_rpc_call($method, $params = []) {
    $body = wp_json_encode(['jsonrpc'=>'2.0','id'=>1,'method'=>$method,'params'=>$params]);
    $res = wp_remote_post(ccjvu_option('avalanche_rpc_url'), ['headers'=>['Content-Type'=>'application/json'],'body'=>$body,'timeout'=>25]);
    if (is_wp_error($res)) return $res;
    $json = json_decode(wp_remote_retrieve_body($res), true);
    if (isset($json['error'])) return new WP_Error('rpc_error', $json['error']['message'] ?? 'RPC error');
    return $json['result'] ?? null;
}
function ccjvu_hex_pad_32($hex) {
    $hex = strtolower(ltrim((string)$hex, '0x'));
    return str_pad($hex, 64, '0', STR_PAD_LEFT);
}
function ccjvu_topic_address($address) {
    return '0x' . str_pad(strtolower(ltrim($address, '0x')), 64, '0', STR_PAD_LEFT);
}
function ccjvu_transfer_topic() { return '0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55aeb'; }
function ccjvu_decimal_to_int_string($amount, $decimals = 18) {
    $amount = trim((string)$amount);
    if ($amount === '') return '0';
    if (strpos($amount, '.') === false) return ltrim($amount . str_repeat('0', (int)$decimals), '0') ?: '0';
    list($whole, $frac) = explode('.', $amount, 2);
    $frac = substr(preg_replace('/\D/', '', $frac), 0, (int)$decimals);
    $frac = str_pad($frac, (int)$decimals, '0');
    $whole = preg_replace('/\D/', '', $whole);
    $num = ltrim($whole . $frac, '0');
    return $num === '' ? '0' : $num;
}
function ccjvu_hex_to_dec_string($hex) {
    $hex = strtolower(ltrim((string)$hex, '0x'));
    if ($hex === '') return '0';
    $dec = '0';
    foreach (str_split($hex) as $c) {
        $n = hexdec($c);
        $carry = $n;
        $out = '';
        for ($i = strlen($dec)-1; $i >= 0; $i--) {
            $tmp = ((int)$dec[$i]) * 16 + $carry;
            $out = ($tmp % 10) . $out;
            $carry = intdiv($tmp, 10);
        }
        while ($carry > 0) { $out = ($carry % 10) . $out; $carry = intdiv($carry, 10); }
        $dec = ltrim($out, '0'); if ($dec === '') $dec = '0';
    }
    return $dec;
}
function ccjvu_dec_cmp($a, $b) {
    $a = ltrim((string)$a, '0'); $b = ltrim((string)$b, '0');
    $a = $a === '' ? '0' : $a; $b = $b === '' ? '0' : $b;
    if (strlen($a) > strlen($b)) return 1;
    if (strlen($a) < strlen($b)) return -1;
    return strcmp($a, $b);
}
function ccjvu_abi_call_balance_of($wallet) {
    $selector = '70a08231';
    return '0x' . $selector . ccjvu_hex_pad_32($wallet);
}
function ccjvu_get_live_token_balance_raw($wallet_address, $token_contract) {
    if (!$wallet_address || !$token_contract) return '0';
    $call = ['to'=>$token_contract, 'data'=>ccjvu_abi_call_balance_of($wallet_address)];
    $result = ccjvu_rpc_call('eth_call', [$call, 'latest']);
    if (is_wp_error($result) || !$result) return '0';
    return ccjvu_hex_to_dec_string($result);
}
function ccjvu_format_token_balance($raw, $decimals = 18, $precision = 6) {
    $raw = preg_replace('/\D/', '', (string)$raw); if ($raw === '') return '0';
    if ($decimals <= 0) return $raw;
    if (strlen($raw) <= $decimals) $raw = str_pad($raw, $decimals+1, '0', STR_PAD_LEFT);
    $whole = substr($raw, 0, -$decimals);
    $frac = substr($raw, -$decimals);
    $frac = substr($frac, 0, $precision);
    $frac = rtrim($frac, '0');
    return $frac === '' ? ltrim($whole, '0') ?: '0' : (ltrim($whole, '0') ?: '0') . '.' . $frac;
}
function ccjvu_sync_live_balances_for_user($user_id) {
    global $wpdb; $t = ccjvu_tables(); $wallet = ccjvu_user_wallet($user_id); if (!$wallet || empty($wallet['wallet_address'])) return [];
    $balances = [];
    foreach (ccjvu_get_workspaces(true) as $w) {
        if (!empty($w['token_contract'])) {
            $raw = ccjvu_get_live_token_balance_raw($wallet['wallet_address'], $w['token_contract']);
            $balances[strtoupper($w['token_symbol'])] = ccjvu_format_token_balance($raw, (int)$w['token_decimals']);
            $balances[strtoupper($w['token_symbol']).'_RAW'] = $raw;
        }
    }
    if ($balances) $wpdb->update($t['wallets'], ['token_balances_json'=>wp_json_encode($balances)], ['id'=>$wallet['id']]);
    return $balances;
}
function ccjvu_can_access_workspace($user_id, $workspace) {
    if (!$user_id) return ['allowed' => false, 'reason' => 'login'];
    $wallet = ccjvu_user_wallet($user_id); if (!$wallet || empty($wallet['wallet_address'])) return ['allowed' => false, 'reason' => 'wallet'];
    $need_raw = ccjvu_decimal_to_int_string((string)$workspace['gate_amount'], (int)$workspace['token_decimals']);
    $have_raw = !empty($workspace['token_contract']) ? ccjvu_get_live_token_balance_raw($wallet['wallet_address'], $workspace['token_contract']) : '0';
    if (ccjvu_dec_cmp($have_raw, $need_raw) < 0) return ['allowed' => false, 'reason' => 'gate', 'required_raw'=>$need_raw, 'have_raw'=>$have_raw];
    return ['allowed' => true, 'reason' => 'ok', 'balance_raw' => $have_raw, 'balance' => ccjvu_format_token_balance($have_raw, (int)$workspace['token_decimals'])];
}
function ccjvu_user_can_module($user_id, $module, $workspace) {
    global $wpdb; $t = ccjvu_tables(); $gate = ccjvu_can_access_workspace($user_id, $workspace); if (!$gate['allowed']) return $gate;
    $override = $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$t['access_overrides']} WHERE user_id=%d AND workspace_id=%d AND module_id=%d AND status='active'", $user_id, $workspace['id'], $module['id']));
    if ($override) return ['allowed' => true, 'reason' => 'override'];
    $sub = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$t['subscriptions']} WHERE user_id=%d AND workspace_id=%d AND module_id=%d ORDER BY id DESC LIMIT 1", $user_id, $workspace['id'], $module['id']), ARRAY_A);
    if ($sub && $sub['status'] === 'active' && strtotime($sub['active_until']) >= current_time('timestamp')) return ['allowed' => true, 'reason' => 'active', 'active_until' => $sub['active_until']];
    return ['allowed' => false, 'reason' => 'subscription'];
}
function ccjvu_prefixed_message_hex($message) {
    $prefix = "Ethereum Signed Message:
" . strlen($message) . $message;
    return '0x' . bin2hex($prefix);
}
function ccjvu_run_sig_recover($msg_hash_hex, $signature_hex) {
    $script = CCJVU_PATH . 'tools/sig_recover.py';
    if (!file_exists($script)) return new WP_Error('missing_script', 'Signature recovery script missing');
    $cmd = escapeshellcmd(PHP_BINARY ? 'python3' : 'python3');
    $cmd = 'python3 ' . escapeshellarg($script) . ' ' . escapeshellarg($msg_hash_hex) . ' ' . escapeshellarg($signature_hex);
    $out = shell_exec($cmd);
    if (!$out) return new WP_Error('recover_failed', 'No recovery output');
    $json = json_decode($out, true);
    if (!$json || empty($json['ok'])) return new WP_Error('recover_failed', is_array($json) ? ($json['error'] ?? 'Recovery failed') : 'Recovery failed');
    return $json;
}
function ccjvu_verify_signature_server_side($wallet, $message, $signature) {
    $prefixed_hex = ccjvu_prefixed_message_hex($message);
    $msg_hash = ccjvu_rpc_call('web3_sha3', [$prefixed_hex]);
    if (is_wp_error($msg_hash) || empty($msg_hash)) return $msg_hash;
    $recovered = ccjvu_run_sig_recover($msg_hash, $signature);
    if (is_wp_error($recovered)) return $recovered;
    $pub_no_prefix = '0x' . ltrim($recovered['public_key_hex'], '0x');
    $pub_hash = ccjvu_rpc_call('web3_sha3', [$pub_no_prefix]);
    if (is_wp_error($pub_hash) || empty($pub_hash)) return $pub_hash;
    $derived = '0x' . substr(strtolower(ltrim($pub_hash, '0x')), -40);
    return [
        'message_hash' => $msg_hash,
        'recovery_id' => $recovered['recovery_id'],
        'public_key_hex' => $recovered['public_key_hex'],
        'derived_wallet' => strtolower($derived),
        'wallet_match' => strtolower($derived) === strtolower($wallet),
        'mode' => 'server_python_recover',
    ];
}
function ccjvu_tx_receipt($tx_hash) { return ccjvu_rpc_call('eth_getTransactionReceipt', [$tx_hash]); }
function ccjvu_tx_status_success($receipt) { return !empty($receipt['status']) && strtolower($receipt['status']) === '0x1'; }
function ccjvu_find_payment_log($receipt, $payment) {
    $treasury_contract = strtolower(ccjvu_option('treasury_contract'));
    $treasury_wallet = strtolower(ccjvu_option('treasury_wallet'));
    $topic0 = strtolower((string)ccjvu_option('treasury_payment_topic0'));
    $transfer0 = strtolower(ccjvu_transfer_topic());
    $payer_topic = ccjvu_topic_address($payment['wallet_address']);
    $to_topic_wallet = $treasury_wallet ? ccjvu_topic_address($treasury_wallet) : '';
    $to_topic_contract = $treasury_contract ? ccjvu_topic_address($treasury_contract) : '';
    $expected_raw = ccjvu_decimal_to_int_string((string)$payment['amount'], 18);
    foreach (($receipt['logs'] ?? []) as $log) {
        $addr = strtolower($log['address'] ?? '');
        $topics = array_map('strtolower', $log['topics'] ?? []);
        if ($topic0 && $treasury_contract && $addr === $treasury_contract && isset($topics[0]) && $topics[0] === $topic0) return ['matched'=>true,'log'=>$log,'mode'=>'custom_topic'];
        if (isset($topics[0]) && $topics[0] === $transfer0 && isset($topics[1]) && $topics[1] === strtolower($payer_topic) && isset($topics[2])) {
            $toOk = ($to_topic_wallet && strtolower($topics[2]) === strtolower($to_topic_wallet)) || ($to_topic_contract && strtolower($topics[2]) === strtolower($to_topic_contract));
            if ($toOk) {
                $amount_raw = ccjvu_hex_to_dec_string($log['data'] ?? '0x0');
                if (ccjvu_dec_cmp($amount_raw, $expected_raw) >= 0) return ['matched'=>true,'log'=>$log,'amount_raw'=>$amount_raw,'mode'=>'erc20_transfer'];
            }
        }
    }
    return ['matched'=>false];
}
function ccjvu_find_vault_log($receipt, $vault_record) {
    $vault_contract = strtolower(ccjvu_option('vault_contract'));
    $topic0 = strtolower((string)ccjvu_option('vault_anchor_topic0'));
    foreach (($receipt['logs'] ?? []) as $log) {
        $addr = strtolower($log['address'] ?? '');
        $topics = array_map('strtolower', $log['topics'] ?? []);
        if ($vault_contract && $addr !== $vault_contract) continue;
        if ($topic0 && isset($topics[0]) && $topics[0] !== $topic0) continue;
        return ['matched'=>true,'log'=>$log];
    }
    return ['matched'=>false];
}
