<?php
if (!defined('ABSPATH')) exit;
class CCJVU_DB {
  public static function activate() {
    global $wpdb; require_once ABSPATH . 'wp-admin/includes/upgrade.php';
    $t = ccjvu_tables(); $c = $wpdb->get_charset_collate();
    dbDelta("CREATE TABLE {$t['workspaces']} (id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,name VARCHAR(120) NOT NULL,slug VARCHAR(120) NOT NULL,token_symbol VARCHAR(20) NOT NULL,token_contract VARCHAR(80) DEFAULT '',token_decimals INT DEFAULT 18,gate_amount DECIMAL(24,8) DEFAULT 1,accent_color VARCHAR(20) DEFAULT '#2563eb',skin VARCHAR(60) DEFAULT 'default',hero_title VARCHAR(255) DEFAULT '',hero_text TEXT,buy_url VARCHAR(255) DEFAULT '',is_core TINYINT(1) DEFAULT 0,active TINYINT(1) DEFAULT 1,sort_order INT DEFAULT 0,created_at DATETIME DEFAULT CURRENT_TIMESTAMP,PRIMARY KEY (id), UNIQUE KEY slug (slug)) $c;");
    dbDelta("CREATE TABLE {$t['modules']} (id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,workspace_id BIGINT UNSIGNED NOT NULL,name VARCHAR(120) NOT NULL,slug VARCHAR(120) NOT NULL,monthly_fee DECIMAL(24,8) DEFAULT 1,fee_token_symbol VARCHAR(20) DEFAULT '',allowed_roles VARCHAR(255) DEFAULT '',summary TEXT,active TINYINT(1) DEFAULT 1,sort_order INT DEFAULT 0,created_at DATETIME DEFAULT CURRENT_TIMESTAMP,PRIMARY KEY (id), KEY workspace_id (workspace_id)) $c;");
    dbDelta("CREATE TABLE {$t['ventures']} (id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,name VARCHAR(190) NOT NULL,slug VARCHAR(190) NOT NULL,summary TEXT,created_by BIGINT UNSIGNED DEFAULT 0,created_at DATETIME DEFAULT CURRENT_TIMESTAMP,PRIMARY KEY (id), UNIQUE KEY slug (slug)) $c;");
    dbDelta("CREATE TABLE {$t['venture_workspaces']} (id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,venture_id BIGINT UNSIGNED NOT NULL,workspace_id BIGINT UNSIGNED NOT NULL,PRIMARY KEY (id),KEY venture_id (venture_id),KEY workspace_id (workspace_id)) $c;");
    dbDelta("CREATE TABLE {$t['wallets']} (id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,user_id BIGINT UNSIGNED NOT NULL,wallet_address VARCHAR(80) NOT NULL,chain_id VARCHAR(30) DEFAULT '',signature_message TEXT,signature_value TEXT,nonce VARCHAR(128) DEFAULT '',verified_at DATETIME DEFAULT NULL,verified_mode VARCHAR(40) DEFAULT '',message_hash VARCHAR(80) DEFAULT '',public_key_hex TEXT,token_balances_json LONGTEXT NULL,created_at DATETIME DEFAULT CURRENT_TIMESTAMP,PRIMARY KEY (id),KEY user_id (user_id)) $c;");
    dbDelta("CREATE TABLE {$t['wallet_challenges']} (id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,user_id BIGINT UNSIGNED NOT NULL,wallet_address VARCHAR(80) NOT NULL,nonce VARCHAR(128) NOT NULL,message TEXT NOT NULL,verified TINYINT(1) DEFAULT 0,created_at DATETIME DEFAULT CURRENT_TIMESTAMP,expires_at DATETIME NULL,PRIMARY KEY(id), KEY user_id(user_id), KEY wallet_address(wallet_address)) $c;");
    dbDelta("CREATE TABLE {$t['subscriptions']} (id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,user_id BIGINT UNSIGNED NOT NULL,workspace_id BIGINT UNSIGNED NOT NULL,module_id BIGINT UNSIGNED NOT NULL,wallet_address VARCHAR(80) DEFAULT '',fee_token_symbol VARCHAR(20) DEFAULT '',monthly_fee DECIMAL(24,8) DEFAULT 0,status VARCHAR(20) DEFAULT 'pending',started_at DATETIME DEFAULT NULL,active_until DATETIME DEFAULT NULL,payment_tx_hash VARCHAR(120) DEFAULT '',created_at DATETIME DEFAULT CURRENT_TIMESTAMP,PRIMARY KEY (id),KEY user_id (user_id),KEY module_id (module_id), KEY payment_tx_hash(payment_tx_hash)) $c;");
    dbDelta("CREATE TABLE {$t['payments']} (id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,user_id BIGINT UNSIGNED NOT NULL,workspace_id BIGINT UNSIGNED NOT NULL,module_id BIGINT UNSIGNED NOT NULL,wallet_address VARCHAR(80) DEFAULT '',token_symbol VARCHAR(20) DEFAULT '',token_contract VARCHAR(80) DEFAULT '',amount DECIMAL(24,8) DEFAULT 0,amount_raw VARCHAR(120) DEFAULT '',tx_hash VARCHAR(120) DEFAULT '',status VARCHAR(20) DEFAULT 'submitted',paid_for_months INT DEFAULT 1,block_number BIGINT UNSIGNED DEFAULT NULL,receipt_json LONGTEXT NULL,confirmed_at DATETIME DEFAULT NULL,failure_reason VARCHAR(255) DEFAULT '',created_at DATETIME DEFAULT CURRENT_TIMESTAMP,PRIMARY KEY(id),KEY tx_hash(tx_hash), KEY status(status)) $c;");
    dbDelta("CREATE TABLE {$t['vault']} (id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,workspace_slug VARCHAR(80) NOT NULL DEFAULT 'core',module_slug VARCHAR(80) NOT NULL DEFAULT 'vault',entity_type VARCHAR(80) NOT NULL DEFAULT 'general',entity_id VARCHAR(120) NOT NULL DEFAULT '',file_group VARCHAR(80) NOT NULL DEFAULT 'general',original_filename VARCHAR(255) NOT NULL,stored_filename VARCHAR(255) NOT NULL,mime_type VARCHAR(120) NOT NULL DEFAULT '',file_ext VARCHAR(20) NOT NULL DEFAULT '',file_size BIGINT UNSIGNED NOT NULL DEFAULT 0,relative_path TEXT NOT NULL,sha256_hash CHAR(64) NOT NULL,sha3_hash CHAR(64) NOT NULL,file_id_hash CHAR(64) DEFAULT '',metadata_hash CHAR(64) DEFAULT '',tx_hash VARCHAR(100) NOT NULL DEFAULT '',tx_status VARCHAR(20) NOT NULL DEFAULT 'pending',wallet_address VARCHAR(80) NOT NULL DEFAULT '',anchor_receipt_json LONGTEXT NULL,anchored_at DATETIME DEFAULT NULL,created_by BIGINT UNSIGNED NULL,created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,PRIMARY KEY(id),UNIQUE KEY sha256_hash(sha256_hash),KEY workspace_slug(workspace_slug), KEY tx_status(tx_status)) $c;");
    dbDelta("CREATE TABLE {$t['access_overrides']} (id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,user_id BIGINT UNSIGNED NOT NULL,workspace_id BIGINT UNSIGNED NOT NULL,module_id BIGINT UNSIGNED NOT NULL,status VARCHAR(20) DEFAULT 'active',created_at DATETIME DEFAULT CURRENT_TIMESTAMP,PRIMARY KEY(id)) $c;");
    dbDelta("CREATE TABLE {$t['sector_plugins']} (id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,slug VARCHAR(120) NOT NULL,name VARCHAR(120) NOT NULL,plugin_file VARCHAR(255) DEFAULT '',workspace_slug VARCHAR(120) DEFAULT '',token_symbol VARCHAR(20) DEFAULT '',active TINYINT(1) DEFAULT 1,created_at DATETIME DEFAULT CURRENT_TIMESTAMP,PRIMARY KEY(id),UNIQUE KEY slug(slug)) $c;");
    dbDelta("CREATE TABLE {$t['audit']} (id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,user_id BIGINT UNSIGNED DEFAULT 0,action VARCHAR(120) NOT NULL,context VARCHAR(190) DEFAULT '',payload LONGTEXT,created_at DATETIME DEFAULT CURRENT_TIMESTAMP,PRIMARY KEY(id)) $c;");
    dbDelta("CREATE TABLE {$t['sync_runs']} (id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,sync_type VARCHAR(60) NOT NULL,status VARCHAR(20) DEFAULT 'ok',items_total INT DEFAULT 0,items_confirmed INT DEFAULT 0,items_failed INT DEFAULT 0,notes TEXT,created_at DATETIME DEFAULT CURRENT_TIMESTAMP,PRIMARY KEY(id)) $c;");
    if (!get_option('ccjvu_settings')) update_option('ccjvu_settings', ccjvu_default_settings());
  }
  public static function seed() {
    global $wpdb; $t = ccjvu_tables();
    if ((int)$wpdb->get_var("SELECT COUNT(*) FROM {$t['workspaces']}") > 0) return;
    $wpdb->insert($t['workspaces'], ['name'=>'CCJV Core','slug'=>'core','token_symbol'=>'CJV','token_decimals'=>18,'gate_amount'=>1,'accent_color'=>'#2563eb','skin'=>'core','hero_title'=>'Operate Your Business Through CCJV','hero_text'=>'1 CJV token gate to access the core ERP. 1 CJV token/month per element.','buy_url'=>'https://xmarkets.ca','is_core'=>1,'active'=>1,'sort_order'=>1]);
    $core_id = $wpdb->insert_id;
    foreach ([['CRM','crm'],['HRM','hrm'],['Accounting','accounting'],['Project Management','project-management'],['Asset Management','asset-management']] as $i=>$m) $wpdb->insert($t['modules'], ['workspace_id'=>$core_id,'name'=>$m[0],'slug'=>$m[1],'monthly_fee'=>1,'fee_token_symbol'=>'CJV','summary'=>'1 CJV token/month per element','active'=>1,'sort_order'=>$i+1]);
    $ws = [ ['Constructum','constructum','CST','#ea580c','Construction ERP. 1 CST gate. 1 CST/month per element.'], ['EnergyChain','energychain','ENRC','#16a34a','Energy ERP. 1 ENRC gate. 1 ENRC/month per element.'], ['LandBank','landbank','LBC','#a16207','Land ERP. 1 LBC gate. 1 LBC/month per element.'] ];
    foreach ($ws as $i=>$w) { $wpdb->insert($t['workspaces'], ['name'=>$w[0],'slug'=>$w[1],'token_symbol'=>$w[2],'token_decimals'=>18,'gate_amount'=>1,'accent_color'=>$w[3],'skin'=>$w[1],'hero_title'=>$w[0].' Workspace','hero_text'=>$w[4],'buy_url'=>'https://xmarkets.ca','is_core'=>0,'active'=>1,'sort_order'=>$i+2]); $wid=$wpdb->insert_id; foreach ([['Operations','operations'],['Documents','documents'],['Reports','reports']] as $j=>$m) $wpdb->insert($t['modules'], ['workspace_id'=>$wid,'name'=>$m[0],'slug'=>$m[1],'monthly_fee'=>1,'fee_token_symbol'=>$w[2],'summary'=>'1 '.$w[2].' token/month per element','active'=>1,'sort_order'=>$j+1]); }
  }
  public static function schedule() {
    if (!wp_next_scheduled('ccjvu_hardened_sync')) wp_schedule_event(time()+300, 'hourly', 'ccjvu_hardened_sync');
  }
  public static function unschedule() {
    $timestamp = wp_next_scheduled('ccjvu_hardened_sync');
    if ($timestamp) wp_unschedule_event($timestamp, 'ccjvu_hardened_sync');
  }
  public static function run_scheduled_sync() {
    global $wpdb; $t = ccjvu_tables();
    $batch = max(1, intval(ccjvu_option('sync_batch_size', 20)));
    $payments = $wpdb->get_results($wpdb->prepare("SELECT * FROM {$t['payments']} WHERE status IN ('submitted','pending') ORDER BY id ASC LIMIT %d", $batch), ARRAY_A);
    $confirmed = 0; $failed = 0;
    foreach ($payments as $p) {
      $result = CCJVU_REST::sync_payment_record($p);
      if ($result['status'] === 'confirmed') $confirmed++;
      elseif ($result['status'] === 'failed') $failed++;
    }
    $vaults = $wpdb->get_results($wpdb->prepare("SELECT * FROM {$t['vault']} WHERE tx_hash <> '' AND tx_status IN ('pending','submitted') ORDER BY id ASC LIMIT %d", $batch), ARRAY_A);
    foreach ($vaults as $v) CCJVU_REST::sync_vault_record($v);
    $wpdb->insert($t['sync_runs'], ['sync_type'=>'scheduled','status'=>'ok','items_total'=>count($payments)+count($vaults),'items_confirmed'=>$confirmed,'items_failed'=>$failed,'notes'=>'Hourly sync']);
  }
}
