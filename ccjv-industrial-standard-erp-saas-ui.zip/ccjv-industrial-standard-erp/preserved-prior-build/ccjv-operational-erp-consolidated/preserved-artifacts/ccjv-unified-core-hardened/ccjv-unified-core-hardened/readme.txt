CCJV Unified Core Hardened

Includes hardened payment reconciliation, Avalanche receipt sync, server-side signature recovery workflow, live balance reads, and admin reconciliation screens.
