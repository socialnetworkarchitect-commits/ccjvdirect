<?php
/*
Plugin Name: CCJV Deep Integration Layer
Description: Deep vault integration for CCJV core and sector ERP plugins. Adds context-aware vault panels, workspace-aware document classes, venture record support, admin metaboxes, and sector compatibility hooks.
Version: 1.0.0
Author: OpenAI
*/
if (!defined('ABSPATH')) exit;

class CCJV_Deep_Integration_Layer {
    const OPT_KEY = 'ccjv_deep_integration_settings';
    const NONCE = 'ccjv_deep_integration_nonce';

    public function __construct() {
        register_activation_hook(__FILE__, [$this, 'activate']);
        add_action('admin_notices', [$this, 'dependency_notice']);
        add_action('init', [$this, 'register_post_types']);
        add_action('admin_menu', [$this, 'admin_menu']);
        add_action('admin_init', [$this, 'register_settings']);
        add_action('admin_enqueue_scripts', [$this, 'admin_assets']);
        add_action('wp_enqueue_scripts', [$this, 'frontend_assets']);
        add_action('add_meta_boxes', [$this, 'register_meta_boxes']);
        add_action('rest_api_init', [$this, 'rest_routes']);
        add_filter('ccjv_registered_workspaces', [$this, 'inject_dynamic_workspaces'], 20);
        add_filter('ccjv_deep_document_classes', [$this, 'default_document_classes']);
        add_shortcode('ccjv_entity_vault', [$this, 'render_entity_vault']);
        add_shortcode('ccjv_venture_vault', [$this, 'render_venture_vault']);
        add_shortcode('ccjv_workspace_documents', [$this, 'render_workspace_documents']);
    }

    public function activate() {
        if (!get_option(self::OPT_KEY)) {
            update_option(self::OPT_KEY, [
                'enabled_post_types' => ['ccjv_project','ccjv_invoice','ccjv_asset','ccjv_employee','ccjv_contact'],
                'default_module' => 'vault',
                'show_records_under_forms' => 1,
                'workspace_mode' => 'dynamic',
                'allowed_sector_adapters' => ['constructum','energychain','landbank'],
            ]);
        }
    }

    private function deps_ok() {
        return class_exists('CCJV_Vault_Avalanche') || class_exists('CCJV_Token_Gate_Core_V4') || shortcode_exists('ccjv_vault');
    }

    public function dependency_notice() {
        if (!current_user_can('manage_options')) return;
        if (!shortcode_exists('ccjv_vault')) {
            echo '<div class="notice notice-warning"><p><strong>CCJV Deep Integration Layer:</strong> CCJV Vault Avalanche Anchor is not active. Vault panels will not render until that plugin is active.</p></div>';
        }
        if (!class_exists('CCJV_Token_Gate_Core_V4') && !shortcode_exists('ccjv_shell_v4') && !shortcode_exists('ccjv_shell_v5')) {
            echo '<div class="notice notice-info"><p><strong>CCJV Deep Integration Layer:</strong> CCJV Token Gate Core is not active. Core workspace and venture integrations will use fallback mode.</p></div>';
        }
    }

    public function settings() {
        return wp_parse_args((array)get_option(self::OPT_KEY, []), [
            'enabled_post_types' => ['ccjv_project','ccjv_invoice','ccjv_asset','ccjv_employee','ccjv_contact'],
            'default_module' => 'vault',
            'show_records_under_forms' => 1,
            'workspace_mode' => 'dynamic',
            'allowed_sector_adapters' => ['constructum','energychain','landbank'],
        ]);
    }

    public function register_post_types() {
        register_post_type('ccjv_venture_record', [
            'label' => 'CCJV Venture Records',
            'public' => false,
            'show_ui' => false,
            'supports' => ['title','editor']
        ]);
    }

    public function admin_menu() {
        add_menu_page('CCJV Deep Integration', 'CCJV Deep Integration', 'manage_options', 'ccjv-deep-integration', [$this, 'settings_page'], 'dashicons-networking', 29);
        add_submenu_page('ccjv-deep-integration', 'Settings', 'Settings', 'manage_options', 'ccjv-deep-integration', [$this, 'settings_page']);
        add_submenu_page('ccjv-deep-integration', 'Document Classes', 'Document Classes', 'manage_options', 'ccjv-deep-doc-classes', [$this, 'doc_classes_page']);
        add_submenu_page('ccjv-deep-integration', 'Venture Vault', 'Venture Vault', 'manage_options', 'ccjv-deep-venture-vault', [$this, 'venture_console_page']);
    }

    public function register_settings() {
        register_setting('ccjv_deep_integration_group', self::OPT_KEY, [$this, 'sanitize_settings']);
    }

    public function sanitize_settings($input) {
        $out = $this->settings();
        $out['default_module'] = sanitize_key($input['default_module'] ?? 'vault');
        $out['show_records_under_forms'] = !empty($input['show_records_under_forms']) ? 1 : 0;
        $out['workspace_mode'] = in_array(($input['workspace_mode'] ?? 'dynamic'), ['dynamic','manual'], true) ? $input['workspace_mode'] : 'dynamic';
        $types = isset($input['enabled_post_types']) && is_array($input['enabled_post_types']) ? $input['enabled_post_types'] : [];
        $out['enabled_post_types'] = array_values(array_filter(array_map('sanitize_key', $types)));
        $adapters = isset($input['allowed_sector_adapters']) && is_array($input['allowed_sector_adapters']) ? $input['allowed_sector_adapters'] : [];
        $out['allowed_sector_adapters'] = array_values(array_filter(array_map('sanitize_key', $adapters)));
        return $out;
    }

    public function admin_assets($hook) {
        if (strpos($hook, 'ccjv-deep') === false && $hook !== 'post.php' && $hook !== 'post-new.php') return;
        wp_enqueue_style('ccjv-deep-admin', plugin_dir_url(__FILE__) . 'assets/css/ccjv-deep.css', [], '1.0.0');
    }

    public function frontend_assets() {
        wp_enqueue_style('ccjv-deep-front', plugin_dir_url(__FILE__) . 'assets/css/ccjv-deep.css', [], '1.0.0');
        wp_enqueue_script('ccjv-deep-js', plugin_dir_url(__FILE__) . 'assets/js/ccjv-deep.js', ['jquery'], '1.0.0', true);
        wp_localize_script('ccjv-deep-js', 'CCJVDeep', [
            'restUrl' => esc_url_raw(rest_url('ccjv-deep/v1/')),
            'nonce' => wp_create_nonce('wp_rest'),
        ]);
    }

    public function inject_dynamic_workspaces($workspaces) {
        if (!is_array($workspaces)) $workspaces = [];
        global $wpdb;
        $table = $wpdb->prefix . 'ccjv_workspaces';
        $exists = $wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $table));
        if ($exists === $table) {
            $rows = $wpdb->get_results("SELECT slug, name FROM {$table} WHERE is_enabled=1 ORDER BY name ASC", ARRAY_A) ?: [];
            foreach ($rows as $row) {
                $workspaces[sanitize_key($row['slug'])] = sanitize_text_field($row['name']);
            }
        }
        if (!$workspaces) {
            $workspaces = [
                'core' => 'CCJV Core',
                'constructum' => 'Constructum',
                'energychain' => 'EnergyChain',
                'landbank' => 'LandBank',
            ];
        }
        return $workspaces;
    }

    public function default_document_classes($classes) {
        if (!is_array($classes)) $classes = [];
        $base = [
            'core' => [
                'general' => 'General',
                'contracts' => 'Contracts',
                'invoices' => 'Invoices',
                'payroll' => 'Payroll',
                'crm' => 'CRM',
                'hrm' => 'HRM',
                'accounting' => 'Accounting',
                'projects' => 'Projects',
                'assets' => 'Assets',
                'compliance' => 'Compliance',
                'governance' => 'Governance',
            ],
            'constructum' => [
                'drawings' => 'Drawings',
                'permits' => 'Permits',
                'change_orders' => 'Change Orders',
                'site_photos' => 'Site Photos',
                'subcontracts' => 'Subcontracts',
            ],
            'energychain' => [
                'meter_reports' => 'Meter Reports',
                'generation_reports' => 'Generation Reports',
                'ppas' => 'PPAs',
                'interconnection' => 'Interconnection',
                'site_assets' => 'Site Assets',
            ],
            'landbank' => [
                'titles' => 'Titles',
                'zoning' => 'Zoning',
                'entitlements' => 'Entitlements',
                'surveys' => 'Surveys',
                'valuations' => 'Valuations',
            ],
        ];
        return array_replace_recursive($base, $classes);
    }

    public function register_meta_boxes() {
        $types = $this->settings()['enabled_post_types'];
        foreach ($types as $type) {
            add_meta_box('ccjv_deep_vault_box', 'CCJV Vault Integration', [$this, 'render_meta_box'], $type, 'normal', 'default');
        }
    }

    public function render_meta_box($post) {
        $workspace = sanitize_key(get_post_meta($post->ID, 'workspace_slug', true));
        if (!$workspace) $workspace = 'core';
        $entity_type = $post->post_type;
        $entity_id = (string)$post->ID;
        $classes = $this->get_document_classes_for_workspace($workspace);
        echo '<div class="ccjv-deep-box">';
        echo '<p><strong>Workspace:</strong> ' . esc_html($workspace) . ' &nbsp; <strong>Entity:</strong> ' . esc_html($entity_type . ':' . $entity_id) . '</p>';
        echo '<p><strong>Recommended document classes:</strong> ' . esc_html(implode(', ', array_values($classes))) . '</p>';
        if (shortcode_exists('ccjv_vault')) {
            echo do_shortcode(sprintf('[ccjv_vault workspace="%s" module="%s" entity_type="%s" entity_id="%s" file_group="general"]', esc_attr($workspace), esc_attr($this->settings()['default_module']), esc_attr($entity_type), esc_attr($entity_id)));
            if ($this->settings()['show_records_under_forms']) {
                echo '<div class="ccjv-deep-records">' . do_shortcode(sprintf('[ccjv_vault_records workspace="%s" entity_type="%s" entity_id="%s"]', esc_attr($workspace), esc_attr($entity_type), esc_attr($entity_id))) . '</div>';
            }
        } else {
            echo '<p>Activate CCJV Vault Avalanche Anchor to enable uploads and on-chain anchoring here.</p>';
        }
        echo '</div>';
    }

    private function get_document_classes_for_workspace($workspace) {
        $all = apply_filters('ccjv_deep_document_classes', []);
        $core = $all['core'] ?? [];
        $ws = $all[$workspace] ?? [];
        return array_merge($core, $ws);
    }

    public function rest_routes() {
        register_rest_route('ccjv-deep/v1', '/context', [
            'methods' => 'GET',
            'callback' => [$this, 'rest_context'],
            'permission_callback' => '__return_true',
        ]);
        register_rest_route('ccjv-deep/v1', '/workspaces', [
            'methods' => 'GET',
            'callback' => [$this, 'rest_workspaces'],
            'permission_callback' => '__return_true',
        ]);
        register_rest_route('ccjv-deep/v1', '/ventures', [
            'methods' => 'GET',
            'callback' => [$this, 'rest_ventures'],
            'permission_callback' => function() { return is_user_logged_in(); },
        ]);
    }

    public function rest_context($req) {
        $workspace = sanitize_key($req['workspace'] ?: 'core');
        $entity_type = sanitize_key($req['entity_type'] ?: 'general');
        $entity_id = sanitize_text_field($req['entity_id'] ?: 'general');
        $out = [
            'workspace' => $workspace,
            'entity_type' => $entity_type,
            'entity_id' => $entity_id,
            'document_classes' => $this->get_document_classes_for_workspace($workspace),
            'vault_shortcode' => sprintf('[ccjv_vault workspace="%s" module="%s" entity_type="%s" entity_id="%s"]', $workspace, $this->settings()['default_module'], $entity_type, $entity_id),
            'records_shortcode' => sprintf('[ccjv_vault_records workspace="%s" entity_type="%s" entity_id="%s"]', $workspace, $entity_type, $entity_id),
        ];
        return rest_ensure_response($out);
    }

    public function rest_workspaces() {
        return rest_ensure_response(['workspaces' => $this->inject_dynamic_workspaces([])]);
    }

    public function rest_ventures() {
        global $wpdb;
        $table = $wpdb->prefix . 'ccjv_ventures';
        $exists = $wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $table));
        if ($exists !== $table) return rest_ensure_response(['ventures' => []]);
        $ventures = $wpdb->get_results("SELECT id, title, workspace_slug, linked_workspaces, status FROM {$table} ORDER BY id DESC LIMIT 100", ARRAY_A) ?: [];
        foreach ($ventures as &$venture) {
            $venture['linked_workspaces'] = maybe_unserialize($venture['linked_workspaces']);
        }
        return rest_ensure_response(['ventures' => $ventures]);
    }

    public function render_entity_vault($atts) {
        $a = shortcode_atts([
            'workspace' => 'core',
            'module' => '',
            'entity_type' => 'general',
            'entity_id' => 'general',
            'title' => 'Entity Documents',
        ], $atts);
        $module = $a['module'] ?: $this->settings()['default_module'];
        ob_start();
        echo '<div class="ccjv-deep-panel">';
        echo '<div class="ccjv-deep-head"><h3>' . esc_html($a['title']) . '</h3><span>' . esc_html($a['workspace'] . ' / ' . $a['entity_type'] . ':' . $a['entity_id']) . '</span></div>';
        if (shortcode_exists('ccjv_vault')) {
            echo do_shortcode(sprintf('[ccjv_vault workspace="%s" module="%s" entity_type="%s" entity_id="%s"]', esc_attr($a['workspace']), esc_attr($module), esc_attr($a['entity_type']), esc_attr($a['entity_id'])));
            if ($this->settings()['show_records_under_forms']) {
                echo '<div class="ccjv-deep-records">' . do_shortcode(sprintf('[ccjv_vault_records workspace="%s" entity_type="%s" entity_id="%s"]', esc_attr($a['workspace']), esc_attr($a['entity_type']), esc_attr($a['entity_id']))) . '</div>';
            }
        } else {
            echo '<p>CCJV Vault Avalanche Anchor is required for this panel.</p>';
        }
        echo '</div>';
        return ob_get_clean();
    }

    public function render_venture_vault($atts) {
        $a = shortcode_atts([
            'venture_id' => 0,
            'workspace' => '',
            'title' => 'Venture Vault'
        ], $atts);
        $venture_id = (int)$a['venture_id'];
        if (!$venture_id && !empty($_GET['venture_id'])) $venture_id = (int)$_GET['venture_id'];
        if (!$venture_id) return '<div class="ccjv-deep-panel"><p>No venture selected.</p></div>';
        global $wpdb;
        $table = $wpdb->prefix . 'ccjv_ventures';
        $venture = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table} WHERE id=%d", $venture_id), ARRAY_A);
        if (!$venture) return '<div class="ccjv-deep-panel"><p>Venture not found.</p></div>';
        $workspace = $a['workspace'] ? sanitize_key($a['workspace']) : sanitize_key($venture['workspace_slug'] ?: 'core');
        ob_start();
        echo '<div class="ccjv-deep-panel">';
        echo '<div class="ccjv-deep-head"><h3>' . esc_html($a['title']) . '</h3><span>' . esc_html($venture['title']) . '</span></div>';
        echo '<div class="ccjv-venture-meta"><div><strong>Status:</strong> ' . esc_html($venture['status']) . '</div><div><strong>Workspace:</strong> ' . esc_html($workspace) . '</div></div>';
        echo $this->render_entity_vault([
            'workspace' => $workspace,
            'module' => 'venture',
            'entity_type' => 'venture',
            'entity_id' => (string)$venture_id,
            'title' => 'Venture Documents'
        ]);
        echo '</div>';
        return ob_get_clean();
    }

    public function render_workspace_documents($atts) {
        $a = shortcode_atts([
            'workspace' => 'core',
            'entity_type' => 'general',
            'entity_id' => 'general',
        ], $atts);
        return $this->render_entity_vault($a);
    }

    public function settings_page() {
        $settings = $this->settings();
        $post_types = get_post_types(['public' => false], 'objects');
        echo '<div class="wrap ccjv-deep-wrap"><h1>CCJV Deep Integration Layer</h1><form method="post" action="options.php">';
        settings_fields('ccjv_deep_integration_group');
        echo '<table class="form-table"><tbody>';
        echo '<tr><th>Default Module</th><td><input type="text" name="'.self::OPT_KEY.'[default_module]" value="'.esc_attr($settings['default_module']).'" class="regular-text"></td></tr>';
        echo '<tr><th>Workspace Mode</th><td><select name="'.self::OPT_KEY.'[workspace_mode]"><option value="dynamic" '.selected($settings['workspace_mode'],'dynamic',false).'>Dynamic from CCJV Core</option><option value="manual" '.selected($settings['workspace_mode'],'manual',false).'>Manual/Fallback</option></select></td></tr>';
        echo '<tr><th>Show records under forms</th><td><label><input type="checkbox" name="'.self::OPT_KEY.'[show_records_under_forms]" value="1" '.checked($settings['show_records_under_forms'],1,false).'> Yes</label></td></tr>';
        echo '<tr><th>Enable admin metaboxes on post types</th><td>';
        foreach ($post_types as $post_type) {
            if (strpos($post_type->name, 'ccjv_') !== 0) continue;
            echo '<label style="display:block;margin:4px 0"><input type="checkbox" name="'.self::OPT_KEY.'[enabled_post_types][]" value="'.esc_attr($post_type->name).'" '.checked(in_array($post_type->name, $settings['enabled_post_types'], true), true, false).'> '.esc_html($post_type->label).' ('.$post_type->name.')</label>';
        }
        echo '</td></tr>';
        echo '</tbody></table>';
        submit_button();
        echo '</form>';

        echo '<hr><h2>Quick Integration Shortcodes</h2>';
        echo '<p><code>[ccjv_entity_vault workspace="core" entity_type="ccjv_project" entity_id="123"]</code></p>';
        echo '<p><code>[ccjv_venture_vault venture_id="1"]</code></p>';
        echo '<p><code>[ccjv_workspace_documents workspace="constructum" entity_type="venture" entity_id="5"]</code></p>';
        echo '</div>';
    }

    public function doc_classes_page() {
        $workspaces = $this->inject_dynamic_workspaces([]);
        echo '<div class="wrap ccjv-deep-wrap"><h1>CCJV Document Classes</h1><p>These document classes are available to the vault integration layer. Sector plugins can extend this using the <code>ccjv_deep_document_classes</code> filter.</p>';
        foreach ($workspaces as $slug => $label) {
            $classes = $this->get_document_classes_for_workspace($slug);
            echo '<div class="ccjv-docclass-card"><h2>'.esc_html($label).' <code>'.esc_html($slug).'</code></h2><ul>';
            foreach ($classes as $key => $value) {
                echo '<li><strong>'.esc_html($key).'</strong> — '.esc_html($value).'</li>';
            }
            echo '</ul></div>';
        }
        echo '</div>';
    }

    public function venture_console_page() {
        global $wpdb;
        $table = $wpdb->prefix . 'ccjv_ventures';
        $exists = $wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $table));
        echo '<div class="wrap ccjv-deep-wrap"><h1>Venture Vault Console</h1>';
        if ($exists !== $table) {
            echo '<p>The CCJV ventures table was not found. Activate the CCJV token gate core plugin first.</p></div>';
            return;
        }
        $ventures = $wpdb->get_results("SELECT id, title, workspace_slug, status FROM {$table} ORDER BY id DESC LIMIT 100", ARRAY_A) ?: [];
        echo '<div class="ccjv-docclass-card"><table class="widefat striped"><thead><tr><th>ID</th><th>Title</th><th>Workspace</th><th>Status</th><th>Vault Panel</th></tr></thead><tbody>';
        foreach ($ventures as $v) {
            echo '<tr><td>'.(int)$v['id'].'</td><td>'.esc_html($v['title']).'</td><td>'.esc_html($v['workspace_slug']).'</td><td>'.esc_html($v['status']).'</td><td><code>[ccjv_venture_vault venture_id="'.(int)$v['id'].'"]</code></td></tr>';
        }
        echo '</tbody></table></div></div>';
    }
}

new CCJV_Deep_Integration_Layer();
