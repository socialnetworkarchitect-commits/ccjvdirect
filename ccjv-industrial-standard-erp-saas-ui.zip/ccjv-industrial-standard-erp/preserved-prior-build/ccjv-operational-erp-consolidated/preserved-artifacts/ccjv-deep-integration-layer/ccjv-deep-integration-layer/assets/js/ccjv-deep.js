(function($){
  $(document).on('click','.ccjv-deep-refresh',function(){ location.reload(); });
})(jQuery);
