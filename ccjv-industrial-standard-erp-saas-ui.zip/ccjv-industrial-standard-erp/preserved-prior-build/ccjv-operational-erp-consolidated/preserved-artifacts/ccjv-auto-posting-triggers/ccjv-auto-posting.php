<?php
/*
Plugin Name: CCJV Auto Posting Triggers
Description: Automatically posts HRM payroll, Asset depreciation, and Project costs into Core Accounting.
Version: 1.0.0
Author: OpenAI
*/

if (!defined('ABSPATH')) exit;

if (!defined('CCJV_CORE_ACTIVE') && !function_exists('ccjv_core_loaded')) {
    add_action('admin_notices', function () {
        echo '<div class="notice notice-error"><p><strong>CCJV Auto Posting Triggers</strong> requires CCJV Core.</p></div>';
    });
    return;
}

function ccjv_auto_get_tenant($user_id = 0){
    if (!$user_id) $user_id = get_current_user_id();
    $tenant = get_user_meta($user_id, 'ccjv_tenant', true);
    if (!$tenant && function_exists('ccjvx_get_tenant')){
        $tenant = ccjvx_get_tenant($user_id);
    }
    return $tenant ?: '';
}

function ccjv_auto_post($tenant_id, $account_id, $debit, $credit, $memo){
    if (!function_exists('ccjv_post_journal')) return false;
    ccjv_post_journal($tenant_id, $account_id, $debit, $credit, $memo);
    return true;
}

/*
AUTO PAYROLL (hook after HRM employee/payment save)
*/
add_action('ccjv_hrm_payroll_processed', function($data){
    $tenant = ccjv_auto_get_tenant();
    if (!$tenant) return;

    $amount = (float)$data['amount'];

    $expense = get_option('ccjv_payroll_expense_account');
    $liability = get_option('ccjv_payroll_liability_account');

    if ($amount > 0 && $expense && $liability){
        ccjv_auto_post($tenant, $expense, $amount, 0, 'Auto Payroll Expense');
        ccjv_auto_post($tenant, $liability, 0, $amount, 'Auto Payroll Liability');
    }
});

/*
AUTO DEPRECIATION (daily cron)
*/
add_action('ccjv_auto_daily_depreciation', function(){
    global $wpdb;
    $assets = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}ccjv_assets");

    foreach ($assets as $asset){
        $tenant = $asset->tenant_id;
        $rate = 0.01; // 1% default monthly simplified

        $amount = $asset->book_value * $rate;

        if ($amount <= 0) continue;

        $expense = get_option('ccjv_depreciation_expense_account');
        $contra = get_option('ccjv_depreciation_contra_account');

        if ($expense && $contra){
            ccjv_auto_post($tenant, $expense, $amount, 0, 'Auto Depreciation');
            ccjv_auto_post($tenant, $contra, 0, $amount, 'Auto Depreciation');
        }
    }
});

/*
AUTO PROJECT COST (on task creation)
*/
add_action('ccjv_project_task_created', function($task){
    $tenant = ccjv_auto_get_tenant();
    if (!$tenant) return;

    $amount = (float)($task['cost'] ?? 0);

    $project_account = get_option('ccjv_project_cost_account');
    $offset_account = get_option('ccjv_project_offset_account');

    if ($amount > 0 && $project_account && $offset_account){
        ccjv_auto_post($tenant, $project_account, $amount, 0, 'Auto Project Cost');
        ccjv_auto_post($tenant, $offset_account, 0, $amount, 'Auto Project Cost Offset');
    }
});

/*
SETUP CRON
*/
if (!wp_next_scheduled('ccjv_auto_daily_depreciation')){
    wp_schedule_event(time(), 'daily', 'ccjv_auto_daily_depreciation');
}

/*
ADMIN SETTINGS
*/
add_action('admin_menu', function(){
    add_submenu_page('ccjv','Auto Posting','Auto Posting','manage_options','ccjv-auto-posting',function(){
        ?>
        <div class="wrap">
            <h1>Auto Posting Settings</h1>
            <form method="post">
                <?php wp_nonce_field('ccjv_auto_settings'); ?>

                <h3>Payroll</h3>
                <input type="number" name="payroll_expense" placeholder="Expense Account ID"><br>
                <input type="number" name="payroll_liability" placeholder="Liability Account ID"><br>

                <h3>Depreciation</h3>
                <input type="number" name="dep_expense" placeholder="Expense Account ID"><br>
                <input type="number" name="dep_contra" placeholder="Contra Asset Account ID"><br>

                <h3>Project</h3>
                <input type="number" name="proj_cost" placeholder="Project Cost Account ID"><br>
                <input type="number" name="proj_offset" placeholder="Offset Account ID"><br>

                <p><button class="button button-primary">Save</button></p>
            </form>
        </div>
        <?php
        if ($_POST && check_admin_referer('ccjv_auto_settings')){
            update_option('ccjv_payroll_expense_account', intval($_POST['payroll_expense']));
            update_option('ccjv_payroll_liability_account', intval($_POST['payroll_liability']));
            update_option('ccjv_depreciation_expense_account', intval($_POST['dep_expense']));
            update_option('ccjv_depreciation_contra_account', intval($_POST['dep_contra']));
            update_option('ccjv_project_cost_account', intval($_POST['proj_cost']));
            update_option('ccjv_project_offset_account', intval($_POST['proj_offset']));
            echo "<p>Saved.</p>";
        }
    });
});
