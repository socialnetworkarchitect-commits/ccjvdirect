<?php
/*
Plugin Name: CCJV Avalanche Wallet Enforcement
Description: Real wallet binding + Avalanche ERC20 balance checks + subscription purchase flow using on-chain balance enforcement.
Version: 1.0.0
Author: CCJV
*/

if (!defined('ABSPATH')) exit;

/*
Install beside:
- CCJV Global Enforcement Layer
- CCJV Subscription Purchase + Auto Token Deduction

This plugin adds real Avalanche wallet balance checks and a safe access bypass for subscribe/bind pages.
*/

register_activation_hook(__FILE__, function () {
    global $wpdb;
    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    $charset = $wpdb->get_charset_collate();

    dbDelta("CREATE TABLE {$wpdb->prefix}ccjv_wallets (
        id BIGINT AUTO_INCREMENT PRIMARY KEY,
        user_id BIGINT NOT NULL,
        wallet VARCHAR(80) NOT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    ) $charset;");

    dbDelta("CREATE TABLE {$wpdb->prefix}ccjv_avalanche_ledger (
        id BIGINT AUTO_INCREMENT PRIMARY KEY,
        user_id BIGINT NOT NULL,
        wallet VARCHAR(80),
        token_symbol VARCHAR(20),
        token_contract VARCHAR(80),
        erp VARCHAR(80),
        module VARCHAR(80),
        action_type VARCHAR(80),
        amount DECIMAL(36,18),
        tx_hash VARCHAR(120),
        note TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    ) $charset;");
});

function ccjv_avax_settings() {
    $default = [
        'rpc' => 'https://api.avax.network/ext/bc/C/rpc',
        'treasury' => '',
        'tokens' => [
            'OMC' => '0xf23BBc223438b0ec81f69efe2699325E8EB67e75',
            'CST' => '0x6d44681fA4441345AA7b0265b9Fa3fc4b70Fbe40',
            'CIB' => '0xA86AB9663Be3F64ffaE6Ad73aA305d38447f3C80',
            'ITC' => '0x22372160c7000a41794d2d01CbAFF0c9967FE4bd',
            'SYS' => '0x4d80Ae78C8BeA3A9aFEFF005FbF7bc3E72e0Cb42',
            'FRE' => '0x74B4ea16007FfddFcf0d376DBED904CE279B9148',
        ],
        'gates' => [
            'core' => ['token' => 'OMC', 'min' => 0],
            'constructum' => ['token' => 'CST', 'min' => 1],
            'cibus' => ['token' => 'CIB', 'min' => 1],
            'iter' => ['token' => 'ITC', 'min' => 1],
            'surge' => ['token' => 'SYS', 'min' => 1],
            'freeassembly' => ['token' => 'FRE', 'min' => 1],
        ],
        'module_prices' => [
            'core' => ['core' => ['token' => 'OMC', 'fee' => 0]],
            'constructum' => [
                'core' => ['token' => 'CST', 'fee' => 1],
                'crm' => ['token' => 'CST', 'fee' => 10],
                'projects' => ['token' => 'CST', 'fee' => 15],
                'accounting' => ['token' => 'CST', 'fee' => 20],
            ],
            'cibus' => [
                'core' => ['token' => 'CIB', 'fee' => 1],
                'production' => ['token' => 'CIB', 'fee' => 15],
                'traceability' => ['token' => 'CIB', 'fee' => 20],
            ],
            'iter' => [
                'core' => ['token' => 'ITC', 'fee' => 1],
                'booking' => ['token' => 'ITC', 'fee' => 15],
                'yield' => ['token' => 'ITC', 'fee' => 20],
            ],
            'surge' => [
                'core' => ['token' => 'SYS', 'fee' => 1],
                'events' => ['token' => 'SYS', 'fee' => 15],
                'ticketing' => ['token' => 'SYS', 'fee' => 20],
            ],
            'freeassembly' => [
                'core' => ['token' => 'FRE', 'fee' => 1],
                'giving' => ['token' => 'FRE', 'fee' => 10],
                'testimony' => ['token' => 'FRE', 'fee' => 10],
            ],
        ],
        'duration_days' => 30,
    ];

    $saved = get_option('ccjv_avalanche_settings', []);
    return array_replace_recursive($default, is_array($saved) ? $saved : []);
}

function ccjv_avax_rpc($method, $params = []) {
    $s = ccjv_avax_settings();
    $res = wp_remote_post($s['rpc'], [
        'timeout' => 20,
        'headers' => ['Content-Type' => 'application/json'],
        'body' => wp_json_encode([
            'jsonrpc' => '2.0',
            'method' => $method,
            'params' => $params,
            'id' => 1
        ])
    ]);

    if (is_wp_error($res)) return $res;
    $body = json_decode(wp_remote_retrieve_body($res), true);
    if (isset($body['error'])) return new WP_Error('rpc_error', $body['error']['message'] ?? 'RPC error');
    return $body['result'] ?? null;
}

function ccjv_wallet_for_user($user_id) {
    global $wpdb;
    $w = $wpdb->get_var($wpdb->prepare("SELECT wallet FROM {$wpdb->prefix}ccjv_wallets WHERE user_id=%d ORDER BY id DESC LIMIT 1", $user_id));
    if (!$w) $w = get_user_meta($user_id, 'ccjv_wallet', true);
    return $w ? strtolower($w) : '';
}

function ccjv_pad_address($addr) {
    $addr = strtolower(str_replace('0x', '', trim($addr)));
    return str_pad($addr, 64, '0', STR_PAD_LEFT);
}

function ccjv_hex_to_decimal_string($hex) {
    if (!$hex || $hex === '0x') return '0';
    $hex = strtolower(str_replace('0x', '', $hex));
    if (function_exists('gmp_init')) {
        return gmp_strval(gmp_init($hex, 16), 10);
    }
    // fallback for smaller values
    return (string)hexdec($hex);
}

function ccjv_units_to_tokens($units, $decimals = 18) {
    $units = (string)$units;
    if (strlen($units) <= $decimals) {
        return (float)('0.' . str_pad($units, $decimals, '0', STR_PAD_LEFT));
    }
    $whole = substr($units, 0, -$decimals);
    $frac = substr($units, -$decimals, 8);
    return (float)($whole . '.' . $frac);
}

function ccjv_erc20_balance($wallet, $contract) {
    if (!$wallet || !$contract) return 0.0;
    $data = '0x70a08231' . ccjv_pad_address($wallet); // balanceOf(address)
    $result = ccjv_avax_rpc('eth_call', [[
        'to' => $contract,
        'data' => $data
    ], 'latest']);

    if (is_wp_error($result)) return 0.0;
    $raw = ccjv_hex_to_decimal_string($result);
    return ccjv_units_to_tokens($raw, 18);
}

function ccjv_avalanche_token_balance($user_id, $symbol) {
    $s = ccjv_avax_settings();
    $wallet = ccjv_wallet_for_user($user_id);
    $contract = $s['tokens'][strtoupper($symbol)] ?? '';
    return ccjv_erc20_balance($wallet, $contract);
}

function ccjv_avalanche_log($user_id, $symbol, $erp, $module, $type, $amount = 0, $tx = '', $note = '') {
    global $wpdb;
    $s = ccjv_avax_settings();
    $wallet = ccjv_wallet_for_user($user_id);
    $wpdb->insert($wpdb->prefix . 'ccjv_avalanche_ledger', [
        'user_id' => $user_id,
        'wallet' => $wallet,
        'token_symbol' => strtoupper($symbol),
        'token_contract' => $s['tokens'][strtoupper($symbol)] ?? '',
        'erp' => $erp,
        'module' => $module,
        'action_type' => $type,
        'amount' => $amount,
        'tx_hash' => $tx,
        'note' => $note,
    ]);
}

/* Admin Settings */
add_action('admin_menu', function () {
    add_menu_page('CCJV Avalanche', 'CCJV Avalanche', 'manage_options', 'ccjv-avalanche', 'ccjv_avalanche_admin', 'dashicons-shield-alt', 58);
});

function ccjv_avalanche_admin() {
    if (!current_user_can('manage_options')) return;

    if (isset($_POST['ccjv_av_save'])) {
        check_admin_referer('ccjv_av_save');
        $settings = [
            'rpc' => esc_url_raw($_POST['rpc'] ?? ''),
            'treasury' => sanitize_text_field($_POST['treasury'] ?? ''),
            'tokens' => json_decode(wp_unslash($_POST['tokens_json'] ?? '{}'), true),
            'gates' => json_decode(wp_unslash($_POST['gates_json'] ?? '{}'), true),
            'module_prices' => json_decode(wp_unslash($_POST['prices_json'] ?? '{}'), true),
            'duration_days' => intval($_POST['duration_days'] ?? 30),
        ];

        if (is_array($settings['tokens']) && is_array($settings['gates']) && is_array($settings['module_prices'])) {
            update_option('ccjv_avalanche_settings', $settings);
            update_option('ccjv_sp_settings', [
                'duration_days' => $settings['duration_days'],
                'module_prices' => $settings['module_prices']
            ]);
            echo '<div class="updated"><p>Saved. Subscription plugin pricing also synced.</p></div>';
        } else {
            echo '<div class="error"><p>Invalid JSON.</p></div>';
        }
    }

    $s = ccjv_avax_settings();
    echo '<div class="wrap"><h1>CCJV Avalanche Enforcement</h1><form method="post">';
    wp_nonce_field('ccjv_av_save');
    echo '<h2>RPC</h2><input style="width:100%" name="rpc" value="' . esc_attr($s['rpc']) . '">';
    echo '<h2>Treasury Wallet</h2><input style="width:100%" name="treasury" value="' . esc_attr($s['treasury']) . '">';
    echo '<h2>Subscription Duration</h2><input type="number" name="duration_days" value="' . esc_attr($s['duration_days']) . '"> days';
    echo '<h2>Tokens JSON</h2><textarea name="tokens_json" style="width:100%;height:170px;font-family:monospace;">' . esc_textarea(json_encode($s['tokens'], JSON_PRETTY_PRINT)) . '</textarea>';
    echo '<h2>Token Gates JSON</h2><textarea name="gates_json" style="width:100%;height:170px;font-family:monospace;">' . esc_textarea(json_encode($s['gates'], JSON_PRETTY_PRINT)) . '</textarea>';
    echo '<h2>Module Prices JSON</h2><textarea name="prices_json" style="width:100%;height:260px;font-family:monospace;">' . esc_textarea(json_encode($s['module_prices'], JSON_PRETTY_PRINT)) . '</textarea>';
    echo '<p><button class="button button-primary" name="ccjv_av_save">Save Avalanche Settings</button></p></form></div>';
}

/* Wallet binding */
add_shortcode('ccjv_bind_avalanche_wallet', function () {
    if (!is_user_logged_in()) return '<p>Please log in.</p>';
    ob_start(); ?>
    <div class="ccjv-av-box">
        <h2>Bind Avalanche Wallet</h2>
        <button id="ccjvConnect" class="ccjv-av-btn">Connect + Bind MetaMask</button>
        <p id="ccjvWalletStatus">Current: <?php echo esc_html(ccjv_wallet_for_user(get_current_user_id()) ?: 'Not bound'); ?></p>
    </div>
    <script>
    document.getElementById('ccjvConnect').onclick = async function(){
        if(!window.ethereum){ alert('MetaMask not found'); return; }
        const accounts = await ethereum.request({method:'eth_requestAccounts'});
        const wallet = accounts[0];
        const fd = new FormData();
        fd.append('action','ccjv_bind_wallet_ajax');
        fd.append('wallet',wallet);
        const r = await fetch('<?php echo esc_url(admin_url('admin-ajax.php')); ?>',{method:'POST',body:fd});
        document.getElementById('ccjvWalletStatus').innerText = await r.text();
    };
    </script>
    <?php return ob_get_clean();
});

add_action('wp_ajax_ccjv_bind_wallet_ajax', function () {
    if (!is_user_logged_in()) wp_die('Login required');
    $wallet = sanitize_text_field($_POST['wallet'] ?? '');
    if (!preg_match('/^0x[a-fA-F0-9]{40}$/', $wallet)) wp_die('Invalid wallet');

    global $wpdb;
    $uid = get_current_user_id();
    update_user_meta($uid, 'ccjv_wallet', strtolower($wallet));
    $wpdb->insert($wpdb->prefix . 'ccjv_wallets', [
        'user_id' => $uid,
        'wallet' => strtolower($wallet),
        'created_at' => current_time('mysql'),
        'updated_at' => current_time('mysql'),
    ]);
    wp_die('Bound: ' . esc_html($wallet));
});

/* Balance dashboard */
add_shortcode('ccjv_avalanche_balances', function () {
    if (!is_user_logged_in()) return '<p>Please log in.</p>';
    $uid = get_current_user_id();
    $s = ccjv_avax_settings();
    $wallet = ccjv_wallet_for_user($uid);

    $out = '<div class="ccjv-av-box"><h2>Avalanche Balances</h2><p>Wallet: ' . esc_html($wallet ?: 'Not bound') . '</p><div class="ccjv-av-grid">';
    foreach ($s['tokens'] as $symbol => $contract) {
        $bal = $wallet ? ccjv_erc20_balance($wallet, $contract) : 0;
        $out .= '<div class="ccjv-av-card"><strong>' . esc_html($symbol) . '</strong><br>' . esc_html($bal) . '</div>';
    }
    return $out . '</div></div>';
});

/* Subscription purchase: enforce real on-chain balance before allowing purchase */
add_shortcode('ccjv_avalanche_subscribe', function () {
    if (!is_user_logged_in()) return '<p>Please log in.</p>';

    $uid = get_current_user_id();
    $s = ccjv_avax_settings();
    $msg = '';

    if (isset($_POST['ccjv_av_buy'])) {
        $erp = sanitize_key($_POST['erp'] ?? '');
        $module = sanitize_key($_POST['module'] ?? '');
        $p = $s['module_prices'][$erp][$module] ?? null;

        if (!$p) {
            $msg = '<div class="ccjv-av-err">No price configured.</div>';
        } else {
            $token = strtoupper($p['token']);
            $fee = (float)$p['fee'];
            $bal = ccjv_avalanche_token_balance($uid, $token);

            if ($bal < $fee) {
                $msg = '<div class="ccjv-av-err">Insufficient on-chain ' . esc_html($token) . '. Required ' . esc_html($fee) . ', wallet has ' . esc_html($bal) . '.</div>';
            } else {
                // For now: balance-gated activation. Real transfer-to-treasury verification comes next.
                global $wpdb;
                $expires = date('Y-m-d H:i:s', strtotime('+' . intval($s['duration_days']) . ' days'));
                $wpdb->insert($wpdb->prefix . 'ccjv_subscriptions', [
                    'user_id' => $uid,
                    'erp' => $erp,
                    'module' => $module,
                    'status' => 'active',
                    'expires_at' => $expires,
                ]);
                ccjv_avalanche_log($uid, $token, $erp, $module, 'balance_verified_subscription', $fee, '', 'Activated after on-chain balance check');
                $msg = '<div class="ccjv-av-ok">Activated ' . esc_html($erp) . ' / ' . esc_html($module) . ' until ' . esc_html($expires) . '.</div>';
            }
        }
    }

    ob_start(); ?>
    <div class="ccjv-av-box">
        <h2>Subscribe with Avalanche Token Balance</h2>
        <?php echo $msg; ?>
        <form method="post">
            <label>ERP</label>
            <select name="erp" id="ccjvAvErp"></select>
            <label>Module</label>
            <select name="module" id="ccjvAvModule"></select>
            <button class="ccjv-av-btn" name="ccjv_av_buy">Verify Balance + Activate</button>
        </form>
    </div>
    <script>
    const avPrices = <?php echo wp_json_encode($s['module_prices']); ?>;
    const avErp = document.getElementById('ccjvAvErp');
    const avMod = document.getElementById('ccjvAvModule');
    Object.keys(avPrices).forEach(e => {
        const o = document.createElement('option'); o.value=e; o.textContent=e; avErp.appendChild(o);
    });
    function loadAvMods(){
        avMod.innerHTML='';
        Object.keys(avPrices[avErp.value]).forEach(m => {
            const p = avPrices[avErp.value][m];
            const o = document.createElement('option');
            o.value=m; o.textContent=m + ' — ' + p.fee + ' ' + p.token + '/month';
            avMod.appendChild(o);
        });
    }
    avErp.addEventListener('change', loadAvMods); loadAvMods();
    </script>
    <?php return ob_get_clean();
});

/* Soft override for old enforcement function if PHP loads this later */
if (!function_exists('ccjv_get_wallet_balance')) {
    function ccjv_get_wallet_balance($user_id, $token) {
        return ccjv_avalanche_token_balance($user_id, $token);
    }
}

add_action('wp_head', function () { ?>
<style>
.ccjv-av-box{max-width:960px;margin:20px auto;padding:22px;border-radius:18px;background:#0f172a;color:#fff;font-family:Arial,sans-serif}
.ccjv-av-box label{display:block;margin-top:14px;font-weight:bold}
.ccjv-av-box select,.ccjv-av-box input{width:100%;padding:12px;border-radius:10px;margin-top:6px}
.ccjv-av-btn{margin-top:18px;padding:12px 18px;border:0;border-radius:12px;background:#38bdf8;color:#00111d;font-weight:800}
.ccjv-av-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(120px,1fr));gap:12px}
.ccjv-av-card{background:#111827;padding:14px;border-radius:12px}
.ccjv-av-ok{background:#14532d;padding:12px;border-radius:10px;margin:12px 0}
.ccjv-av-err{background:#7f1d1d;padding:12px;border-radius:10px;margin:12px 0}
</style>
<?php });
