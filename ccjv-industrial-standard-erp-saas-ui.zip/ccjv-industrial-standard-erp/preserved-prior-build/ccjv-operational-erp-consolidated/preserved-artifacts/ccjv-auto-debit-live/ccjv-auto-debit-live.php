<?php
/*
Plugin Name: CCJV Auto Debit LIVE
*/
add_action('init','ccjv_run_billing');
function ccjv_run_billing(){
 $users = get_users();
 foreach($users as $u){
  $wallet = get_user_meta($u->ID,'ccjv_wallet',true);
  if(!$wallet) continue;
  wp_remote_post(get_option('ccjv_signer_url').'/transfer',[
   'body'=>json_encode([
    'from'=>$wallet,
    'to'=>get_option('ccjv_treasury_wallet'),
    'token'=>'CJV',
    'amount'=>0.01
   ])
  ]);
 }
}
