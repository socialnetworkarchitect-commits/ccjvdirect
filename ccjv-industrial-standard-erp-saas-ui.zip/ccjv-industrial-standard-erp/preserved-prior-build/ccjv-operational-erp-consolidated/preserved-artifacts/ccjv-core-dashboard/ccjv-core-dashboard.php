<?php
/*
Plugin Name: CCJV Core Dashboard (ERP Launcher + Status + Vault)
Description: Frontend dashboard with ERP launcher, wallet/token/payment status, and vault viewer.
Version: 1.0.0
*/

if (!defined('ABSPATH')) exit;

/* ---------- Helpers ---------- */

function ccjv_dash_get_wallet($user_id){
    return get_user_meta($user_id, 'ccjv_wallet', true);
}

function ccjv_dash_get_tenant($user_id){
    return get_user_meta($user_id, 'ccjv_tenant', true);
}

function ccjv_dash_get_signer(){
    return get_option('ccjv_signer_url', 'http://localhost:3001');
}

function ccjv_dash_token_balance($wallet, $symbol){
    if (!$wallet) return 0;
    $url = ccjv_dash_get_signer() . "/balance?wallet={$wallet}&token={$symbol}";
    $res = wp_remote_get($url, ['timeout'=>5]);
    if (is_wp_error($res)) return 0;
    $body = json_decode(wp_remote_retrieve_body($res), true);
    return floatval($body['balance'] ?? 0);
}

function ccjv_dash_is_paid($user_id, $erp){
    global $wpdb;
    $table = $wpdb->prefix . "ccjv_subscriptions";
    $row = $wpdb->get_row($wpdb->prepare(
        "SELECT * FROM $table WHERE user_id=%d AND erp=%s",
        $user_id, $erp
    ));
    if (!$row) return false;
    return (strtotime($row->expires_at) > time());
}

/* ---------- ERP Map ---------- */

function ccjv_dash_erps(){
    return [
        'iter' => [
            'name' => 'Iter ERP',
            'symbol' => 'ITC',
            'portal' => '/iter-portal',
            'app' => '/iter-app'
        ],
        'cibus' => [
            'name' => 'Cibus ERP',
            'symbol' => 'CIB',
            'portal' => '/cibus-portal',
            'app' => '/cibus-app'
        ],
        'surge' => [
            'name' => 'Surge Symposia',
            'symbol' => 'SYS',
            'portal' => '/surge-portal',
            'app' => '/surge-app'
        ]
    ];
}

/* ---------- Shortcode ---------- */

add_shortcode('ccjv_core_dashboard', function(){

    if (!is_user_logged_in()){
        return '<p>Please login.</p>';
    }

    $user_id = get_current_user_id();
    $wallet = ccjv_dash_get_wallet($user_id);
    $tenant = ccjv_dash_get_tenant($user_id);

    ob_start();
    ?>
    <style>
    .ccjv-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(280px,1fr));gap:16px}
    .ccjv-card{border:1px solid #ddd;padding:16px;border-radius:10px;background:#fff}
    .ccjv-card h3{margin-top:0}
    .ccjv-badge{display:inline-block;padding:4px 8px;border-radius:6px;background:#eef;margin-right:6px}
    .ccjv-ok{background:#d4edda}
    .ccjv-bad{background:#f8d7da}
    .ccjv-actions a{display:inline-block;margin-right:8px;margin-top:8px}
    .ccjv-section{margin-bottom:24px}
    </style>

    <div class="ccjv-section">
        <h2>Account</h2>
        <p><strong>Wallet:</strong> <?php echo esc_html($wallet ?: 'Not connected'); ?></p>
        <p><strong>Tenant:</strong> <?php echo esc_html($tenant ?: 'Not created'); ?></p>
    </div>

    <div class="ccjv-section">
        <h2>Token Balances</h2>
        <?php if ($wallet): ?>
            <p>SYS: <?php echo ccjv_dash_token_balance($wallet,'SYS'); ?></p>
            <p>ITC: <?php echo ccjv_dash_token_balance($wallet,'ITC'); ?></p>
            <p>CIB: <?php echo ccjv_dash_token_balance($wallet,'CIB'); ?></p>
        <?php else: ?>
            <p>Connect wallet to view balances.</p>
        <?php endif; ?>
    </div>

    <div class="ccjv-section">
        <h2>ERP Launcher</h2>
        <div class="ccjv-grid">
            <?php foreach (ccjv_dash_erps() as $key => $erp):
                $paid = ccjv_dash_is_paid($user_id, $key);
                $balance = $wallet ? ccjv_dash_token_balance($wallet, $erp['symbol']) : 0;
                $threshold = get_option('ccjv_gate_'.$erp['symbol'], 1);
                $has_token = $balance >= $threshold;
                ?>
                <div class="ccjv-card">
                    <h3><?php echo esc_html($erp['name']); ?></h3>

                    <div>
                        <span class="ccjv-badge <?php echo $wallet ? 'ccjv-ok':'ccjv-bad'; ?>">
                            Wallet
                        </span>
                        <span class="ccjv-badge <?php echo $has_token ? 'ccjv-ok':'ccjv-bad'; ?>">
                            Token
                        </span>
                        <span class="ccjv-badge <?php echo $paid ? 'ccjv-ok':'ccjv-bad'; ?>">
                            Payment
                        </span>
                        <span class="ccjv-badge <?php echo $tenant ? 'ccjv-ok':'ccjv-bad'; ?>">
                            Tenant
                        </span>
                    </div>

                    <div class="ccjv-actions">
                        <a class="button" href="<?php echo esc_url(home_url($erp['portal'])); ?>">Portal</a>
                        <a class="button button-primary" href="<?php echo esc_url(home_url($erp['app'])); ?>">Launch ERP</a>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>

    <div class="ccjv-section">
        <h2>Vault</h2>
        <?php echo do_shortcode('[ccjv_vault_list]'); ?>
    </div>

    <?php
    return ob_get_clean();
});
