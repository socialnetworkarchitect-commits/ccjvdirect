<?php
/*
Plugin Name: CCJV 39 Sector Scale Pack (Bootstrapless Clean)
Description: Bootstrapless registry, switcher, and settings for 39 sector ERPs.
Version: 1.0.0
Author: OpenAI
*/

if (!defined('ABSPATH')) exit;

if (!function_exists('ccjv_39_sector_map_bless')) {
    function ccjv_39_sector_map_bless() {
        return [
            ['slug'=>'energychain','label'=>'EnergyChain ERP','token'=>'ENRC','group'=>'core-infra'],
            ['slug'=>'cibus','label'=>'Cibus ERP','token'=>'CIB','group'=>'core-infra'],
            ['slug'=>'aquacoin','label'=>'AquaCoin ERP','token'=>'AQUA','group'=>'core-infra'],
            ['slug'=>'landbank','label'=>'LandBank ERP','token'=>'LAND','group'=>'core-infra'],
            ['slug'=>'educatio','label'=>'Educatio ERP','token'=>'EDU','group'=>'core-infra'],
            ['slug'=>'vehiculum','label'=>'Vehiculum ERP','token'=>'VEH','group'=>'core-infra'],
            ['slug'=>'impensa','label'=>'Impensa ERP','token'=>'IMP','group'=>'core-infra'],
            ['slug'=>'manufactura','label'=>'Manufactura ERP','token'=>'MFG','group'=>'core-infra'],
            ['slug'=>'datum','label'=>'Datum ERP','token'=>'DATA','group'=>'core-infra'],
            ['slug'=>'tvyou','label'=>'TVYou ERP','token'=>'TVY','group'=>'core-infra'],
            ['slug'=>'workersfirst','label'=>'Workers First ERP','token'=>'WRK','group'=>'industry'],
            ['slug'=>'plasticus','label'=>'Plasticus ERP','token'=>'PLS','group'=>'industry'],
            ['slug'=>'constructum','label'=>'Constructum ERP','token'=>'CST','group'=>'industry'],
            ['slug'=>'iter','label'=>'Iter ERP','token'=>'ITC','group'=>'industry'],
            ['slug'=>'surge','label'=>'Surge ERP','token'=>'SYS','group'=>'industry'],
            ['slug'=>'qing','label'=>'Qing ERP','token'=>'QNG','group'=>'industry'],
            ['slug'=>'altacoin','label'=>'Altacoin ERP','token'=>'ALT','group'=>'industry'],
            ['slug'=>'spacecoin','label'=>'SpaceCoin ERP','token'=>'SPC','group'=>'industry'],
            ['slug'=>'hydrogen','label'=>'Hydrogen ERP','token'=>'H2C','group'=>'industry'],
            ['slug'=>'thorium','label'=>'Thorium ERP','token'=>'THR','group'=>'industry'],
            ['slug'=>'logistica','label'=>'Logistica ERP','token'=>'LOG','group'=>'transport'],
            ['slug'=>'portum','label'=>'Portum ERP','token'=>'PRT','group'=>'transport'],
            ['slug'=>'desal','label'=>'Desal ERP','token'=>'DSL','group'=>'transport'],
            ['slug'=>'railchain','label'=>'RailChain ERP','token'=>'RLC','group'=>'transport'],
            ['slug'=>'aeros','label'=>'Aeros ERP','token'=>'AER','group'=>'transport'],
            ['slug'=>'luna','label'=>'Luna ERP','token'=>'LUNA','group'=>'transport'],
            ['slug'=>'agricola','label'=>'Agricola ERP','token'=>'AGR','group'=>'transport'],
            ['slug'=>'medica','label'=>'Medica ERP','token'=>'MED','group'=>'transport'],
            ['slug'=>'habitat','label'=>'Habitat ERP','token'=>'HAB','group'=>'transport'],
            ['slug'=>'retailium','label'=>'Retailium ERP','token'=>'RTL','group'=>'transport'],
            ['slug'=>'financia','label'=>'Financia ERP','token'=>'FIN','group'=>'civic'],
            ['slug'=>'legalis','label'=>'Legalis ERP','token'=>'LGL','group'=>'civic'],
            ['slug'=>'minera','label'=>'Minera ERP','token'=>'MIN','group'=>'civic'],
            ['slug'=>'petra','label'=>'Petra ERP','token'=>'PET','group'=>'civic'],
            ['slug'=>'securus','label'=>'Securus ERP','token'=>'SEC','group'=>'civic'],
            ['slug'=>'tourismo','label'=>'Tourismo ERP','token'=>'TOUR','group'=>'civic'],
            ['slug'=>'civitas','label'=>'Civitas ERP','token'=>'CIV','group'=>'civic'],
            ['slug'=>'firstpeoples','label'=>'First Peoples ERP','token'=>'FPT','group'=>'civic'],
            ['slug'=>'omnichain','label'=>'Omnichain ERP','token'=>'OMC','group'=>'civic'],
        ];
    }
}

register_activation_hook(__FILE__, function () {
    foreach (ccjv_39_sector_map_bless() as $sector) {
        add_option('ccjv_enable_' . $sector['slug'], 1);
        add_option($sector['slug'] . '_token_symbol', $sector['token']);
        add_option('ccjv_gate_' . $sector['token'], 1);
        add_option('ccjv_' . $sector['slug'] . '_portal_slug', $sector['slug'] . '-portal');
        add_option('ccjv_' . $sector['slug'] . '_app_slug', $sector['slug'] . '-app');
        add_option('ccjv_' . $sector['slug'] . '_buy_url', home_url('/buy-token'));
    }
});

add_shortcode('ccjv_39_sector_switcher', function () {
    if (!is_user_logged_in()) return '<p>Please log in.</p>';
    $wallet = get_user_meta(get_current_user_id(), 'ccjv_wallet', true);
    $tenant = get_user_meta(get_current_user_id(), 'ccjv_tenant', true);
    $search = isset($_GET['ccjv_sector_search']) ? sanitize_text_field(wp_unslash($_GET['ccjv_sector_search'])) : '';
    $group = isset($_GET['ccjv_sector_group']) ? sanitize_text_field(wp_unslash($_GET['ccjv_sector_group'])) : 'all';
    $groups = [];
    foreach (ccjv_39_sector_map_bless() as $sector) $groups[$sector['group']] = true;
    ksort($groups);

    ob_start(); ?>
    <style>
    .ccjv-39-wrap{max-width:1320px;margin:0 auto;padding:24px}.ccjv-39-top,.ccjv-39-grid{display:grid;gap:20px}.ccjv-39-top{grid-template-columns:1.2fr .8fr;margin-bottom:20px}.ccjv-39-grid{grid-template-columns:repeat(3,minmax(0,1fr))}.ccjv-39-card{background:#fff;border:1px solid #ddd;border-radius:16px;padding:18px;box-shadow:0 8px 24px rgba(0,0,0,.04)}@media (max-width:1000px){.ccjv-39-top,.ccjv-39-grid{grid-template-columns:1fr}}
    </style>
    <div class="ccjv-39-wrap">
        <div class="ccjv-39-top">
            <div class="ccjv-39-card"><h2>39 Sector ERP Switcher</h2><p><strong>Wallet:</strong> <?php echo esc_html($wallet ?: 'Not connected'); ?></p><p><strong>Tenant:</strong> <?php echo esc_html($tenant ?: 'Not created'); ?></p></div>
            <div class="ccjv-39-card">
                <h3>Filter</h3>
                <form method="get">
                    <p><input type="text" name="ccjv_sector_search" value="<?php echo esc_attr($search); ?>" placeholder="Search ERP or token" class="regular-text"></p>
                    <p><select name="ccjv_sector_group"><option value="all">All Groups</option><?php foreach ($groups as $g => $dummy): ?><option value="<?php echo esc_attr($g); ?>" <?php selected($group,$g); ?>><?php echo esc_html(ucfirst($g)); ?></option><?php endforeach; ?></select></p>
                    <p><button class="button button-primary">Apply</button></p>
                </form>
            </div>
        </div>
        <div class="ccjv-39-grid">
            <?php foreach (ccjv_39_sector_map_bless() as $sector):
                if (!get_option('ccjv_enable_' . $sector['slug'], 1)) continue;
                if ($group !== 'all' && $sector['group'] !== $group) continue;
                if ($search && stripos($sector['label'].' '.$sector['token'].' '.$sector['slug'], $search) === false) continue;
                $token = get_option($sector['slug'] . '_token_symbol', $sector['token']);
                $buy = get_option('ccjv_' . $sector['slug'] . '_buy_url', home_url('/buy-token'));
                ?>
                <div class="ccjv-39-card">
                    <h3><?php echo esc_html($sector['label']); ?></h3>
                    <p><strong>Token:</strong> <?php echo esc_html($token); ?></p>
                    <p><strong>Group:</strong> <?php echo esc_html($sector['group']); ?></p>
                    <p><strong>Portal:</strong> /<?php echo esc_html(get_option('ccjv_' . $sector['slug'] . '_portal_slug', $sector['slug'] . '-portal')); ?></p>
                    <p><a class="button" href="<?php echo esc_url(home_url('/' . get_option('ccjv_' . $sector['slug'] . '_portal_slug', $sector['slug'] . '-portal'))); ?>">Open Portal</a> <a class="button" href="<?php echo esc_url($buy); ?>">Get <?php echo esc_html($token); ?></a></p>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
    <?php return ob_get_clean();
});

add_action('admin_menu', function () {
    add_submenu_page(
        'ccjv-command-center',
        '39 Sector Scale',
        '39 Sector Scale',
        'manage_options',
        'ccjv-39-sector-scale',
        function () {
            if ($_SERVER['REQUEST_METHOD'] === 'POST' && !empty($_POST['ccjv_39_save'])) {
                check_admin_referer('ccjv_39_save');
                foreach (ccjv_39_sector_map_bless() as $sector) {
                    $slug = $sector['slug'];
                    update_option('ccjv_enable_' . $slug, !empty($_POST['enabled'][$slug]) ? 1 : 0);
                    update_option($slug . '_token_symbol', sanitize_text_field(wp_unslash($_POST['token'][$slug] ?? $sector['token'])));
                    update_option('ccjv_gate_' . sanitize_text_field(wp_unslash($_POST['token'][$slug] ?? $sector['token'])), (float)($_POST['gate'][$slug] ?? 1));
                    update_option('ccjv_' . $slug . '_portal_slug', sanitize_title(wp_unslash($_POST['portal'][$slug] ?? ($slug . '-portal'))));
                    update_option('ccjv_' . $slug . '_app_slug', sanitize_title(wp_unslash($_POST['app'][$slug] ?? ($slug . '-app'))));
                    update_option('ccjv_' . $slug . '_buy_url', esc_url_raw(wp_unslash($_POST['buy'][$slug] ?? home_url('/buy-token'))));
                }
                echo '<div class="notice notice-success"><p>39 sector registry settings saved.</p></div>';
            }
            ?>
            <div class="wrap">
                <h1>39 Sector Scale Pack</h1>
                <p><strong>Front-end shortcode:</strong> <code>[ccjv_39_sector_switcher]</code></p>
                <form method="post">
                    <?php wp_nonce_field('ccjv_39_save'); ?>
                    <table class="widefat striped">
                        <thead><tr><th>Enable</th><th>Sector</th><th>Token</th><th>Gate</th><th>Portal Slug</th><th>App Slug</th><th>Buy URL</th><th>Group</th></tr></thead>
                        <tbody>
                        <?php foreach (ccjv_39_sector_map_bless() as $sector):
                            $slug = $sector['slug'];
                            $token = get_option($slug . '_token_symbol', $sector['token']); ?>
                            <tr>
                                <td><input type="checkbox" name="enabled[<?php echo esc_attr($slug); ?>]" value="1" <?php checked(1, get_option('ccjv_enable_' . $slug, 1)); ?>></td>
                                <td><?php echo esc_html($sector['label']); ?><br><code><?php echo esc_html($slug); ?></code></td>
                                <td><input type="text" name="token[<?php echo esc_attr($slug); ?>]" value="<?php echo esc_attr($token); ?>" class="small-text"></td>
                                <td><input type="number" step="0.00000001" name="gate[<?php echo esc_attr($slug); ?>]" value="<?php echo esc_attr(get_option('ccjv_gate_' . $token, 1)); ?>" class="small-text"></td>
                                <td><input type="text" name="portal[<?php echo esc_attr($slug); ?>]" value="<?php echo esc_attr(get_option('ccjv_' . $slug . '_portal_slug', $slug . '-portal')); ?>"></td>
                                <td><input type="text" name="app[<?php echo esc_attr($slug); ?>]" value="<?php echo esc_attr(get_option('ccjv_' . $slug . '_app_slug', $slug . '-app')); ?>"></td>
                                <td><input type="url" name="buy[<?php echo esc_attr($slug); ?>]" value="<?php echo esc_attr(get_option('ccjv_' . $slug . '_buy_url', home_url('/buy-token'))); ?>" style="width:220px"></td>
                                <td><?php echo esc_html($sector['group']); ?></td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                    <p><button class="button button-primary" name="ccjv_39_save" value="1">Save 39 Sector Registry</button></p>
                </form>
            </div>
            <?php
        }
    );
}, 160);
