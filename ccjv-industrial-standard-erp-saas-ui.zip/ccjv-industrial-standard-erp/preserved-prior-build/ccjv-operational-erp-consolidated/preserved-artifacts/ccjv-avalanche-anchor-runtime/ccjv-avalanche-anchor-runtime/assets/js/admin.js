window.CCJVRuntime = { slug: 'ccjv-avalanche-anchor-runtime', status: 'loaded' };
