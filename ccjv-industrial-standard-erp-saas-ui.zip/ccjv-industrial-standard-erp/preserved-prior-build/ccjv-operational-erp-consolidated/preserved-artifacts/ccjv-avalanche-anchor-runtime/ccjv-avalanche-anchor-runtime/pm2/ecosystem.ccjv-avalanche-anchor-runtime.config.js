module.exports = { apps: [{ name: 'ccjv-avalanche-anchor-runtime-worker', script: './workers/ccjv-avalanche-anchor-runtime-worker.js' }] };
