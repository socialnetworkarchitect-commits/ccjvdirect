<?php
/**
 * Plugin Name: CCJV Avalanche Anchor Runtime
 * Description: Operational CCJV subsystem package: merkle_batching, anchor_queue, tx_hash_persistence, snowtrace_verification, qr_proofs.
 * Version: 1.0.0
 * Author: CCJV
 */
if (!defined('ABSPATH')) { exit; }
define('CCJV_AVALANCHEANCHORRUNTIME_PATH', plugin_dir_path(__FILE__));
define('CCJV_AVALANCHEANCHORRUNTIME_URL', plugin_dir_url(__FILE__));
define('CCJV_AVALANCHEANCHORRUNTIME_VERSION', '1.0.0');
require_once CCJV_AVALANCHEANCHORRUNTIME_PATH . 'includes/class-runtime.php';
register_activation_hook(__FILE__, array('CCJV_AvalancheAnchorRuntime', 'activate'));
register_deactivation_hook(__FILE__, array('CCJV_AvalancheAnchorRuntime', 'deactivate'));
add_action('plugins_loaded', array('CCJV_AvalancheAnchorRuntime', 'boot'));
