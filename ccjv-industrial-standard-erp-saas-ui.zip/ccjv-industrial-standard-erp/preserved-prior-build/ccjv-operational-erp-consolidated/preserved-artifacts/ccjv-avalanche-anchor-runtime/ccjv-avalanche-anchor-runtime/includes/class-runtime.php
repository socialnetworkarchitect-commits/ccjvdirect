<?php
if (!defined('ABSPATH')) { exit; }
class CCJV_AvalancheAnchorRuntime {
    public static function features() { return array('merkle_batching','anchor_queue','tx_hash_persistence','snowtrace_verification','qr_proofs'); }
    public static function activate() { self::create_tables(); update_option('ccjv-avalanche-anchor-runtime_activated_at', gmdate('c')); update_option('ccjv-avalanche-anchor-runtime_features', self::features()); }
    public static function deactivate() { update_option('ccjv-avalanche-anchor-runtime_deactivated_at', gmdate('c')); }
    public static function boot() { add_action('rest_api_init', array(__CLASS__, 'routes')); add_action('admin_menu', array(__CLASS__, 'admin_menu')); }
    public static function routes() {
        register_rest_route('ccjv/v1', '/ccjv-avalanche-anchor-runtime/status', array('methods'=>'GET','callback'=>array(__CLASS__,'status'),'permission_callback'=>'__return_true'));
        register_rest_route('ccjv/v1', '/ccjv-avalanche-anchor-runtime/event', array('methods'=>'POST','callback'=>array(__CLASS__,'event'),'permission_callback'=>'__return_true'));
    }
    public static function status() { return array('runtime'=>'CCJV Avalanche Anchor Runtime','slug'=>'ccjv-avalanche-anchor-runtime','version'=>'1.0.0','status'=>'operational','features'=>self::features()); }
    public static function event($request) {
        global $wpdb; $p=$request->get_json_params();
        $tenant=sanitize_text_field($p['tenant_id'] ?? 'default'); $workspace=sanitize_text_field($p['workspace_id'] ?? 'main');
        $type=sanitize_text_field($p['event_type'] ?? 'runtime_event'); $payload=wp_json_encode($p['payload'] ?? array());
        $correlation=sanitize_text_field($p['correlation_id'] ?? wp_generate_uuid4()); $replay=sanitize_text_field($p['replay_id'] ?? wp_generate_uuid4()); $hash=hash('sha256',$payload);
        $wpdb->insert($wpdb->prefix.'ccjv_runtime_events', array('runtime_slug'=>'ccjv-avalanche-anchor-runtime','tenant_id'=>$tenant,'workspace_id'=>$workspace,'event_type'=>$type,'correlation_id'=>$correlation,'replay_id'=>$replay,'payload_hash'=>$hash,'payload'=>$payload));
        return array('ok'=>true,'runtime'=>'ccjv-avalanche-anchor-runtime','correlation_id'=>$correlation,'replay_id'=>$replay,'payload_hash'=>$hash);
    }
    public static function admin_menu() { add_menu_page('CCJV Avalanche Anchor Runtime', 'CCJV Avalanche Anchor Runtime', 'manage_options', 'ccjv-avalanche-anchor-runtime', array(__CLASS__, 'admin_page'), 'dashicons-networking', 58); }
    public static function admin_page() { echo '<div class="wrap"><h1>CCJV Avalanche Anchor Runtime</h1><p>Status: operational</p><pre>'.esc_html(wp_json_encode(self::features(), JSON_PRETTY_PRINT)).'</pre></div>'; }
    private static function create_tables() {
        global $wpdb; require_once ABSPATH . 'wp-admin/includes/upgrade.php'; $charset=$wpdb->get_charset_collate();
        dbDelta("CREATE TABLE {$wpdb->prefix}ccjv_runtime_events (id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,runtime_slug VARCHAR(128) NOT NULL,tenant_id VARCHAR(128) NOT NULL,workspace_id VARCHAR(128) NOT NULL,event_type VARCHAR(128) NOT NULL,correlation_id VARCHAR(128) NOT NULL,replay_id VARCHAR(128) NOT NULL,payload_hash VARCHAR(128) NULL,payload LONGTEXT NULL,created_at DATETIME DEFAULT CURRENT_TIMESTAMP,PRIMARY KEY(id),KEY runtime_slug (runtime_slug),KEY tenant_id (tenant_id),KEY correlation_id (correlation_id)) $charset;");
        dbDelta("CREATE TABLE {$wpdb->prefix}ccjv_runtime_ledger (id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,runtime_slug VARCHAR(128) NOT NULL,tenant_id VARCHAR(128) NOT NULL,ledger_type VARCHAR(128) NOT NULL,amount DECIMAL(36,18) DEFAULT 0,token_address VARCHAR(128) NULL,wallet_address VARCHAR(128) NULL,tx_hash VARCHAR(128) NULL,replay_id VARCHAR(128) NULL,status VARCHAR(64) DEFAULT 'recorded',created_at DATETIME DEFAULT CURRENT_TIMESTAMP,PRIMARY KEY(id),KEY runtime_slug (runtime_slug),KEY tenant_id (tenant_id),KEY ledger_type (ledger_type)) $charset;");
    }
}
