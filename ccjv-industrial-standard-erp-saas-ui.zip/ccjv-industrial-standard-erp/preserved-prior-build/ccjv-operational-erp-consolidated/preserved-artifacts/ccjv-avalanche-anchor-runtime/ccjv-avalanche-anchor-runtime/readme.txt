CCJV Avalanche Anchor Runtime

Install:
1. Upload ccjv-avalanche-anchor-runtime.zip in WordPress Plugins > Add New > Upload Plugin.
2. Activate.
3. Verify /wp-json/ccjv/v1/ccjv-avalanche-anchor-runtime/status.
4. Optional PM2 worker: pm2 start pm2/ecosystem.ccjv-avalanche-anchor-runtime.config.js

No shebang/interpreter lines are included.
