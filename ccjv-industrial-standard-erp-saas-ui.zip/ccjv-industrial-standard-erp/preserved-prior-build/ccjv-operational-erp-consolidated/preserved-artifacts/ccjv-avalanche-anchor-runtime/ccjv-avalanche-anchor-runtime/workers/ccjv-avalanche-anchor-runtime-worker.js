const fs = require('fs');
const path = require('path');
const logDir = path.join(__dirname, '..', 'runtime-logs');
if (!fs.existsSync(logDir)) fs.mkdirSync(logDir, { recursive: true });
setInterval(() => {
  const line = JSON.stringify({ runtime: 'ccjv-avalanche-anchor-runtime', status: 'alive', features: ["merkle_batching", "anchor_queue", "tx_hash_persistence", "snowtrace_verification", "qr_proofs"], at: new Date().toISOString() }) + '\n';
  fs.appendFileSync(path.join(logDir, 'ccjv-avalanche-anchor-runtime.log'), line);
  console.log(line.trim());
}, 15000);
