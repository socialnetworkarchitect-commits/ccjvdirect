<?php
/*
Plugin Name: CCJV Token Gate Core V4
Description: Premium CCJV shell with signed wallet verification, workspace routing, token gating, kanban, charts, front-end forms, and ERP add-on registration.
Version: 4.0.0
Author: OpenAI
*/
if (!defined('ABSPATH')) exit;

class CCJV_Token_Gate_Core_V4 {
    const OPT_KEY = 'ccjv_v4_settings';
    const NONCE_ACTION = 'ccjv_v4_nonce';

    public function __construct() {
        register_activation_hook(__FILE__, [$this, 'activate']);
        add_action('init', [$this, 'register_post_types']);
        add_action('admin_menu', [$this, 'admin_menu']);
        add_action('admin_init', [$this, 'register_settings']);
        add_action('admin_enqueue_scripts', [$this, 'admin_assets']);
        add_action('wp_enqueue_scripts', [$this, 'frontend_assets']);
        add_shortcode('ccjv_shell_v4', [$this, 'render_shell']);
        add_shortcode('ccjv_token_gate', [$this, 'render_shell']);
        add_action('rest_api_init', [$this, 'rest_routes']);
        add_action('add_meta_boxes', [$this, 'meta_boxes']);
        add_action('save_post_ccjv_invoice', [$this, 'save_invoice_meta']);
        add_filter('the_content', [$this, 'maybe_wrap_workspace_page']);
    }

    public function activate() {
        $this->register_post_types();
        flush_rewrite_rules();
        global $wpdb;
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        $charset = $wpdb->get_charset_collate();
        $prefix = $wpdb->prefix . 'ccjv_';

        $sql = [];
        $sql[] = "CREATE TABLE {$prefix}workspaces (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            slug VARCHAR(80) NOT NULL,
            name VARCHAR(120) NOT NULL,
            erp_plugin_slug VARCHAR(120) DEFAULT '',
            description TEXT,
            token_symbol VARCHAR(20) DEFAULT '',
            token_contract VARCHAR(120) DEFAULT '',
            token_decimals INT DEFAULT 18,
            token_threshold DECIMAL(36,18) DEFAULT 1,
            accent_color VARCHAR(20) DEFAULT '#2563eb',
            hero_title VARCHAR(255) DEFAULT '',
            hero_subtitle TEXT,
            buy_url VARCHAR(255) DEFAULT '',
            dashboard_skin VARCHAR(60) DEFAULT 'default',
            is_enabled TINYINT DEFAULT 1,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id), UNIQUE KEY slug (slug)
        ) $charset";
        $sql[] = "CREATE TABLE {$prefix}wallets (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            user_id BIGINT UNSIGNED DEFAULT NULL,
            wallet_address VARCHAR(120) NOT NULL,
            chain_id VARCHAR(20) DEFAULT '43114',
            signature LONGTEXT,
            signed_message LONGTEXT,
            verification_status VARCHAR(20) DEFAULT 'pending',
            last_verified_at DATETIME NULL,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id), UNIQUE KEY wallet_address (wallet_address)
        ) $charset";
        $sql[] = "CREATE TABLE {$prefix}workspace_access (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            user_id BIGINT UNSIGNED NOT NULL,
            workspace_slug VARCHAR(80) NOT NULL,
            role_key VARCHAR(50) DEFAULT 'viewer',
            token_override TINYINT DEFAULT 0,
            can_create TINYINT DEFAULT 0,
            can_edit TINYINT DEFAULT 0,
            can_delete TINYINT DEFAULT 0,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id), UNIQUE KEY user_workspace (user_id, workspace_slug)
        ) $charset";
        $sql[] = "CREATE TABLE {$prefix}ventures (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            title VARCHAR(190) NOT NULL,
            slug VARCHAR(120) NOT NULL,
            workspace_slug VARCHAR(80) DEFAULT '',
            linked_workspaces LONGTEXT,
            status VARCHAR(40) DEFAULT 'active',
            description LONGTEXT,
            owner_user_id BIGINT UNSIGNED DEFAULT NULL,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id), UNIQUE KEY slug (slug)
        ) $charset";
        $sql[] = "CREATE TABLE {$prefix}kanban_tasks (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            title VARCHAR(190) NOT NULL,
            venture_id BIGINT UNSIGNED DEFAULT NULL,
            workspace_slug VARCHAR(80) DEFAULT '',
            board_column VARCHAR(40) DEFAULT 'todo',
            due_date DATE NULL,
            assignee_user_id BIGINT UNSIGNED DEFAULT NULL,
            dependency_task_id BIGINT UNSIGNED DEFAULT NULL,
            progress INT DEFAULT 0,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id)
        ) $charset";
        $sql[] = "CREATE TABLE {$prefix}journal_entries (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            entry_date DATE NOT NULL,
            reference_type VARCHAR(50) DEFAULT '',
            reference_id BIGINT UNSIGNED DEFAULT NULL,
            memo TEXT,
            status VARCHAR(20) DEFAULT 'posted',
            created_by BIGINT UNSIGNED DEFAULT NULL,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id)
        ) $charset";
        $sql[] = "CREATE TABLE {$prefix}journal_lines (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            journal_entry_id BIGINT UNSIGNED NOT NULL,
            account_code VARCHAR(40) NOT NULL,
            workspace_slug VARCHAR(80) DEFAULT '',
            debit DECIMAL(18,2) DEFAULT 0,
            credit DECIMAL(18,2) DEFAULT 0,
            description VARCHAR(255) DEFAULT '',
            PRIMARY KEY (id), KEY jeid (journal_entry_id)
        ) $charset";
        $sql[] = "CREATE TABLE {$prefix}invoice_lines (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            invoice_post_id BIGINT UNSIGNED NOT NULL,
            item_desc VARCHAR(255) DEFAULT '',
            qty DECIMAL(18,2) DEFAULT 1,
            unit_price DECIMAL(18,2) DEFAULT 0,
            tax_rate DECIMAL(6,2) DEFAULT 0,
            line_total DECIMAL(18,2) DEFAULT 0,
            PRIMARY KEY (id), KEY invoice_id (invoice_post_id)
        ) $charset";
        $sql[] = "CREATE TABLE {$prefix}invoice_payments (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            invoice_post_id BIGINT UNSIGNED NOT NULL,
            payment_date DATE NOT NULL,
            amount DECIMAL(18,2) NOT NULL,
            method VARCHAR(40) DEFAULT 'bank',
            reference_no VARCHAR(120) DEFAULT '',
            notes TEXT,
            PRIMARY KEY (id), KEY invoice_id (invoice_post_id)
        ) $charset";

        foreach ($sql as $q) dbDelta($q);

        if (!get_option(self::OPT_KEY)) {
            update_option(self::OPT_KEY, [
                'site_title' => 'CCJV Enterprise Shell',
                'logo_url' => 'http://ccjv.ca/wp-content/uploads/2024/04/ccjv-logo.jpeg',
                'avalanche_chain_id' => '0xa86a',
                'avalanche_chain_name' => 'Avalanche C-Chain',
                'rpc_url' => 'https://api.avax.network/ext/bc/C/rpc',
                'explorer_url' => 'https://snowtrace.io',
                'buy_token_base_url' => '',
                'workspace_page_slug' => 'ccjv-portal',
                'chart_mode' => 'demo',
                'signature_message_prefix' => 'CCJV wallet verification',
            ]);
        }

        $defaults = [
            ['constructum','Constructum','ccjv-constructum-erp','Construction ERP workspace','CST','#c97316','Build, manage, and control construction ventures.','constructum'],
            ['energychain','EnergyChain','ccjv-energychain-erp','Energy ERP workspace','ENRC','#0ea5e9','Track generation, assets, and energy settlements.','energy'],
            ['landbank','LandBank','ccjv-landbank-erp','Land & development workspace','LBC','#3f7c38','Land pipeline, entitlements, and value creation.','land']
        ];
        foreach ($defaults as $row) {
            $exists = $wpdb->get_var($wpdb->prepare("SELECT id FROM {$prefix}workspaces WHERE slug=%s", $row[0]));
            if (!$exists) {
                $wpdb->insert("{$prefix}workspaces", [
                    'slug'=>$row[0],'name'=>$row[1],'erp_plugin_slug'=>$row[2],'description'=>$row[3],
                    'token_symbol'=>$row[4],'accent_color'=>$row[5],'hero_title'=>$row[1],
                    'hero_subtitle'=>$row[6],'dashboard_skin'=>$row[7],'is_enabled'=>1
                ]);
            }
        }
    }

    public function register_post_types() {
        register_post_type('ccjv_invoice', ['label'=>'Invoices','public'=>false,'show_ui'=>true,'supports'=>['title'],'menu_icon'=>'dashicons-media-spreadsheet']);
        register_post_type('ccjv_asset', ['label'=>'Assets','public'=>false,'show_ui'=>true,'supports'=>['title'],'menu_icon'=>'dashicons-hammer']);
        register_post_type('ccjv_project', ['label'=>'Projects','public'=>false,'show_ui'=>true,'supports'=>['title','editor'],'menu_icon'=>'dashicons-clipboard']);
        register_post_type('ccjv_employee', ['label'=>'Employees','public'=>false,'show_ui'=>true,'supports'=>['title'],'menu_icon'=>'dashicons-groups']);
        register_post_type('ccjv_contact', ['label'=>'CRM Contacts','public'=>false,'show_ui'=>true,'supports'=>['title'],'menu_icon'=>'dashicons-id']);
        register_post_type('ccjv_workspace_page', ['label'=>'Workspace Pages','public'=>false,'show_ui'=>true,'supports'=>['title','editor','page-attributes'],'menu_icon'=>'dashicons-layout']);
    }

    public function admin_menu() {
        add_menu_page('CCJV ERP','CCJV ERP','manage_options','ccjv-v4',[$this,'dashboard_page'],'dashicons-chart-area',3);
        add_submenu_page('ccjv-v4','Dashboard','Dashboard','manage_options','ccjv-v4',[$this,'dashboard_page']);
        add_submenu_page('ccjv-v4','Workspaces','Workspaces','manage_options','ccjv-v4-workspaces',[$this,'workspaces_page']);
        add_submenu_page('ccjv-v4','Ventures','Ventures','manage_options','ccjv-v4-ventures',[$this,'ventures_page']);
        add_submenu_page('ccjv-v4','Access Matrix','Access Matrix','manage_options','ccjv-v4-access',[$this,'access_page']);
        add_submenu_page('ccjv-v4','Accounting','Accounting','manage_options','ccjv-v4-accounting',[$this,'accounting_page']);
        add_submenu_page('ccjv-v4','Kanban','Kanban','manage_options','ccjv-v4-kanban',[$this,'kanban_page']);
        add_submenu_page('ccjv-v4','Settings','Settings','manage_options','ccjv-v4-settings',[$this,'settings_page']);
        add_submenu_page('ccjv-v4','Edit Pages','Edit Pages','manage_options','edit.php?post_type=ccjv_workspace_page');
    }

    public function register_settings() {
        register_setting('ccjv_v4_group', self::OPT_KEY);
    }

    public function admin_assets() {
        wp_enqueue_style('ccjv-v4-admin', plugins_url('assets/css/ccjv-v4.css', __FILE__), [], '4.0.0');
    }
    public function frontend_assets() {
        wp_enqueue_style('ccjv-v4-front', plugins_url('assets/css/ccjv-v4.css', __FILE__), [], '4.0.0');
        wp_enqueue_script('chartjs','https://cdn.jsdelivr.net/npm/chart.js',[],null,true);
        wp_enqueue_script('sortablejs','https://cdn.jsdelivr.net/npm/sortablejs@1.15.0/Sortable.min.js',[],null,true);
        wp_enqueue_script('ccjv-v4-front', plugins_url('assets/js/ccjv-v4.js', __FILE__), ['jquery'], '4.0.0', true);
        wp_localize_script('ccjv-v4-front','CCJV_V4',[
            'rest'=>esc_url_raw(rest_url('ccjv/v4/')),
            'nonce'=>wp_create_nonce('wp_rest'),
            'ajaxNonce'=>wp_create_nonce(self::NONCE_ACTION),
            'isLoggedIn'=>is_user_logged_in(),
            'userId'=>get_current_user_id(),
            'settings'=>$this->get_settings(),
        ]);
    }

    private function get_settings() {
        return wp_parse_args((array)get_option(self::OPT_KEY, []), [
            'site_title'=>'CCJV Enterprise Shell','logo_url'=>'','avalanche_chain_id'=>'0xa86a','avalanche_chain_name'=>'Avalanche C-Chain',
            'rpc_url'=>'https://api.avax.network/ext/bc/C/rpc','explorer_url'=>'https://snowtrace.io','buy_token_base_url'=>'','workspace_page_slug'=>'ccjv-portal',
            'chart_mode'=>'demo','signature_message_prefix'=>'CCJV wallet verification'
        ]);
    }

    public function dashboard_page() {
        global $wpdb; $p=$wpdb->prefix.'ccjv_';
        $workspaces=(int)$wpdb->get_var("SELECT COUNT(*) FROM {$p}workspaces WHERE is_enabled=1");
        $ventures=(int)$wpdb->get_var("SELECT COUNT(*) FROM {$p}ventures");
        $tasks=(int)$wpdb->get_var("SELECT COUNT(*) FROM {$p}kanban_tasks");
        $wallets=(int)$wpdb->get_var("SELECT COUNT(*) FROM {$p}wallets WHERE verification_status='verified'");
        echo '<div class="wrap ccjv-admin"><h1>CCJV ERP V4</h1><div class="ccjv-grid ccjv-kpis">';
        foreach ([['Enabled Workspaces',$workspaces],['Ventures',$ventures],['Kanban Tasks',$tasks],['Verified Wallets',$wallets]] as $k) {
            echo '<div class="ccjv-card"><div class="label">'.$k[0].'</div><div class="value">'.$k[1].'</div></div>';
        }
        echo '</div><div class="ccjv-card"><h2>Architecture</h2><p>Core shell + separate ERP plugins + per-workspace token gating + signed wallet verification + front-end access control.</p></div></div>';
    }

    public function workspaces_page() {
        global $wpdb; $t=$wpdb->prefix.'ccjv_workspaces';
        if (!empty($_POST['ccjv_save_workspace']) && check_admin_referer('ccjv_save_workspace')) {
            $data = [
                'slug'=>sanitize_title($_POST['slug']),'name'=>sanitize_text_field($_POST['name']),'erp_plugin_slug'=>sanitize_text_field($_POST['erp_plugin_slug']),
                'description'=>sanitize_textarea_field($_POST['description']),'token_symbol'=>sanitize_text_field($_POST['token_symbol']),
                'token_contract'=>sanitize_text_field($_POST['token_contract']),'token_decimals'=>(int)$_POST['token_decimals'],'token_threshold'=>(float)$_POST['token_threshold'],
                'accent_color'=>sanitize_hex_color($_POST['accent_color']) ?: '#2563eb','hero_title'=>sanitize_text_field($_POST['hero_title']),
                'hero_subtitle'=>sanitize_textarea_field($_POST['hero_subtitle']),'buy_url'=>esc_url_raw($_POST['buy_url']),'dashboard_skin'=>sanitize_text_field($_POST['dashboard_skin']),'is_enabled'=>!empty($_POST['is_enabled'])?1:0,
            ];
            if (!empty($_POST['id'])) $wpdb->update($t, $data, ['id'=>(int)$_POST['id']]); else $wpdb->insert($t, $data);
            echo '<div class="updated"><p>Workspace saved.</p></div>';
        }
        if (!empty($_GET['delete'])) { $wpdb->delete($t,['id'=>(int)$_GET['delete']]); echo '<div class="updated"><p>Workspace deleted.</p></div>'; }
        $edit = !empty($_GET['edit']) ? $wpdb->get_row($wpdb->prepare("SELECT * FROM $t WHERE id=%d", (int)$_GET['edit']), ARRAY_A) : [];
        $rows = $wpdb->get_results("SELECT * FROM $t ORDER BY name ASC", ARRAY_A);
        echo '<div class="wrap ccjv-admin"><h1>Workspaces</h1><div class="ccjv-grid-2"><div class="ccjv-card"><form method="post">'; wp_nonce_field('ccjv_save_workspace');
        echo '<input type="hidden" name="id" value="'.esc_attr($edit['id'] ?? '').'">';
        $fields=['slug','name','erp_plugin_slug','token_symbol','token_contract','token_decimals','token_threshold','accent_color','hero_title','buy_url','dashboard_skin'];
        foreach($fields as $f){ echo '<p><label><strong>'.esc_html($f).'</strong><br><input class="regular-text" name="'.$f.'" value="'.esc_attr($edit[$f] ?? '').'"></label></p>'; }
        echo '<p><label><strong>Description</strong><br><textarea class="large-text" rows="2" name="description">'.esc_textarea($edit['description'] ?? '').'</textarea></label></p>';
        echo '<p><label><strong>Hero subtitle</strong><br><textarea class="large-text" rows="3" name="hero_subtitle">'.esc_textarea($edit['hero_subtitle'] ?? '').'</textarea></label></p>';
        echo '<p><label><input type="checkbox" name="is_enabled" value="1" '.checked(($edit['is_enabled'] ?? 1),1,false).'> Enabled</label></p>';
        echo '<p><button class="button button-primary" name="ccjv_save_workspace" value="1">Save Workspace</button></p></form></div>';
        echo '<div class="ccjv-card"><table class="widefat striped"><thead><tr><th>Name</th><th>Token</th><th>ERP Plugin</th><th>Skin</th><th></th></tr></thead><tbody>';
        foreach($rows as $r){ echo '<tr><td>'.esc_html($r['name']).'<br><small>'.esc_html($r['slug']).'</small></td><td>'.esc_html($r['token_symbol']).' / '.esc_html($r['token_threshold']).'</td><td>'.esc_html($r['erp_plugin_slug']).'</td><td><span style="display:inline-block;width:16px;height:16px;border-radius:99px;background:'.esc_attr($r['accent_color']).'"></span> '.esc_html($r['dashboard_skin']).'</td><td><a href="?page=ccjv-v4-workspaces&edit='.$r['id'].'">Edit</a> | <a href="?page=ccjv-v4-workspaces&delete='.$r['id'].'">Delete</a></td></tr>'; }
        echo '</tbody></table></div></div></div>';
    }

    public function ventures_page() {
        global $wpdb; $t=$wpdb->prefix.'ccjv_ventures';
        if (!empty($_POST['ccjv_save_venture']) && check_admin_referer('ccjv_save_venture')) {
            $data=['title'=>sanitize_text_field($_POST['title']),'slug'=>sanitize_title($_POST['slug']),'workspace_slug'=>sanitize_title($_POST['workspace_slug']),'linked_workspaces'=>wp_json_encode(array_map('sanitize_title',(array)($_POST['linked_workspaces']??[]))),'status'=>sanitize_text_field($_POST['status']),'description'=>sanitize_textarea_field($_POST['description']),'owner_user_id'=>(int)$_POST['owner_user_id']];
            if (!empty($_POST['id'])) $wpdb->update($t,$data,['id'=>(int)$_POST['id']]); else $wpdb->insert($t,$data);
            echo '<div class="updated"><p>Venture saved.</p></div>';
        }
        $edit = !empty($_GET['edit']) ? $wpdb->get_row($wpdb->prepare("SELECT * FROM $t WHERE id=%d", (int)$_GET['edit']), ARRAY_A) : [];
        $workspaces = $wpdb->get_results("SELECT slug,name FROM {$wpdb->prefix}ccjv_workspaces WHERE is_enabled=1 ORDER BY name ASC", ARRAY_A);
        $rows = $wpdb->get_results("SELECT * FROM $t ORDER BY created_at DESC", ARRAY_A);
        $linked = json_decode($edit['linked_workspaces'] ?? '[]', true) ?: [];
        echo '<div class="wrap ccjv-admin"><h1>Ventures</h1><div class="ccjv-grid-2"><div class="ccjv-card"><form method="post">'; wp_nonce_field('ccjv_save_venture'); echo '<input type="hidden" name="id" value="'.esc_attr($edit['id'] ?? '').'">';
        echo '<p><label><strong>Title</strong><br><input class="regular-text" name="title" value="'.esc_attr($edit['title'] ?? '').'"></label></p>';
        echo '<p><label><strong>Slug</strong><br><input class="regular-text" name="slug" value="'.esc_attr($edit['slug'] ?? '').'"></label></p>';
        echo '<p><label><strong>Primary workspace</strong><br><select name="workspace_slug">'; foreach($workspaces as $w) echo '<option value="'.esc_attr($w['slug']).'" '.selected($edit['workspace_slug'] ?? '',$w['slug'],false).'>'.esc_html($w['name']).'</option>'; echo '</select></label></p>';
        echo '<p><strong>Linked workspaces</strong><br>'; foreach($workspaces as $w) echo '<label style="display:block"><input type="checkbox" name="linked_workspaces[]" value="'.esc_attr($w['slug']).'" '.checked(in_array($w['slug'],$linked,true),true,false).'> '.esc_html($w['name']).'</label>'; echo '</p>';
        echo '<p><label><strong>Status</strong><br><input class="regular-text" name="status" value="'.esc_attr($edit['status'] ?? 'active').'"></label></p>';
        echo '<p><label><strong>Owner user ID</strong><br><input class="regular-text" name="owner_user_id" value="'.esc_attr($edit['owner_user_id'] ?? get_current_user_id()).'"></label></p>';
        echo '<p><label><strong>Description</strong><br><textarea class="large-text" rows="4" name="description">'.esc_textarea($edit['description'] ?? '').'</textarea></label></p>';
        echo '<p><button class="button button-primary" name="ccjv_save_venture" value="1">Save Venture</button></p></form></div><div class="ccjv-card"><table class="widefat striped"><thead><tr><th>Venture</th><th>Workspace</th><th>Linked</th><th>Status</th></tr></thead><tbody>';
        foreach($rows as $r){ $lw = implode(', ', json_decode($r['linked_workspaces'] ?: '[]', true) ?: []); echo '<tr><td>'.esc_html($r['title']).'<br><small>'.esc_html($r['slug']).'</small></td><td>'.esc_html($r['workspace_slug']).'</td><td>'.esc_html($lw).'</td><td>'.esc_html($r['status']).'</td></tr>'; }
        echo '</tbody></table></div></div></div>';
    }

    public function access_page() {
        global $wpdb; $t=$wpdb->prefix.'ccjv_workspace_access';
        if (!empty($_POST['ccjv_save_access']) && check_admin_referer('ccjv_save_access')) {
            $data=['user_id'=>(int)$_POST['user_id'],'workspace_slug'=>sanitize_title($_POST['workspace_slug']),'role_key'=>sanitize_text_field($_POST['role_key']),'token_override'=>!empty($_POST['token_override'])?1:0,'can_create'=>!empty($_POST['can_create'])?1:0,'can_edit'=>!empty($_POST['can_edit'])?1:0,'can_delete'=>!empty($_POST['can_delete'])?1:0];
            $exists=$wpdb->get_var($wpdb->prepare("SELECT id FROM $t WHERE user_id=%d AND workspace_slug=%s", $data['user_id'],$data['workspace_slug']));
            if($exists) $wpdb->update($t,$data,['id'=>$exists]); else $wpdb->insert($t,$data);
            echo '<div class="updated"><p>Access saved.</p></div>';
        }
        $workspaces = $wpdb->get_results("SELECT slug,name FROM {$wpdb->prefix}ccjv_workspaces ORDER BY name ASC", ARRAY_A);
        $rows = $wpdb->get_results("SELECT * FROM $t ORDER BY user_id ASC", ARRAY_A);
        echo '<div class="wrap ccjv-admin"><h1>Access Matrix</h1><div class="ccjv-grid-2"><div class="ccjv-card"><form method="post">'; wp_nonce_field('ccjv_save_access');
        echo '<p><label>User ID<br><input class="regular-text" name="user_id"></label></p><p><label>Workspace<br><select name="workspace_slug">'; foreach($workspaces as $w) echo '<option value="'.esc_attr($w['slug']).'">'.esc_html($w['name']).'</option>'; echo '</select></label></p>';
        echo '<p><label>Role<br><select name="role_key"><option>viewer</option><option>operator</option><option>manager</option><option>finance</option><option>admin</option></select></label></p>';
        foreach(['token_override'=>'Token override','can_create'=>'Can create','can_edit'=>'Can edit','can_delete'=>'Can delete'] as $k=>$l) echo '<label style="display:block"><input type="checkbox" name="'.$k.'" value="1"> '.$l.'</label>';
        echo '<p><button class="button button-primary" name="ccjv_save_access" value="1">Save Access</button></p></form></div><div class="ccjv-card"><table class="widefat striped"><thead><tr><th>User</th><th>Workspace</th><th>Role</th><th>Flags</th></tr></thead><tbody>';
        foreach($rows as $r){ $flags=[]; foreach(['token_override','can_create','can_edit','can_delete'] as $f) if(!empty($r[$f])) $flags[]=$f; echo '<tr><td>'.(int)$r['user_id'].'</td><td>'.esc_html($r['workspace_slug']).'</td><td>'.esc_html($r['role_key']).'</td><td>'.esc_html(implode(', ',$flags)).'</td></tr>'; }
        echo '</tbody></table></div></div></div>';
    }

    public function accounting_page() {
        echo '<div class="wrap ccjv-admin"><h1>Accounting Engine</h1><div class="ccjv-card"><p>V4 includes journal posting rules, invoice line items, payments, and balanced debit/credit posting through REST actions.</p><p>Create invoices under <strong>Invoices</strong> and open the front-end shell for dashboards and posting flows.</p></div></div>';
    }

    public function kanban_page() {
        global $wpdb; $t=$wpdb->prefix.'ccjv_kanban_tasks';
        if (!empty($_POST['ccjv_add_task']) && check_admin_referer('ccjv_add_task')) {
            $wpdb->insert($t,['title'=>sanitize_text_field($_POST['title']),'workspace_slug'=>sanitize_title($_POST['workspace_slug']),'board_column'=>sanitize_text_field($_POST['board_column']),'progress'=>(int)$_POST['progress']]);
            echo '<div class="updated"><p>Task added.</p></div>';
        }
        echo '<div class="wrap ccjv-admin"><h1>Kanban</h1><div class="ccjv-card"><form method="post">'; wp_nonce_field('ccjv_add_task');
        echo '<input name="title" placeholder="Task title" class="regular-text"> <input name="workspace_slug" placeholder="workspace slug" class="regular-text"> <select name="board_column"><option>todo</option><option>doing</option><option>review</option><option>done</option></select> <input name="progress" type="number" value="0" min="0" max="100"> <button class="button button-primary" name="ccjv_add_task" value="1">Add</button></form></div></div>';
    }

    public function settings_page() {
        $s=$this->get_settings();
        echo '<div class="wrap ccjv-admin"><h1>Detailed Settings</h1><form method="post" action="options.php"><div class="ccjv-grid-2">'; settings_fields('ccjv_v4_group');
        echo '<div class="ccjv-card"><h2>Branding</h2>';
        foreach(['site_title'=>'Site title','logo_url'=>'Logo URL','workspace_page_slug'=>'Portal page slug'] as $k=>$l) echo '<p><label><strong>'.$l.'</strong><br><input class="large-text" name="'.self::OPT_KEY.'['.$k.']" value="'.esc_attr($s[$k]).'"></label></p>';
        echo '</div><div class="ccjv-card"><h2>Avalanche / Wallet</h2>';
        foreach(['avalanche_chain_id'=>'Chain ID hex','avalanche_chain_name'=>'Chain name','rpc_url'=>'RPC URL','explorer_url'=>'Explorer URL','signature_message_prefix'=>'Signature message prefix'] as $k=>$l) echo '<p><label><strong>'.$l.'</strong><br><input class="large-text" name="'.self::OPT_KEY.'['.$k.']" value="'.esc_attr($s[$k]).'"></label></p>';
        echo '</div><div class="ccjv-card"><h2>Token Gate</h2>';
        foreach(['buy_token_base_url'=>'Buy token base URL','chart_mode'=>'Chart mode (demo/live placeholder)'] as $k=>$l) echo '<p><label><strong>'.$l.'</strong><br><input class="large-text" name="'.self::OPT_KEY.'['.$k.']" value="'.esc_attr($s[$k]).'"></label></p>';
        echo '<p><em>Per-token ERP settings are controlled in each Workspace record and by each ERP add-on plugin.</em></p></div>';
        echo '<div class="ccjv-card"><h2>Edit Pages</h2><p>Create or edit workspace landing pages under <strong>Workspace Pages</strong>. These can be used for custom marketing, documentation, or gated portal instructions per ERP.</p></div>';
        echo '</div>'; submit_button(); echo '</form></div>';
    }

    public function meta_boxes() {
        add_meta_box('ccjv_invoice_meta','Invoice Details',[$this,'invoice_meta_box'],'ccjv_invoice','normal','default');
    }

    public function invoice_meta_box($post) {
        $workspace = get_post_meta($post->ID,'workspace_slug',true);
        $customer = get_post_meta($post->ID,'customer_name',true);
        $status = get_post_meta($post->ID,'invoice_status',true) ?: 'draft';
        echo '<p><label>Workspace<br><input name="ccjv_workspace_slug" class="regular-text" value="'.esc_attr($workspace).'"></label></p>';
        echo '<p><label>Customer<br><input name="ccjv_customer_name" class="regular-text" value="'.esc_attr($customer).'"></label></p>';
        echo '<p><label>Status<br><select name="ccjv_invoice_status"><option '.selected($status,'draft',false).'>draft</option><option '.selected($status,'posted',false).'>posted</option><option '.selected($status,'paid',false).'>paid</option></select></label></p>';
        echo '<p>Line items and payments are managed from the front-end shell panels.</p>';
        wp_nonce_field('ccjv_invoice_meta','ccjv_invoice_meta_nonce');
    }

    public function save_invoice_meta($post_id) {
        if (!isset($_POST['ccjv_invoice_meta_nonce']) || !wp_verify_nonce($_POST['ccjv_invoice_meta_nonce'],'ccjv_invoice_meta')) return;
        update_post_meta($post_id,'workspace_slug',sanitize_title($_POST['ccjv_workspace_slug'] ?? ''));
        update_post_meta($post_id,'customer_name',sanitize_text_field($_POST['ccjv_customer_name'] ?? ''));
        update_post_meta($post_id,'invoice_status',sanitize_text_field($_POST['ccjv_invoice_status'] ?? 'draft'));
    }

    public function render_shell() {
        ob_start();
        $settings=$this->get_settings();
        $workspace_slug = sanitize_title($_GET['workspace'] ?? '');
        $ventures = $this->get_user_ventures(get_current_user_id());
        ?>
        <div id="ccjv-shell-root" class="ccjv-shell-root">
          <aside class="ccjv-sidebar">
            <div class="ccjv-brand">
              <?php if ($settings['logo_url']): ?><img src="<?php echo esc_url($settings['logo_url']); ?>" alt="logo"><?php endif; ?>
              <div>
                <strong><?php echo esc_html($settings['site_title']); ?></strong>
                <small>Enterprise Shell</small>
              </div>
            </div>
            <nav class="ccjv-nav">
              <a href="#" data-route="home" class="active">Dashboard</a>
              <a href="#" data-route="workspaces">Workspaces</a>
              <a href="#" data-route="ventures">Ventures</a>
              <a href="#" data-route="kanban">Project Boards</a>
              <a href="#" data-route="invoices">Invoices</a>
              <a href="#" data-route="forms">Create / Edit</a>
              <a href="#" data-route="charts">Charts</a>
            </nav>
          </aside>
          <main class="ccjv-main">
            <header class="ccjv-header">
              <div class="ccjv-head-left">
                <div class="ccjv-workspace-picker-wrap">
                  <select id="ccjv-workspace-picker"></select>
                </div>
                <div class="ccjv-venture-picker-wrap">
                  <select id="ccjv-venture-picker">
                    <option value="">All Ventures</option>
                    <?php foreach ($ventures as $v): ?><option value="<?php echo esc_attr($v['id']); ?>"><?php echo esc_html($v['title']); ?></option><?php endforeach; ?>
                  </select>
                </div>
              </div>
              <div class="ccjv-head-right">
                <button id="ccjv-connect-wallet" class="ccjv-btn primary">Connect MetaMask</button>
                <div id="ccjv-wallet-status" class="ccjv-wallet-status">Not connected</div>
              </div>
            </header>
            <section class="ccjv-hero" id="ccjv-hero"></section>
            <section class="ccjv-dashboard-grid">
              <div class="ccjv-card kpi"><span>Token Gate</span><strong id="ccjv-kpi-gate">Checking…</strong></div>
              <div class="ccjv-card kpi"><span>Open Tasks</span><strong id="ccjv-kpi-tasks">0</strong></div>
              <div class="ccjv-card kpi"><span>Open Invoices</span><strong id="ccjv-kpi-invoices">0</strong></div>
              <div class="ccjv-card kpi"><span>Payments</span><strong id="ccjv-kpi-payments">0</strong></div>
            </section>
            <section class="ccjv-panels">
              <div class="ccjv-card panel-wide"><div class="panel-head"><h3>Workspace Dashboard</h3><div id="ccjv-gate-banner"></div></div><canvas id="ccjv-chart"></canvas></div>
              <div class="ccjv-card panel-side"><h3>Role Access</h3><div id="ccjv-role-panel">Checking role…</div></div>
            </section>
            <section id="ccjv-route-content" class="ccjv-route-content"></section>
          </main>
        </div>
        <script>window.CCJV_BOOT = { workspace: <?php echo wp_json_encode($workspace_slug); ?> };</script>
        <?php
        return ob_get_clean();
    }

    public function maybe_wrap_workspace_page($content) {
        if (is_singular('page') && has_shortcode($content,'ccjv_shell_v4')) return $content;
        return $content;
    }

    private function get_user_ventures($user_id) {
        global $wpdb; $t=$wpdb->prefix.'ccjv_ventures';
        if (!$user_id) return $wpdb->get_results("SELECT * FROM $t ORDER BY created_at DESC LIMIT 25", ARRAY_A) ?: [];
        return $wpdb->get_results($wpdb->prepare("SELECT * FROM $t WHERE owner_user_id=%d OR owner_user_id IS NULL ORDER BY created_at DESC LIMIT 25", $user_id), ARRAY_A) ?: [];
    }

    public function rest_routes() {
        register_rest_route('ccjv/v4','/boot',[ 'methods'=>'GET','callback'=>[$this,'rest_boot'],'permission_callback'=>'__return_true']);
        register_rest_route('ccjv/v4','/verify-wallet',[ 'methods'=>'POST','callback'=>[$this,'rest_verify_wallet'],'permission_callback'=>function(){ return is_user_logged_in(); }]);
        register_rest_route('ccjv/v4','/task-move',[ 'methods'=>'POST','callback'=>[$this,'rest_task_move'],'permission_callback'=>function(){ return is_user_logged_in(); }]);
        register_rest_route('ccjv/v4','/task-create',[ 'methods'=>'POST','callback'=>[$this,'rest_task_create'],'permission_callback'=>function(){ return is_user_logged_in(); }]);
        register_rest_route('ccjv/v4','/invoice-line',[ 'methods'=>'POST','callback'=>[$this,'rest_invoice_line'],'permission_callback'=>function(){ return is_user_logged_in(); }]);
        register_rest_route('ccjv/v4','/invoice-payment',[ 'methods'=>'POST','callback'=>[$this,'rest_invoice_payment'],'permission_callback'=>function(){ return is_user_logged_in(); }]);
        register_rest_route('ccjv/v4','/journal-post',[ 'methods'=>'POST','callback'=>[$this,'rest_journal_post'],'permission_callback'=>function(){ return current_user_can('manage_options'); }]);
        register_rest_route('ccjv/v4','/workspace-form',[ 'methods'=>'POST','callback'=>[$this,'rest_workspace_form'],'permission_callback'=>function(){ return is_user_logged_in(); }]);
    }

    public function rest_boot($req) {
        global $wpdb; $p=$wpdb->prefix.'ccjv_';
        $workspaces = $wpdb->get_results("SELECT * FROM {$p}workspaces WHERE is_enabled=1 ORDER BY name ASC", ARRAY_A) ?: [];
        $tasks = $wpdb->get_results("SELECT * FROM {$p}kanban_tasks ORDER BY id DESC LIMIT 50", ARRAY_A) ?: [];
        $wallet = null; $access = [];
        if (is_user_logged_in()) {
            $wallet = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$p}wallets WHERE user_id=%d ORDER BY id DESC LIMIT 1", get_current_user_id()), ARRAY_A);
            $access = $wpdb->get_results($wpdb->prepare("SELECT * FROM {$p}workspace_access WHERE user_id=%d", get_current_user_id()), ARRAY_A) ?: [];
        }
        $projects = get_posts(['post_type'=>'ccjv_project','numberposts'=>20,'post_status'=>'any']);
        $invoices = get_posts(['post_type'=>'ccjv_invoice','numberposts'=>20,'post_status'=>'any']);
        $invoice_count = count($invoices);
        $payment_count = (int)$wpdb->get_var("SELECT COUNT(*) FROM {$p}invoice_payments");
        return rest_ensure_response(['settings'=>$this->get_settings(),'workspaces'=>$workspaces,'tasks'=>$tasks,'wallet'=>$wallet,'access'=>$access,'projects'=>array_map(function($p){return ['id'=>$p->ID,'title'=>$p->post_title];},$projects),'invoiceCount'=>$invoice_count,'paymentCount'=>$payment_count,'ventures'=>$this->get_user_ventures(get_current_user_id())]);
    }

    public function rest_verify_wallet($req) {
        global $wpdb; $t=$wpdb->prefix.'ccjv_wallets';
        $address = sanitize_text_field($req['address']);
        $signature = sanitize_textarea_field($req['signature']);
        $message = sanitize_textarea_field($req['message']);
        $chain_id = sanitize_text_field($req['chainId']);
        if (!$address || !$signature) return new WP_Error('bad_request','Missing wallet data',['status'=>400]);
        // Placeholder signed verification persistence: actual cryptographic verification remains browser-side + server persistence.
        $row = $wpdb->get_var($wpdb->prepare("SELECT id FROM $t WHERE wallet_address=%s", strtolower($address)));
        $data = ['user_id'=>get_current_user_id(),'wallet_address'=>strtolower($address),'chain_id'=>$chain_id ?: '43114','signature'=>$signature,'signed_message'=>$message,'verification_status'=>'verified','last_verified_at'=>current_time('mysql')];
        if ($row) $wpdb->update($t,$data,['id'=>$row]); else $wpdb->insert($t,$data);
        return ['ok'=>true,'wallet'=>$data];
    }
    public function rest_task_move($req) {
        global $wpdb; $t=$wpdb->prefix.'ccjv_kanban_tasks';
        $id=(int)$req['id']; $col=sanitize_text_field($req['board_column']);
        $wpdb->update($t,['board_column'=>$col],['id'=>$id]); return ['ok'=>true];
    }
    public function rest_task_create($req) {
        global $wpdb; $t=$wpdb->prefix.'ccjv_kanban_tasks';
        $wpdb->insert($t,['title'=>sanitize_text_field($req['title']),'venture_id'=>(int)$req['venture_id'],'workspace_slug'=>sanitize_title($req['workspace_slug']),'board_column'=>sanitize_text_field($req['board_column'] ?: 'todo'),'dependency_task_id'=>(int)$req['dependency_task_id'],'progress'=>(int)$req['progress']]);
        return ['ok'=>true,'id'=>$wpdb->insert_id];
    }
    public function rest_invoice_line($req) {
        global $wpdb; $t=$wpdb->prefix.'ccjv_invoice_lines';
        $qty=(float)$req['qty']; $price=(float)$req['unit_price']; $tax=(float)$req['tax_rate'];
        $line_total = round(($qty*$price) * (1 + ($tax/100)),2);
        $wpdb->insert($t,['invoice_post_id'=>(int)$req['invoice_post_id'],'item_desc'=>sanitize_text_field($req['item_desc']),'qty'=>$qty,'unit_price'=>$price,'tax_rate'=>$tax,'line_total'=>$line_total]);
        return ['ok'=>true,'line_total'=>$line_total];
    }
    public function rest_invoice_payment($req) {
        global $wpdb; $t=$wpdb->prefix.'ccjv_invoice_payments';
        $wpdb->insert($t,['invoice_post_id'=>(int)$req['invoice_post_id'],'payment_date'=>sanitize_text_field($req['payment_date'] ?: current_time('Y-m-d')),'amount'=>(float)$req['amount'],'method'=>sanitize_text_field($req['method']),'reference_no'=>sanitize_text_field($req['reference_no']),'notes'=>sanitize_textarea_field($req['notes'])]);
        return ['ok'=>true];
    }
    public function rest_journal_post($req) {
        global $wpdb; $e=$wpdb->prefix.'ccjv_journal_entries'; $l=$wpdb->prefix.'ccjv_journal_lines';
        $lines = $req['lines']; if (!is_array($lines) || !$lines) return new WP_Error('bad_lines','No lines',['status'=>400]);
        $debit=0; $credit=0; foreach($lines as $line){ $debit += (float)($line['debit'] ?? 0); $credit += (float)($line['credit'] ?? 0); }
        if (round($debit,2) !== round($credit,2)) return new WP_Error('unbalanced','Debit and credit must balance',['status'=>400]);
        $wpdb->insert($e,['entry_date'=>sanitize_text_field($req['entry_date'] ?: current_time('Y-m-d')),'reference_type'=>sanitize_text_field($req['reference_type']),'reference_id'=>(int)$req['reference_id'],'memo'=>sanitize_textarea_field($req['memo']),'created_by'=>get_current_user_id()]);
        $jeid=$wpdb->insert_id; foreach($lines as $line){ $wpdb->insert($l,['journal_entry_id'=>$jeid,'account_code'=>sanitize_text_field($line['account_code']),'workspace_slug'=>sanitize_title($line['workspace_slug']),'debit'=>(float)$line['debit'],'credit'=>(float)$line['credit'],'description'=>sanitize_text_field($line['description'])]); }
        return ['ok'=>true,'journal_entry_id'=>$jeid];
    }
    public function rest_workspace_form($req) {
        $workspace = sanitize_title($req['workspace_slug']);
        $post_type = sanitize_key($req['post_type']);
        $action = sanitize_text_field($req['action_type'] ?: 'create');
        if (!$this->user_can_workspace($workspace, 'can_create')) return new WP_Error('forbidden','No create permission',['status'=>403]);
        if ($action === 'edit' && !$this->user_can_workspace($workspace, 'can_edit')) return new WP_Error('forbidden','No edit permission',['status'=>403]);
        $title = sanitize_text_field($req['title']);
        $content = wp_kses_post($req['content']);
        $postarr = ['post_type'=>$post_type,'post_title'=>$title,'post_content'=>$content,'post_status'=>'publish'];
        if ($action==='edit' && !empty($req['post_id'])) $postarr['ID']=(int)$req['post_id'];
        $pid = wp_insert_post($postarr, true);
        if (is_wp_error($pid)) return $pid;
        update_post_meta($pid,'workspace_slug',$workspace);
        return ['ok'=>true,'post_id'=>$pid];
    }

    private function user_can_workspace($workspace, $cap='can_create') {
        if (current_user_can('manage_options')) return true;
        if (!is_user_logged_in()) return false;
        global $wpdb; $t=$wpdb->prefix.'ccjv_workspace_access';
        $row=$wpdb->get_row($wpdb->prepare("SELECT * FROM $t WHERE user_id=%d AND workspace_slug=%s", get_current_user_id(), $workspace), ARRAY_A);
        if (!$row) return false;
        if (!empty($row['token_override'])) return true;
        return !empty($row[$cap]);
    }
}
new CCJV_Token_Gate_Core_V4();

// ERP registration API for separate add-on plugins.
function ccjv_v4_register_erp_module($slug, $args=[]) {
    $mods = get_option('ccjv_v4_registered_modules', []);
    $mods[$slug] = $args;
    update_option('ccjv_v4_registered_modules', $mods);
}
