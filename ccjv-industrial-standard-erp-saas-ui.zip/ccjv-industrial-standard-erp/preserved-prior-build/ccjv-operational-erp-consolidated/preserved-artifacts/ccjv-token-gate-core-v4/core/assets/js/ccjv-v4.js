(function(){
  const root = document.getElementById('ccjv-shell-root');
  if(!root || typeof CCJV_V4 === 'undefined') return;
  let state = {boot:null, currentWorkspace:null, gateStatus:null, role:null, wallet:null};

  async function api(path, opts={}){
    const res = await fetch(CCJV_V4.rest + path, {headers:{'Content-Type':'application/json','X-WP-Nonce':CCJV_V4.nonce}, ...opts});
    const data = await res.json();
    if(!res.ok) throw data;
    return data;
  }

  function fmtCurrency(v){ return new Intl.NumberFormat(undefined,{style:'currency',currency:'CAD'}).format(v||0); }

  async function boot(){
    state.boot = await api('boot');
    state.wallet = state.boot.wallet || null;
    renderWorkspacePicker();
    bindRoutes();
    setWalletStatus();
    const fromQuery = (window.CCJV_BOOT && window.CCJV_BOOT.workspace) || new URLSearchParams(location.search).get('workspace');
    const first = fromQuery || (state.boot.workspaces[0] && state.boot.workspaces[0].slug);
    if(first) selectWorkspace(first);
    updateKpis();
  }

  function renderWorkspacePicker(){
    const sel = document.getElementById('ccjv-workspace-picker'); if(!sel) return;
    sel.innerHTML = state.boot.workspaces.map(w=>`<option value="${w.slug}">${w.name} (${w.token_symbol || 'TOKEN'})</option>`).join('');
    sel.onchange = e => selectWorkspace(e.target.value);
  }

  async function connectWallet(){
    if(!window.ethereum){ alert('MetaMask is required in this browser.'); return; }
    const s = CCJV_V4.settings;
    try {
      const accounts = await ethereum.request({ method:'eth_requestAccounts' });
      const address = accounts[0];
      try {
        await ethereum.request({ method:'wallet_switchEthereumChain', params:[{chainId:s.avalanche_chain_id}] });
      } catch(err){
        await ethereum.request({ method:'wallet_addEthereumChain', params:[{ chainId:s.avalanche_chain_id, chainName:s.avalanche_chain_name, nativeCurrency:{name:'Avalanche',symbol:'AVAX',decimals:18}, rpcUrls:[s.rpc_url], blockExplorerUrls:[s.explorer_url] }] });
      }
      const msg = `${s.signature_message_prefix}\nAddress: ${address}\nTime: ${new Date().toISOString()}`;
      const signature = await ethereum.request({ method:'personal_sign', params:[msg, address] });
      const chainIdHex = await ethereum.request({ method:'eth_chainId' });
      await api('verify-wallet', { method:'POST', body: JSON.stringify({ address, signature, message: msg, chainId: parseInt(chainIdHex,16).toString() }) });
      state.wallet = { wallet_address: address, verification_status: 'verified' };
      setWalletStatus();
      await refreshGate();
    } catch(e){ console.error(e); alert('Wallet connect failed.'); }
  }

  function setWalletStatus(){
    const el = document.getElementById('ccjv-wallet-status');
    el.textContent = state.wallet ? `${state.wallet.wallet_address.slice(0,6)}…${state.wallet.wallet_address.slice(-4)} · ${state.wallet.verification_status}` : 'Not connected';
  }

  async function getTokenBalance(contract, address, decimals=18){
    if(!window.ethereum || !contract || !address) return 0;
    const data = '0x70a08231000000000000000000000000' + address.replace('0x','').toLowerCase();
    const result = await ethereum.request({ method:'eth_call', params:[{to: contract, data}, 'latest'] });
    const raw = BigInt(result);
    return Number(raw) / Math.pow(10, decimals);
  }

  async function refreshGate(){
    if(!state.currentWorkspace){ return; }
    const rolePanel = document.getElementById('ccjv-role-panel');
    const gateBanner = document.getElementById('ccjv-gate-banner');
    const access = (state.boot.access || []).find(a => a.workspace_slug === state.currentWorkspace.slug);
    state.role = access ? access.role_key : 'viewer';
    const override = access && Number(access.token_override) === 1;
    let gateOk = false, balance = 0;
    if(override) {
      gateOk = true;
    } else if(state.wallet && state.currentWorkspace.token_contract) {
      try { balance = await getTokenBalance(state.currentWorkspace.token_contract, state.wallet.wallet_address, Number(state.currentWorkspace.token_decimals || 18)); } catch(e){ console.warn(e); }
      gateOk = balance >= Number(state.currentWorkspace.token_threshold || 1);
    }
    state.gateStatus = {ok: gateOk, balance, threshold: Number(state.currentWorkspace.token_threshold || 1), override};
    document.getElementById('ccjv-kpi-gate').textContent = gateOk ? 'Open' : 'Locked';
    gateBanner.innerHTML = gateOk ? `<span class="ccjv-badge">Token gate open</span>` : `<span class="ccjv-badge" style="background:#fee2e2;color:#b91c1c">Need ${state.currentWorkspace.token_threshold} ${state.currentWorkspace.token_symbol}</span>`;
    rolePanel.innerHTML = `<p><strong>Workspace Role:</strong> ${state.role}</p><p><strong>Wallet:</strong> ${state.wallet ? 'Verified' : 'Not connected'}</p><p><strong>Balance:</strong> ${balance.toFixed(4)} ${state.currentWorkspace.token_symbol || ''}</p><p><strong>Permissions:</strong> ${access ? ['can_create','can_edit','can_delete'].filter(f=>Number(access[f])===1).join(', ') || 'view only' : 'view only'}</p>`;
    renderRoute(currentRoute || 'home');
  }

  function updateKpis(){
    document.getElementById('ccjv-kpi-tasks').textContent = String((state.boot.tasks||[]).length);
    document.getElementById('ccjv-kpi-invoices').textContent = String(state.boot.invoiceCount || 0);
    document.getElementById('ccjv-kpi-payments').textContent = String(state.boot.paymentCount || 0);
  }

  function selectWorkspace(slug){
    state.currentWorkspace = state.boot.workspaces.find(w => w.slug === slug);
    if(!state.currentWorkspace) return;
    const sel = document.getElementById('ccjv-workspace-picker'); if(sel) sel.value = slug;
    renderHero();
    refreshGate();
  }

  function renderHero(){
    const hero = document.getElementById('ccjv-hero');
    const w = state.currentWorkspace;
    hero.style.background = `linear-gradient(135deg, #111827, ${w.accent_color || '#2563eb'})`;
    hero.innerHTML = `<div><h1>${w.hero_title || w.name}</h1><p>${w.hero_subtitle || w.description || ''}</p><div style="margin-top:12px"><span class="ccjv-badge" style="background:rgba(255,255,255,.15);color:#fff">${w.token_symbol || 'TOKEN'} Gate</span> <span class="ccjv-badge" style="background:rgba(255,255,255,.15);color:#fff">ERP Plugin: ${w.erp_plugin_slug || 'n/a'}</span></div></div>`;
    drawChart();
  }

  function drawChart(){
    const ctx = document.getElementById('ccjv-chart'); if(!ctx || typeof Chart === 'undefined') return;
    if(window._ccjvChart) window._ccjvChart.destroy();
    const skin = state.currentWorkspace && state.currentWorkspace.dashboard_skin;
    const sets = {
      constructum:[8,14,12,18,21,24], energy:[12,15,18,19,22,26], land:[3,5,7,10,12,15], default:[5,7,9,10,11,13]
    };
    const data = sets[skin] || sets.default;
    window._ccjvChart = new Chart(ctx, { type:'line', data:{ labels:['Jan','Feb','Mar','Apr','May','Jun'], datasets:[{ label:'Workspace Throughput', data, borderColor:(state.currentWorkspace && state.currentWorkspace.accent_color) || '#2563eb', tension:.35, fill:false }] }, options:{ responsive:true, plugins:{legend:{display:true}} } });
  }

  let currentRoute = 'home';
  function bindRoutes(){
    document.querySelectorAll('.ccjv-nav a').forEach(a => a.addEventListener('click', e => { e.preventDefault(); document.querySelectorAll('.ccjv-nav a').forEach(x=>x.classList.remove('active')); a.classList.add('active'); renderRoute(a.dataset.route); }));
    document.getElementById('ccjv-connect-wallet').addEventListener('click', connectWallet);
  }

  function renderRoute(route){
    currentRoute = route;
    const el = document.getElementById('ccjv-route-content');
    if(!state.currentWorkspace){ el.innerHTML=''; return; }
    switch(route){
      case 'workspaces': el.innerHTML = renderWorkspaceCards(); break;
      case 'ventures': el.innerHTML = renderVentures(); break;
      case 'kanban': el.innerHTML = renderKanban(); setTimeout(bindKanban, 50); break;
      case 'invoices': el.innerHTML = renderInvoices(); bindInvoiceForms(); break;
      case 'forms': el.innerHTML = renderForms(); bindGenericForm(); break;
      case 'charts': el.innerHTML = renderCharts(); break;
      default: el.innerHTML = renderHome();
    }
  }

  function renderHome(){
    const gateClass = state.gateStatus && state.gateStatus.ok ? 'ccjv-open' : 'ccjv-gated';
    return `<div class="ccjv-grid-2"><div class="ccjv-card ${gateClass}"><h3>${state.currentWorkspace.name} Summary</h3><p>${state.currentWorkspace.description || ''}</p><p><strong>Token:</strong> ${state.currentWorkspace.token_symbol} · <strong>Threshold:</strong> ${state.currentWorkspace.token_threshold}</p><p><strong>Gate balance:</strong> ${(state.gateStatus && state.gateStatus.balance || 0).toFixed(4)}</p></div><div class="ccjv-card"><h3>ERP Routing</h3><p>This workspace is configured to route into plugin <strong>${state.currentWorkspace.erp_plugin_slug || 'n/a'}</strong>.</p><p>Use this shell as the premium launcher, gating layer, dashboard, and role-aware UI.</p></div></div>`;
  }

  function renderWorkspaceCards(){
    return `<div class="ccjv-grid-2">${state.boot.workspaces.map(w=>`<div class="ccjv-card"><h3>${w.name}</h3><p>${w.description||''}</p><p><span class="ccjv-badge">${w.token_symbol}</span></p><button class="ccjv-btn primary" onclick="location.search='?workspace=${w.slug}'">Open Workspace</button></div>`).join('')}</div>`;
  }

  function renderVentures(){
    const ventures = state.boot.ventures || [];
    return `<div class="ccjv-card"><h3>Venture Routing</h3><table class="ccjv-table"><thead><tr><th>Venture</th><th>Primary Workspace</th><th>Linked Workspaces</th><th>Status</th></tr></thead><tbody>${ventures.map(v=>{ let linked=[]; try{linked=JSON.parse(v.linked_workspaces||'[]')}catch(e){} return `<tr><td>${v.title}</td><td>${v.workspace_slug||''}</td><td>${linked.join(', ')}</td><td>${v.status}</td></tr>`; }).join('')}</tbody></table></div>`;
  }

  function renderKanban(){
    const cols = ['todo','doing','review','done'];
    const grouped = Object.fromEntries(cols.map(c=>[c, (state.boot.tasks||[]).filter(t=>t.workspace_slug===state.currentWorkspace.slug && t.board_column===c)]));
    return `<div class="ccjv-card"><div class="panel-head"><h3>Drag-and-Drop Kanban</h3><button id="ccjv-add-task-btn" class="ccjv-btn primary">Quick Task</button></div><div class="ccjv-kanban">${cols.map(c=>`<div class="ccjv-col" data-col="${c}"><h4>${c.toUpperCase()}</h4>${grouped[c].map(t=>`<div class="ccjv-task" data-id="${t.id}"><strong>${t.title}</strong><div>Progress: ${t.progress||0}%</div><small>Dependency: ${t.dependency_task_id || '-'}</small></div>`).join('')}</div>`).join('')}</div></div>`;
  }

  function bindKanban(){
    document.querySelectorAll('.ccjv-col').forEach(col=> new Sortable(col,{ group:'ccjv', animation:150, onAdd: async (evt)=>{ const id = evt.item.dataset.id; const board_column = evt.to.dataset.col; await api('task-move',{method:'POST',body:JSON.stringify({id,board_column})}); } }));
    const btn = document.getElementById('ccjv-add-task-btn'); if(btn) btn.onclick = async ()=>{ const title = prompt('Task title'); if(!title) return; await api('task-create',{method:'POST',body:JSON.stringify({title,workspace_slug:state.currentWorkspace.slug,board_column:'todo',progress:0})}); state.boot = await api('boot'); renderRoute('kanban'); updateKpis(); };
  }

  function renderInvoices(){
    return `<div class="ccjv-grid-2"><div class="ccjv-card"><h3>Invoice Line Item</h3><form id="ccjv-line-form" class="ccjv-form"><div class="ccjv-form-grid"><input name="invoice_post_id" placeholder="Invoice post ID"><input name="item_desc" placeholder="Description"><input name="qty" placeholder="Qty" value="1"><input name="unit_price" placeholder="Unit price"><input name="tax_rate" placeholder="Tax %" value="0"></div><p><button class="ccjv-btn primary">Add Line</button></p></form><div id="ccjv-line-result"></div></div><div class="ccjv-card"><h3>Record Payment</h3><form id="ccjv-payment-form" class="ccjv-form"><div class="ccjv-form-grid"><input name="invoice_post_id" placeholder="Invoice post ID"><input name="payment_date" type="date"><input name="amount" placeholder="Amount"><select name="method"><option>bank</option><option>crypto</option><option>cash</option><option>card</option></select><input name="reference_no" placeholder="Reference"></div><textarea name="notes" placeholder="Notes"></textarea><p><button class="ccjv-btn primary">Save Payment</button></p></form><div id="ccjv-payment-result"></div></div></div>`;
  }
  function bindInvoiceForms(){
    const lf = document.getElementById('ccjv-line-form'); if(lf) lf.onsubmit = async e=>{ e.preventDefault(); const d=Object.fromEntries(new FormData(lf).entries()); const r=await api('invoice-line',{method:'POST',body:JSON.stringify(d)}); document.getElementById('ccjv-line-result').innerHTML = `<p>Line total: <strong>${fmtCurrency(r.line_total)}</strong></p>`; };
    const pf = document.getElementById('ccjv-payment-form'); if(pf) pf.onsubmit = async e=>{ e.preventDefault(); const d=Object.fromEntries(new FormData(pf).entries()); await api('invoice-payment',{method:'POST',body:JSON.stringify(d)}); document.getElementById('ccjv-payment-result').innerHTML = '<p>Payment saved.</p>'; };
  }

  function renderForms(){
    const blocked = !(state.gateStatus && state.gateStatus.ok);
    const access = (state.boot.access || []).find(a => a.workspace_slug === state.currentWorkspace.slug);
    const canCreate = access && (Number(access.can_create)===1 || Number(access.token_override)===1);
    if(blocked) return `<div class="ccjv-card ccjv-gated"><h3>Token Gate Locked</h3><p>You need ${state.currentWorkspace.token_threshold} ${state.currentWorkspace.token_symbol} to create or edit records here.</p></div>`;
    if(!canCreate) return `<div class="ccjv-card ccjv-gated"><h3>Permission Required</h3><p>Your role does not allow front-end record creation in this workspace.</p></div>`;
    return `<div class="ccjv-card"><h3>Create / Edit Front-End Form</h3><form id="ccjv-generic-form" class="ccjv-form"><div class="ccjv-form-grid"><select name="post_type"><option value="ccjv_project">Project</option><option value="ccjv_contact">CRM Contact</option><option value="ccjv_employee">Employee</option><option value="ccjv_asset">Asset</option></select><select name="action_type"><option value="create">Create</option><option value="edit">Edit</option></select><input name="post_id" placeholder="Post ID for edit"><input name="title" placeholder="Title"></div><textarea name="content" placeholder="Content / notes"></textarea><input type="hidden" name="workspace_slug" value="${state.currentWorkspace.slug}"><p><button class="ccjv-btn primary">Save</button></p></form><div id="ccjv-generic-result"></div></div>`;
  }
  function bindGenericForm(){
    const gf = document.getElementById('ccjv-generic-form'); if(gf) gf.onsubmit = async e=>{ e.preventDefault(); const d=Object.fromEntries(new FormData(gf).entries()); const r=await api('workspace-form',{method:'POST',body:JSON.stringify(d)}); document.getElementById('ccjv-generic-result').innerHTML = `<p>Saved record #${r.post_id}</p>`; };
  }

  function renderCharts(){
    return `<div class="ccjv-grid-2"><div class="ccjv-card"><h3>${state.currentWorkspace.name} Skin</h3><p>Dashboard skin: <strong>${state.currentWorkspace.dashboard_skin}</strong></p><p>Accent color: <span class="ccjv-badge" style="background:${state.currentWorkspace.accent_color};color:#fff">${state.currentWorkspace.accent_color}</span></p></div><div class="ccjv-card"><h3>Venture Workspace Routing</h3><p>Use the venture table to link multiple workspaces to one deal. This shell is designed for cross-workspace routing on the same venture.</p></div></div>`;
  }

  document.addEventListener('DOMContentLoaded', boot);
})();
