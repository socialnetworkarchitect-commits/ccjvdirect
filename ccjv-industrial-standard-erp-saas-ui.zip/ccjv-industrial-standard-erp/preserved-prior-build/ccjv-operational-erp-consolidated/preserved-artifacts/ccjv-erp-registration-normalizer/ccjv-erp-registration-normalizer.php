<?php
/*
Plugin Name: CCJV ERP Registration Normalizer
Description: Normalizes Cibus, Iter, and Surge ERP registration and places them under CCJV Unified Core.
Version: 1.0.0
Author: OpenAI
*/

if (!defined('ABSPATH')) exit;

if (!defined('CCJV_CORE_ACTIVE') && !function_exists('ccjv_core_loaded')) {
    add_action('admin_notices', function () {
        echo '<div class="notice notice-error"><p><strong>CCJV ERP Registration Normalizer</strong> requires the CCJV core stack.</p></div>';
    });
    return;
}

define('CCJV_ERP_NORMALIZER_ACTIVE', true);

/*
 * Known ERP keys and labels.
 */
function ccjv_erp_normalizer_map() {
    return [
        'cibus' => [
            'label' => 'Cibus ERP',
            'menu_slug' => 'cibus-erp',
            'portal_slug' => 'cibus-portal',
            'app_slug' => 'cibus-app',
        ],
        'iter' => [
            'label' => 'Iter ERP',
            'menu_slug' => 'iter-erp',
            'portal_slug' => 'iter-portal',
            'app_slug' => 'iter-app',
        ],
        'surge' => [
            'label' => 'Surge ERP',
            'menu_slug' => 'surge-erp',
            'portal_slug' => 'surge-portal',
            'app_slug' => 'surge-app',
        ],
    ];
}

/*
 * Register standardized ERP metadata for dashboard/launcher layers.
 */
add_action('init', function () {
    $map = ccjv_erp_normalizer_map();

    foreach ($map as $key => $config) {
        if (function_exists('ccjvx_register_erp')) {
            ccjvx_register_erp($key, [
                'name' => $config['label'],
                'portal_slug' => $config['portal_slug'],
                'app_slug' => $config['app_slug'],
            ]);
        }

        if (function_exists('ccjv_register_erp')) {
            // legacy registration path
            $token = strtoupper(substr($key, 0, 3));
            if ($key === 'iter') $token = 'ITC';
            if ($key === 'cibus') $token = 'CIB';
            if ($key === 'surge') $token = 'SRG';
            ccjv_register_erp($key, $config['label'], $token);
        }
    }
}, 30);

/*
 * Add unified ERP launchers under CCJV Unified Core.
 * This does not remove existing top-level ERP menus safely, but gives one clean home.
 */
add_action('admin_menu', function () {
    $parent_slug = 'ccjv';
    global $menu;
    $has_parent = false;

    if (is_array($menu)) {
        foreach ($menu as $item) {
            if (!empty($item[2]) && $item[2] === $parent_slug) {
                $has_parent = true;
                break;
            }
        }
    }

    if (!$has_parent) {
        return;
    }

    foreach (ccjv_erp_normalizer_map() as $key => $config) {
        add_submenu_page(
            $parent_slug,
            $config['label'],
            $config['label'],
            'manage_options',
            'ccjv-normalized-' . $key,
            function () use ($key, $config) {
                $portal_url = home_url('/' . $config['portal_slug']);
                $app_url = home_url('/' . $config['app_slug']);
                echo '<div class="wrap">';
                echo '<h1>' . esc_html($config['label']) . '</h1>';
                echo '<p>Normalized entry for ' . esc_html($config['label']) . '.</p>';
                echo '<p><a class="button button-primary" href="' . esc_url($portal_url) . '">Open Portal</a> ';
                echo '<a class="button" href="' . esc_url($app_url) . '">Open ERP App</a></p>';
                echo '<hr>';
                echo '<table class="widefat striped" style="max-width:900px"><tbody>';
                echo '<tr><td><strong>Portal slug</strong></td><td>' . esc_html($config['portal_slug']) . '</td></tr>';
                echo '<tr><td><strong>App slug</strong></td><td>' . esc_html($config['app_slug']) . '</td></tr>';
                echo '<tr><td><strong>Menu slug</strong></td><td>' . esc_html($config['menu_slug']) . '</td></tr>';
                echo '</tbody></table>';
                echo '</div>';
            }
        );
    }
}, 99);

/*
 * Status page under Core X if that menu exists.
 */
add_action('admin_menu', function () {
    add_submenu_page(
        'ccjvx',
        'ERP Normalizer',
        'ERP Normalizer',
        'manage_options',
        'ccjv-erp-normalizer',
        function () {
            echo '<div class="wrap"><h1>CCJV ERP Registration Normalizer</h1>';
            echo '<p>This layer standardizes ERP registration and provides one clean registration map for Cibus, Iter, and Surge.</p>';
            echo '<table class="widefat striped" style="max-width:900px"><thead><tr><th>ERP</th><th>Portal</th><th>App</th></tr></thead><tbody>';
            foreach (ccjv_erp_normalizer_map() as $key => $config) {
                echo '<tr>';
                echo '<td>' . esc_html($config['label']) . '</td>';
                echo '<td>' . esc_html('/' . $config['portal_slug']) . '</td>';
                echo '<td>' . esc_html('/' . $config['app_slug']) . '</td>';
                echo '</tr>';
            }
            echo '</tbody></table></div>';
        }
    );
}, 100);
