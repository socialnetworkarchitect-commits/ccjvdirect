<?php
/*
Plugin Name: CCJV Core Project + Asset Screens
Description: Adds tenant-aware Project Management and Asset Management data screens on top of the CCJV Core ERP Engine.
Version: 1.0.0
Author: OpenAI
*/

if (!defined('ABSPATH')) exit;

if (!defined('CCJV_CORE_ACTIVE') && !function_exists('ccjv_core_loaded')) {
    add_action('admin_notices', function () {
        echo '<div class="notice notice-error"><p><strong>CCJV Core Project + Asset Screens</strong> requires the CCJV core stack.</p></div>';
    });
    return;
}

/*
 * Activation: create project + asset tables
 */
register_activation_hook(__FILE__, function () {
    global $wpdb;
    $charset = $wpdb->get_charset_collate();

    $projects = $wpdb->prefix . 'ccjv_projects';
    $project_tasks = $wpdb->prefix . 'ccjv_project_tasks';
    $assets = $wpdb->prefix . 'ccjv_assets';

    require_once ABSPATH . 'wp-admin/includes/upgrade.php';

    $sql1 = "CREATE TABLE {$projects} (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        tenant_id VARCHAR(255) NOT NULL,
        name VARCHAR(255) NOT NULL,
        status VARCHAR(50) NULL,
        budget DECIMAL(20,8) DEFAULT 0,
        description TEXT NULL,
        created_by BIGINT UNSIGNED NULL,
        created_at DATETIME NOT NULL,
        PRIMARY KEY (id),
        KEY tenant_id (tenant_id(191))
    ) {$charset};";

    $sql2 = "CREATE TABLE {$project_tasks} (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        tenant_id VARCHAR(255) NOT NULL,
        project_id BIGINT UNSIGNED NOT NULL,
        title VARCHAR(255) NOT NULL,
        status VARCHAR(50) NULL,
        owner_name VARCHAR(255) NULL,
        notes TEXT NULL,
        created_at DATETIME NOT NULL,
        PRIMARY KEY (id),
        KEY tenant_id (tenant_id(191)),
        KEY project_id (project_id)
    ) {$charset};";

    $sql3 = "CREATE TABLE {$assets} (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        tenant_id VARCHAR(255) NOT NULL,
        asset_name VARCHAR(255) NOT NULL,
        asset_type VARCHAR(100) NULL,
        acquisition_cost DECIMAL(20,8) DEFAULT 0,
        book_value DECIMAL(20,8) DEFAULT 0,
        status VARCHAR(50) NULL,
        notes TEXT NULL,
        created_by BIGINT UNSIGNED NULL,
        created_at DATETIME NOT NULL,
        PRIMARY KEY (id),
        KEY tenant_id (tenant_id(191))
    ) {$charset};";

    dbDelta($sql1);
    dbDelta($sql2);
    dbDelta($sql3);
});

function ccjv_pa_get_current_tenant($user_id = 0) {
    if (!$user_id) $user_id = get_current_user_id();

    $tenant = get_user_meta($user_id, 'ccjv_tenant', true);
    if (!$tenant && function_exists('ccjvx_get_tenant')) {
        $tenant = ccjvx_get_tenant($user_id);
    }

    return $tenant ?: '';
}

function ccjv_pa_user_allowed($module_key) {
    if (!is_user_logged_in()) return false;

    if (function_exists('ccjv_core_module_access_state')) {
        $state = ccjv_core_module_access_state($module_key, get_current_user_id());
        return !empty($state['allowed']);
    }

    return true;
}

/*
 * Project helpers
 */
function ccjv_pa_add_project($tenant_id, $data) {
    global $wpdb;
    return $wpdb->insert($wpdb->prefix . 'ccjv_projects', [
        'tenant_id' => $tenant_id,
        'name' => sanitize_text_field($data['name'] ?? ''),
        'status' => sanitize_text_field($data['status'] ?? 'planned'),
        'budget' => (float)($data['budget'] ?? 0),
        'description' => sanitize_textarea_field($data['description'] ?? ''),
        'created_by' => get_current_user_id(),
        'created_at' => current_time('mysql'),
    ]);
}

function ccjv_pa_get_projects($tenant_id) {
    global $wpdb;
    return $wpdb->get_results($wpdb->prepare(
        "SELECT * FROM {$wpdb->prefix}ccjv_projects WHERE tenant_id=%s ORDER BY id DESC",
        $tenant_id
    ));
}

function ccjv_pa_add_project_task($tenant_id, $data) {
    global $wpdb;
    return $wpdb->insert($wpdb->prefix . 'ccjv_project_tasks', [
        'tenant_id' => $tenant_id,
        'project_id' => absint($data['project_id'] ?? 0),
        'title' => sanitize_text_field($data['title'] ?? ''),
        'status' => sanitize_text_field($data['status'] ?? 'open'),
        'owner_name' => sanitize_text_field($data['owner_name'] ?? ''),
        'notes' => sanitize_textarea_field($data['notes'] ?? ''),
        'created_at' => current_time('mysql'),
    ]);
}

function ccjv_pa_get_project_tasks($tenant_id, $project_id = 0) {
    global $wpdb;
    if ($project_id) {
        return $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}ccjv_project_tasks WHERE tenant_id=%s AND project_id=%d ORDER BY id DESC",
            $tenant_id, $project_id
        ));
    }

    return $wpdb->get_results($wpdb->prepare(
        "SELECT * FROM {$wpdb->prefix}ccjv_project_tasks WHERE tenant_id=%s ORDER BY id DESC",
        $tenant_id
    ));
}

/*
 * Asset helpers
 */
function ccjv_pa_add_asset($tenant_id, $data) {
    global $wpdb;
    $cost = (float)($data['acquisition_cost'] ?? 0);
    return $wpdb->insert($wpdb->prefix . 'ccjv_assets', [
        'tenant_id' => $tenant_id,
        'asset_name' => sanitize_text_field($data['asset_name'] ?? ''),
        'asset_type' => sanitize_text_field($data['asset_type'] ?? ''),
        'acquisition_cost' => $cost,
        'book_value' => $cost,
        'status' => sanitize_text_field($data['status'] ?? 'active'),
        'notes' => sanitize_textarea_field($data['notes'] ?? ''),
        'created_by' => get_current_user_id(),
        'created_at' => current_time('mysql'),
    ]);
}

function ccjv_pa_get_assets($tenant_id) {
    global $wpdb;
    return $wpdb->get_results($wpdb->prepare(
        "SELECT * FROM {$wpdb->prefix}ccjv_assets WHERE tenant_id=%s ORDER BY id DESC",
        $tenant_id
    ));
}

/*
 * Project screen
 */
add_shortcode('ccjv_core_project_screen', function () {
    if (!ccjv_pa_user_allowed('project')) {
        return '<p>Access denied.</p>';
    }

    $tenant_id = ccjv_pa_get_current_tenant();
    if (!$tenant_id) {
        return '<p>No tenant context found.</p>';
    }

    $messages = [];

    if (isset($_POST['ccjv_add_project'])) {
        if (!isset($_POST['_wpnonce']) || !wp_verify_nonce($_POST['_wpnonce'], 'ccjv_add_project')) {
            $messages[] = '<p>Security check failed while saving project.</p>';
        } else {
            ccjv_pa_add_project($tenant_id, wp_unslash($_POST));
            $messages[] = '<p>Project created.</p>';
        }
    }

    if (isset($_POST['ccjv_add_project_task'])) {
        if (!isset($_POST['_wpnonce']) || !wp_verify_nonce($_POST['_wpnonce'], 'ccjv_add_project_task')) {
            $messages[] = '<p>Security check failed while saving task.</p>';
        } else {
            ccjv_pa_add_project_task($tenant_id, wp_unslash($_POST));
            $messages[] = '<p>Task created.</p>';
        }
    }

    $projects = ccjv_pa_get_projects($tenant_id);
    $filter_project_id = isset($_GET['project_id']) ? absint($_GET['project_id']) : 0;
    $tasks = ccjv_pa_get_project_tasks($tenant_id, $filter_project_id);

    ob_start(); ?>
    <div style="max-width:1280px;margin:0 auto;padding:24px">
        <div class="ccjv-card">
            <h2>Core Project Management</h2>
            <p>Tenant-aware projects and tasks on top of the Core ERP Engine.</p>
            <p><strong>Tenant:</strong> <?php echo esc_html($tenant_id); ?></p>
        </div>

        <?php if ($messages): ?>
            <div class="ccjv-card">
                <?php foreach ($messages as $message) echo wp_kses_post($message); ?>
            </div>
        <?php endif; ?>

        <div class="ccjv-card">
            <h3>Add Project</h3>
            <form method="post">
                <?php wp_nonce_field('ccjv_add_project'); ?>
                <p><input type="text" name="name" placeholder="Project Name" required class="regular-text"></p>
                <p>
                    <select name="status">
                        <option value="planned">planned</option>
                        <option value="active">active</option>
                        <option value="on-hold">on-hold</option>
                        <option value="completed">completed</option>
                    </select>
                </p>
                <p><input type="number" step="0.00000001" name="budget" placeholder="Budget" class="regular-text"></p>
                <p><textarea name="description" placeholder="Description" rows="4" class="large-text"></textarea></p>
                <p><button class="button button-primary" name="ccjv_add_project" value="1">Save Project</button></p>
            </form>
        </div>

        <div class="ccjv-card">
            <h3>Projects</h3>
            <?php if (!$projects): ?>
                <p>No projects yet.</p>
            <?php else: ?>
                <table class="widefat striped">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Name</th>
                            <th>Status</th>
                            <th>Budget</th>
                            <th>Tasks</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($projects as $project): ?>
                            <tr>
                                <td><?php echo (int)$project->id; ?></td>
                                <td><?php echo esc_html($project->name); ?></td>
                                <td><?php echo esc_html($project->status); ?></td>
                                <td><?php echo esc_html((string)$project->budget); ?></td>
                                <td><a href="<?php echo esc_url(add_query_arg('project_id', (int)$project->id)); ?>">Open Tasks</a></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </div>

        <div class="ccjv-card">
            <h3>Add Task</h3>
            <form method="post">
                <?php wp_nonce_field('ccjv_add_project_task'); ?>
                <p>
                    <select name="project_id" required>
                        <option value="">Select Project</option>
                        <?php foreach ($projects as $project): ?>
                            <option value="<?php echo (int)$project->id; ?>"><?php echo esc_html($project->name); ?></option>
                        <?php endforeach; ?>
                    </select>
                </p>
                <p><input type="text" name="title" placeholder="Task Title" required class="regular-text"></p>
                <p>
                    <select name="status">
                        <option value="open">open</option>
                        <option value="in-progress">in-progress</option>
                        <option value="blocked">blocked</option>
                        <option value="done">done</option>
                    </select>
                </p>
                <p><input type="text" name="owner_name" placeholder="Owner / Assignee" class="regular-text"></p>
                <p><textarea name="notes" placeholder="Notes" rows="4" class="large-text"></textarea></p>
                <p><button class="button button-primary" name="ccjv_add_project_task" value="1">Save Task</button></p>
            </form>
        </div>

        <div class="ccjv-card">
            <h3>Task View</h3>
            <?php if ($filter_project_id): ?>
                <p>Showing tasks for project ID <strong><?php echo (int)$filter_project_id; ?></strong> — <a href="<?php echo esc_url(remove_query_arg('project_id')); ?>">clear filter</a></p>
            <?php else: ?>
                <p>Showing all tenant tasks.</p>
            <?php endif; ?>

            <?php if (!$tasks): ?>
                <p>No tasks yet.</p>
            <?php else: ?>
                <table class="widefat striped">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Project ID</th>
                            <th>Title</th>
                            <th>Status</th>
                            <th>Owner</th>
                            <th>Created</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($tasks as $task): ?>
                            <tr>
                                <td><?php echo (int)$task->id; ?></td>
                                <td><?php echo (int)$task->project_id; ?></td>
                                <td><?php echo esc_html($task->title); ?></td>
                                <td><?php echo esc_html($task->status); ?></td>
                                <td><?php echo esc_html($task->owner_name); ?></td>
                                <td><?php echo esc_html($task->created_at); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </div>
    </div>
    <?php
    return ob_get_clean();
});

/*
 * Asset screen
 */
add_shortcode('ccjv_core_asset_screen', function () {
    if (!ccjv_pa_user_allowed('asset')) {
        return '<p>Access denied.</p>';
    }

    $tenant_id = ccjv_pa_get_current_tenant();
    if (!$tenant_id) {
        return '<p>No tenant context found.</p>';
    }

    $messages = [];

    if (isset($_POST['ccjv_add_asset'])) {
        if (!isset($_POST['_wpnonce']) || !wp_verify_nonce($_POST['_wpnonce'], 'ccjv_add_asset')) {
            $messages[] = '<p>Security check failed while saving asset.</p>';
        } else {
            ccjv_pa_add_asset($tenant_id, wp_unslash($_POST));
            $messages[] = '<p>Asset created.</p>';
        }
    }

    $assets = ccjv_pa_get_assets($tenant_id);

    ob_start(); ?>
    <div style="max-width:1280px;margin:0 auto;padding:24px">
        <div class="ccjv-card">
            <h2>Core Asset Management</h2>
            <p>Tenant-aware assets on top of the Core ERP Engine.</p>
            <p><strong>Tenant:</strong> <?php echo esc_html($tenant_id); ?></p>
        </div>

        <?php if ($messages): ?>
            <div class="ccjv-card">
                <?php foreach ($messages as $message) echo wp_kses_post($message); ?>
            </div>
        <?php endif; ?>

        <div class="ccjv-card">
            <h3>Add Asset</h3>
            <form method="post">
                <?php wp_nonce_field('ccjv_add_asset'); ?>
                <p><input type="text" name="asset_name" placeholder="Asset Name" required class="regular-text"></p>
                <p><input type="text" name="asset_type" placeholder="Asset Type" class="regular-text"></p>
                <p><input type="number" step="0.00000001" name="acquisition_cost" placeholder="Acquisition Cost" class="regular-text"></p>
                <p>
                    <select name="status">
                        <option value="active">active</option>
                        <option value="inactive">inactive</option>
                        <option value="disposed">disposed</option>
                    </select>
                </p>
                <p><textarea name="notes" placeholder="Notes" rows="4" class="large-text"></textarea></p>
                <p><button class="button button-primary" name="ccjv_add_asset" value="1">Save Asset</button></p>
            </form>
        </div>

        <div class="ccjv-card">
            <h3>Assets</h3>
            <?php if (!$assets): ?>
                <p>No assets yet.</p>
            <?php else: ?>
                <table class="widefat striped">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Asset Name</th>
                            <th>Type</th>
                            <th>Acquisition Cost</th>
                            <th>Book Value</th>
                            <th>Status</th>
                            <th>Created</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($assets as $asset): ?>
                            <tr>
                                <td><?php echo (int)$asset->id; ?></td>
                                <td><?php echo esc_html($asset->asset_name); ?></td>
                                <td><?php echo esc_html($asset->asset_type); ?></td>
                                <td><?php echo esc_html((string)$asset->acquisition_cost); ?></td>
                                <td><?php echo esc_html((string)$asset->book_value); ?></td>
                                <td><?php echo esc_html($asset->status); ?></td>
                                <td><?php echo esc_html($asset->created_at); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </div>
    </div>
    <?php
    return ob_get_clean();
});

/*
 * Admin visibility
 */
add_action('admin_menu', function () {
    add_submenu_page(
        'ccjv',
        'Core Project + Asset Screens',
        'Core Project + Asset Screens',
        'manage_options',
        'ccjv-core-project-asset-screens',
        function () {
            echo '<div class="wrap"><h1>Core Project + Asset Screens</h1>';
            echo '<p>This layer adds tenant-aware project and asset data screens on top of the Core ERP Engine.</p>';
            echo '<ul>';
            echo '<li><code>[ccjv_core_project_screen]</code></li>';
            echo '<li><code>[ccjv_core_asset_screen]</code></li>';
            echo '</ul></div>';
        }
    );
}, 96);
