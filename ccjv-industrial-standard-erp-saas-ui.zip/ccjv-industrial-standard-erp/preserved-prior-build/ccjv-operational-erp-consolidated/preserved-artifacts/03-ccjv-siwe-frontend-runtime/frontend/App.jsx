export default function App(){ return <div>CCJV SIWE Frontend</div> }
