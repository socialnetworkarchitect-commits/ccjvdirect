# CCJV Core ERP — HRM Depth Pass

Added:
- Employees/contractors table
- Departments table
- Certifications table
- Competencies table
- Schedules table
- Training workflows table
- HRM timeline table
- REST routes for HRM entities
- Workforce dashboard
- Certification expiry warnings
- Schedule calendar
- Readiness heatmap
- Org chart renderer
- Training workflow UI
- Vault hash generation
- Replay event emission
- Treasury reference linkage
- Tenant-scoped persistence

Regression preserved:
- ERP dashboard
- CRM depth pass
- Runtime settings
- Health panel
- Generic module workspaces
- Vault/replay/treasury continuity
