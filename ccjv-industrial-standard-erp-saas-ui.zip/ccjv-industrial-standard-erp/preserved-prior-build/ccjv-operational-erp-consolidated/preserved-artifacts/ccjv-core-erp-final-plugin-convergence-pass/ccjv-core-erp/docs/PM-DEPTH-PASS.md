# CCJV Core ERP — Project Management Depth Pass

Added:
- Projects
- Milestones
- Tasks
- Dependencies
- Approvals
- Documents/evidence links
- Project timeline
- REST routes for PM entities
- Kanban board
- Gantt timeline
- Dependency graph
- Workload planning
- Approval workflow UI
- Vault-linked document records
- Vault hash generation
- Replay event emission
- Treasury reference linkage
- Tenant-scoped persistence

Regression preserved:
- ERP dashboard
- CRM depth pass
- HRM depth pass
- Accounting depth pass
- Runtime settings
- Health panel
- Vault/replay/treasury continuity
