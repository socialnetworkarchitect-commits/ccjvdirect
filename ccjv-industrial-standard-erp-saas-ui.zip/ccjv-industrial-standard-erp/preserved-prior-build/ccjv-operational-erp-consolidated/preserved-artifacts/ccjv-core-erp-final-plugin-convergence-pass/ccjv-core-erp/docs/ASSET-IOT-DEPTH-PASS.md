# CCJV Core ERP — Asset + IoT Depth Pass

Added:
- Asset registry
- Maintenance work orders
- Inspections
- Digital twins
- Sensors
- Telemetry events
- Anomaly alerts
- Asset/IoT timeline
- REST routes for Asset + IoT entities
- Operational map overlay
- Asset explorer
- Maintenance board
- Inspection history
- Twin visualization
- Telemetry bar chart
- Alert stream
- Dashboard KPIs
- Vault hash generation
- Replay event emission
- Treasury reference linkage
- Tenant-scoped persistence

Regression preserved:
- ERP dashboard
- CRM depth pass
- HRM depth pass
- Accounting depth pass
- PM depth pass
- Runtime settings
- Health panel
- Vault/replay/treasury continuity
