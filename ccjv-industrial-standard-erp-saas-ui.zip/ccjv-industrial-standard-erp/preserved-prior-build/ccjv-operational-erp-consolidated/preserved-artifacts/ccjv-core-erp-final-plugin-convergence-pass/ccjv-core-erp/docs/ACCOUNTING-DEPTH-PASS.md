# CCJV Core ERP — Accounting Depth Pass

Added:
- Chart of accounts
- Journal entries
- Journal lines / ledger
- AP/AR invoices
- Payments with tx hash field
- Reconciliations
- Reports
- Accounting timeline
- REST routes for accounting entities
- Ledger view
- AP/AR aging view
- Treasury reconciliation cockpit
- KPI dashboard
- Report generation foundation
- Vault hash generation
- Replay event emission
- Treasury reference linkage
- Tenant-scoped persistence

Regression preserved:
- ERP dashboard
- CRM depth pass
- HRM depth pass
- Runtime settings
- Health panel
- Vault/replay/treasury continuity
