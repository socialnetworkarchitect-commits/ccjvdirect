# CCJV Core ERP — CRM Depth Pass

Added:
- CRM accounts table
- CRM contacts table
- CRM opportunities table
- CRM activities table
- CRM timeline table
- REST routes for CRM entities
- Salesforce-style pipeline board
- Account overview
- Contact list/timeline foundation
- Activity feed
- Opportunity forecasting
- Search/filter/status toolbar foundation
- Vault hash generation
- Replay event emission
- Treasury reference linkage
- Tenant-scoped persistence

Regression preserved:
- ERP dashboard
- Generic module workspaces
- Runtime settings
- Health panel
- Record creation
- Vault/replay/treasury continuity
