# CCJV Core ERP — Procurement + Governance Depth Pass

Added:
- Vendor registry
- RFQs
- Bid submissions
- Bid comparison scoring
- Purchase order lifecycle
- Governance proposals
- Voting persistence
- Quorum endpoint
- Procurement/governance timeline
- REST routes
- Workspace UI
- Vault hash generation
- Replay event emission
- Treasury linkage
- Tenant-scoped persistence

Regression preserved:
- ERP dashboard
- CRM depth
- HRM depth
- Accounting depth
- PM depth
- Asset + IoT depth
- Runtime settings
- Health panel
- Vault/replay/treasury continuity
