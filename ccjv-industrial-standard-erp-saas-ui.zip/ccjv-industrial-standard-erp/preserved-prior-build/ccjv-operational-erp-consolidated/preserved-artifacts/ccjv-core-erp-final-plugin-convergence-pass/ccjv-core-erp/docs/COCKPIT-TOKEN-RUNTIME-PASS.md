# CCJV Core ERP — Cockpit UX + Runtime Bridge + Token Enforcement Pass

Added:
- Federated cockpit shell
- Global operational search
- Workspace federation switcher
- Runtime bridge event queue
- Runtime summary endpoint
- Token entitlement persistence
- Token check endpoint
- Module fee and allowance visibility
- Replay-linked entitlement checks
- Treasury reference linkage

Preserved:
- CRM depth
- HRM depth
- Accounting depth
- PM depth
- Asset + IoT depth
- Procurement + Governance depth
