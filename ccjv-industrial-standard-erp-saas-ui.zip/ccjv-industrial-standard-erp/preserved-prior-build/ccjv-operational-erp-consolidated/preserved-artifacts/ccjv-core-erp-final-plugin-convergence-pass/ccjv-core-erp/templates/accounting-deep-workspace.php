<div class="ccjv-erp-workspace ccjv-accounting-workspace" data-module="accounting">
  <header class="ccjv-workspace-header">
    <div>
      <div class="ccjv-module-icon">📘</div>
      <h1>Accounting Runtime Workspace</h1>
      <p>Chart of accounts, GL, AP/AR, invoices, payments, reconciliation, journals, treasury settlement cockpit, financial reporting and token billing continuity.</p>
    </div>
    <div class="ccjv-workspace-status">
      <span>Token Gate: <?php echo esc_html(get_option('ccjv_core_token_symbol','CCJV')); ?></span>
      <span>Fee: 35.00 / month</span>
      <span>Runtime: Treasury-linked</span>
    </div>
  </header>

  <section class="ccjv-accounting-kpis" id="ccjv-accounting-kpis">Loading accounting KPIs…</section>

  <section class="ccjv-crm-tabs">
    <button data-acct-tab="ledger" class="active">General Ledger</button>
    <button data-acct-tab="chart">Chart</button>
    <button data-acct-tab="invoices">AP / AR</button>
    <button data-acct-tab="payments">Payments</button>
    <button data-acct-tab="reconciliation">Reconciliation</button>
    <button data-acct-tab="reports">Reports</button>
    <button data-acct-tab="treasury">Treasury Cockpit</button>
  </section>

  <section class="ccjv-crm-toolbar">
    <input id="ccjv-accounting-search" placeholder="Search ledger, invoices, payments">
    <select id="ccjv-accounting-status">
      <option value="">All statuses</option>
      <option value="open">Open</option>
      <option value="posted">Posted</option>
      <option value="paid">Paid</option>
      <option value="pending">Pending</option>
      <option value="variance">Variance</option>
    </select>
  </section>

  <section class="ccjv-acct-panel" data-acct-panel="ledger">
    <div class="ccjv-erp-grid">
      <div class="ccjv-erp-card">
        <h2>Create Journal Entry</h2>
        <form class="ccjv-acct-form" data-entity="journals">
          <label>Journal No<input name="journal_no" placeholder="J-1001"></label>
          <label>Memo<input name="memo"></label>
          <label>Journal Date<input name="journal_date" type="date"></label>
          <label>Account ID<input name="account_id" type="number"></label>
          <label>Debit<input name="debit" type="number" step="0.01" value="0"></label>
          <label>Credit<input name="credit" type="number" step="0.01" value="0"></label>
          <button class="ccjv-erp-button">Post Journal</button>
        </form>
      </div>
      <div class="ccjv-erp-card">
        <h2>Ledger View</h2>
        <div id="ccjv-acct-ledger" class="ccjv-advanced-table">Loading ledger…</div>
      </div>
    </div>
  </section>

  <section class="ccjv-acct-panel hidden" data-acct-panel="chart">
    <div class="ccjv-erp-grid">
      <div class="ccjv-erp-card">
        <h2>Add Chart Account</h2>
        <form class="ccjv-acct-form" data-entity="accounts">
          <label>Code<input name="account_code" required></label>
          <label>Name<input name="account_name" required></label>
          <label>Type<select name="account_type"><option>asset</option><option>liability</option><option>equity</option><option>revenue</option><option>expense</option></select></label>
          <label>Normal Balance<select name="normal_balance"><option>debit</option><option>credit</option></select></label>
          <button class="ccjv-erp-button">Save Account</button>
        </form>
      </div>
      <div class="ccjv-erp-card">
        <h2>Chart of Accounts</h2>
        <div id="ccjv-acct-accounts" class="ccjv-advanced-table">Loading chart…</div>
      </div>
    </div>
  </section>

  <section class="ccjv-acct-panel hidden" data-acct-panel="invoices">
    <div class="ccjv-erp-grid">
      <div class="ccjv-erp-card">
        <h2>Create Invoice / Bill</h2>
        <form class="ccjv-acct-form" data-entity="invoices">
          <label>Invoice No<input name="invoice_no"></label>
          <label>Counterparty<input name="counterparty" required></label>
          <label>Type<select name="invoice_type"><option value="ar">AR Invoice</option><option value="ap">AP Bill</option></select></label>
          <label>Issue Date<input name="issue_date" type="date"></label>
          <label>Due Date<input name="due_date" type="date"></label>
          <label>Amount<input name="amount" type="number" step="0.01"></label>
          <button class="ccjv-erp-button">Save Invoice</button>
        </form>
      </div>
      <div class="ccjv-erp-card">
        <h2>AP / AR Aging</h2>
        <div id="ccjv-acct-aging" class="ccjv-forecast-grid">Loading aging…</div>
        <h2>Invoices</h2>
        <div id="ccjv-acct-invoices" class="ccjv-advanced-table">Loading invoices…</div>
      </div>
    </div>
  </section>

  <section class="ccjv-acct-panel hidden" data-acct-panel="payments">
    <div class="ccjv-erp-grid">
      <div class="ccjv-erp-card">
        <h2>Record Payment</h2>
        <form class="ccjv-acct-form" data-entity="payments">
          <label>Invoice ID<input name="invoice_id" type="number"></label>
          <label>Payment Ref<input name="payment_ref"></label>
          <label>Payment Date<input name="payment_date" type="date"></label>
          <label>Amount<input name="amount" type="number" step="0.01"></label>
          <label>Method<select name="method"><option>token</option><option>bank</option><option>card</option></select></label>
          <label>Tx Hash<input name="tx_hash"></label>
          <button class="ccjv-erp-button">Save Payment</button>
        </form>
      </div>
      <div class="ccjv-erp-card">
        <h2>Payments</h2>
        <div id="ccjv-acct-payments" class="ccjv-advanced-table">Loading payments…</div>
      </div>
    </div>
  </section>

  <section class="ccjv-acct-panel hidden" data-acct-panel="reconciliation">
    <div class="ccjv-erp-grid">
      <div class="ccjv-erp-card">
        <h2>Run Reconciliation</h2>
        <form class="ccjv-acct-form" data-entity="reconciliations">
          <label>Reconciliation No<input name="reconciliation_no"></label>
          <label>Account ID<input name="account_id" type="number"></label>
          <label>Statement Date<input name="statement_date" type="date"></label>
          <label>Statement Balance<input name="statement_balance" type="number" step="0.01"></label>
          <label>Book Balance<input name="book_balance" type="number" step="0.01"></label>
          <button class="ccjv-erp-button">Save Reconciliation</button>
        </form>
      </div>
      <div class="ccjv-erp-card">
        <h2>Reconciliation Explorer</h2>
        <div id="ccjv-acct-reconciliations" class="ccjv-advanced-table">Loading reconciliations…</div>
      </div>
    </div>
  </section>

  <section class="ccjv-acct-panel hidden" data-acct-panel="reports">
    <div class="ccjv-erp-grid">
      <div class="ccjv-erp-card">
        <h2>Generate Report</h2>
        <form class="ccjv-acct-form" data-entity="reports">
          <label>Report Type<select name="report_type"><option>balance_sheet</option><option>income_statement</option><option>cashflow</option><option>aging</option></select></label>
          <label>Period Start<input name="period_start" type="date"></label>
          <label>Period End<input name="period_end" type="date"></label>
          <button class="ccjv-erp-button">Generate Report</button>
        </form>
      </div>
      <div class="ccjv-erp-card">
        <h2>Reporting Dashboard</h2>
        <div id="ccjv-acct-reports" class="ccjv-advanced-table">Loading reports…</div>
      </div>
    </div>
  </section>

  <section class="ccjv-acct-panel hidden" data-acct-panel="treasury">
    <h2>Treasury Reconciliation Cockpit</h2>
    <div id="ccjv-acct-treasury" class="ccjv-treasury-cockpit">Loading treasury continuity…</div>
  </section>
</div>
