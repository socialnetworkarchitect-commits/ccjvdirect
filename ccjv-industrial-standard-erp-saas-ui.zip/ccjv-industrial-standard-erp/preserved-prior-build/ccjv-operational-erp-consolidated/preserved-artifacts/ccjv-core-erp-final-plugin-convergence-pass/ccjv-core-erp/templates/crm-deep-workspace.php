<div class="ccjv-erp-workspace ccjv-crm-workspace" data-module="crm">
  <header class="ccjv-workspace-header">
    <div>
      <div class="ccjv-module-icon">👥</div>
      <h1>CRM Runtime Workspace</h1>
      <p>Accounts, contacts, opportunities, activities, pipeline, timelines, vault/replay/treasury continuity.</p>
    </div>
    <div class="ccjv-workspace-status">
      <span>Token Gate: <?php echo esc_html(get_option('ccjv_core_token_symbol','CCJV')); ?></span>
      <span>Fee: 25.00 / month</span>
      <span>Runtime: Bridge-linked</span>
    </div>
  </header>

  <section class="ccjv-crm-tabs">
    <button data-crm-tab="pipeline" class="active">Pipeline</button>
    <button data-crm-tab="accounts">Accounts</button>
    <button data-crm-tab="contacts">Contacts</button>
    <button data-crm-tab="activities">Activities</button>
    <button data-crm-tab="forecast">Forecast</button>
  </section>

  <section class="ccjv-crm-toolbar">
    <input id="ccjv-crm-search" placeholder="Search CRM records, contacts, opportunities">
    <select id="ccjv-crm-status">
      <option value="">All statuses</option>
      <option value="active">Active</option>
      <option value="open">Open</option>
      <option value="won">Won</option>
      <option value="closed">Closed</option>
      <option value="review">Review</option>
    </select>
  </section>

  <section class="ccjv-crm-panel" data-crm-panel="pipeline">
    <h2>Salesforce-style Pipeline Board</h2>
    <div id="ccjv-crm-pipeline" class="ccjv-kanban">Loading pipeline…</div>
  </section>

  <section class="ccjv-crm-panel hidden" data-crm-panel="accounts">
    <div class="ccjv-erp-grid">
      <div class="ccjv-erp-card">
        <h2>Create Account</h2>
        <form class="ccjv-crm-form" data-entity="accounts">
          <label>Account Name<input name="account_name" required></label>
          <label>Industry<input name="industry"></label>
          <label>Status<select name="status"><option>active</option><option>review</option><option>closed</option></select></label>
          <label>Health Score<input name="health_score" type="number" value="75" min="0" max="100"></label>
          <button class="ccjv-erp-button">Save Account</button>
        </form>
      </div>
      <div class="ccjv-erp-card">
        <h2>Account Overview</h2>
        <div id="ccjv-crm-accounts" class="ccjv-advanced-table">Loading accounts…</div>
      </div>
    </div>
  </section>

  <section class="ccjv-crm-panel hidden" data-crm-panel="contacts">
    <div class="ccjv-erp-grid">
      <div class="ccjv-erp-card">
        <h2>Create Contact</h2>
        <form class="ccjv-crm-form" data-entity="contacts">
          <label>Full Name<input name="full_name" required></label>
          <label>Email<input name="email" type="email"></label>
          <label>Phone<input name="phone"></label>
          <label>Title<input name="title"></label>
          <button class="ccjv-erp-button">Save Contact</button>
        </form>
      </div>
      <div class="ccjv-erp-card">
        <h2>Contact Timeline</h2>
        <div id="ccjv-crm-contacts" class="ccjv-advanced-table">Loading contacts…</div>
      </div>
    </div>
  </section>

  <section class="ccjv-crm-panel hidden" data-crm-panel="activities">
    <div class="ccjv-erp-grid">
      <div class="ccjv-erp-card">
        <h2>Create Activity / Task</h2>
        <form class="ccjv-crm-form" data-entity="activities">
          <label>Type<select name="activity_type"><option>note</option><option>call</option><option>email</option><option>meeting</option><option>task</option></select></label>
          <label>Subject<input name="subject" required></label>
          <label>Details<textarea name="details"></textarea></label>
          <label>Status<select name="status"><option>open</option><option>done</option><option>blocked</option></select></label>
          <button class="ccjv-erp-button">Save Activity</button>
        </form>
      </div>
      <div class="ccjv-erp-card">
        <h2>Activity Feed</h2>
        <div id="ccjv-crm-activities" class="ccjv-activity-feed">Loading activities…</div>
      </div>
    </div>
  </section>

  <section class="ccjv-crm-panel hidden" data-crm-panel="forecast">
    <h2>Opportunity Forecasting</h2>
    <div id="ccjv-crm-forecast" class="ccjv-forecast-grid">Loading forecast…</div>
  </section>
</div>
