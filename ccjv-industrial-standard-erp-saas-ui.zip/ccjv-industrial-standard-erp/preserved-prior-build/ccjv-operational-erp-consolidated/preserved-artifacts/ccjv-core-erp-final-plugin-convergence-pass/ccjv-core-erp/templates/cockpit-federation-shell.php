<div class="ccjv-erp-workspace ccjv-cockpit-federation">
  <header class="ccjv-workspace-header">
    <div><div class="ccjv-module-icon">🧠</div><h1>Federated Runtime Cockpit</h1><p>Global search, runtime bridge health, token entitlement visibility, replay and treasury synchronization.</p></div>
    <div class="ccjv-workspace-status"><span id="ccjv-cockpit-runtime-status">Runtime checking…</span><span>Token Entitlements: Active</span></div>
  </header>
  <section class="ccjv-command-palette"><input id="ccjv-global-search" placeholder="Search all ERP modules"><button class="ccjv-erp-button" id="ccjv-bridge-sync">Queue Runtime Sync</button></section>
  <section class="ccjv-cockpit-kpis" id="ccjv-cockpit-kpis">Loading cockpit summary…</section>
  <section class="ccjv-erp-grid">
    <div class="ccjv-erp-card"><h2>Workspace Federation</h2><div class="ccjv-workspace-switcher"><?php foreach (CCJV_Core_Modules::all() as $key => $module): ?><a href="<?php echo esc_url(add_query_arg(['ccjv_module'=>$key])); ?>"><?php echo esc_html($module['icon'].' '.$module['label']); ?></a><?php endforeach; ?></div></div>
    <div class="ccjv-erp-card"><h2>Token Entitlements</h2><div id="ccjv-entitlement-list" class="ccjv-advanced-table">Loading entitlements…</div></div>
  </section>
  <section class="ccjv-erp-grid">
    <div class="ccjv-erp-card"><h2>Global Search Results</h2><div id="ccjv-global-results" class="ccjv-advanced-table">Search to begin.</div></div>
    <div class="ccjv-erp-card"><h2>Runtime Bridge Events</h2><div id="ccjv-bridge-events" class="ccjv-advanced-table">Loading bridge events…</div></div>
  </section>
</div>
