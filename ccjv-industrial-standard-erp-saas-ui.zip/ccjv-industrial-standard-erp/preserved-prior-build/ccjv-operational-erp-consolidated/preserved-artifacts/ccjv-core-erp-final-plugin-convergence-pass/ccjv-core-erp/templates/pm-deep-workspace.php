<div class="ccjv-erp-workspace ccjv-pm-workspace" data-module="projects">
  <header class="ccjv-workspace-header">
    <div>
      <div class="ccjv-module-icon">📋</div>
      <h1>Project Management Runtime Workspace</h1>
      <p>Projects, milestones, tasks, dependencies, approvals, kanban, gantt, workload, documents and replay-linked collaboration.</p>
    </div>
    <div class="ccjv-workspace-status">
      <span>Token Gate: <?php echo esc_html(get_option('ccjv_core_token_symbol','CCJV')); ?></span>
      <span>Fee: 30.00 / month</span>
      <span>Runtime: Replay + Vault linked</span>
    </div>
  </header>

  <section class="ccjv-crm-tabs">
    <button data-pm-tab="kanban" class="active">Kanban</button>
    <button data-pm-tab="projects">Projects</button>
    <button data-pm-tab="gantt">Gantt</button>
    <button data-pm-tab="dependencies">Dependencies</button>
    <button data-pm-tab="workload">Workload</button>
    <button data-pm-tab="approvals">Approvals</button>
    <button data-pm-tab="documents">Documents</button>
  </section>

  <section class="ccjv-crm-toolbar">
    <input id="ccjv-pm-search" placeholder="Search projects, milestones, tasks">
    <select id="ccjv-pm-status">
      <option value="">All statuses</option><option value="todo">Todo</option><option value="in_progress">In Progress</option><option value="blocked">Blocked</option><option value="review">Review</option><option value="done">Done</option>
    </select>
  </section>

  <section class="ccjv-pm-panel" data-pm-panel="kanban">
    <div class="ccjv-erp-grid">
      <div class="ccjv-erp-card">
        <h2>Create Task</h2>
        <form class="ccjv-pm-form" data-entity="tasks">
          <label>Project ID<input name="project_id" type="number" value="0"></label>
          <label>Task Title<input name="task_title" required></label>
          <label>Assignee ID<input name="assignee_id" type="number"></label>
          <label>Status<select name="status"><option>todo</option><option>in_progress</option><option>blocked</option><option>review</option><option>done</option></select></label>
          <label>Priority<select name="priority"><option>low</option><option selected>normal</option><option>high</option><option>critical</option></select></label>
          <label>Start<input name="starts_at" type="date"></label>
          <label>Due<input name="due_date" type="date"></label>
          <label>Estimate Hours<input name="estimate_hours" type="number" step="0.25" value="0"></label>
          <button class="ccjv-erp-button">Save Task</button>
        </form>
      </div>
      <div class="ccjv-erp-card pm-wide"><h2>Kanban Board</h2><div id="ccjv-pm-kanban" class="ccjv-kanban">Loading kanban…</div></div>
    </div>
  </section>

  <section class="ccjv-pm-panel hidden" data-pm-panel="projects">
    <div class="ccjv-erp-grid">
      <div class="ccjv-erp-card">
        <h2>Create Project</h2>
        <form class="ccjv-pm-form" data-entity="projects">
          <label>Project Code<input name="project_code"></label><label>Project Name<input name="project_name" required></label>
          <label>Priority<select name="priority"><option>low</option><option selected>normal</option><option>high</option><option>critical</option></select></label>
          <label>Budget<input name="budget" type="number" step="0.01"></label><label>Starts<input name="starts_at" type="date"></label><label>Ends<input name="ends_at" type="date"></label>
          <button class="ccjv-erp-button">Save Project</button>
        </form>
      </div>
      <div class="ccjv-erp-card"><h2>Project Portfolio</h2><div id="ccjv-pm-projects" class="ccjv-advanced-table">Loading projects…</div></div>
    </div>
  </section>

  <section class="ccjv-pm-panel hidden" data-pm-panel="gantt"><h2>Gantt Timeline</h2><div id="ccjv-pm-gantt" class="ccjv-gantt">Loading gantt…</div></section>

  <section class="ccjv-pm-panel hidden" data-pm-panel="dependencies">
    <div class="ccjv-erp-grid"><div class="ccjv-erp-card"><h2>Add Dependency</h2><form class="ccjv-pm-form" data-entity="dependencies"><label>Predecessor Task ID<input name="predecessor_task_id" type="number" required></label><label>Successor Task ID<input name="successor_task_id" type="number" required></label><label>Type<select name="dependency_type"><option>finish_to_start</option><option>start_to_start</option><option>finish_to_finish</option></select></label><button class="ccjv-erp-button">Save Dependency</button></form></div><div class="ccjv-erp-card"><h2>Dependency Graph</h2><div id="ccjv-pm-dependencies" class="ccjv-dependency-graph">Loading dependencies…</div></div></div>
  </section>

  <section class="ccjv-pm-panel hidden" data-pm-panel="workload"><h2>Workload Planning</h2><div id="ccjv-pm-workload" class="ccjv-forecast-grid">Loading workload…</div></section>

  <section class="ccjv-pm-panel hidden" data-pm-panel="approvals">
    <div class="ccjv-erp-grid"><div class="ccjv-erp-card"><h2>Create Approval</h2><form class="ccjv-pm-form" data-entity="approvals"><label>Project ID<input name="project_id" type="number" required></label><label>Entity Type<input name="entity_type" value="task"></label><label>Entity ID<input name="entity_id" type="number" required></label><label>Decision<select name="decision"><option>pending</option><option>approved</option><option>rejected</option></select></label><label>Comment<textarea name="comment"></textarea></label><button class="ccjv-erp-button">Save Approval</button></form></div><div class="ccjv-erp-card"><h2>Approval Workflow</h2><div id="ccjv-pm-approvals" class="ccjv-advanced-table">Loading approvals…</div></div></div>
  </section>

  <section class="ccjv-pm-panel hidden" data-pm-panel="documents">
    <div class="ccjv-erp-grid"><div class="ccjv-erp-card"><h2>Link Document / Evidence</h2><form class="ccjv-pm-form" data-entity="documents"><label>Project ID<input name="project_id" type="number" required></label><label>Document Title<input name="document_title" required></label><label>Entity Type<input name="entity_type" value="project"></label><label>Entity ID<input name="entity_id" type="number"></label><label>Proof Ref<input name="proof_ref"></label><button class="ccjv-erp-button">Save Document Link</button></form></div><div class="ccjv-erp-card"><h2>Vault-linked Documents</h2><div id="ccjv-pm-documents" class="ccjv-advanced-table">Loading documents…</div></div></div>
  </section>
</div>
