<div class="ccjv-erp-workspace ccjv-final-admin">
  <header class="ccjv-workspace-header">
    <div>
      <div class="ccjv-module-icon">🛡️</div>
      <h1>ERP Admin Convergence Console</h1>
      <p>Tenant settings, RBAC, module pricing, replay/audit viewer, and Avalanche proof explorer.</p>
    </div>
    <div class="ccjv-workspace-status">
      <span>ERP Plugin Controls</span>
      <span>RBAC + Pricing + Proofs</span>
    </div>
  </header>

  <section class="ccjv-crm-tabs">
    <button data-final-tab="rbac" class="active">RBAC Matrix</button>
    <button data-final-tab="pricing">Module Pricing</button>
    <button data-final-tab="tenant">Tenant Settings</button>
    <button data-final-tab="audit">Replay / Audit</button>
    <button data-final-tab="proofs">Avalanche Proof Explorer</button>
    <button data-final-tab="summary">Module Depth Summary</button>
  </section>

  <section class="ccjv-final-panel" data-final-panel="rbac">
    <div class="ccjv-erp-grid">
      <div class="ccjv-erp-card">
        <h2>Create Role</h2>
        <form class="ccjv-final-form" data-endpoint="/admin/rbac/roles">
          <label>Role Key<input name="role_key" placeholder="operations_manager"></label>
          <label>Role Name<input name="role_name" placeholder="Operations Manager"></label>
          <label>Description<textarea name="description"></textarea></label>
          <button class="ccjv-erp-button">Save Role</button>
        </form>
      </div>
      <div class="ccjv-erp-card">
        <h2>Permission Matrix</h2>
        <form class="ccjv-final-form ccjv-inline-form" data-endpoint="/admin/rbac/permissions">
          <input name="role_key" placeholder="role_key">
          <input name="module_key" placeholder="module_key">
          <input name="permission_key" placeholder="view/create/edit/approve/export/admin">
          <select name="allowed"><option value="1">Allowed</option><option value="0">Denied</option></select>
          <button class="ccjv-erp-button">Save</button>
        </form>
        <div id="ccjv-rbac-list" class="ccjv-advanced-table">Loading RBAC…</div>
      </div>
    </div>
  </section>

  <section class="ccjv-final-panel hidden" data-final-panel="pricing">
    <div class="ccjv-erp-card">
      <h2>Module Fee / Reward Editor</h2>
      <form class="ccjv-final-form ccjv-inline-form" data-endpoint="/admin/module-pricing">
        <input name="module_key" placeholder="module_key">
        <input name="monthly_fee" placeholder="monthly fee">
        <input name="upload_reward" placeholder="upload reward">
        <input name="view_fee" placeholder="view fee">
        <input name="download_fee" placeholder="download fee">
        <button class="ccjv-erp-button">Save Pricing</button>
      </form>
      <div id="ccjv-pricing-list" class="ccjv-advanced-table">Loading pricing…</div>
    </div>
  </section>

  <section class="ccjv-final-panel hidden" data-final-panel="tenant">
    <div class="ccjv-erp-card">
      <h2>Tenant Settings</h2>
      <form class="ccjv-final-form" data-endpoint="/admin/tenant-settings">
        <label>Setting Key<input name="setting_key" placeholder="brand_profile"></label>
        <label>Setting JSON<textarea name="setting_value" placeholder='{"name":"CCJV","accent":"blue"}'></textarea></label>
        <button class="ccjv-erp-button">Save Setting</button>
      </form>
      <div id="ccjv-tenant-settings" class="ccjv-advanced-table">Loading settings…</div>
    </div>
  </section>

  <section class="ccjv-final-panel hidden" data-final-panel="audit">
    <div class="ccjv-erp-card">
      <h2>Replay / Audit Explorer</h2>
      <div id="ccjv-audit-replay" class="ccjv-advanced-table">Loading audit trail…</div>
    </div>
  </section>

  <section class="ccjv-final-panel hidden" data-final-panel="proofs">
    <div class="ccjv-erp-card">
      <h2>Avalanche Proof Explorer</h2>
      <form class="ccjv-final-form ccjv-inline-form" data-endpoint="/admin/proofs">
        <input name="source_module" placeholder="source module">
        <input name="source_record_id" placeholder="record id">
        <input name="vault_hash" placeholder="vault hash">
        <input name="replay_id" placeholder="replay id">
        <button class="ccjv-erp-button">Record Proof</button>
      </form>
      <div id="ccjv-proof-list" class="ccjv-advanced-table">Loading proofs…</div>
    </div>
  </section>

  <section class="ccjv-final-panel hidden" data-final-panel="summary">
    <div class="ccjv-erp-card">
      <h2>Module Depth Summary</h2>
      <div id="ccjv-depth-summary" class="ccjv-depth-grid">Loading depth summary…</div>
    </div>
  </section>
</div>
