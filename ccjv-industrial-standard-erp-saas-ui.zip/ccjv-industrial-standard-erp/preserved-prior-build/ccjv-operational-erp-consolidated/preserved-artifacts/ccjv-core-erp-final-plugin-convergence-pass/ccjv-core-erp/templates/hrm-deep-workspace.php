<div class="ccjv-erp-workspace ccjv-hrm-workspace" data-module="hrm">
  <header class="ccjv-workspace-header">
    <div>
      <div class="ccjv-module-icon">🧑‍🏭</div>
      <h1>HRM Runtime Workspace</h1>
      <p>Employees, contractors, departments, certifications, competencies, schedules, readiness, onboarding, training and replay-linked workforce continuity.</p>
    </div>
    <div class="ccjv-workspace-status">
      <span>Token Gate: <?php echo esc_html(get_option('ccjv_core_token_symbol','CCJV')); ?></span>
      <span>Fee: 25.00 / month</span>
      <span>Runtime: HRM Bridge-linked</span>
    </div>
  </header>

  <section class="ccjv-hrm-kpis" id="ccjv-hrm-readiness">Loading readiness…</section>

  <section class="ccjv-crm-tabs">
    <button data-hrm-tab="workforce" class="active">Workforce</button>
    <button data-hrm-tab="certifications">Certifications</button>
    <button data-hrm-tab="schedule">Schedule</button>
    <button data-hrm-tab="readiness">Readiness Heatmap</button>
    <button data-hrm-tab="org">Org Chart</button>
    <button data-hrm-tab="training">Training</button>
  </section>

  <section class="ccjv-crm-toolbar">
    <input id="ccjv-hrm-search" placeholder="Search people, certifications, schedules">
    <select id="ccjv-hrm-status">
      <option value="">All statuses</option>
      <option value="active">Active</option>
      <option value="contractor">Contractor</option>
      <option value="valid">Valid</option>
      <option value="expired">Expired</option>
      <option value="scheduled">Scheduled</option>
    </select>
  </section>

  <section class="ccjv-hrm-panel" data-hrm-panel="workforce">
    <div class="ccjv-erp-grid">
      <div class="ccjv-erp-card">
        <h2>Add Employee / Contractor</h2>
        <form class="ccjv-hrm-form" data-entity="people">
          <label>Type<select name="person_type"><option value="employee">Employee</option><option value="contractor">Contractor</option></select></label>
          <label>Full Name<input name="full_name" required></label>
          <label>Email<input name="email" type="email"></label>
          <label>Phone<input name="phone"></label>
          <label>Role Title<input name="role_title"></label>
          <label>Readiness Score<input name="readiness_score" type="number" value="75" min="0" max="100"></label>
          <button class="ccjv-erp-button">Save Workforce Profile</button>
        </form>
      </div>
      <div class="ccjv-erp-card">
        <h2>Workforce Dashboard</h2>
        <div id="ccjv-hrm-people" class="ccjv-advanced-table">Loading workforce…</div>
      </div>
    </div>
  </section>

  <section class="ccjv-hrm-panel hidden" data-hrm-panel="certifications">
    <div class="ccjv-erp-grid">
      <div class="ccjv-erp-card">
        <h2>Add Certification</h2>
        <form class="ccjv-hrm-form" data-entity="certifications">
          <label>Person ID<input name="person_id" type="number" required></label>
          <label>Certification<input name="certification_name" required></label>
          <label>Issuer<input name="issuer"></label>
          <label>Issued At<input name="issued_at" type="date"></label>
          <label>Expires At<input name="expires_at" type="date"></label>
          <button class="ccjv-erp-button">Save Certification</button>
        </form>
      </div>
      <div class="ccjv-erp-card">
        <h2>Certification Expiry Warnings</h2>
        <div id="ccjv-hrm-certifications" class="ccjv-advanced-table">Loading certifications…</div>
      </div>
    </div>
  </section>

  <section class="ccjv-hrm-panel hidden" data-hrm-panel="schedule">
    <div class="ccjv-erp-grid">
      <div class="ccjv-erp-card">
        <h2>Add Schedule</h2>
        <form class="ccjv-hrm-form" data-entity="schedules">
          <label>Person ID<input name="person_id" type="number" required></label>
          <label>Shift Title<input name="shift_title" required></label>
          <label>Starts At<input name="starts_at" type="datetime-local"></label>
          <label>Ends At<input name="ends_at" type="datetime-local"></label>
          <label>Location<input name="location"></label>
          <button class="ccjv-erp-button">Save Schedule</button>
        </form>
      </div>
      <div class="ccjv-erp-card">
        <h2>Schedule Calendar</h2>
        <div id="ccjv-hrm-schedules" class="ccjv-schedule-calendar">Loading schedule…</div>
      </div>
    </div>
  </section>

  <section class="ccjv-hrm-panel hidden" data-hrm-panel="readiness">
    <h2>Readiness Heatmap</h2>
    <div id="ccjv-hrm-heatmap" class="ccjv-readiness-heatmap">Loading readiness heatmap…</div>
  </section>

  <section class="ccjv-hrm-panel hidden" data-hrm-panel="org">
    <h2>Org Chart</h2>
    <div id="ccjv-hrm-org" class="ccjv-org-chart">Loading org chart…</div>
  </section>

  <section class="ccjv-hrm-panel hidden" data-hrm-panel="training">
    <div class="ccjv-erp-grid">
      <div class="ccjv-erp-card">
        <h2>Add Training Workflow</h2>
        <form class="ccjv-hrm-form" data-entity="training">
          <label>Person ID<input name="person_id" type="number" required></label>
          <label>Training Title<input name="training_title" required></label>
          <label>Stage<select name="stage"><option>assigned</option><option>in_progress</option><option>complete</option></select></label>
          <label>Due At<input name="due_at" type="date"></label>
          <button class="ccjv-erp-button">Save Training</button>
        </form>
      </div>
      <div class="ccjv-erp-card">
        <h2>Training Workflows</h2>
        <div id="ccjv-hrm-training" class="ccjv-advanced-table">Loading training…</div>
      </div>
    </div>
  </section>
</div>
