<div class="ccjv-erp-workspace ccjv-asset-iot-workspace" data-module="asset-iot">
  <header class="ccjv-workspace-header">
    <div><div class="ccjv-module-icon">🏗️📡</div><h1>Asset + IoT Runtime Workspace</h1><p>Fleet, equipment, inspections, maintenance, geolocation, digital twins, telemetry, anomaly alerts and replay-linked operational overlays.</p></div>
    <div class="ccjv-workspace-status"><span>Token Gate: <?php echo esc_html(get_option('ccjv_core_token_symbol','CCJV')); ?></span><span>Fee: 35.00 / month</span><span>Runtime: Telemetry + Twin linked</span></div>
  </header>

  <section class="ccjv-asset-kpis" id="ccjv-asset-kpis">Loading asset runtime…</section>

  <section class="ccjv-crm-tabs">
    <button data-ai-tab="map" class="active">Live Map</button><button data-ai-tab="assets">Assets</button><button data-ai-tab="maintenance">Maintenance</button><button data-ai-tab="inspections">Inspections</button><button data-ai-tab="twins">Digital Twins</button><button data-ai-tab="telemetry">Telemetry</button><button data-ai-tab="alerts">Alerts</button>
  </section>

  <section class="ccjv-crm-toolbar"><input id="ccjv-asset-search" placeholder="Search assets, sensors, locations"><select id="ccjv-asset-status"><option value="">All statuses</option><option>active</option><option>open</option><option>normal</option><option>anomaly</option><option>critical</option></select></section>

  <section class="ccjv-ai-panel" data-ai-panel="map"><h2>Operational Map Overlay</h2><div id="ccjv-asset-map" class="ccjv-map-board">Loading map…</div></section>

  <section class="ccjv-ai-panel hidden" data-ai-panel="assets">
    <div class="ccjv-erp-grid"><div class="ccjv-erp-card"><h2>Register Asset</h2><form class="ccjv-ai-form" data-entity="assets"><label>Asset Code<input name="asset_code"></label><label>Asset Name<input name="asset_name" required></label><label>Type<select name="asset_type"><option>equipment</option><option>fleet</option><option>container</option><option>facility</option></select></label><label>Latitude<input name="latitude" type="number" step="0.000001"></label><label>Longitude<input name="longitude" type="number" step="0.000001"></label><label>Location<input name="location_label"></label><label>Health Score<input name="health_score" type="number" value="80"></label><button class="ccjv-erp-button">Save Asset</button></form></div><div class="ccjv-erp-card"><h2>Asset Explorer</h2><div id="ccjv-assets-list" class="ccjv-advanced-table">Loading assets…</div></div></div>
  </section>

  <section class="ccjv-ai-panel hidden" data-ai-panel="maintenance">
    <div class="ccjv-erp-grid"><div class="ccjv-erp-card"><h2>Create Maintenance Work Order</h2><form class="ccjv-ai-form" data-entity="maintenance"><label>Asset ID<input name="asset_id" type="number" required></label><label>Work Order<input name="work_order"></label><label>Type<select name="maintenance_type"><option>preventive</option><option>corrective</option><option>emergency</option></select></label><label>Priority<select name="priority"><option>low</option><option selected>normal</option><option>high</option><option>critical</option></select></label><label>Scheduled<input name="scheduled_at" type="datetime-local"></label><label>Notes<textarea name="notes"></textarea></label><button class="ccjv-erp-button">Save Work Order</button></form></div><div class="ccjv-erp-card"><h2>Maintenance Board</h2><div id="ccjv-maintenance-list" class="ccjv-advanced-table">Loading maintenance…</div></div></div>
  </section>

  <section class="ccjv-ai-panel hidden" data-ai-panel="inspections">
    <div class="ccjv-erp-grid"><div class="ccjv-erp-card"><h2>Record Inspection</h2><form class="ccjv-ai-form" data-entity="inspections"><label>Asset ID<input name="asset_id" type="number" required></label><label>Type<input name="inspection_type" value="routine"></label><label>Result<select name="result"><option>pass</option><option>warning</option><option>fail</option></select></label><label>Findings<textarea name="findings"></textarea></label><button class="ccjv-erp-button">Save Inspection</button></form></div><div class="ccjv-erp-card"><h2>Inspection History</h2><div id="ccjv-inspections-list" class="ccjv-advanced-table">Loading inspections…</div></div></div>
  </section>

  <section class="ccjv-ai-panel hidden" data-ai-panel="twins">
    <div class="ccjv-erp-grid"><div class="ccjv-erp-card"><h2>Create Digital Twin</h2><form class="ccjv-ai-form" data-entity="twins"><label>Asset ID<input name="asset_id" type="number" required></label><label>Model Ref<input name="model_ref"></label><label>Telemetry Ref<input name="telemetry_ref"></label><button class="ccjv-erp-button">Save Twin</button></form></div><div class="ccjv-erp-card"><h2>Twin Visualization</h2><div id="ccjv-twins-list" class="ccjv-twin-board">Loading twins…</div></div></div>
  </section>

  <section class="ccjv-ai-panel hidden" data-ai-panel="telemetry">
    <div class="ccjv-erp-grid"><div class="ccjv-erp-card"><h2>Register Sensor</h2><form class="ccjv-ai-form" data-entity="sensors"><label>Asset ID<input name="asset_id" type="number"></label><label>Sensor Name<input name="sensor_name" required></label><label>Type<input name="sensor_type" value="telemetry"></label><label>Unit<input name="unit"></label><button class="ccjv-erp-button">Save Sensor</button></form><h2>Capture Telemetry</h2><form class="ccjv-ai-form" data-entity="telemetry"><label>Sensor ID<input name="sensor_id" type="number" required></label><label>Asset ID<input name="asset_id" type="number"></label><label>Metric<input name="metric" value="temperature"></label><label>Value<input name="value" type="number" step="0.000001"></label><label>Unit<input name="unit"></label><label>Threshold<input name="threshold" type="number" step="0.000001"></label><button class="ccjv-erp-button">Capture Telemetry</button></form></div><div class="ccjv-erp-card"><h2>Real-time Telemetry Dashboard</h2><div id="ccjv-telemetry-chart" class="ccjv-telemetry-chart">Loading telemetry…</div><h2>Sensors</h2><div id="ccjv-sensors-list" class="ccjv-advanced-table">Loading sensors…</div></div></div>
  </section>

  <section class="ccjv-ai-panel hidden" data-ai-panel="alerts"><h2>Alert Stream</h2><div id="ccjv-alerts-list" class="ccjv-alert-stream">Loading alerts…</div></section>
</div>
