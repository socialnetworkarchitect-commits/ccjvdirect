<div class="ccjv-erp-workspace ccjv-procgov-workspace" data-module="procurement-governance">
  <header class="ccjv-workspace-header">
    <div>
      <div class="ccjv-module-icon">🧾⚖️</div>
      <h1>Procurement + Governance Runtime Workspace</h1>
      <p>RFQs, bids, vendor scoring, purchase orders, workflow approvals, proposals, voting, quorum and replay-linked policy lineage.</p>
    </div>
    <div class="ccjv-workspace-status">
      <span>Token Gate: <?php echo esc_html(get_option('ccjv_core_token_symbol','CCJV')); ?></span>
      <span>Runtime: Treasury + Replay linked</span>
    </div>
  </header>

  <section class="ccjv-crm-tabs">
    <button data-pg-tab="rfqs" class="active">RFQs</button>
    <button data-pg-tab="bids">Bid Comparison</button>
    <button data-pg-tab="pos">Purchase Orders</button>
    <button data-pg-tab="proposals">Proposals</button>
    <button data-pg-tab="votes">Voting + Quorum</button>
  </section>

  <section class="ccjv-pg-panel" data-pg-panel="rfqs">
    <div class="ccjv-erp-grid">
      <div class="ccjv-erp-card"><h2>Create RFQ</h2>
        <form class="ccjv-pg-form" data-endpoint="/procurement/rfqs">
          <label>Title<input name="title" required></label>
          <label>Budget<input name="budget" type="number" step="0.01"></label>
          <label>Description<textarea name="description"></textarea></label>
          <button class="ccjv-erp-button">Create RFQ</button>
        </form>
      </div>
      <div class="ccjv-erp-card"><h2>RFQ Register</h2><div id="ccjv-pg-rfqs" class="ccjv-advanced-table">Loading RFQs…</div></div>
    </div>
  </section>

  <section class="ccjv-pg-panel hidden" data-pg-panel="bids">
    <div class="ccjv-erp-grid">
      <div class="ccjv-erp-card"><h2>Submit Bid</h2>
        <form class="ccjv-pg-form" data-endpoint="/procurement/bids">
          <label>RFQ ID<input name="rfq_id" type="number" required></label>
          <label>Vendor<input name="vendor_name" required></label>
          <label>Bid Amount<input name="bid_amount" type="number" step="0.01"></label>
          <label>Delivery Days<input name="delivery_days" type="number"></label>
          <label>Score<input name="score" type="number" step="0.01"></label>
          <button class="ccjv-erp-button">Submit Bid</button>
        </form>
      </div>
      <div class="ccjv-erp-card"><h2>Bid Comparison</h2><div id="ccjv-pg-bids" class="ccjv-advanced-table">Loading bids…</div></div>
    </div>
  </section>

  <section class="ccjv-pg-panel hidden" data-pg-panel="pos">
    <div class="ccjv-erp-grid">
      <div class="ccjv-erp-card"><h2>Create Purchase Order</h2>
        <form class="ccjv-pg-form" data-endpoint="/procurement/pos">
          <label>PO Number<input name="po_number"></label>
          <label>Vendor<input name="vendor_name" required></label>
          <label>Total<input name="total_amount" type="number" step="0.01"></label>
          <label>Status<select name="approval_status"><option>pending</option><option>approved</option><option>rejected</option></select></label>
          <button class="ccjv-erp-button">Create PO</button>
        </form>
      </div>
      <div class="ccjv-erp-card"><h2>PO Lifecycle</h2><div id="ccjv-pg-pos" class="ccjv-advanced-table">Loading POs…</div></div>
    </div>
  </section>

  <section class="ccjv-pg-panel hidden" data-pg-panel="proposals">
    <div class="ccjv-erp-grid">
      <div class="ccjv-erp-card"><h2>Create Proposal</h2>
        <form class="ccjv-pg-form" data-endpoint="/governance/proposals">
          <label>Title<input name="title" required></label>
          <label>Quorum Required<input name="quorum_required" type="number" value="50"></label>
          <label>Proposal Text<textarea name="proposal_text"></textarea></label>
          <button class="ccjv-erp-button">Create Proposal</button>
        </form>
      </div>
      <div class="ccjv-erp-card"><h2>Proposal Explorer</h2><div id="ccjv-pg-proposals" class="ccjv-advanced-table">Loading proposals…</div></div>
    </div>
  </section>

  <section class="ccjv-pg-panel hidden" data-pg-panel="votes">
    <div class="ccjv-erp-grid">
      <div class="ccjv-erp-card"><h2>Cast Vote</h2>
        <form class="ccjv-pg-form" data-endpoint="/governance/votes">
          <label>Proposal ID<input name="proposal_id" type="number" required></label>
          <label>Vote<select name="vote"><option>yes</option><option>no</option><option>abstain</option></select></label>
          <label>Voting Power<input name="voting_power" type="number" step="0.01" value="1"></label>
          <button class="ccjv-erp-button">Cast Vote</button>
        </form>
      </div>
      <div class="ccjv-erp-card"><h2>Governance Timeline</h2><div id="ccjv-pg-votes" class="ccjv-advanced-table">Loading votes…</div></div>
    </div>
  </section>
</div>
