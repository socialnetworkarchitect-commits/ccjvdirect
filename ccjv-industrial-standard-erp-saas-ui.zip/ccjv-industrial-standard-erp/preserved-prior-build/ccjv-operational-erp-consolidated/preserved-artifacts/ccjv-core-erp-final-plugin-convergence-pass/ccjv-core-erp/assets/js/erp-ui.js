(function(){
  async function api(path, options){
    const res=await fetch(ccjvERP.rest+path,Object.assign({headers:{'Content-Type':'application/json','X-WP-Nonce':ccjvERP.nonce}},options||{}));
    return await res.json();
  }
  async function loadEvents(){
    const el=document.getElementById('ccjv-event-feed'); if(!el)return;
    try{const events=await api('/events'); if(!Array.isArray(events)||events.length===0){el.innerHTML='<p>No runtime events yet.</p>';return;}
    el.innerHTML=events.map(e=>`<div class="ccjv-record-row"><div><strong>${e.event_type}</strong><br><small>${e.module} · ${e.correlation_id||''}</small></div><span>${e.record_id||'-'}</span><small>${e.created_at}</small></div>`).join('');}catch(e){el.innerHTML='<p>Event feed unavailable.</p>';}
  }
  async function loadRecords(module,target){
    try{const records=await api('/records/'+module); if(!Array.isArray(records)||records.length===0){target.innerHTML='<p>No records yet. Create the first one.</p>';return;}
    target.innerHTML=records.map(r=>`<div class="ccjv-record-row"><div><strong>${r.title}</strong><br><small>Vault: ${r.vault_hash||'-'}<br>Replay: ${r.replay_id||'-'}</small></div><span>${r.status}</span><small>${r.created_at}</small></div>`).join('');}catch(e){target.innerHTML='<p>Records unavailable.</p>';}
  }
  function wireForms(){
    document.querySelectorAll('.ccjv-record-form').forEach(form=>{const module=form.dataset.module;form.addEventListener('submit',async e=>{e.preventDefault();const fd=new FormData(form);await api('/records',{method:'POST',body:JSON.stringify({module,title:fd.get('title'),status:fd.get('status'),payload:{notes:fd.get('notes')}})});form.reset();document.querySelectorAll(`.ccjv-record-table[data-module="${module}"]`).forEach(t=>loadRecords(module,t));loadEvents();});});
  }
  function wireRuntime(){
    const live=document.getElementById('ccjv-runtime-live'); if(!live)return;
    if(ccjvERP.runtimeWs){try{const ws=new WebSocket(ccjvERP.runtimeWs);ws.onopen=()=>live.textContent='Runtime websocket connected';ws.onmessage=()=>loadEvents();ws.onerror=()=>live.textContent='Runtime websocket error';}catch(e){live.textContent='Runtime websocket unavailable';}} else live.textContent='Runtime API configured in settings';
  }
  document.addEventListener('DOMContentLoaded',()=>{loadEvents();wireForms();wireRuntime();document.querySelectorAll('.ccjv-record-table').forEach(t=>loadRecords(t.dataset.module,t));});
})();

(function(){
  if(!window.ccjvERP) return;
  async function crmApi(path, options){
    const res = await fetch(ccjvERP.rest + path, Object.assign({
      headers:{'Content-Type':'application/json','X-WP-Nonce':ccjvERP.nonce}
    }, options || {}));
    return await res.json();
  }

  function money(v){ return '$' + Number(v || 0).toLocaleString(); }

  async function loadPipeline(){
    const el = document.getElementById('ccjv-crm-pipeline'); if(!el) return;
    const stages = await crmApi('/crm/pipeline');
    const labels = ['prospecting','qualified','proposal','negotiation','won','lost'];
    el.innerHTML = labels.map(stage => {
      const deals = stages[stage] || [];
      return `<div class="ccjv-kanban-col"><h3>${stage}</h3>${deals.map(d => `<div class="ccjv-deal-card"><strong>${d.title}</strong><small>${money(d.amount)} · ${d.probability}%</small><br><small>Vault ${d.vault_hash || '-'}</small></div>`).join('') || '<small>No opportunities</small>'}</div>`;
    }).join('');
    loadForecast(stages);
  }

  async function loadEntity(entity, targetId){
    const target = document.getElementById(targetId); if(!target) return;
    const rows = await crmApi('/crm/' + entity);
    if(!Array.isArray(rows) || !rows.length){ target.innerHTML = '<p>No records yet.</p>'; return; }
    target.innerHTML = rows.map(r => {
      const title = r.account_name || r.full_name || r.title || r.subject;
      const sub = r.industry || r.email || r.stage || r.activity_type || '';
      const status = r.status || r.stage || 'active';
      return `<div class="ccjv-table-row"><div><strong>${title}</strong><br><small>${sub}<br>Vault ${r.vault_hash || '-'}</small></div><span>${status}</span><small>${r.created_at || ''}</small></div>`;
    }).join('');
  }

  function loadForecast(stages){
    const el = document.getElementById('ccjv-crm-forecast'); if(!el) return;
    let total = 0, weighted = 0, count = 0;
    Object.values(stages || {}).flat().forEach(d => { count++; total += Number(d.amount || 0); weighted += Number(d.amount || 0) * Number(d.probability || 0) / 100; });
    el.innerHTML = `<div class="ccjv-forecast-card"><strong>${count}</strong><span>Open Opportunities</span></div><div class="ccjv-forecast-card"><strong>${money(total)}</strong><span>Total Pipeline</span></div><div class="ccjv-forecast-card"><strong>${money(weighted)}</strong><span>Weighted Forecast</span></div>`;
  }

  function wireCrmTabs(){
    document.querySelectorAll('[data-crm-tab]').forEach(btn => {
      btn.addEventListener('click', () => {
        document.querySelectorAll('[data-crm-tab]').forEach(b => b.classList.remove('active'));
        document.querySelectorAll('[data-crm-panel]').forEach(p => p.classList.add('hidden'));
        btn.classList.add('active');
        const panel = document.querySelector(`[data-crm-panel="${btn.dataset.crmTab}"]`);
        if(panel) panel.classList.remove('hidden');
      });
    });
  }

  function wireCrmForms(){
    document.querySelectorAll('.ccjv-crm-form').forEach(form => {
      form.addEventListener('submit', async e => {
        e.preventDefault();
        const entity = form.dataset.entity;
        const data = {};
        new FormData(form).forEach((v,k) => data[k] = v);
        await crmApi('/crm/' + entity, {method:'POST', body:JSON.stringify(data)});
        form.reset();
        await refreshCrm();
      });
    });
  }

  async function refreshCrm(){
    await loadPipeline();
    await loadEntity('accounts','ccjv-crm-accounts');
    await loadEntity('contacts','ccjv-crm-contacts');
    await loadEntity('activities','ccjv-crm-activities');
  }

  document.addEventListener('DOMContentLoaded', () => {
    wireCrmTabs();
    wireCrmForms();
    refreshCrm();
  });
})();

(function(){
  if(!window.ccjvERP) return;
  async function hrmApi(path, options){
    const res = await fetch(ccjvERP.rest + path, Object.assign({
      headers:{'Content-Type':'application/json','X-WP-Nonce':ccjvERP.nonce}
    }, options || {}));
    return await res.json();
  }
  function esc(s){ return String(s || '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c])); }

  function wireHrmTabs(){
    document.querySelectorAll('[data-hrm-tab]').forEach(btn => {
      btn.addEventListener('click', () => {
        document.querySelectorAll('[data-hrm-tab]').forEach(b => b.classList.remove('active'));
        document.querySelectorAll('[data-hrm-panel]').forEach(p => p.classList.add('hidden'));
        btn.classList.add('active');
        const panel = document.querySelector(`[data-hrm-panel="${btn.dataset.hrmTab}"]`);
        if(panel) panel.classList.remove('hidden');
      });
    });
  }

  async function loadHrmReadiness(){
    const el = document.getElementById('ccjv-hrm-readiness'); if(!el) return;
    const r = await hrmApi('/hrm/readiness');
    el.innerHTML = `<div class="ccjv-hrm-kpi"><strong>${r.people || 0}</strong><span>Total People</span></div><div class="ccjv-hrm-kpi"><strong>${r.active || 0}</strong><span>Active Workforce</span></div><div class="ccjv-hrm-kpi"><strong>${r.avg_readiness || 0}%</strong><span>Avg Readiness</span></div><div class="ccjv-hrm-kpi"><strong>${esc(r.risk || 'n/a')}</strong><span>Operational Risk</span></div>`;
  }

  async function loadHrmEntity(entity, targetId){
    const target = document.getElementById(targetId); if(!target) return;
    const rows = await hrmApi('/hrm/' + entity);
    if(!Array.isArray(rows) || !rows.length){ target.innerHTML = '<p>No records yet.</p>'; return; }
    target.innerHTML = rows.map(r => {
      const title = r.full_name || r.certification_name || r.shift_title || r.training_title || r.name || r.competency || 'Record';
      const sub = r.role_title || r.issuer || r.location || r.stage || r.status || '';
      const status = r.employment_status || r.status || r.person_type || '';
      const expiry = r.expires_at ? `<br><small class="${new Date(r.expires_at) < new Date() ? 'ccjv-expiry-danger' : 'ccjv-expiry-warning'}">Expires: ${esc(r.expires_at)}</small>` : '';
      return `<div class="ccjv-table-row"><div><strong>${esc(title)}</strong><br><small>${esc(sub)}${expiry}<br>Vault ${esc(r.vault_hash || '-')}</small></div><span>${esc(status)}</span><small>${esc(r.created_at || '')}</small></div>`;
    }).join('');
  }

  async function loadSchedule(){
    const el = document.getElementById('ccjv-hrm-schedules'); if(!el) return;
    const rows = await hrmApi('/hrm/schedules');
    if(!Array.isArray(rows) || !rows.length){ el.innerHTML = '<p>No schedule records yet.</p>'; return; }
    el.innerHTML = rows.map(r => `<div class="ccjv-schedule-item"><strong>${esc(r.shift_title)}</strong><br><small>Person #${esc(r.person_id)} · ${esc(r.starts_at)} → ${esc(r.ends_at)} · ${esc(r.location)}</small></div>`).join('');
  }

  async function loadHeatmap(){
    const el = document.getElementById('ccjv-hrm-heatmap'); if(!el) return;
    const people = await hrmApi('/hrm/people');
    if(!Array.isArray(people) || !people.length){ el.innerHTML = '<p>No workforce records yet.</p>'; return; }
    el.innerHTML = people.map(p => {
      const score = Number(p.readiness_score || 0);
      const cls = score >= 80 ? 'high' : score >= 60 ? 'medium' : 'low';
      return `<div class="ccjv-readiness-cell ${cls}"><strong>${esc(p.full_name)}</strong><br><small>${esc(p.role_title)} · ${score}% readiness</small></div>`;
    }).join('');
  }

  async function loadOrg(){
    const el = document.getElementById('ccjv-hrm-org'); if(!el) return;
    const org = await hrmApi('/hrm/org');
    const deps = org.departments || [];
    const people = org.people || [];
    el.innerHTML = deps.map(d => {
      const members = people.filter(p => String(p.department_id || '0') === String(d.id));
      return `<div class="ccjv-org-node"><strong>${esc(d.name)}</strong><br><small>${members.length} people</small>${members.map(m => `<div><small>• ${esc(m.full_name)} — ${esc(m.role_title)}</small></div>`).join('')}</div>`;
    }).join('') || '<p>Create departments to render the org chart.</p>';
  }

  function wireHrmForms(){
    document.querySelectorAll('.ccjv-hrm-form').forEach(form => {
      form.addEventListener('submit', async e => {
        e.preventDefault();
        const entity = form.dataset.entity;
        const data = {};
        new FormData(form).forEach((v,k) => data[k] = v);
        await hrmApi('/hrm/' + entity, {method:'POST', body:JSON.stringify(data)});
        form.reset();
        refreshHrm();
      });
    });
  }

  async function refreshHrm(){
    await loadHrmReadiness();
    await loadHrmEntity('people','ccjv-hrm-people');
    await loadHrmEntity('certifications','ccjv-hrm-certifications');
    await loadSchedule();
    await loadHrmEntity('training','ccjv-hrm-training');
    await loadHeatmap();
    await loadOrg();
  }

  document.addEventListener('DOMContentLoaded', () => {
    wireHrmTabs();
    wireHrmForms();
    refreshHrm();
  });
})();

(function(){
  if(!window.ccjvERP) return;
  async function acctApi(path, options){
    const res = await fetch(ccjvERP.rest + path, Object.assign({
      headers:{'Content-Type':'application/json','X-WP-Nonce':ccjvERP.nonce}
    }, options || {}));
    return await res.json();
  }
  function esc(s){ return String(s || '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c])); }
  function money(v){ return '$' + Number(v || 0).toLocaleString(undefined,{minimumFractionDigits:2,maximumFractionDigits:2}); }

  function wireAcctTabs(){
    document.querySelectorAll('[data-acct-tab]').forEach(btn => {
      btn.addEventListener('click', () => {
        document.querySelectorAll('[data-acct-tab]').forEach(b => b.classList.remove('active'));
        document.querySelectorAll('[data-acct-panel]').forEach(p => p.classList.add('hidden'));
        btn.classList.add('active');
        const panel = document.querySelector(`[data-acct-panel="${btn.dataset.acctTab}"]`);
        if(panel) panel.classList.remove('hidden');
      });
    });
  }

  async function loadAcctKpis(){
    const el=document.getElementById('ccjv-accounting-kpis'); if(!el)return;
    const k=await acctApi('/accounting/kpis');
    el.innerHTML=`<div class="ccjv-acct-kpi"><strong>${money(k.invoice_total)}</strong><span>Invoice Total</span></div><div class="ccjv-acct-kpi"><strong>${money(k.open_total)}</strong><span>Open AP/AR</span></div><div class="ccjv-acct-kpi"><strong>${money(k.payments)}</strong><span>Payments</span></div><div class="ccjv-acct-kpi"><strong>${money(k.reconciliation_variance)}</strong><span>Variance</span></div>`;
  }

  async function loadLedger(){
    const el=document.getElementById('ccjv-acct-ledger'); if(!el)return;
    const rows=await acctApi('/accounting/ledger');
    if(!Array.isArray(rows)||!rows.length){el.innerHTML='<p>No ledger lines yet.</p>';return;}
    el.innerHTML=rows.map(r=>`<div class="ccjv-ledger-row"><strong>${esc(r.account_code||'')}</strong><div>${esc(r.account_name||'')}<br><small>${esc(r.memo||r.description||'')}</small></div><span>${money(r.debit)}</span><span>${money(r.credit)}</span></div>`).join('');
  }

  async function loadAcctEntity(entity,targetId){
    const el=document.getElementById(targetId); if(!el)return;
    const rows=await acctApi('/accounting/'+entity);
    if(!Array.isArray(rows)||!rows.length){el.innerHTML='<p>No records yet.</p>';return;}
    el.innerHTML=rows.map(r=>{
      const title=r.account_name||r.invoice_no||r.payment_ref||r.reconciliation_no||r.journal_no||r.report_type||'Record';
      const sub=r.counterparty||r.memo||r.account_type||r.method||r.status||'';
      const amount=r.amount||r.total_debit||r.statement_balance||'';
      const status=r.status||r.normal_balance||'';
      return `<div class="ccjv-table-row"><div><strong>${esc(title)}</strong><br><small>${esc(sub)}<br>Vault ${esc(r.vault_hash||'-')}</small></div><span>${esc(status)}</span><small>${amount!==''?money(amount):esc(r.created_at||'')}</small></div>`;
    }).join('');
  }

  async function loadAging(){
    const el=document.getElementById('ccjv-acct-aging'); if(!el)return;
    const a=await acctApi('/accounting/aging');
    el.innerHTML=['current','1_30','31_60','61_90','90_plus'].map(k=>`<div class="ccjv-forecast-card"><strong>${money(a[k]||0)}</strong><span>${k.replace('_','-')} days</span></div>`).join('');
  }

  async function loadTreasuryCockpit(){
    const el=document.getElementById('ccjv-acct-treasury'); if(!el)return;
    const k=await acctApi('/accounting/kpis');
    el.innerHTML=`<div class="ccjv-treasury-card"><strong>${money(k.payments)}</strong><span>Token/Payment Settlements</span></div><div class="ccjv-treasury-card"><strong>${money(k.open_total)}</strong><span>Outstanding Settlement Exposure</span></div><div class="ccjv-treasury-card"><strong>${money(k.reconciliation_variance)}</strong><span>Reconciliation Variance</span></div><div class="ccjv-treasury-card"><strong>Replay</strong><span>Accounting events emit replay continuity</span></div>`;
  }

  function wireAcctForms(){
    document.querySelectorAll('.ccjv-acct-form').forEach(form=>{
      form.addEventListener('submit',async e=>{
        e.preventDefault();
        const entity=form.dataset.entity;
        const data={};
        new FormData(form).forEach((v,k)=>data[k]=v);
        await acctApi('/accounting/'+entity,{method:'POST',body:JSON.stringify(data)});
        form.reset();
        refreshAcct();
      });
    });
  }

  async function refreshAcct(){
    await loadAcctKpis();
    await loadLedger();
    await loadAcctEntity('accounts','ccjv-acct-accounts');
    await loadAcctEntity('invoices','ccjv-acct-invoices');
    await loadAcctEntity('payments','ccjv-acct-payments');
    await loadAcctEntity('reconciliations','ccjv-acct-reconciliations');
    await loadAcctEntity('reports','ccjv-acct-reports');
    await loadAging();
    await loadTreasuryCockpit();
  }

  document.addEventListener('DOMContentLoaded',()=>{
    wireAcctTabs();
    wireAcctForms();
    refreshAcct();
  });
})();

(function(){
  if(!window.ccjvERP) return;
  async function pmApi(path, options){
    const res = await fetch(ccjvERP.rest + path, Object.assign({headers:{'Content-Type':'application/json','X-WP-Nonce':ccjvERP.nonce}}, options || {}));
    return await res.json();
  }
  function esc(s){ return String(s || '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c])); }
  function wirePmTabs(){document.querySelectorAll('[data-pm-tab]').forEach(btn=>btn.addEventListener('click',()=>{document.querySelectorAll('[data-pm-tab]').forEach(b=>b.classList.remove('active'));document.querySelectorAll('[data-pm-panel]').forEach(p=>p.classList.add('hidden'));btn.classList.add('active');const panel=document.querySelector(`[data-pm-panel="${btn.dataset.pmTab}"]`);if(panel)panel.classList.remove('hidden');}));}
  async function loadKanban(){const el=document.getElementById('ccjv-pm-kanban');if(!el)return;const data=await pmApi('/pm/kanban');const cols=['todo','in_progress','blocked','review','done'];el.innerHTML=cols.map(c=>`<div class="ccjv-kanban-col"><h3>${c.replace('_',' ')}</h3>${(data[c]||[]).map(t=>`<div class="ccjv-deal-card"><strong>${esc(t.task_title)}</strong><small>Project #${esc(t.project_id)} · ${esc(t.priority)}</small><br><small>Due ${esc(t.due_date||'-')} · Vault ${esc(t.vault_hash||'-')}</small></div>`).join('')||'<small>No tasks</small>'}</div>`).join('');}
  async function loadPmEntity(entity,targetId){const el=document.getElementById(targetId);if(!el)return;const rows=await pmApi('/pm/'+entity);if(!Array.isArray(rows)||!rows.length){el.innerHTML='<p>No records yet.</p>';return;}el.innerHTML=rows.map(r=>{const title=r.project_name||r.milestone_name||r.task_title||r.document_title||r.decision||('Dependency #'+r.id);const sub=r.project_code||r.priority||r.entity_type||r.dependency_type||r.proof_ref||'';const status=r.status||r.decision||'active';return `<div class="ccjv-table-row"><div><strong>${esc(title)}</strong><br><small>${esc(sub)}<br>Vault ${esc(r.vault_hash||'-')}</small></div><span>${esc(status)}</span><small>${esc(r.created_at||'')}</small></div>`;}).join('');}
  async function loadGantt(){const el=document.getElementById('ccjv-pm-gantt');if(!el)return;const data=await pmApi('/pm/gantt');const tasks=data.tasks||[];if(!tasks.length){el.innerHTML='<p>No tasks with timeline yet.</p>';return;}el.innerHTML=tasks.map(t=>{const pct=Math.min(100,Math.max(10,Number(t.estimate_hours||1)*10));return `<div class="ccjv-gantt-row"><strong>${esc(t.task_title)}</strong><div class="ccjv-gantt-bar-wrap"><div class="ccjv-gantt-bar" style="width:${pct}%"></div></div><small>${esc(t.due_date||'-')}</small></div>`;}).join('');}
  async function loadDependencies(){const el=document.getElementById('ccjv-pm-dependencies');if(!el)return;const rows=await pmApi('/pm/dependencies');if(!Array.isArray(rows)||!rows.length){el.innerHTML='<p>No dependencies yet.</p>';return;}el.innerHTML=rows.map(d=>`<div class="ccjv-dependency-edge"><strong>Task #${esc(d.predecessor_task_id)} → Task #${esc(d.successor_task_id)}</strong><br><small>${esc(d.dependency_type)} · ${esc(d.status)} · Replay ${esc(d.replay_id||'-')}</small></div>`).join('');}
  async function loadWorkload(){const el=document.getElementById('ccjv-pm-workload');if(!el)return;const rows=await pmApi('/pm/workload');if(!Array.isArray(rows)||!rows.length){el.innerHTML='<p>No workload yet.</p>';return;}el.innerHTML=rows.map(w=>`<div class="ccjv-workload-card"><strong>${esc(w.tasks)}</strong><span>User #${esc(w.assignee_id||'Unassigned')} · ${esc(w.estimate)}h estimate · ${esc(w.actual)}h actual</span></div>`).join('');}
  function wirePmForms(){document.querySelectorAll('.ccjv-pm-form').forEach(form=>form.addEventListener('submit',async e=>{e.preventDefault();const entity=form.dataset.entity;const data={};new FormData(form).forEach((v,k)=>data[k]=v);await pmApi('/pm/'+entity,{method:'POST',body:JSON.stringify(data)});form.reset();refreshPm();}));}
  async function refreshPm(){await loadKanban();await loadPmEntity('projects','ccjv-pm-projects');await loadGantt();await loadDependencies();await loadWorkload();await loadPmEntity('approvals','ccjv-pm-approvals');await loadPmEntity('documents','ccjv-pm-documents');}
  document.addEventListener('DOMContentLoaded',()=>{wirePmTabs();wirePmForms();refreshPm();});
})();

(function(){
  if(!window.ccjvERP) return;
  async function aiApi(path, options){
    const res = await fetch(ccjvERP.rest + path, Object.assign({headers:{'Content-Type':'application/json','X-WP-Nonce':ccjvERP.nonce}}, options || {}));
    return await res.json();
  }
  function esc(s){ return String(s || '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c])); }

  function wireAiTabs(){document.querySelectorAll('[data-ai-tab]').forEach(btn=>btn.addEventListener('click',()=>{document.querySelectorAll('[data-ai-tab]').forEach(b=>b.classList.remove('active'));document.querySelectorAll('[data-ai-panel]').forEach(p=>p.classList.add('hidden'));btn.classList.add('active');const panel=document.querySelector(`[data-ai-panel="${btn.dataset.aiTab}"]`);if(panel)panel.classList.remove('hidden');}));}

  async function loadDashboard(){const el=document.getElementById('ccjv-asset-kpis');if(!el)return;const d=await aiApi('/asset-iot/dashboard');el.innerHTML=`<div class="ccjv-asset-kpi"><strong>${d.assets||0}</strong><span>Assets</span></div><div class="ccjv-asset-kpi"><strong>${d.avg_health||0}%</strong><span>Avg Health</span></div><div class="ccjv-asset-kpi"><strong>${d.open_maintenance||0}</strong><span>Open Maintenance</span></div><div class="ccjv-asset-kpi"><strong>${d.sensors||0}</strong><span>Sensors</span></div><div class="ccjv-asset-kpi"><strong>${d.telemetry||0}</strong><span>Telemetry Events</span></div><div class="ccjv-asset-kpi"><strong>${d.open_alerts||0}</strong><span>Open Alerts</span></div>`;}

  async function loadMap(){const el=document.getElementById('ccjv-asset-map');if(!el)return;const rows=await aiApi('/asset-iot/map');if(!Array.isArray(rows)||!rows.length){el.innerHTML='<p>No geolocated assets yet.</p>';return;}el.innerHTML=rows.map((a,i)=>{const left=10+((Number(a.longitude||0)+180)%80);const top=10+((Number(a.latitude||0)+90)%65);return `<div class="ccjv-map-pin" style="left:${left}%;top:${top}%">${esc(a.asset_name)} · ${esc(a.health_score)}%</div>`;}).join('');}

  async function loadEntity(entity,targetId){const el=document.getElementById(targetId);if(!el)return;const rows=await aiApi('/asset-iot/'+entity);if(!Array.isArray(rows)||!rows.length){el.innerHTML='<p>No records yet.</p>';return;}el.innerHTML=rows.map(r=>{const title=r.asset_name||r.work_order||r.inspection_type||r.sensor_name||r.metric||r.message||('Twin #'+r.id);const sub=r.location_label||r.maintenance_type||r.result||r.sensor_type||r.value||r.model_ref||r.severity||'';const status=r.lifecycle_status||r.status||r.result||'active';return `<div class="ccjv-table-row"><div><strong>${esc(title)}</strong><br><small>${esc(sub)}<br>Vault ${esc(r.vault_hash||'-')}</small></div><span>${esc(status)}</span><small>${esc(r.created_at||'')}</small></div>`;}).join('');}

  async function loadTelemetryChart(){const el=document.getElementById('ccjv-telemetry-chart');if(!el)return;const rows=await aiApi('/asset-iot/telemetry');if(!Array.isArray(rows)||!rows.length){el.innerHTML='<p>No telemetry yet.</p>';return;}el.innerHTML=rows.slice(0,24).reverse().map(r=>{const h=Math.max(8,Math.min(200,Number(r.value||0)));return `<div title="${esc(r.metric)} ${esc(r.value)}" class="ccjv-telemetry-bar" style="height:${h}px"></div>`;}).join('');}

  async function loadTwins(){const el=document.getElementById('ccjv-twins-list');if(!el)return;const rows=await aiApi('/asset-iot/twins');if(!Array.isArray(rows)||!rows.length){el.innerHTML='<p>No twins yet.</p>';return;}el.innerHTML=rows.map(t=>`<div class="ccjv-twin-card"><strong>Asset #${esc(t.asset_id)}</strong><br><small>${esc(t.model_ref||'model')} · ${esc(t.status)}<br>Telemetry: ${esc(t.telemetry_ref||'-')}</small></div>`).join('');}

  async function loadAlerts(){const el=document.getElementById('ccjv-alerts-list');if(!el)return;const rows=await aiApi('/asset-iot/alerts');if(!Array.isArray(rows)||!rows.length){el.innerHTML='<p>No alerts yet.</p>';return;}el.innerHTML=rows.map(a=>`<div class="ccjv-alert-item ${esc(a.severity)}"><strong>${esc(a.message)}</strong><br><small>${esc(a.alert_type)} · ${esc(a.severity)} · ${esc(a.status)} · Replay ${esc(a.replay_id||'-')}</small></div>`).join('');}

  function wireAiForms(){document.querySelectorAll('.ccjv-ai-form').forEach(form=>form.addEventListener('submit',async e=>{e.preventDefault();const entity=form.dataset.entity;const data={};new FormData(form).forEach((v,k)=>data[k]=v);await aiApi('/asset-iot/'+entity,{method:'POST',body:JSON.stringify(data)});form.reset();refreshAi();}));}

  async function refreshAi(){await loadDashboard();await loadMap();await loadEntity('assets','ccjv-assets-list');await loadEntity('maintenance','ccjv-maintenance-list');await loadEntity('inspections','ccjv-inspections-list');await loadTwins();await loadTelemetryChart();await loadEntity('sensors','ccjv-sensors-list');await loadAlerts();}
  document.addEventListener('DOMContentLoaded',()=>{wireAiTabs();wireAiForms();refreshAi();});
})();

(function(){
  if(!window.ccjvERP) return;
  async function pgApi(path, options){
    const res = await fetch(ccjvERP.rest + path, Object.assign({headers:{'Content-Type':'application/json','X-WP-Nonce':ccjvERP.nonce}}, options || {}));
    return await res.json();
  }
  function esc(s){ return String(s || '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c])); }
  function money(v){ return '$' + Number(v || 0).toLocaleString(undefined,{minimumFractionDigits:2,maximumFractionDigits:2}); }

  function wirePgTabs(){
    document.querySelectorAll('[data-pg-tab]').forEach(btn=>btn.addEventListener('click',()=>{
      document.querySelectorAll('[data-pg-tab]').forEach(b=>b.classList.remove('active'));
      document.querySelectorAll('[data-pg-panel]').forEach(p=>p.classList.add('hidden'));
      btn.classList.add('active');
      const panel=document.querySelector(`[data-pg-panel="${btn.dataset.pgTab}"]`);
      if(panel) panel.classList.remove('hidden');
    }));
  }

  async function loadPg(endpoint,targetId){
    const el=document.getElementById(targetId); if(!el) return;
    const rows=await pgApi(endpoint);
    if(!Array.isArray(rows)||!rows.length){el.innerHTML='<p>No records yet.</p>';return;}
    el.innerHTML=rows.map(r=>{
      const title=r.title||r.rfq_number||r.vendor_name||r.po_number||r.proposal_code||('Vote #'+r.id);
      const sub=r.description||r.status||r.approval_status||r.vote||'';
      const amt=r.budget||r.bid_amount||r.total_amount||r.voting_power||'';
      return `<div class="ccjv-table-row"><div><strong>${esc(title)}</strong><br><small>${esc(sub)}<br>Vault ${esc(r.vault_hash||'-')}<br>Replay ${esc(r.replay_id||'-')}</small></div><span>${esc(r.status||r.approval_status||r.vote||'active')}</span><small>${amt!==''?money(amt):esc(r.created_at||'')}</small></div>`;
    }).join('');
  }

  function wirePgForms(){
    document.querySelectorAll('.ccjv-pg-form').forEach(form=>form.addEventListener('submit',async e=>{
      e.preventDefault();
      const data={};
      new FormData(form).forEach((v,k)=>data[k]=v);
      await pgApi(form.dataset.endpoint,{method:'POST',body:JSON.stringify(data)});
      form.reset();
      refreshPg();
    }));
  }

  async function refreshPg(){
    await loadPg('/procurement/rfqs','ccjv-pg-rfqs');
    await loadPg('/procurement/bids','ccjv-pg-bids');
    await loadPg('/procurement/pos','ccjv-pg-pos');
    await loadPg('/governance/proposals','ccjv-pg-proposals');
    await loadPg('/governance/votes','ccjv-pg-votes');
  }

  document.addEventListener('DOMContentLoaded',()=>{wirePgTabs();wirePgForms();refreshPg();});
})();

(function(){
  if(!window.ccjvERP) return;
  async function cApi(path, options){const res=await fetch(ccjvERP.rest+path,Object.assign({headers:{'Content-Type':'application/json','X-WP-Nonce':ccjvERP.nonce}},options||{}));return await res.json();}
  function esc(s){return String(s||'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c]));}
  async function loadCockpitSummary(){const el=document.getElementById('ccjv-cockpit-kpis');if(!el)return;const s=await cApi('/cockpit/summary');el.innerHTML=`<div class="ccjv-cockpit-kpi"><strong>${s.modules||0}</strong><span>Modules</span></div><div class="ccjv-cockpit-kpi"><strong>${s.records||0}</strong><span>Records</span></div><div class="ccjv-cockpit-kpi"><strong>${s.events||0}</strong><span>Replay Events</span></div><div class="ccjv-cockpit-kpi"><strong>${s.bridge_events||0}</strong><span>Bridge Events</span></div><div class="ccjv-cockpit-kpi"><strong>${s.entitlements||0}</strong><span>Entitlements</span></div>`;const st=document.getElementById('ccjv-cockpit-runtime-status');if(st)st.textContent=s.runtime_api?'Runtime API configured':'Runtime API not configured';}
  async function loadEntitlements(){const el=document.getElementById('ccjv-entitlement-list');if(!el)return;const rows=await cApi('/token/entitlements');if(!Array.isArray(rows)||!rows.length){el.innerHTML='<p>No entitlements yet.</p>';return;}el.innerHTML=rows.map(r=>`<div class="ccjv-table-row"><div><strong>${esc(r.module_key)}</strong><br><small>${esc(r.token_symbol)} · fee ${esc(r.monthly_fee)} · allowance ${esc(r.allowance_required)}<br>Replay ${esc(r.replay_id||'-')}</small></div><span>${esc(r.status)}</span><small>${esc(r.expires_at||'')}</small></div>`).join('');}
  async function loadBridgeEvents(){const el=document.getElementById('ccjv-bridge-events');if(!el)return;const rows=await cApi('/runtime/bridge-events');if(!Array.isArray(rows)||!rows.length){el.innerHTML='<p>No bridge events yet.</p>';return;}el.innerHTML=rows.map(r=>`<div class="ccjv-table-row"><div><strong>${esc(r.event_type)}</strong><br><small>${esc(r.source_module)} · ${esc(r.runtime_endpoint)}<br>${esc(r.correlation_id||'')}</small></div><span>${esc(r.status)}</span><small>${esc(r.created_at||'')}</small></div>`).join('');}
  function wireGlobalSearch(){const input=document.getElementById('ccjv-global-search'),out=document.getElementById('ccjv-global-results');if(!input||!out)return;let timer=null;input.addEventListener('input',()=>{clearTimeout(timer);timer=setTimeout(async()=>{const q=input.value.trim();if(!q){out.innerHTML='Search to begin.';return;}const rows=await cApi('/cockpit/search?q='+encodeURIComponent(q));out.innerHTML=(!Array.isArray(rows)||!rows.length)?'<p>No results.</p>':rows.map(r=>`<div class="ccjv-table-row"><div><strong>${esc(r.title)}</strong><br><small>${esc(r.type)}</small></div><span>${esc(r.status||'')}</span><small>${esc(r.created_at||'')}</small></div>`).join('');},250);});}
  function wireBridgeSync(){const btn=document.getElementById('ccjv-bridge-sync');if(!btn)return;btn.addEventListener('click',async()=>{await cApi('/runtime/bridge-events',{method:'POST',body:JSON.stringify({event_type:'cockpit.manual_sync',source_module:'cockpit',runtime_endpoint:'/runtime/sync',payload:{trigger:'manual'}})});refreshCockpit();});}
  async function refreshCockpit(){await loadCockpitSummary();await loadEntitlements();await loadBridgeEvents();}
  document.addEventListener('DOMContentLoaded',()=>{wireGlobalSearch();wireBridgeSync();refreshCockpit();});
})();

(function(){
  if(!window.ccjvERP) return;
  async function fApi(path, options){
    const res = await fetch(ccjvERP.rest + path, Object.assign({headers:{'Content-Type':'application/json','X-WP-Nonce':ccjvERP.nonce}}, options || {}));
    return await res.json();
  }
  function esc(s){ return String(s || '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c])); }

  function wireFinalTabs(){
    document.querySelectorAll('[data-final-tab]').forEach(btn=>btn.addEventListener('click',()=>{
      document.querySelectorAll('[data-final-tab]').forEach(b=>b.classList.remove('active'));
      document.querySelectorAll('[data-final-panel]').forEach(p=>p.classList.add('hidden'));
      btn.classList.add('active');
      const panel=document.querySelector(`[data-final-panel="${btn.dataset.finalTab}"]`);
      if(panel) panel.classList.remove('hidden');
    }));
  }

  function row(title, sub, status, date){
    return `<div class="ccjv-table-row"><div><strong>${esc(title)}</strong><br><small>${esc(sub)}</small></div><span>${esc(status||'')}</span><small>${esc(date||'')}</small></div>`;
  }

  async function loadFinalAdmin(){
    const perms = document.getElementById('ccjv-rbac-list');
    if(perms){
      const rows = await fApi('/admin/rbac/permissions');
      perms.innerHTML = !Array.isArray(rows)||!rows.length ? '<p>No permissions.</p>' : rows.slice(0,200).map(r=>row(`${r.role_key} / ${r.module_key}`, r.permission_key, r.allowed==='1'||r.allowed===1?'allowed':'denied', r.updated_at)).join('');
    }

    const pricing = document.getElementById('ccjv-pricing-list');
    if(pricing){
      const rows = await fApi('/admin/module-pricing');
      pricing.innerHTML = !Array.isArray(rows)||!rows.length ? '<p>No pricing.</p>' : rows.map(r=>row(r.module_key, `monthly ${r.monthly_fee} ${r.token_symbol} · upload reward ${r.upload_reward} · view ${r.view_fee} · download ${r.download_fee}`, r.status, r.updated_at)).join('');
    }

    const settings = document.getElementById('ccjv-tenant-settings');
    if(settings){
      const rows = await fApi('/admin/tenant-settings');
      settings.innerHTML = !Array.isArray(rows)||!rows.length ? '<p>No tenant settings yet.</p>' : rows.map(r=>row(r.setting_key, r.setting_value, 'saved', r.updated_at)).join('');
    }

    const audit = document.getElementById('ccjv-audit-replay');
    if(audit){
      const data = await fApi('/admin/audit-replay');
      const events = (data.events||[]).map(e=>row(e.event_type, `${e.module} · record ${e.record_id} · ${e.correlation_id}`, 'event', e.created_at)).join('');
      const bridge = (data.bridge||[]).map(e=>row(e.event_type, `${e.source_module} · ${e.correlation_id}`, e.status, e.created_at)).join('');
      audit.innerHTML = events + bridge || '<p>No audit events.</p>';
    }

    const proofs = document.getElementById('ccjv-proof-list');
    if(proofs){
      const rows = await fApi('/admin/proofs');
      proofs.innerHTML = !Array.isArray(rows)||!rows.length ? '<p>No proofs yet.</p>' : rows.map(r=>row(`${r.source_module} #${r.source_record_id}`, `Vault ${r.vault_hash}<br>Tx ${r.avalanche_tx_hash||'-'}<br>Replay ${r.replay_id||'-'}`, r.anchor_status, r.created_at)).join('');
    }

    const summary = document.getElementById('ccjv-depth-summary');
    if(summary){
      const data = await fApi('/admin/module-deepening-summary');
      summary.innerHTML = Object.keys(data).map(k=>`<div class="ccjv-depth-card"><strong>${esc(k)}</strong><small>${data[k].map(esc).join('<br>')}</small></div>`).join('');
    }
  }

  function wireFinalForms(){
    document.querySelectorAll('.ccjv-final-form').forEach(form=>form.addEventListener('submit',async e=>{
      e.preventDefault();
      const data={};
      new FormData(form).forEach((v,k)=>{
        if(k === 'setting_value'){
          try { data[k] = JSON.parse(v); } catch(e) { data[k] = v; }
        } else if(k === 'allowed') {
          data[k] = v === '1';
        } else data[k] = v;
      });
      await fApi(form.dataset.endpoint,{method:'POST',body:JSON.stringify(data)});
      form.reset();
      loadFinalAdmin();
    }));
  }

  function wireFinalAdminConsole(){
    wireFinalTabs();
    wireFinalForms();
    loadFinalAdmin();
  }

  document.addEventListener('DOMContentLoaded', wireFinalAdminConsole);
})();
