=== CCJV Core ERP ===
Version: 1.0.0-ui-pass

Usable CCJV ERP cockpit plugin with:
- Super admin cockpit
- Tenant-style module dashboard
- CRM, HRM, Accounting, Projects, Assets, IoT, Procurement, Governance, Vault, Replay, Treasury, Federation workspaces
- Operational record creation
- Vault hash generation
- Replay event emission
- Treasury reference creation
- Runtime health settings
- Runtime websocket status

Shortcodes:
[ccjv_core_dashboard]
[ccjv_core_workspace module="crm"]
[ccjv_core_module key="accounting"]
