<?php
/**
 * Plugin Name: CCJV Core ERP
 * Description: CCJV operational ERP cockpit with CRM, HRM, Accounting, PM, Asset, IoT, Procurement, Governance and runtime continuity UI.
 * Version: 1.0.0-ui-pass
 * Author: CCJV
 */
if (!defined('ABSPATH')) exit;
define('CCJV_CORE_ERP_PATH', plugin_dir_path(__FILE__));
define('CCJV_CORE_ERP_URL', plugin_dir_url(__FILE__));
define('CCJV_CORE_ERP_VERSION', '1.0.0-ui-pass');
require_once CCJV_CORE_ERP_PATH . 'includes/class-ccjv-core-modules.php';
require_once CCJV_CORE_ERP_PATH . 'includes/class-ccjv-core-installer.php';
require_once CCJV_CORE_ERP_PATH . 'includes/class-ccjv-core-runtime-client.php';
require_once CCJV_CORE_ERP_PATH . 'includes/class-ccjv-core-admin.php';
require_once CCJV_CORE_ERP_PATH . 'includes/class-ccjv-core-shortcodes.php';
require_once CCJV_CORE_ERP_PATH . 'includes/class-ccjv-core-rest.php';
require_once CCJV_CORE_ERP_PATH . 'includes/class-ccjv-final-admin-runtime.php';
require_once CCJV_CORE_ERP_PATH . 'includes/class-ccjv-final-admin-rest.php';
require_once CCJV_CORE_ERP_PATH . 'includes/class-ccjv-cockpit-token-runtime.php';
require_once CCJV_CORE_ERP_PATH . 'includes/class-ccjv-cockpit-token-rest.php';
require_once CCJV_CORE_ERP_PATH . 'includes/class-ccjv-crm-depth.php';
require_once CCJV_CORE_ERP_PATH . 'includes/class-ccjv-crm-rest.php';
require_once CCJV_CORE_ERP_PATH . 'includes/class-ccjv-hrm-depth.php';
require_once CCJV_CORE_ERP_PATH . 'includes/class-ccjv-hrm-rest.php';
require_once CCJV_CORE_ERP_PATH . 'includes/class-ccjv-accounting-depth.php';
require_once CCJV_CORE_ERP_PATH . 'includes/class-ccjv-accounting-rest.php';
require_once CCJV_CORE_ERP_PATH . 'includes/class-ccjv-pm-depth.php';
require_once CCJV_CORE_ERP_PATH . 'includes/class-ccjv-pm-rest.php';
require_once CCJV_CORE_ERP_PATH . 'includes/class-ccjv-asset-iot-depth.php';
require_once CCJV_CORE_ERP_PATH . 'includes/class-ccjv-asset-iot-rest.php';
require_once CCJV_CORE_ERP_PATH . 'includes/class-ccjv-procurement-governance-depth.php';
require_once CCJV_CORE_ERP_PATH . 'includes/class-ccjv-procurement-governance-rest.php';

final class CCJV_Core_ERP {
    public function __construct() {
        register_activation_hook(__FILE__, ['CCJV_Core_Installer', 'activate']);
        add_action('admin_menu', ['CCJV_Core_Admin', 'menu']);
        add_action('admin_init', ['CCJV_Core_Admin', 'settings']);
        add_action('wp_enqueue_scripts', [$this, 'assets']);
        add_action('admin_enqueue_scripts', [$this, 'admin_assets']);
        new CCJV_Core_Shortcodes();
        new CCJV_Core_REST();
        new CCJV_Final_Admin_REST();
        new CCJV_Cockpit_Token_REST();
        new CCJV_CRM_REST();
        new CCJV_HRM_REST();
        new CCJV_Accounting_REST();
        new CCJV_PM_REST();
        new CCJV_Asset_IoT_REST();
        new CCJV_Procurement_Governance_REST();
    }
    public function assets() {
        wp_enqueue_style('ccjv-core-erp', CCJV_CORE_ERP_URL . 'assets/css/erp-ui.css', [], CCJV_CORE_ERP_VERSION);
        wp_enqueue_script('ccjv-core-erp', CCJV_CORE_ERP_URL . 'assets/js/erp-ui.js', [], CCJV_CORE_ERP_VERSION, true);
        wp_localize_script('ccjv-core-erp', 'ccjvERP', [
            'rest' => rest_url('ccjv-core/v1'),
            'nonce' => wp_create_nonce('wp_rest'),
            'runtimeApi' => get_option('ccjv_core_runtime_api', ''),
            'runtimeWs' => get_option('ccjv_core_runtime_ws', ''),
        ]);
    }
    public function admin_assets($hook) {
        if (strpos((string)$hook, 'ccjv-core') === false && strpos((string)$hook, 'ccjv-erp') === false) return;
        $this->assets();
    }
}
new CCJV_Core_ERP();
