<?php
if (!defined('ABSPATH')) exit;

class CCJV_HRM_REST {
    public function __construct() {
        add_action('rest_api_init', [$this, 'routes']);
    }

    public function routes() {
        foreach (['people','departments','certifications','competencies','schedules','training'] as $entity) {
            register_rest_route('ccjv-core/v1', '/hrm/' . $entity, [
                'methods' => 'GET',
                'callback' => [$this, 'list_' . $entity],
                'permission_callback' => function(){ return is_user_logged_in(); }
            ]);
            register_rest_route('ccjv-core/v1', '/hrm/' . $entity, [
                'methods' => 'POST',
                'callback' => [$this, 'create_' . $entity],
                'permission_callback' => function(){ return is_user_logged_in(); }
            ]);
        }

        register_rest_route('ccjv-core/v1', '/hrm/readiness', [
            'methods' => 'GET',
            'callback' => [$this, 'readiness'],
            'permission_callback' => function(){ return is_user_logged_in(); }
        ]);

        register_rest_route('ccjv-core/v1', '/hrm/org', [
            'methods' => 'GET',
            'callback' => [$this, 'org'],
            'permission_callback' => function(){ return is_user_logged_in(); }
        ]);

        register_rest_route('ccjv-core/v1', '/hrm/timeline/(?P<entity>[a-z0-9_-]+)/(?P<id>\\d+)', [
            'methods' => 'GET',
            'callback' => [$this, 'timeline'],
            'permission_callback' => function(){ return is_user_logged_in(); }
        ]);
    }

    private function insert($table, $data, $entity_type, $label) {
        global $wpdb;
        $data['tenant_id'] = 1;
        $data['vault_hash'] = CCJV_HRM_Depth::hash_payload($data);
        $data['created_at'] = current_time('mysql');
        $data['updated_at'] = current_time('mysql');
        $wpdb->insert($wpdb->prefix . 'ccjv_' . $table, $data);
        $id = $wpdb->insert_id;
        $replay = CCJV_HRM_Depth::emit($entity_type, $id, $entity_type . '.created', $label, $data);
        $updates = ['replay_id' => $replay];
        if ($table === 'hrm_people') $updates['treasury_ref'] = 'hrm-module-fee';
        $wpdb->update($wpdb->prefix . 'ccjv_' . $table, $updates, ['id' => $id]);
        return ['ok' => true, 'id' => $id, 'vault_hash' => $data['vault_hash'], 'replay_id' => $replay, 'treasury_ref' => $updates['treasury_ref'] ?? null];
    }

    public function create_people($request) {
        $p = $request->get_json_params();
        return $this->insert('hrm_people', [
            'person_type' => sanitize_text_field($p['person_type'] ?? 'employee'),
            'full_name' => sanitize_text_field($p['full_name'] ?? 'New Person'),
            'email' => sanitize_email($p['email'] ?? ''),
            'phone' => sanitize_text_field($p['phone'] ?? ''),
            'department_id' => absint($p['department_id'] ?? 0),
            'role_title' => sanitize_text_field($p['role_title'] ?? ''),
            'employment_status' => sanitize_text_field($p['employment_status'] ?? 'active'),
            'readiness_score' => absint($p['readiness_score'] ?? 70),
        ], 'person', 'Person created');
    }

    public function create_departments($request) {
        $p = $request->get_json_params();
        return $this->insert('hrm_departments', [
            'name' => sanitize_text_field($p['name'] ?? 'New Department'),
            'parent_id' => absint($p['parent_id'] ?? 0),
            'manager_id' => absint($p['manager_id'] ?? 0),
            'status' => sanitize_text_field($p['status'] ?? 'active'),
        ], 'department', 'Department created');
    }

    public function create_certifications($request) {
        $p = $request->get_json_params();
        return $this->insert('hrm_certifications', [
            'person_id' => absint($p['person_id'] ?? 0),
            'certification_name' => sanitize_text_field($p['certification_name'] ?? 'Certification'),
            'issuer' => sanitize_text_field($p['issuer'] ?? ''),
            'issued_at' => sanitize_text_field($p['issued_at'] ?? ''),
            'expires_at' => sanitize_text_field($p['expires_at'] ?? ''),
            'status' => sanitize_text_field($p['status'] ?? 'valid'),
        ], 'certification', 'Certification created');
    }

    public function create_competencies($request) {
        $p = $request->get_json_params();
        return $this->insert('hrm_competencies', [
            'person_id' => absint($p['person_id'] ?? 0),
            'competency' => sanitize_text_field($p['competency'] ?? 'Competency'),
            'proficiency' => absint($p['proficiency'] ?? 50),
            'verified_by' => get_current_user_id(),
            'status' => sanitize_text_field($p['status'] ?? 'active'),
        ], 'competency', 'Competency created');
    }

    public function create_schedules($request) {
        $p = $request->get_json_params();
        return $this->insert('hrm_schedules', [
            'person_id' => absint($p['person_id'] ?? 0),
            'shift_title' => sanitize_text_field($p['shift_title'] ?? 'Shift'),
            'starts_at' => sanitize_text_field($p['starts_at'] ?? current_time('mysql')),
            'ends_at' => sanitize_text_field($p['ends_at'] ?? current_time('mysql')),
            'location' => sanitize_text_field($p['location'] ?? ''),
            'status' => sanitize_text_field($p['status'] ?? 'scheduled'),
        ], 'schedule', 'Schedule created');
    }

    public function create_training($request) {
        $p = $request->get_json_params();
        return $this->insert('hrm_training', [
            'person_id' => absint($p['person_id'] ?? 0),
            'training_title' => sanitize_text_field($p['training_title'] ?? 'Training'),
            'stage' => sanitize_text_field($p['stage'] ?? 'assigned'),
            'due_at' => sanitize_text_field($p['due_at'] ?? ''),
            'status' => sanitize_text_field($p['status'] ?? 'open'),
        ], 'training', 'Training created');
    }

    private function list_table($table) {
        global $wpdb;
        return $wpdb->get_results("SELECT * FROM {$wpdb->prefix}ccjv_{$table} ORDER BY id DESC LIMIT 100", ARRAY_A);
    }

    public function list_people(){ return $this->list_table('hrm_people'); }
    public function list_departments(){ return $this->list_table('hrm_departments'); }
    public function list_certifications(){ return $this->list_table('hrm_certifications'); }
    public function list_competencies(){ return $this->list_table('hrm_competencies'); }
    public function list_schedules(){ return $this->list_table('hrm_schedules'); }
    public function list_training(){ return $this->list_table('hrm_training'); }

    public function readiness() {
        global $wpdb;
        $rows = $wpdb->get_results("SELECT readiness_score, employment_status FROM {$wpdb->prefix}ccjv_hrm_people", ARRAY_A);
        $count = count($rows);
        $avg = $count ? round(array_sum(array_map(fn($r)=>intval($r['readiness_score']), $rows)) / $count) : 0;
        $active = count(array_filter($rows, fn($r)=>$r['employment_status']==='active'));
        return ['people' => $count, 'active' => $active, 'avg_readiness' => $avg, 'risk' => $avg < 65 ? 'high' : ($avg < 80 ? 'medium' : 'low')];
    }

    public function org() {
        global $wpdb;
        return [
            'departments' => $wpdb->get_results("SELECT * FROM {$wpdb->prefix}ccjv_hrm_departments ORDER BY name ASC", ARRAY_A),
            'people' => $wpdb->get_results("SELECT id, full_name, department_id, role_title, readiness_score FROM {$wpdb->prefix}ccjv_hrm_people ORDER BY full_name ASC", ARRAY_A)
        ];
    }

    public function timeline($request) {
        global $wpdb;
        return $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}ccjv_hrm_timeline WHERE entity_type=%s AND entity_id=%d ORDER BY id DESC LIMIT 100",
            sanitize_key($request['entity']),
            absint($request['id'])
        ), ARRAY_A);
    }
}
