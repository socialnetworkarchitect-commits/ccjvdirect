<?php
if (!defined('ABSPATH')) exit;

class CCJV_Procurement_Governance_REST {
    public function __construct() {
        add_action('rest_api_init', [$this, 'routes']);
    }

    public function routes() {
        foreach ([
            'vendors' => 'procurement',
            'rfqs' => 'procurement',
            'bids' => 'procurement',
            'pos' => 'procurement',
            'proposals' => 'governance',
            'votes' => 'governance'
        ] as $entity => $group) {
            register_rest_route('ccjv-core/v1', '/' . $group . '/' . $entity, [
                'methods'=>'GET',
                'callback'=>[$this, 'list_' . $entity],
                'permission_callback'=>function(){ return is_user_logged_in(); }
            ]);
            register_rest_route('ccjv-core/v1', '/' . $group . '/' . $entity, [
                'methods'=>'POST',
                'callback'=>[$this, 'create_' . $entity],
                'permission_callback'=>function(){ return is_user_logged_in(); }
            ]);
        }

        register_rest_route('ccjv-core/v1', '/governance/quorum/(?P<id>\d+)', [
            'methods'=>'GET',
            'callback'=>[$this, 'quorum'],
            'permission_callback'=>function(){ return is_user_logged_in(); }
        ]);

        register_rest_route('ccjv-core/v1', '/procurement/bid-comparison/(?P<id>\d+)', [
            'methods'=>'GET',
            'callback'=>[$this, 'bid_comparison'],
            'permission_callback'=>function(){ return is_user_logged_in(); }
        ]);
    }

    private function insert($table, $data, $module, $entity_type, $label) {
        global $wpdb;
        $data['tenant_id'] = 1;
        $data['vault_hash'] = CCJV_Procurement_Governance_Depth::hash_payload($data);
        $data['created_at'] = current_time('mysql');
        if (!isset($data['updated_at'])) $data['updated_at'] = current_time('mysql');
        $wpdb->insert($wpdb->prefix.'ccjv_'.$table, $data);
        $id = $wpdb->insert_id;
        $replay = CCJV_Procurement_Governance_Depth::emit($module, $entity_type, $id, $entity_type.'.created', $label, $data);
        $updates = ['replay_id'=>$replay];
        if (in_array($table, ['procurement_rfqs','procurement_purchase_orders','governance_proposals'])) {
            $updates['treasury_ref'] = $module . '-treasury-link';
        }
        $wpdb->update($wpdb->prefix.'ccjv_'.$table, $updates, ['id'=>$id]);
        return ['ok'=>true, 'id'=>$id, 'vault_hash'=>$data['vault_hash'], 'replay_id'=>$replay, 'treasury_ref'=>$updates['treasury_ref'] ?? null];
    }

    public function create_vendors($request) {
        $p = $request->get_json_params();
        return $this->insert('procurement_vendors', [
            'vendor_name'=>sanitize_text_field($p['vendor_name'] ?? 'Vendor'),
            'category'=>sanitize_text_field($p['category'] ?? ''),
            'score'=>floatval($p['score'] ?? 0),
            'status'=>sanitize_text_field($p['status'] ?? 'active')
        ], 'procurement', 'vendor', 'Vendor created');
    }

    public function create_rfqs($request) {
        $p = $request->get_json_params();
        return $this->insert('procurement_rfqs', [
            'rfq_number'=>sanitize_text_field($p['rfq_number'] ?? 'RFQ-'.time()),
            'title'=>sanitize_text_field($p['title'] ?? 'RFQ'),
            'description'=>sanitize_textarea_field($p['description'] ?? ''),
            'budget'=>floatval($p['budget'] ?? 0),
            'status'=>sanitize_text_field($p['status'] ?? 'draft'),
            'closing_date'=>sanitize_text_field($p['closing_date'] ?? '')
        ], 'procurement', 'rfq', 'RFQ created');
    }

    public function create_bids($request) {
        $p = $request->get_json_params();
        return $this->insert('procurement_bids', [
            'rfq_id'=>absint($p['rfq_id'] ?? 0),
            'vendor_id'=>absint($p['vendor_id'] ?? 0),
            'vendor_name'=>sanitize_text_field($p['vendor_name'] ?? 'Vendor'),
            'bid_amount'=>floatval($p['bid_amount'] ?? 0),
            'delivery_days'=>absint($p['delivery_days'] ?? 0),
            'score'=>floatval($p['score'] ?? 0),
            'status'=>sanitize_text_field($p['status'] ?? 'submitted')
        ], 'procurement', 'bid', 'Bid submitted');
    }

    public function create_pos($request) {
        $p = $request->get_json_params();
        return $this->insert('procurement_purchase_orders', [
            'po_number'=>sanitize_text_field($p['po_number'] ?? 'PO-'.time()),
            'rfq_id'=>absint($p['rfq_id'] ?? 0),
            'bid_id'=>absint($p['bid_id'] ?? 0),
            'vendor_name'=>sanitize_text_field($p['vendor_name'] ?? 'Vendor'),
            'total_amount'=>floatval($p['total_amount'] ?? 0),
            'approval_status'=>sanitize_text_field($p['approval_status'] ?? 'pending')
        ], 'procurement', 'purchase_order', 'Purchase order created');
    }

    public function create_proposals($request) {
        $p = $request->get_json_params();
        return $this->insert('governance_proposals', [
            'proposal_code'=>sanitize_text_field($p['proposal_code'] ?? 'PROP-'.time()),
            'title'=>sanitize_text_field($p['title'] ?? 'Proposal'),
            'proposal_text'=>sanitize_textarea_field($p['proposal_text'] ?? ''),
            'quorum_required'=>floatval($p['quorum_required'] ?? 50),
            'status'=>sanitize_text_field($p['status'] ?? 'open')
        ], 'governance', 'proposal', 'Proposal created');
    }

    public function create_votes($request) {
        global $wpdb;
        $p = $request->get_json_params();
        $payload = [
            'tenant_id'=>1,
            'proposal_id'=>absint($p['proposal_id'] ?? 0),
            'voter_id'=>get_current_user_id(),
            'vote'=>sanitize_text_field($p['vote'] ?? 'yes'),
            'voting_power'=>floatval($p['voting_power'] ?? 1),
            'created_at'=>current_time('mysql')
        ];
        $wpdb->insert($wpdb->prefix.'ccjv_governance_votes', $payload);
        $id = $wpdb->insert_id;
        $replay = CCJV_Procurement_Governance_Depth::emit('governance','vote',$id,'vote.created','Vote recorded',$payload);
        $wpdb->update($wpdb->prefix.'ccjv_governance_votes', ['replay_id'=>$replay], ['id'=>$id]);
        return ['ok'=>true,'id'=>$id,'replay_id'=>$replay];
    }

    private function table($name) {
        global $wpdb;
        return $wpdb->get_results("SELECT * FROM {$wpdb->prefix}ccjv_{$name} ORDER BY id DESC LIMIT 200", ARRAY_A);
    }

    public function list_vendors(){ return $this->table('procurement_vendors'); }
    public function list_rfqs(){ return $this->table('procurement_rfqs'); }
    public function list_bids(){ return $this->table('procurement_bids'); }
    public function list_pos(){ return $this->table('procurement_purchase_orders'); }
    public function list_proposals(){ return $this->table('governance_proposals'); }
    public function list_votes(){ return $this->table('governance_votes'); }

    public function bid_comparison($request) {
        global $wpdb;
        return $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}ccjv_procurement_bids WHERE rfq_id=%d ORDER BY score DESC, bid_amount ASC",
            absint($request['id'])
        ), ARRAY_A);
    }

    public function quorum($request) {
        global $wpdb;
        $proposal_id = absint($request['id']);
        $proposal = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$wpdb->prefix}ccjv_governance_proposals WHERE id=%d", $proposal_id), ARRAY_A);
        $yes = floatval($wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(voting_power),0) FROM {$wpdb->prefix}ccjv_governance_votes WHERE proposal_id=%d AND vote='yes'", $proposal_id)));
        $no = floatval($wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(voting_power),0) FROM {$wpdb->prefix}ccjv_governance_votes WHERE proposal_id=%d AND vote='no'", $proposal_id)));
        $total = $yes + $no;
        $required = floatval($proposal['quorum_required'] ?? 50);
        return ['proposal_id'=>$proposal_id, 'yes'=>$yes, 'no'=>$no, 'total'=>$total, 'quorum_required'=>$required, 'quorum_met'=>$total >= $required];
    }
}
