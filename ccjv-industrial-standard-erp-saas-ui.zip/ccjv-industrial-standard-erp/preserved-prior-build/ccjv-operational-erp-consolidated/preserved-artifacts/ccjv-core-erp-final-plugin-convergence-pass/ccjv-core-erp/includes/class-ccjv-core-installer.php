<?php
if (!defined('ABSPATH')) exit;
class CCJV_Core_Installer {
    public static function activate() {
        global $wpdb;
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        $charset = $wpdb->get_charset_collate();
        $p = $wpdb->prefix . 'ccjv_';

        dbDelta("CREATE TABLE {$p}tenants (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            name VARCHAR(190) NOT NULL,
            slug VARCHAR(190) NOT NULL,
            status VARCHAR(40) NOT NULL DEFAULT 'active',
            created_at DATETIME NOT NULL,
            PRIMARY KEY (id),
            UNIQUE KEY slug (slug)
        ) $charset;");

        dbDelta("CREATE TABLE {$p}records (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            tenant_id BIGINT UNSIGNED NOT NULL DEFAULT 1,
            module VARCHAR(80) NOT NULL,
            title VARCHAR(255) NOT NULL,
            status VARCHAR(80) NOT NULL DEFAULT 'active',
            payload LONGTEXT NULL,
            vault_hash VARCHAR(128) NULL,
            replay_id VARCHAR(128) NULL,
            treasury_ref VARCHAR(128) NULL,
            created_by BIGINT UNSIGNED NULL,
            created_at DATETIME NOT NULL,
            updated_at DATETIME NULL,
            PRIMARY KEY (id),
            KEY module (module),
            KEY tenant_module (tenant_id,module)
        ) $charset;");

        dbDelta("CREATE TABLE {$p}events (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            tenant_id BIGINT UNSIGNED NOT NULL DEFAULT 1,
            module VARCHAR(80) NOT NULL,
            event_type VARCHAR(120) NOT NULL,
            record_id BIGINT UNSIGNED NULL,
            correlation_id VARCHAR(128) NULL,
            payload LONGTEXT NULL,
            created_at DATETIME NOT NULL,
            PRIMARY KEY (id),
            KEY tenant_module (tenant_id,module),
            KEY correlation_id (correlation_id)
        ) $charset;");

        dbDelta("CREATE TABLE {$p}module_access (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            tenant_id BIGINT UNSIGNED NOT NULL DEFAULT 1,
            module VARCHAR(80) NOT NULL,
            token_required VARCHAR(80) NULL,
            monthly_fee DECIMAL(18,8) NOT NULL DEFAULT 0,
            status VARCHAR(40) NOT NULL DEFAULT 'active',
            expires_at DATETIME NULL,
            PRIMARY KEY (id),
            UNIQUE KEY tenant_module (tenant_id,module)
        ) $charset;");

        if (!$wpdb->get_var("SELECT id FROM {$p}tenants WHERE slug='default'")) {
            $wpdb->insert($p.'tenants', ['name'=>'Default CCJV Tenant','slug'=>'default','status'=>'active','created_at'=>current_time('mysql')]);
        }
        if (class_exists('CCJV_CRM_Depth')) { CCJV_CRM_Depth::install(); }
        if (class_exists('CCJV_HRM_Depth')) { CCJV_HRM_Depth::install(); }
        if (class_exists('CCJV_Accounting_Depth')) { CCJV_Accounting_Depth::install(); }
        if (class_exists('CCJV_PM_Depth')) { CCJV_PM_Depth::install(); }
        if (class_exists('CCJV_Asset_IoT_Depth')) { CCJV_Asset_IoT_Depth::install(); }
        if (class_exists('CCJV_Procurement_Governance_Depth')) { CCJV_Procurement_Governance_Depth::install(); }

        if (class_exists('CCJV_Cockpit_Token_Runtime')) { CCJV_Cockpit_Token_Runtime::install(); }

        if (class_exists('CCJV_Final_Admin_Runtime')) { CCJV_Final_Admin_Runtime::install(); }

        foreach (CCJV_Core_Modules::all() as $key => $module) {
            if (!$wpdb->get_var($wpdb->prepare("SELECT id FROM {$p}module_access WHERE tenant_id=1 AND module=%s", $key))) {
                $wpdb->insert($p.'module_access', ['tenant_id'=>1,'module'=>$key,'token_required'=>'CCJV','monthly_fee'=>$module['fee'],'status'=>'active']);
            }
        }
    }
}
