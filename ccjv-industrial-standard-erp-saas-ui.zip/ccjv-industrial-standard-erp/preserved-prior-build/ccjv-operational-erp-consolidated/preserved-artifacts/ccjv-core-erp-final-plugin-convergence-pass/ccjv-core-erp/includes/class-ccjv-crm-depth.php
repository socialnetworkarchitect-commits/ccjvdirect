<?php
if (!defined('ABSPATH')) exit;

class CCJV_CRM_Depth {
    public static function install() {
        global $wpdb;
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        $charset = $wpdb->get_charset_collate();
        $p = $wpdb->prefix . 'ccjv_';

        dbDelta("CREATE TABLE {$p}crm_accounts (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            tenant_id BIGINT UNSIGNED NOT NULL DEFAULT 1,
            account_name VARCHAR(255) NOT NULL,
            industry VARCHAR(160) NULL,
            status VARCHAR(80) NOT NULL DEFAULT 'active',
            owner_id BIGINT UNSIGNED NULL,
            health_score INT NOT NULL DEFAULT 75,
            vault_hash VARCHAR(128) NULL,
            replay_id VARCHAR(128) NULL,
            treasury_ref VARCHAR(128) NULL,
            created_at DATETIME NOT NULL,
            updated_at DATETIME NULL,
            PRIMARY KEY (id),
            KEY tenant_status (tenant_id,status)
        ) $charset;");

        dbDelta("CREATE TABLE {$p}crm_contacts (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            tenant_id BIGINT UNSIGNED NOT NULL DEFAULT 1,
            account_id BIGINT UNSIGNED NULL,
            full_name VARCHAR(255) NOT NULL,
            email VARCHAR(190) NULL,
            phone VARCHAR(80) NULL,
            title VARCHAR(160) NULL,
            status VARCHAR(80) NOT NULL DEFAULT 'active',
            vault_hash VARCHAR(128) NULL,
            replay_id VARCHAR(128) NULL,
            created_at DATETIME NOT NULL,
            updated_at DATETIME NULL,
            PRIMARY KEY (id),
            KEY tenant_account (tenant_id,account_id)
        ) $charset;");

        dbDelta("CREATE TABLE {$p}crm_opportunities (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            tenant_id BIGINT UNSIGNED NOT NULL DEFAULT 1,
            account_id BIGINT UNSIGNED NULL,
            title VARCHAR(255) NOT NULL,
            stage VARCHAR(80) NOT NULL DEFAULT 'prospecting',
            amount DECIMAL(18,2) NOT NULL DEFAULT 0,
            probability INT NOT NULL DEFAULT 10,
            close_date DATE NULL,
            status VARCHAR(80) NOT NULL DEFAULT 'open',
            vault_hash VARCHAR(128) NULL,
            replay_id VARCHAR(128) NULL,
            treasury_ref VARCHAR(128) NULL,
            created_at DATETIME NOT NULL,
            updated_at DATETIME NULL,
            PRIMARY KEY (id),
            KEY tenant_stage (tenant_id,stage)
        ) $charset;");

        dbDelta("CREATE TABLE {$p}crm_activities (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            tenant_id BIGINT UNSIGNED NOT NULL DEFAULT 1,
            account_id BIGINT UNSIGNED NULL,
            contact_id BIGINT UNSIGNED NULL,
            opportunity_id BIGINT UNSIGNED NULL,
            activity_type VARCHAR(80) NOT NULL DEFAULT 'note',
            subject VARCHAR(255) NOT NULL,
            details LONGTEXT NULL,
            due_at DATETIME NULL,
            status VARCHAR(80) NOT NULL DEFAULT 'open',
            vault_hash VARCHAR(128) NULL,
            replay_id VARCHAR(128) NULL,
            created_at DATETIME NOT NULL,
            updated_at DATETIME NULL,
            PRIMARY KEY (id),
            KEY tenant_status (tenant_id,status)
        ) $charset;");

        dbDelta("CREATE TABLE {$p}crm_timeline (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            tenant_id BIGINT UNSIGNED NOT NULL DEFAULT 1,
            entity_type VARCHAR(80) NOT NULL,
            entity_id BIGINT UNSIGNED NOT NULL,
            event_type VARCHAR(120) NOT NULL,
            label VARCHAR(255) NOT NULL,
            payload LONGTEXT NULL,
            correlation_id VARCHAR(128) NULL,
            created_at DATETIME NOT NULL,
            PRIMARY KEY (id),
            KEY entity (entity_type,entity_id),
            KEY tenant_event (tenant_id,event_type)
        ) $charset;");
    }

    public static function emit($entity_type, $entity_id, $event_type, $label, $payload = []) {
        global $wpdb;
        $correlation = CCJV_Core_Runtime_Client::emit_event('crm', $event_type, $entity_id, $payload);
        $wpdb->insert($wpdb->prefix . 'ccjv_crm_timeline', [
            'tenant_id' => 1,
            'entity_type' => sanitize_key($entity_type),
            'entity_id' => absint($entity_id),
            'event_type' => sanitize_text_field($event_type),
            'label' => sanitize_text_field($label),
            'payload' => wp_json_encode($payload),
            'correlation_id' => $correlation,
            'created_at' => current_time('mysql')
        ]);
        return $correlation;
    }

    public static function hash_payload($payload) {
        return hash('sha256', wp_json_encode($payload) . microtime(true));
    }
}
