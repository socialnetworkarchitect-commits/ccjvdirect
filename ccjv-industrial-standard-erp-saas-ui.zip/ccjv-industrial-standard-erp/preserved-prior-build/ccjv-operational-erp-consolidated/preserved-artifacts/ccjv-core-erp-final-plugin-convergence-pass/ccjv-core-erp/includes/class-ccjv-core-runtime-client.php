<?php
if (!defined('ABSPATH')) exit;
class CCJV_Core_Runtime_Client {
    public static function request($method, $endpoint, $body = []) {
        $base = rtrim((string)get_option('ccjv_core_runtime_api', ''), '/');
        if (!$base) return ['ok'=>false,'error'=>'Runtime API not configured'];
        $args = ['method'=>strtoupper($method),'timeout'=>20,'headers'=>['Content-Type'=>'application/json','Authorization'=>'Bearer '.get_option('ccjv_core_runtime_token',''),'X-CCJV-ERP'=>'core']];
        if (!empty($body)) $args['body'] = wp_json_encode($body);
        $response = wp_remote_request($base.'/'.ltrim($endpoint,'/'), $args);
        if (is_wp_error($response)) return ['ok'=>false,'error'=>$response->get_error_message()];
        return ['ok'=>wp_remote_retrieve_response_code($response)>=200 && wp_remote_retrieve_response_code($response)<300,'status'=>wp_remote_retrieve_response_code($response),'body'=>json_decode(wp_remote_retrieve_body($response), true)];
    }
    public static function emit_event($module, $event_type, $record_id, $payload = []) {
        global $wpdb;
        $p = $wpdb->prefix.'ccjv_';
        $correlation_id = 'ccjv_' . wp_generate_uuid4();
        $wpdb->insert($p.'events', ['tenant_id'=>1,'module'=>sanitize_key($module),'event_type'=>sanitize_text_field($event_type),'record_id'=>absint($record_id),'correlation_id'=>$correlation_id,'payload'=>wp_json_encode($payload),'created_at'=>current_time('mysql')]);
        self::request('POST','/replay/append',['module'=>$module,'event_type'=>$event_type,'record_id'=>$record_id,'correlation_id'=>$correlation_id,'payload'=>$payload]);
        return $correlation_id;
    }
}
