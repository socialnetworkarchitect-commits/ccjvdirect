<?php
if (!defined('ABSPATH')) exit;

class CCJV_Procurement_Governance_Depth {
    public static function install() {
        global $wpdb;
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        $charset = $wpdb->get_charset_collate();
        $p = $wpdb->prefix . 'ccjv_';

        dbDelta("CREATE TABLE {$p}procurement_vendors (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            tenant_id BIGINT UNSIGNED NOT NULL DEFAULT 1,
            vendor_name VARCHAR(255) NOT NULL,
            category VARCHAR(120) NULL,
            score DECIMAL(8,2) NOT NULL DEFAULT 0,
            status VARCHAR(80) NOT NULL DEFAULT 'active',
            vault_hash VARCHAR(128) NULL,
            replay_id VARCHAR(128) NULL,
            treasury_ref VARCHAR(128) NULL,
            created_at DATETIME NOT NULL,
            updated_at DATETIME NULL,
            PRIMARY KEY (id),
            KEY tenant_status (tenant_id,status)
        ) $charset;");

        dbDelta("CREATE TABLE {$p}procurement_rfqs (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            tenant_id BIGINT UNSIGNED NOT NULL DEFAULT 1,
            rfq_number VARCHAR(120) NOT NULL,
            title VARCHAR(255) NOT NULL,
            description LONGTEXT NULL,
            budget DECIMAL(18,2) NOT NULL DEFAULT 0,
            status VARCHAR(80) NOT NULL DEFAULT 'draft',
            closing_date DATETIME NULL,
            vault_hash VARCHAR(128) NULL,
            replay_id VARCHAR(128) NULL,
            treasury_ref VARCHAR(128) NULL,
            created_at DATETIME NOT NULL,
            updated_at DATETIME NULL,
            PRIMARY KEY (id),
            KEY tenant_status (tenant_id,status)
        ) $charset;");

        dbDelta("CREATE TABLE {$p}procurement_bids (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            tenant_id BIGINT UNSIGNED NOT NULL DEFAULT 1,
            rfq_id BIGINT UNSIGNED NOT NULL,
            vendor_id BIGINT UNSIGNED NULL,
            vendor_name VARCHAR(255) NOT NULL,
            bid_amount DECIMAL(18,2) NOT NULL DEFAULT 0,
            delivery_days INT NOT NULL DEFAULT 0,
            score DECIMAL(8,2) NOT NULL DEFAULT 0,
            status VARCHAR(80) NOT NULL DEFAULT 'submitted',
            vault_hash VARCHAR(128) NULL,
            replay_id VARCHAR(128) NULL,
            treasury_ref VARCHAR(128) NULL,
            created_at DATETIME NOT NULL,
            updated_at DATETIME NULL,
            PRIMARY KEY (id),
            KEY rfq_id (rfq_id),
            KEY score (score)
        ) $charset;");

        dbDelta("CREATE TABLE {$p}procurement_purchase_orders (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            tenant_id BIGINT UNSIGNED NOT NULL DEFAULT 1,
            po_number VARCHAR(120) NOT NULL,
            rfq_id BIGINT UNSIGNED NULL,
            bid_id BIGINT UNSIGNED NULL,
            vendor_name VARCHAR(255) NOT NULL,
            total_amount DECIMAL(18,2) NOT NULL DEFAULT 0,
            approval_status VARCHAR(80) NOT NULL DEFAULT 'pending',
            treasury_ref VARCHAR(128) NULL,
            vault_hash VARCHAR(128) NULL,
            replay_id VARCHAR(128) NULL,
            created_at DATETIME NOT NULL,
            updated_at DATETIME NULL,
            PRIMARY KEY (id),
            KEY approval_status (approval_status)
        ) $charset;");

        dbDelta("CREATE TABLE {$p}governance_proposals (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            tenant_id BIGINT UNSIGNED NOT NULL DEFAULT 1,
            proposal_code VARCHAR(120) NOT NULL,
            title VARCHAR(255) NOT NULL,
            proposal_text LONGTEXT NULL,
            quorum_required DECIMAL(8,2) NOT NULL DEFAULT 50,
            status VARCHAR(80) NOT NULL DEFAULT 'open',
            vault_hash VARCHAR(128) NULL,
            replay_id VARCHAR(128) NULL,
            treasury_ref VARCHAR(128) NULL,
            created_at DATETIME NOT NULL,
            updated_at DATETIME NULL,
            PRIMARY KEY (id),
            KEY tenant_status (tenant_id,status)
        ) $charset;");

        dbDelta("CREATE TABLE {$p}governance_votes (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            tenant_id BIGINT UNSIGNED NOT NULL DEFAULT 1,
            proposal_id BIGINT UNSIGNED NOT NULL,
            voter_id BIGINT UNSIGNED NOT NULL,
            vote VARCHAR(20) NOT NULL,
            voting_power DECIMAL(18,2) NOT NULL DEFAULT 1,
            replay_id VARCHAR(128) NULL,
            created_at DATETIME NOT NULL,
            PRIMARY KEY (id),
            KEY proposal_id (proposal_id)
        ) $charset;");

        dbDelta("CREATE TABLE {$p}procgov_timeline (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            tenant_id BIGINT UNSIGNED NOT NULL DEFAULT 1,
            module VARCHAR(40) NOT NULL,
            entity_type VARCHAR(80) NOT NULL,
            entity_id BIGINT UNSIGNED NOT NULL,
            event_type VARCHAR(120) NOT NULL,
            label VARCHAR(255) NOT NULL,
            payload LONGTEXT NULL,
            correlation_id VARCHAR(128) NULL,
            created_at DATETIME NOT NULL,
            PRIMARY KEY (id),
            KEY entity (entity_type,entity_id)
        ) $charset;");
    }

    public static function hash_payload($payload) {
        return hash('sha256', wp_json_encode($payload) . microtime(true));
    }

    public static function emit($module, $entity_type, $entity_id, $event_type, $label, $payload = []) {
        global $wpdb;
        $correlation = CCJV_Core_Runtime_Client::emit_event($module, $event_type, $entity_id, $payload);
        $wpdb->insert($wpdb->prefix . 'ccjv_procgov_timeline', [
            'tenant_id'=>1,
            'module'=>sanitize_key($module),
            'entity_type'=>sanitize_key($entity_type),
            'entity_id'=>absint($entity_id),
            'event_type'=>sanitize_text_field($event_type),
            'label'=>sanitize_text_field($label),
            'payload'=>wp_json_encode($payload),
            'correlation_id'=>$correlation,
            'created_at'=>current_time('mysql')
        ]);
        return $correlation;
    }
}
