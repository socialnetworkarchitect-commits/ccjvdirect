<?php
if (!defined('ABSPATH')) exit;

class CCJV_HRM_Depth {
    public static function install() {
        global $wpdb;
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        $charset = $wpdb->get_charset_collate();
        $p = $wpdb->prefix . 'ccjv_';

        dbDelta("CREATE TABLE {$p}hrm_departments (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            tenant_id BIGINT UNSIGNED NOT NULL DEFAULT 1,
            name VARCHAR(255) NOT NULL,
            parent_id BIGINT UNSIGNED NULL,
            manager_id BIGINT UNSIGNED NULL,
            status VARCHAR(80) NOT NULL DEFAULT 'active',
            created_at DATETIME NOT NULL,
            updated_at DATETIME NULL,
            PRIMARY KEY (id),
            KEY tenant_status (tenant_id,status)
        ) $charset;");

        dbDelta("CREATE TABLE {$p}hrm_people (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            tenant_id BIGINT UNSIGNED NOT NULL DEFAULT 1,
            person_type VARCHAR(80) NOT NULL DEFAULT 'employee',
            full_name VARCHAR(255) NOT NULL,
            email VARCHAR(190) NULL,
            phone VARCHAR(80) NULL,
            department_id BIGINT UNSIGNED NULL,
            role_title VARCHAR(190) NULL,
            employment_status VARCHAR(80) NOT NULL DEFAULT 'active',
            readiness_score INT NOT NULL DEFAULT 70,
            vault_hash VARCHAR(128) NULL,
            replay_id VARCHAR(128) NULL,
            treasury_ref VARCHAR(128) NULL,
            created_at DATETIME NOT NULL,
            updated_at DATETIME NULL,
            PRIMARY KEY (id),
            KEY tenant_type (tenant_id,person_type),
            KEY readiness (readiness_score)
        ) $charset;");

        dbDelta("CREATE TABLE {$p}hrm_certifications (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            tenant_id BIGINT UNSIGNED NOT NULL DEFAULT 1,
            person_id BIGINT UNSIGNED NOT NULL,
            certification_name VARCHAR(255) NOT NULL,
            issuer VARCHAR(255) NULL,
            issued_at DATE NULL,
            expires_at DATE NULL,
            status VARCHAR(80) NOT NULL DEFAULT 'valid',
            vault_hash VARCHAR(128) NULL,
            replay_id VARCHAR(128) NULL,
            created_at DATETIME NOT NULL,
            updated_at DATETIME NULL,
            PRIMARY KEY (id),
            KEY tenant_person (tenant_id,person_id),
            KEY expires_at (expires_at)
        ) $charset;");

        dbDelta("CREATE TABLE {$p}hrm_competencies (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            tenant_id BIGINT UNSIGNED NOT NULL DEFAULT 1,
            person_id BIGINT UNSIGNED NOT NULL,
            competency VARCHAR(255) NOT NULL,
            proficiency INT NOT NULL DEFAULT 50,
            verified_by BIGINT UNSIGNED NULL,
            status VARCHAR(80) NOT NULL DEFAULT 'active',
            vault_hash VARCHAR(128) NULL,
            replay_id VARCHAR(128) NULL,
            created_at DATETIME NOT NULL,
            updated_at DATETIME NULL,
            PRIMARY KEY (id),
            KEY tenant_person (tenant_id,person_id)
        ) $charset;");

        dbDelta("CREATE TABLE {$p}hrm_schedules (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            tenant_id BIGINT UNSIGNED NOT NULL DEFAULT 1,
            person_id BIGINT UNSIGNED NOT NULL,
            shift_title VARCHAR(255) NOT NULL,
            starts_at DATETIME NOT NULL,
            ends_at DATETIME NOT NULL,
            location VARCHAR(255) NULL,
            status VARCHAR(80) NOT NULL DEFAULT 'scheduled',
            vault_hash VARCHAR(128) NULL,
            replay_id VARCHAR(128) NULL,
            created_at DATETIME NOT NULL,
            updated_at DATETIME NULL,
            PRIMARY KEY (id),
            KEY tenant_person (tenant_id,person_id),
            KEY starts_at (starts_at)
        ) $charset;");

        dbDelta("CREATE TABLE {$p}hrm_training (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            tenant_id BIGINT UNSIGNED NOT NULL DEFAULT 1,
            person_id BIGINT UNSIGNED NOT NULL,
            training_title VARCHAR(255) NOT NULL,
            stage VARCHAR(80) NOT NULL DEFAULT 'assigned',
            due_at DATE NULL,
            status VARCHAR(80) NOT NULL DEFAULT 'open',
            vault_hash VARCHAR(128) NULL,
            replay_id VARCHAR(128) NULL,
            created_at DATETIME NOT NULL,
            updated_at DATETIME NULL,
            PRIMARY KEY (id),
            KEY tenant_person (tenant_id,person_id)
        ) $charset;");

        dbDelta("CREATE TABLE {$p}hrm_timeline (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            tenant_id BIGINT UNSIGNED NOT NULL DEFAULT 1,
            entity_type VARCHAR(80) NOT NULL,
            entity_id BIGINT UNSIGNED NOT NULL,
            event_type VARCHAR(120) NOT NULL,
            label VARCHAR(255) NOT NULL,
            payload LONGTEXT NULL,
            correlation_id VARCHAR(128) NULL,
            created_at DATETIME NOT NULL,
            PRIMARY KEY (id),
            KEY entity (entity_type,entity_id),
            KEY tenant_event (tenant_id,event_type)
        ) $charset;");
    }

    public static function hash_payload($payload) {
        return hash('sha256', wp_json_encode($payload) . microtime(true));
    }

    public static function emit($entity_type, $entity_id, $event_type, $label, $payload = []) {
        global $wpdb;
        $correlation = CCJV_Core_Runtime_Client::emit_event('hrm', $event_type, $entity_id, $payload);
        $wpdb->insert($wpdb->prefix . 'ccjv_hrm_timeline', [
            'tenant_id' => 1,
            'entity_type' => sanitize_key($entity_type),
            'entity_id' => absint($entity_id),
            'event_type' => sanitize_text_field($event_type),
            'label' => sanitize_text_field($label),
            'payload' => wp_json_encode($payload),
            'correlation_id' => $correlation,
            'created_at' => current_time('mysql')
        ]);
        return $correlation;
    }
}
