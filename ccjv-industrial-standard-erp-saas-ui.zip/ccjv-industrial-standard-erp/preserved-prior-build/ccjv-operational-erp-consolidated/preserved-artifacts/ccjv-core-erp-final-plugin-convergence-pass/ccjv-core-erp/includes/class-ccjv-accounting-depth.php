<?php
if (!defined('ABSPATH')) exit;

class CCJV_Accounting_Depth {
    public static function install() {
        global $wpdb;
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        $charset = $wpdb->get_charset_collate();
        $p = $wpdb->prefix . 'ccjv_';

        dbDelta("CREATE TABLE {$p}acct_accounts (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            tenant_id BIGINT UNSIGNED NOT NULL DEFAULT 1,
            account_code VARCHAR(80) NOT NULL,
            account_name VARCHAR(255) NOT NULL,
            account_type VARCHAR(80) NOT NULL DEFAULT 'asset',
            normal_balance VARCHAR(20) NOT NULL DEFAULT 'debit',
            status VARCHAR(80) NOT NULL DEFAULT 'active',
            vault_hash VARCHAR(128) NULL,
            replay_id VARCHAR(128) NULL,
            created_at DATETIME NOT NULL,
            updated_at DATETIME NULL,
            PRIMARY KEY (id),
            UNIQUE KEY tenant_code (tenant_id, account_code)
        ) $charset;");

        dbDelta("CREATE TABLE {$p}acct_journals (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            tenant_id BIGINT UNSIGNED NOT NULL DEFAULT 1,
            journal_no VARCHAR(120) NOT NULL,
            memo VARCHAR(255) NULL,
            journal_date DATE NOT NULL,
            status VARCHAR(80) NOT NULL DEFAULT 'draft',
            total_debit DECIMAL(18,2) NOT NULL DEFAULT 0,
            total_credit DECIMAL(18,2) NOT NULL DEFAULT 0,
            vault_hash VARCHAR(128) NULL,
            replay_id VARCHAR(128) NULL,
            treasury_ref VARCHAR(128) NULL,
            created_at DATETIME NOT NULL,
            updated_at DATETIME NULL,
            PRIMARY KEY (id),
            KEY tenant_status (tenant_id,status)
        ) $charset;");

        dbDelta("CREATE TABLE {$p}acct_journal_lines (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            tenant_id BIGINT UNSIGNED NOT NULL DEFAULT 1,
            journal_id BIGINT UNSIGNED NOT NULL,
            account_id BIGINT UNSIGNED NOT NULL,
            description VARCHAR(255) NULL,
            debit DECIMAL(18,2) NOT NULL DEFAULT 0,
            credit DECIMAL(18,2) NOT NULL DEFAULT 0,
            created_at DATETIME NOT NULL,
            PRIMARY KEY (id),
            KEY journal_id (journal_id),
            KEY account_id (account_id)
        ) $charset;");

        dbDelta("CREATE TABLE {$p}acct_invoices (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            tenant_id BIGINT UNSIGNED NOT NULL DEFAULT 1,
            invoice_no VARCHAR(120) NOT NULL,
            counterparty VARCHAR(255) NOT NULL,
            invoice_type VARCHAR(40) NOT NULL DEFAULT 'ar',
            issue_date DATE NULL,
            due_date DATE NULL,
            amount DECIMAL(18,2) NOT NULL DEFAULT 0,
            paid_amount DECIMAL(18,2) NOT NULL DEFAULT 0,
            status VARCHAR(80) NOT NULL DEFAULT 'open',
            vault_hash VARCHAR(128) NULL,
            replay_id VARCHAR(128) NULL,
            treasury_ref VARCHAR(128) NULL,
            created_at DATETIME NOT NULL,
            updated_at DATETIME NULL,
            PRIMARY KEY (id),
            KEY tenant_type (tenant_id,invoice_type),
            KEY status (status)
        ) $charset;");

        dbDelta("CREATE TABLE {$p}acct_payments (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            tenant_id BIGINT UNSIGNED NOT NULL DEFAULT 1,
            invoice_id BIGINT UNSIGNED NULL,
            payment_ref VARCHAR(128) NULL,
            payment_date DATE NULL,
            amount DECIMAL(18,2) NOT NULL DEFAULT 0,
            method VARCHAR(80) NOT NULL DEFAULT 'token',
            status VARCHAR(80) NOT NULL DEFAULT 'pending',
            tx_hash VARCHAR(190) NULL,
            vault_hash VARCHAR(128) NULL,
            replay_id VARCHAR(128) NULL,
            treasury_ref VARCHAR(128) NULL,
            created_at DATETIME NOT NULL,
            updated_at DATETIME NULL,
            PRIMARY KEY (id),
            KEY invoice_id (invoice_id),
            KEY tx_hash (tx_hash)
        ) $charset;");

        dbDelta("CREATE TABLE {$p}acct_reconciliations (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            tenant_id BIGINT UNSIGNED NOT NULL DEFAULT 1,
            reconciliation_no VARCHAR(120) NOT NULL,
            account_id BIGINT UNSIGNED NULL,
            statement_date DATE NULL,
            statement_balance DECIMAL(18,2) NOT NULL DEFAULT 0,
            book_balance DECIMAL(18,2) NOT NULL DEFAULT 0,
            variance DECIMAL(18,2) NOT NULL DEFAULT 0,
            status VARCHAR(80) NOT NULL DEFAULT 'open',
            vault_hash VARCHAR(128) NULL,
            replay_id VARCHAR(128) NULL,
            treasury_ref VARCHAR(128) NULL,
            created_at DATETIME NOT NULL,
            updated_at DATETIME NULL,
            PRIMARY KEY (id),
            KEY tenant_status (tenant_id,status)
        ) $charset;");

        dbDelta("CREATE TABLE {$p}acct_reports (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            tenant_id BIGINT UNSIGNED NOT NULL DEFAULT 1,
            report_type VARCHAR(80) NOT NULL,
            period_start DATE NULL,
            period_end DATE NULL,
            payload LONGTEXT NULL,
            vault_hash VARCHAR(128) NULL,
            replay_id VARCHAR(128) NULL,
            created_at DATETIME NOT NULL,
            PRIMARY KEY (id),
            KEY report_type (report_type)
        ) $charset;");

        dbDelta("CREATE TABLE {$p}acct_timeline (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            tenant_id BIGINT UNSIGNED NOT NULL DEFAULT 1,
            entity_type VARCHAR(80) NOT NULL,
            entity_id BIGINT UNSIGNED NOT NULL,
            event_type VARCHAR(120) NOT NULL,
            label VARCHAR(255) NOT NULL,
            payload LONGTEXT NULL,
            correlation_id VARCHAR(128) NULL,
            created_at DATETIME NOT NULL,
            PRIMARY KEY (id),
            KEY entity (entity_type,entity_id),
            KEY tenant_event (tenant_id,event_type)
        ) $charset;");

        self::seed_chart();
    }

    public static function seed_chart() {
        global $wpdb;
        $p = $wpdb->prefix . 'ccjv_';
        $defaults = [
            ['1000','Cash','asset','debit'],
            ['1100','Accounts Receivable','asset','debit'],
            ['1200','Token Treasury Receivable','asset','debit'],
            ['2000','Accounts Payable','liability','credit'],
            ['2100','Token Settlement Liability','liability','credit'],
            ['3000','Member Equity','equity','credit'],
            ['4000','Module Revenue','revenue','credit'],
            ['5000','Operations Expense','expense','debit'],
        ];
        foreach ($defaults as $a) {
            $exists = $wpdb->get_var($wpdb->prepare("SELECT id FROM {$p}acct_accounts WHERE tenant_id=1 AND account_code=%s", $a[0]));
            if (!$exists) {
                $payload = ['code'=>$a[0],'name'=>$a[1],'type'=>$a[2]];
                $wpdb->insert($p.'acct_accounts', [
                    'tenant_id'=>1,
                    'account_code'=>$a[0],
                    'account_name'=>$a[1],
                    'account_type'=>$a[2],
                    'normal_balance'=>$a[3],
                    'status'=>'active',
                    'vault_hash'=>self::hash_payload($payload),
                    'created_at'=>current_time('mysql'),
                    'updated_at'=>current_time('mysql')
                ]);
            }
        }
    }

    public static function hash_payload($payload) {
        return hash('sha256', wp_json_encode($payload) . microtime(true));
    }

    public static function emit($entity_type, $entity_id, $event_type, $label, $payload = []) {
        global $wpdb;
        $correlation = CCJV_Core_Runtime_Client::emit_event('accounting', $event_type, $entity_id, $payload);
        $wpdb->insert($wpdb->prefix . 'ccjv_acct_timeline', [
            'tenant_id'=>1,
            'entity_type'=>sanitize_key($entity_type),
            'entity_id'=>absint($entity_id),
            'event_type'=>sanitize_text_field($event_type),
            'label'=>sanitize_text_field($label),
            'payload'=>wp_json_encode($payload),
            'correlation_id'=>$correlation,
            'created_at'=>current_time('mysql')
        ]);
        return $correlation;
    }
}
