<?php
if (!defined('ABSPATH')) exit;

class CCJV_Cockpit_Token_Runtime {
    public static function install() {
        global $wpdb;
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        $charset = $wpdb->get_charset_collate();
        $p = $wpdb->prefix . 'ccjv_';

        dbDelta("CREATE TABLE {$p}runtime_entitlements (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            tenant_id BIGINT UNSIGNED NOT NULL DEFAULT 1,
            module_key VARCHAR(80) NOT NULL,
            wallet_address VARCHAR(120) NULL,
            token_contract VARCHAR(120) NULL,
            token_symbol VARCHAR(40) NULL,
            required_balance DECIMAL(36,18) NOT NULL DEFAULT 0,
            allowance_required DECIMAL(36,18) NOT NULL DEFAULT 0,
            monthly_fee DECIMAL(36,18) NOT NULL DEFAULT 0,
            status VARCHAR(80) NOT NULL DEFAULT 'configured',
            expires_at DATETIME NULL,
            last_checked DATETIME NULL,
            vault_hash VARCHAR(128) NULL,
            replay_id VARCHAR(128) NULL,
            treasury_ref VARCHAR(128) NULL,
            created_at DATETIME NOT NULL,
            updated_at DATETIME NULL,
            PRIMARY KEY (id),
            KEY tenant_module (tenant_id,module_key)
        ) $charset;");

        dbDelta("CREATE TABLE {$p}runtime_bridge_events (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            tenant_id BIGINT UNSIGNED NOT NULL DEFAULT 1,
            event_type VARCHAR(120) NOT NULL,
            source_module VARCHAR(80) NULL,
            runtime_endpoint VARCHAR(255) NULL,
            status VARCHAR(80) NOT NULL DEFAULT 'queued',
            payload LONGTEXT NULL,
            response LONGTEXT NULL,
            correlation_id VARCHAR(128) NULL,
            created_at DATETIME NOT NULL,
            updated_at DATETIME NULL,
            PRIMARY KEY (id),
            KEY status (status)
        ) $charset;");

        dbDelta("CREATE TABLE {$p}cockpit_notifications (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            tenant_id BIGINT UNSIGNED NOT NULL DEFAULT 1,
            notification_type VARCHAR(120) NOT NULL,
            title VARCHAR(255) NOT NULL,
            message LONGTEXT NULL,
            severity VARCHAR(40) NOT NULL DEFAULT 'info',
            status VARCHAR(80) NOT NULL DEFAULT 'unread',
            source_module VARCHAR(80) NULL,
            replay_id VARCHAR(128) NULL,
            created_at DATETIME NOT NULL,
            PRIMARY KEY (id),
            KEY status (status)
        ) $charset;");

        if (class_exists('CCJV_Core_Modules')) {
            foreach (CCJV_Core_Modules::all() as $key => $module) {
                $exists = $wpdb->get_var($wpdb->prepare("SELECT id FROM {$p}runtime_entitlements WHERE tenant_id=1 AND module_key=%s", $key));
                if (!$exists) {
                    $payload = wp_json_encode(['module'=>$key,'fee'=>$module['fee']]);
                    $wpdb->insert($p.'runtime_entitlements', [
                        'tenant_id'=>1,
                        'module_key'=>$key,
                        'token_contract'=>get_option('ccjv_core_token_contract',''),
                        'token_symbol'=>get_option('ccjv_core_token_symbol','CCJV'),
                        'required_balance'=>1,
                        'allowance_required'=>$module['fee'],
                        'monthly_fee'=>$module['fee'],
                        'status'=>'configured',
                        'vault_hash'=>hash('sha256', $payload . microtime(true)),
                        'treasury_ref'=>'entitlement-'.$key,
                        'created_at'=>current_time('mysql'),
                        'updated_at'=>current_time('mysql')
                    ]);
                }
            }
        }
    }

    public static function emit_bridge_event($type, $module, $endpoint, $payload = []) {
        global $wpdb;
        $correlation = 'bridge_' . wp_generate_uuid4();
        $wpdb->insert($wpdb->prefix . 'ccjv_runtime_bridge_events', [
            'tenant_id'=>1,
            'event_type'=>sanitize_text_field($type),
            'source_module'=>sanitize_key($module),
            'runtime_endpoint'=>sanitize_text_field($endpoint),
            'status'=>'queued',
            'payload'=>wp_json_encode($payload),
            'correlation_id'=>$correlation,
            'created_at'=>current_time('mysql'),
            'updated_at'=>current_time('mysql')
        ]);
        return $correlation;
    }
}
