<?php
if (!defined('ABSPATH')) exit;

class CCJV_CRM_REST {
    public function __construct() {
        add_action('rest_api_init', [$this, 'routes']);
    }

    public function routes() {
        foreach (['accounts','contacts','opportunities','activities'] as $entity) {
            register_rest_route('ccjv-core/v1', '/crm/' . $entity, [
                'methods' => 'GET',
                'callback' => [$this, 'list_' . $entity],
                'permission_callback' => function(){ return is_user_logged_in(); }
            ]);
            register_rest_route('ccjv-core/v1', '/crm/' . $entity, [
                'methods' => 'POST',
                'callback' => [$this, 'create_' . $entity],
                'permission_callback' => function(){ return is_user_logged_in(); }
            ]);
        }

        register_rest_route('ccjv-core/v1', '/crm/pipeline', [
            'methods' => 'GET',
            'callback' => [$this, 'pipeline'],
            'permission_callback' => function(){ return is_user_logged_in(); }
        ]);

        register_rest_route('ccjv-core/v1', '/crm/timeline/(?P<entity>[a-z0-9_-]+)/(?P<id>\\d+)', [
            'methods' => 'GET',
            'callback' => [$this, 'timeline'],
            'permission_callback' => function(){ return is_user_logged_in(); }
        ]);
    }

    private function insert($table, $data, $entity_type, $event_label) {
        global $wpdb;
        $data['tenant_id'] = 1;
        $data['vault_hash'] = CCJV_CRM_Depth::hash_payload($data);
        $data['created_at'] = current_time('mysql');
        $data['updated_at'] = current_time('mysql');
        $wpdb->insert($wpdb->prefix . 'ccjv_' . $table, $data);
        $id = $wpdb->insert_id;
        $replay = CCJV_CRM_Depth::emit($entity_type, $id, $entity_type . '.created', $event_label, $data);
        $wpdb->update($wpdb->prefix . 'ccjv_' . $table, ['replay_id' => $replay, 'treasury_ref' => 'crm-module-fee'], ['id' => $id]);
        return ['ok' => true, 'id' => $id, 'vault_hash' => $data['vault_hash'], 'replay_id' => $replay, 'treasury_ref' => 'crm-module-fee'];
    }

    public function create_accounts($request) {
        $p = $request->get_json_params();
        return $this->insert('crm_accounts', [
            'account_name' => sanitize_text_field($p['account_name'] ?? 'New Account'),
            'industry' => sanitize_text_field($p['industry'] ?? ''),
            'status' => sanitize_text_field($p['status'] ?? 'active'),
            'health_score' => absint($p['health_score'] ?? 75),
            'owner_id' => get_current_user_id(),
        ], 'account', 'Account created');
    }

    public function create_contacts($request) {
        $p = $request->get_json_params();
        return $this->insert('crm_contacts', [
            'account_id' => absint($p['account_id'] ?? 0),
            'full_name' => sanitize_text_field($p['full_name'] ?? 'New Contact'),
            'email' => sanitize_email($p['email'] ?? ''),
            'phone' => sanitize_text_field($p['phone'] ?? ''),
            'title' => sanitize_text_field($p['title'] ?? ''),
            'status' => sanitize_text_field($p['status'] ?? 'active'),
        ], 'contact', 'Contact created');
    }

    public function create_opportunities($request) {
        $p = $request->get_json_params();
        return $this->insert('crm_opportunities', [
            'account_id' => absint($p['account_id'] ?? 0),
            'title' => sanitize_text_field($p['title'] ?? 'New Opportunity'),
            'stage' => sanitize_text_field($p['stage'] ?? 'prospecting'),
            'amount' => floatval($p['amount'] ?? 0),
            'probability' => absint($p['probability'] ?? 10),
            'close_date' => sanitize_text_field($p['close_date'] ?? ''),
            'status' => sanitize_text_field($p['status'] ?? 'open'),
        ], 'opportunity', 'Opportunity created');
    }

    public function create_activities($request) {
        $p = $request->get_json_params();
        return $this->insert('crm_activities', [
            'account_id' => absint($p['account_id'] ?? 0),
            'contact_id' => absint($p['contact_id'] ?? 0),
            'opportunity_id' => absint($p['opportunity_id'] ?? 0),
            'activity_type' => sanitize_text_field($p['activity_type'] ?? 'note'),
            'subject' => sanitize_text_field($p['subject'] ?? 'New Activity'),
            'details' => sanitize_textarea_field($p['details'] ?? ''),
            'due_at' => sanitize_text_field($p['due_at'] ?? ''),
            'status' => sanitize_text_field($p['status'] ?? 'open'),
        ], 'activity', 'Activity created');
    }

    private function list_table($table) {
        global $wpdb;
        return $wpdb->get_results("SELECT * FROM {$wpdb->prefix}ccjv_{$table} ORDER BY id DESC LIMIT 100", ARRAY_A);
    }
    public function list_accounts(){ return $this->list_table('crm_accounts'); }
    public function list_contacts(){ return $this->list_table('crm_contacts'); }
    public function list_opportunities(){ return $this->list_table('crm_opportunities'); }
    public function list_activities(){ return $this->list_table('crm_activities'); }

    public function pipeline() {
        global $wpdb;
        $rows = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}ccjv_crm_opportunities ORDER BY amount DESC LIMIT 100", ARRAY_A);
        $stages = ['prospecting'=>[], 'qualified'=>[], 'proposal'=>[], 'negotiation'=>[], 'won'=>[], 'lost'=>[]];
        foreach ($rows as $row) {
            $stage = $row['stage'] ?: 'prospecting';
            if (!isset($stages[$stage])) $stages[$stage] = [];
            $stages[$stage][] = $row;
        }
        return $stages;
    }

    public function timeline($request) {
        global $wpdb;
        return $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}ccjv_crm_timeline WHERE entity_type=%s AND entity_id=%d ORDER BY id DESC LIMIT 100",
            sanitize_key($request['entity']),
            absint($request['id'])
        ), ARRAY_A);
    }
}
