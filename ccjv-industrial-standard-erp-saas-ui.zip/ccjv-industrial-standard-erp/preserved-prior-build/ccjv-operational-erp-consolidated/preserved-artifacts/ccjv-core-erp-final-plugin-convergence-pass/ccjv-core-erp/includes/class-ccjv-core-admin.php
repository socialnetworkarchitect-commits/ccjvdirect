<?php
if (!defined('ABSPATH')) exit;
class CCJV_Core_Admin {
    public static function menu() {
        add_menu_page('CCJV ERP','CCJV ERP','manage_options','ccjv-core-erp',[__CLASS__,'dashboard'],'dashicons-building',2);
        add_submenu_page('ccjv-core-erp','Settings','Settings','manage_options','ccjv-core-settings',[__CLASS__,'settings_page']);
        add_submenu_page('ccjv-core-erp','Runtime Health','Runtime Health','manage_options','ccjv-core-health',[__CLASS__,'health_page']);
    }
    public static function settings() {
        foreach (['ccjv_core_runtime_api','ccjv_core_runtime_ws','ccjv_core_runtime_token','ccjv_core_token_symbol','ccjv_core_token_contract'] as $setting) register_setting('ccjv_core_settings', $setting);
    }
    public static function dashboard() { echo do_shortcode('[ccjv_core_dashboard]'); }
    public static function settings_page() { include CCJV_CORE_ERP_PATH.'templates/settings.php'; }
    public static function health_page() { include CCJV_CORE_ERP_PATH.'templates/health.php'; }
}
