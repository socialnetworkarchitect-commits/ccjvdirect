<?php
if (!defined('ABSPATH')) exit;

class CCJV_PM_REST {
    public function __construct() { add_action('rest_api_init', [$this,'routes']); }

    public function routes() {
        foreach (['projects','tasks','milestones','dependencies','approvals','documents'] as $entity) {
            register_rest_route('ccjv-core/v1', '/pm/' . $entity, [
                'methods'=>'GET','callback'=>[$this,'list_'.$entity],
                'permission_callback'=>function(){ return is_user_logged_in(); }
            ]);
            register_rest_route('ccjv-core/v1', '/pm/' . $entity, [
                'methods'=>'POST','callback'=>[$this,'create_'.$entity],
                'permission_callback'=>function(){ return is_user_logged_in(); }
            ]);
        }
        register_rest_route('ccjv-core/v1', '/pm/kanban', ['methods'=>'GET','callback'=>[$this,'kanban'],'permission_callback'=>function(){ return is_user_logged_in(); }]);
        register_rest_route('ccjv-core/v1', '/pm/gantt', ['methods'=>'GET','callback'=>[$this,'gantt'],'permission_callback'=>function(){ return is_user_logged_in(); }]);
        register_rest_route('ccjv-core/v1', '/pm/workload', ['methods'=>'GET','callback'=>[$this,'workload'],'permission_callback'=>function(){ return is_user_logged_in(); }]);
    }

    private function insert($table, $data, $entity_type, $label) {
        global $wpdb;
        $data['tenant_id'] = 1;
        $data['vault_hash'] = CCJV_PM_Depth::hash_payload($data);
        $data['created_at'] = current_time('mysql');
        $data['updated_at'] = current_time('mysql');
        $wpdb->insert($wpdb->prefix.'ccjv_'.$table, $data);
        $id = $wpdb->insert_id;
        $replay = CCJV_PM_Depth::emit($entity_type, $id, $entity_type.'.created', $label, $data);
        $updates = ['replay_id'=>$replay];
        if (in_array($table, ['pm_projects','pm_tasks'])) $updates['treasury_ref'] = 'pm-module-fee';
        $wpdb->update($wpdb->prefix.'ccjv_'.$table, $updates, ['id'=>$id]);
        return ['ok'=>true,'id'=>$id,'vault_hash'=>$data['vault_hash'],'replay_id'=>$replay,'treasury_ref'=>$updates['treasury_ref'] ?? null];
    }

    public function create_projects($request) {
        $p=$request->get_json_params();
        return $this->insert('pm_projects', [
            'project_code'=>sanitize_text_field($p['project_code'] ?? 'P-'.time()),
            'project_name'=>sanitize_text_field($p['project_name'] ?? 'New Project'),
            'owner_id'=>get_current_user_id(),
            'status'=>sanitize_text_field($p['status'] ?? 'active'),
            'priority'=>sanitize_text_field($p['priority'] ?? 'normal'),
            'budget'=>floatval($p['budget'] ?? 0),
            'starts_at'=>sanitize_text_field($p['starts_at'] ?? ''),
            'ends_at'=>sanitize_text_field($p['ends_at'] ?? ''),
            'progress'=>absint($p['progress'] ?? 0)
        ], 'project', 'Project created');
    }

    public function create_tasks($request) {
        $p=$request->get_json_params();
        return $this->insert('pm_tasks', [
            'project_id'=>absint($p['project_id'] ?? 0),
            'task_title'=>sanitize_text_field($p['task_title'] ?? 'Task'),
            'assignee_id'=>absint($p['assignee_id'] ?? 0),
            'status'=>sanitize_text_field($p['status'] ?? 'todo'),
            'priority'=>sanitize_text_field($p['priority'] ?? 'normal'),
            'starts_at'=>sanitize_text_field($p['starts_at'] ?? ''),
            'due_date'=>sanitize_text_field($p['due_date'] ?? ''),
            'estimate_hours'=>floatval($p['estimate_hours'] ?? 0),
            'actual_hours'=>floatval($p['actual_hours'] ?? 0)
        ], 'task', 'Task created');
    }

    public function create_milestones($request) {
        $p=$request->get_json_params();
        return $this->insert('pm_milestones', [
            'project_id'=>absint($p['project_id'] ?? 0),
            'milestone_name'=>sanitize_text_field($p['milestone_name'] ?? 'Milestone'),
            'due_date'=>sanitize_text_field($p['due_date'] ?? ''),
            'status'=>sanitize_text_field($p['status'] ?? 'open'),
            'progress'=>absint($p['progress'] ?? 0)
        ], 'milestone', 'Milestone created');
    }

    public function create_dependencies($request) {
        $p=$request->get_json_params();
        return $this->insert('pm_dependencies', [
            'predecessor_task_id'=>absint($p['predecessor_task_id'] ?? 0),
            'successor_task_id'=>absint($p['successor_task_id'] ?? 0),
            'dependency_type'=>sanitize_text_field($p['dependency_type'] ?? 'finish_to_start'),
            'status'=>sanitize_text_field($p['status'] ?? 'active')
        ], 'dependency', 'Dependency created');
    }

    public function create_approvals($request) {
        $p=$request->get_json_params();
        return $this->insert('pm_approvals', [
            'project_id'=>absint($p['project_id'] ?? 0),
            'entity_type'=>sanitize_text_field($p['entity_type'] ?? 'task'),
            'entity_id'=>absint($p['entity_id'] ?? 0),
            'approver_id'=>get_current_user_id(),
            'decision'=>sanitize_text_field($p['decision'] ?? 'pending'),
            'comment'=>sanitize_textarea_field($p['comment'] ?? '')
        ], 'approval', 'Approval created');
    }

    public function create_documents($request) {
        $p=$request->get_json_params();
        return $this->insert('pm_documents', [
            'project_id'=>absint($p['project_id'] ?? 0),
            'entity_type'=>sanitize_text_field($p['entity_type'] ?? 'project'),
            'entity_id'=>absint($p['entity_id'] ?? 0),
            'document_title'=>sanitize_text_field($p['document_title'] ?? 'Project Document'),
            'proof_ref'=>sanitize_text_field($p['proof_ref'] ?? '')
        ], 'document', 'Document linked');
    }

    private function list_table($table) {
        global $wpdb;
        return $wpdb->get_results("SELECT * FROM {$wpdb->prefix}ccjv_{$table} ORDER BY id DESC LIMIT 150", ARRAY_A);
    }
    public function list_projects(){ return $this->list_table('pm_projects'); }
    public function list_tasks(){ return $this->list_table('pm_tasks'); }
    public function list_milestones(){ return $this->list_table('pm_milestones'); }
    public function list_dependencies(){ return $this->list_table('pm_dependencies'); }
    public function list_approvals(){ return $this->list_table('pm_approvals'); }
    public function list_documents(){ return $this->list_table('pm_documents'); }

    public function kanban() {
        global $wpdb;
        $rows = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}ccjv_pm_tasks ORDER BY priority DESC, id DESC LIMIT 150", ARRAY_A);
        $cols = ['todo'=>[], 'in_progress'=>[], 'blocked'=>[], 'review'=>[], 'done'=>[]];
        foreach ($rows as $row) {
            $status = $row['status'] ?: 'todo';
            if (!isset($cols[$status])) $cols[$status] = [];
            $cols[$status][] = $row;
        }
        return $cols;
    }

    public function gantt() {
        global $wpdb;
        return [
            'projects'=>$wpdb->get_results("SELECT id,project_name,starts_at,ends_at,progress,status FROM {$wpdb->prefix}ccjv_pm_projects ORDER BY id DESC LIMIT 100", ARRAY_A),
            'tasks'=>$wpdb->get_results("SELECT id,project_id,task_title,starts_at,due_date,status,estimate_hours FROM {$wpdb->prefix}ccjv_pm_tasks ORDER BY due_date ASC LIMIT 200", ARRAY_A),
            'dependencies'=>$wpdb->get_results("SELECT * FROM {$wpdb->prefix}ccjv_pm_dependencies ORDER BY id DESC LIMIT 200", ARRAY_A)
        ];
    }

    public function workload() {
        global $wpdb;
        return $wpdb->get_results("SELECT assignee_id, COUNT(*) tasks, COALESCE(SUM(estimate_hours),0) estimate, COALESCE(SUM(actual_hours),0) actual FROM {$wpdb->prefix}ccjv_pm_tasks GROUP BY assignee_id", ARRAY_A);
    }
}
