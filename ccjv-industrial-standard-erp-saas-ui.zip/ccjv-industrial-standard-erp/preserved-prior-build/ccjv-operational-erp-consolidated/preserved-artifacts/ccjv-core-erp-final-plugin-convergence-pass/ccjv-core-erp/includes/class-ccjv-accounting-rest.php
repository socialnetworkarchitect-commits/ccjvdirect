<?php
if (!defined('ABSPATH')) exit;

class CCJV_Accounting_REST {
    public function __construct() { add_action('rest_api_init', [$this,'routes']); }

    public function routes() {
        foreach (['accounts','journals','invoices','payments','reconciliations','reports'] as $entity) {
            register_rest_route('ccjv-core/v1', '/accounting/' . $entity, [
                'methods'=>'GET','callback'=>[$this,'list_'.$entity],
                'permission_callback'=>function(){ return is_user_logged_in(); }
            ]);
            register_rest_route('ccjv-core/v1', '/accounting/' . $entity, [
                'methods'=>'POST','callback'=>[$this,'create_'.$entity],
                'permission_callback'=>function(){ return is_user_logged_in(); }
            ]);
        }
        register_rest_route('ccjv-core/v1', '/accounting/ledger', [
            'methods'=>'GET','callback'=>[$this,'ledger'],
            'permission_callback'=>function(){ return is_user_logged_in(); }
        ]);
        register_rest_route('ccjv-core/v1', '/accounting/aging', [
            'methods'=>'GET','callback'=>[$this,'aging'],
            'permission_callback'=>function(){ return is_user_logged_in(); }
        ]);
        register_rest_route('ccjv-core/v1', '/accounting/kpis', [
            'methods'=>'GET','callback'=>[$this,'kpis'],
            'permission_callback'=>function(){ return is_user_logged_in(); }
        ]);
    }

    private function insert($table, $data, $entity_type, $label) {
        global $wpdb;
        $data['tenant_id'] = 1;
        $data['vault_hash'] = CCJV_Accounting_Depth::hash_payload($data);
        $data['created_at'] = current_time('mysql');
        $data['updated_at'] = current_time('mysql');
        $wpdb->insert($wpdb->prefix.'ccjv_'.$table, $data);
        $id = $wpdb->insert_id;
        $replay = CCJV_Accounting_Depth::emit($entity_type, $id, $entity_type.'.created', $label, $data);
        $updates = ['replay_id'=>$replay];
        if (in_array($table, ['acct_journals','acct_invoices','acct_payments','acct_reconciliations'])) $updates['treasury_ref'] = 'accounting-treasury-link';
        $wpdb->update($wpdb->prefix.'ccjv_'.$table, $updates, ['id'=>$id]);
        return ['ok'=>true,'id'=>$id,'vault_hash'=>$data['vault_hash'],'replay_id'=>$replay,'treasury_ref'=>$updates['treasury_ref'] ?? null];
    }

    public function create_accounts($request) {
        $p=$request->get_json_params();
        return $this->insert('acct_accounts', [
            'account_code'=>sanitize_text_field($p['account_code'] ?? ''),
            'account_name'=>sanitize_text_field($p['account_name'] ?? 'New Account'),
            'account_type'=>sanitize_text_field($p['account_type'] ?? 'asset'),
            'normal_balance'=>sanitize_text_field($p['normal_balance'] ?? 'debit'),
            'status'=>sanitize_text_field($p['status'] ?? 'active')
        ], 'account', 'Chart account created');
    }

    public function create_journals($request) {
        global $wpdb;
        $p=$request->get_json_params();
        $debit=floatval($p['debit'] ?? 0);
        $credit=floatval($p['credit'] ?? 0);
        $result = $this->insert('acct_journals', [
            'journal_no'=>sanitize_text_field($p['journal_no'] ?? 'J-'.time()),
            'memo'=>sanitize_text_field($p['memo'] ?? ''),
            'journal_date'=>sanitize_text_field($p['journal_date'] ?? date('Y-m-d')),
            'status'=>sanitize_text_field($p['status'] ?? 'posted'),
            'total_debit'=>$debit,
            'total_credit'=>$credit
        ], 'journal', 'Journal created');

        if (!empty($p['account_id'])) {
            $wpdb->insert($wpdb->prefix.'ccjv_acct_journal_lines', [
                'tenant_id'=>1,
                'journal_id'=>$result['id'],
                'account_id'=>absint($p['account_id']),
                'description'=>sanitize_text_field($p['memo'] ?? ''),
                'debit'=>$debit,
                'credit'=>$credit,
                'created_at'=>current_time('mysql')
            ]);
        }
        return $result;
    }

    public function create_invoices($request) {
        $p=$request->get_json_params();
        return $this->insert('acct_invoices', [
            'invoice_no'=>sanitize_text_field($p['invoice_no'] ?? 'INV-'.time()),
            'counterparty'=>sanitize_text_field($p['counterparty'] ?? 'Counterparty'),
            'invoice_type'=>sanitize_text_field($p['invoice_type'] ?? 'ar'),
            'issue_date'=>sanitize_text_field($p['issue_date'] ?? date('Y-m-d')),
            'due_date'=>sanitize_text_field($p['due_date'] ?? ''),
            'amount'=>floatval($p['amount'] ?? 0),
            'paid_amount'=>floatval($p['paid_amount'] ?? 0),
            'status'=>sanitize_text_field($p['status'] ?? 'open')
        ], 'invoice', 'Invoice created');
    }

    public function create_payments($request) {
        $p=$request->get_json_params();
        return $this->insert('acct_payments', [
            'invoice_id'=>absint($p['invoice_id'] ?? 0),
            'payment_ref'=>sanitize_text_field($p['payment_ref'] ?? 'PAY-'.time()),
            'payment_date'=>sanitize_text_field($p['payment_date'] ?? date('Y-m-d')),
            'amount'=>floatval($p['amount'] ?? 0),
            'method'=>sanitize_text_field($p['method'] ?? 'token'),
            'status'=>sanitize_text_field($p['status'] ?? 'pending'),
            'tx_hash'=>sanitize_text_field($p['tx_hash'] ?? '')
        ], 'payment', 'Payment created');
    }

    public function create_reconciliations($request) {
        $p=$request->get_json_params();
        $book=floatval($p['book_balance'] ?? 0); $statement=floatval($p['statement_balance'] ?? 0);
        return $this->insert('acct_reconciliations', [
            'reconciliation_no'=>sanitize_text_field($p['reconciliation_no'] ?? 'REC-'.time()),
            'account_id'=>absint($p['account_id'] ?? 0),
            'statement_date'=>sanitize_text_field($p['statement_date'] ?? date('Y-m-d')),
            'statement_balance'=>$statement,
            'book_balance'=>$book,
            'variance'=>$statement - $book,
            'status'=>sanitize_text_field($p['status'] ?? (($statement-$book)==0 ? 'balanced' : 'variance'))
        ], 'reconciliation', 'Reconciliation created');
    }

    public function create_reports($request) {
        $p=$request->get_json_params();
        return $this->insert('acct_reports', [
            'report_type'=>sanitize_text_field($p['report_type'] ?? 'balance_sheet'),
            'period_start'=>sanitize_text_field($p['period_start'] ?? ''),
            'period_end'=>sanitize_text_field($p['period_end'] ?? ''),
            'payload'=>wp_json_encode($this->generate_report_payload($p['report_type'] ?? 'balance_sheet'))
        ], 'report', 'Report generated');
    }

    private function list_table($table) {
        global $wpdb;
        return $wpdb->get_results("SELECT * FROM {$wpdb->prefix}ccjv_{$table} ORDER BY id DESC LIMIT 150", ARRAY_A);
    }

    public function list_accounts(){ return $this->list_table('acct_accounts'); }
    public function list_journals(){ return $this->list_table('acct_journals'); }
    public function list_invoices(){ return $this->list_table('acct_invoices'); }
    public function list_payments(){ return $this->list_table('acct_payments'); }
    public function list_reconciliations(){ return $this->list_table('acct_reconciliations'); }
    public function list_reports(){ return $this->list_table('acct_reports'); }

    public function ledger() {
        global $wpdb;
        return $wpdb->get_results("SELECT j.journal_no,j.memo,j.journal_date,j.status,l.description,l.debit,l.credit,a.account_code,a.account_name FROM {$wpdb->prefix}ccjv_acct_journal_lines l LEFT JOIN {$wpdb->prefix}ccjv_acct_journals j ON j.id=l.journal_id LEFT JOIN {$wpdb->prefix}ccjv_acct_accounts a ON a.id=l.account_id ORDER BY l.id DESC LIMIT 150", ARRAY_A);
    }

    public function aging() {
        global $wpdb;
        $rows = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}ccjv_acct_invoices WHERE status='open' ORDER BY due_date ASC", ARRAY_A);
        $buckets = ['current'=>0,'1_30'=>0,'31_60'=>0,'61_90'=>0,'90_plus'=>0];
        foreach ($rows as $r) {
            $days = !empty($r['due_date']) ? floor((time() - strtotime($r['due_date'])) / 86400) : 0;
            $open = floatval($r['amount']) - floatval($r['paid_amount']);
            if ($days <= 0) $buckets['current'] += $open;
            elif ($days <= 30) $buckets['1_30'] += $open;
            elif ($days <= 60) $buckets['31_60'] += $open;
            elif ($days <= 90) $buckets['61_90'] += $open;
            else $buckets['90_plus'] += $open;
        }
        return $buckets;
    }

    public function kpis() {
        global $wpdb;
        $invoice_total = floatval($wpdb->get_var("SELECT COALESCE(SUM(amount),0) FROM {$wpdb->prefix}ccjv_acct_invoices"));
        $paid_total = floatval($wpdb->get_var("SELECT COALESCE(SUM(paid_amount),0) FROM {$wpdb->prefix}ccjv_acct_invoices"));
        $payments = floatval($wpdb->get_var("SELECT COALESCE(SUM(amount),0) FROM {$wpdb->prefix}ccjv_acct_payments"));
        $variance = floatval($wpdb->get_var("SELECT COALESCE(SUM(ABS(variance)),0) FROM {$wpdb->prefix}ccjv_acct_reconciliations"));
        return ['invoice_total'=>$invoice_total,'paid_total'=>$paid_total,'open_total'=>$invoice_total-$paid_total,'payments'=>$payments,'reconciliation_variance'=>$variance];
    }

    private function generate_report_payload($type) {
        return ['type'=>$type,'generated_at'=>current_time('mysql'),'source'=>'ccjv-accounting-runtime'];
    }
}
