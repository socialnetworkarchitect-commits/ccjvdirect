<?php
if (!defined('ABSPATH')) exit;

class CCJV_Final_Admin_Runtime {
    public static function install() {
        global $wpdb;
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        $charset = $wpdb->get_charset_collate();
        $p = $wpdb->prefix . 'ccjv_';

        dbDelta("CREATE TABLE {$p}tenant_settings (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            tenant_id BIGINT UNSIGNED NOT NULL DEFAULT 1,
            setting_key VARCHAR(120) NOT NULL,
            setting_value LONGTEXT NULL,
            updated_by BIGINT UNSIGNED NULL,
            updated_at DATETIME NOT NULL,
            PRIMARY KEY (id),
            UNIQUE KEY tenant_key (tenant_id,setting_key)
        ) $charset;");

        dbDelta("CREATE TABLE {$p}rbac_roles (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            tenant_id BIGINT UNSIGNED NOT NULL DEFAULT 1,
            role_key VARCHAR(120) NOT NULL,
            role_name VARCHAR(190) NOT NULL,
            description LONGTEXT NULL,
            status VARCHAR(80) NOT NULL DEFAULT 'active',
            created_at DATETIME NOT NULL,
            updated_at DATETIME NULL,
            PRIMARY KEY (id),
            UNIQUE KEY tenant_role (tenant_id,role_key)
        ) $charset;");

        dbDelta("CREATE TABLE {$p}rbac_permissions (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            tenant_id BIGINT UNSIGNED NOT NULL DEFAULT 1,
            role_key VARCHAR(120) NOT NULL,
            module_key VARCHAR(80) NOT NULL,
            permission_key VARCHAR(120) NOT NULL,
            allowed TINYINT(1) NOT NULL DEFAULT 0,
            created_at DATETIME NOT NULL,
            updated_at DATETIME NULL,
            PRIMARY KEY (id),
            UNIQUE KEY role_module_permission (tenant_id,role_key,module_key,permission_key)
        ) $charset;");

        dbDelta("CREATE TABLE {$p}module_pricing (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            tenant_id BIGINT UNSIGNED NOT NULL DEFAULT 1,
            module_key VARCHAR(80) NOT NULL,
            token_symbol VARCHAR(40) NOT NULL DEFAULT 'CCJV',
            monthly_fee DECIMAL(36,18) NOT NULL DEFAULT 0,
            upload_reward DECIMAL(36,18) NOT NULL DEFAULT 0,
            view_fee DECIMAL(36,18) NOT NULL DEFAULT 0,
            download_fee DECIMAL(36,18) NOT NULL DEFAULT 0,
            status VARCHAR(80) NOT NULL DEFAULT 'active',
            updated_at DATETIME NOT NULL,
            PRIMARY KEY (id),
            UNIQUE KEY tenant_module (tenant_id,module_key)
        ) $charset;");

        dbDelta("CREATE TABLE {$p}proof_explorer (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            tenant_id BIGINT UNSIGNED NOT NULL DEFAULT 1,
            source_module VARCHAR(80) NOT NULL,
            source_record_id BIGINT UNSIGNED NULL,
            vault_hash VARCHAR(128) NOT NULL,
            avalanche_tx_hash VARCHAR(190) NULL,
            anchor_status VARCHAR(80) NOT NULL DEFAULT 'pending',
            replay_id VARCHAR(128) NULL,
            proof_payload LONGTEXT NULL,
            created_at DATETIME NOT NULL,
            updated_at DATETIME NULL,
            PRIMARY KEY (id),
            KEY vault_hash (vault_hash),
            KEY anchor_status (anchor_status)
        ) $charset;");

        self::seed_defaults();
    }

    public static function seed_defaults() {
        global $wpdb;
        $p = $wpdb->prefix . 'ccjv_';

        $roles = [
            'super_admin' => 'Super Admin',
            'tenant_admin' => 'Tenant Admin',
            'module_manager' => 'Module Manager',
            'finance_operator' => 'Finance Operator',
            'field_operator' => 'Field Operator',
            'viewer' => 'Viewer'
        ];

        foreach ($roles as $key => $name) {
            $exists = $wpdb->get_var($wpdb->prepare("SELECT id FROM {$p}rbac_roles WHERE tenant_id=1 AND role_key=%s", $key));
            if (!$exists) {
                $wpdb->insert($p.'rbac_roles', [
                    'tenant_id'=>1,
                    'role_key'=>$key,
                    'role_name'=>$name,
                    'description'=>$name . ' runtime role',
                    'status'=>'active',
                    'created_at'=>current_time('mysql'),
                    'updated_at'=>current_time('mysql')
                ]);
            }
        }

        if (class_exists('CCJV_Core_Modules')) {
            foreach (CCJV_Core_Modules::all() as $module_key => $module) {
                $exists = $wpdb->get_var($wpdb->prepare("SELECT id FROM {$p}module_pricing WHERE tenant_id=1 AND module_key=%s", $module_key));
                if (!$exists) {
                    $wpdb->insert($p.'module_pricing', [
                        'tenant_id'=>1,
                        'module_key'=>$module_key,
                        'token_symbol'=>get_option('ccjv_core_token_symbol','CCJV'),
                        'monthly_fee'=>$module['fee'],
                        'upload_reward'=>0,
                        'view_fee'=>0,
                        'download_fee'=>0,
                        'status'=>'active',
                        'updated_at'=>current_time('mysql')
                    ]);
                }

                foreach ($roles as $role_key => $role_name) {
                    foreach (['view','create','edit','approve','export','admin'] as $perm) {
                        $exists = $wpdb->get_var($wpdb->prepare(
                            "SELECT id FROM {$p}rbac_permissions WHERE tenant_id=1 AND role_key=%s AND module_key=%s AND permission_key=%s",
                            $role_key, $module_key, $perm
                        ));
                        if (!$exists) {
                            $allowed = in_array($role_key, ['super_admin','tenant_admin']) ? 1 : ($perm === 'view' ? 1 : 0);
                            $wpdb->insert($p.'rbac_permissions', [
                                'tenant_id'=>1,
                                'role_key'=>$role_key,
                                'module_key'=>$module_key,
                                'permission_key'=>$perm,
                                'allowed'=>$allowed,
                                'created_at'=>current_time('mysql'),
                                'updated_at'=>current_time('mysql')
                            ]);
                        }
                    }
                }
            }
        }
    }

    public static function upsert_setting($key, $value) {
        global $wpdb;
        $p = $wpdb->prefix . 'ccjv_';
        $exists = $wpdb->get_var($wpdb->prepare("SELECT id FROM {$p}tenant_settings WHERE tenant_id=1 AND setting_key=%s", $key));
        $row = [
            'tenant_id'=>1,
            'setting_key'=>sanitize_key($key),
            'setting_value'=>wp_json_encode($value),
            'updated_by'=>get_current_user_id(),
            'updated_at'=>current_time('mysql')
        ];
        if ($exists) {
            $wpdb->update($p.'tenant_settings', $row, ['id'=>$exists]);
            return $exists;
        }
        $wpdb->insert($p.'tenant_settings', $row);
        return $wpdb->insert_id;
    }

    public static function record_proof($module, $record_id, $vault_hash, $replay_id = '', $payload = []) {
        global $wpdb;
        $wpdb->insert($wpdb->prefix . 'ccjv_proof_explorer', [
            'tenant_id'=>1,
            'source_module'=>sanitize_key($module),
            'source_record_id'=>absint($record_id),
            'vault_hash'=>sanitize_text_field($vault_hash),
            'anchor_status'=>'pending',
            'replay_id'=>sanitize_text_field($replay_id),
            'proof_payload'=>wp_json_encode($payload),
            'created_at'=>current_time('mysql'),
            'updated_at'=>current_time('mysql')
        ]);
        return $wpdb->insert_id;
    }
}
