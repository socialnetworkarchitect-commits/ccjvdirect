<?php
if (!defined('ABSPATH')) exit;

class CCJV_Final_Admin_REST {
    public function __construct() {
        add_action('rest_api_init', [$this,'routes']);
    }

    public function routes() {
        $routes = [
            '/admin/tenant-settings' => ['GET'=>'tenant_settings','POST'=>'save_tenant_setting'],
            '/admin/rbac/roles' => ['GET'=>'roles','POST'=>'save_role'],
            '/admin/rbac/permissions' => ['GET'=>'permissions','POST'=>'save_permission'],
            '/admin/module-pricing' => ['GET'=>'pricing','POST'=>'save_pricing'],
            '/admin/audit-replay' => ['GET'=>'audit_replay'],
            '/admin/proofs' => ['GET'=>'proofs','POST'=>'save_proof'],
            '/admin/module-deepening-summary' => ['GET'=>'deepening_summary']
        ];

        foreach ($routes as $path => $handlers) {
            foreach ($handlers as $method => $handler) {
                register_rest_route('ccjv-core/v1', $path, [
                    'methods'=>$method,
                    'callback'=>[$this,$handler],
                    'permission_callback'=>function(){ return current_user_can('manage_options') || is_user_logged_in(); }
                ]);
            }
        }
    }

    public function tenant_settings() {
        global $wpdb;
        return $wpdb->get_results("SELECT * FROM {$wpdb->prefix}ccjv_tenant_settings ORDER BY setting_key ASC", ARRAY_A);
    }

    public function save_tenant_setting($request) {
        $p = $request->get_json_params();
        $id = CCJV_Final_Admin_Runtime::upsert_setting($p['setting_key'] ?? 'general', $p['setting_value'] ?? []);
        $replay = CCJV_Core_Runtime_Client::emit_event('admin','tenant.setting.saved',$id,$p);
        return ['ok'=>true,'id'=>$id,'replay_id'=>$replay];
    }

    public function roles() {
        global $wpdb;
        return $wpdb->get_results("SELECT * FROM {$wpdb->prefix}ccjv_rbac_roles ORDER BY role_name ASC", ARRAY_A);
    }

    public function save_role($request) {
        global $wpdb;
        $p = $request->get_json_params();
        $wpdb->insert($wpdb->prefix.'ccjv_rbac_roles', [
            'tenant_id'=>1,
            'role_key'=>sanitize_key($p['role_key'] ?? 'custom_role'),
            'role_name'=>sanitize_text_field($p['role_name'] ?? 'Custom Role'),
            'description'=>sanitize_textarea_field($p['description'] ?? ''),
            'status'=>sanitize_text_field($p['status'] ?? 'active'),
            'created_at'=>current_time('mysql'),
            'updated_at'=>current_time('mysql')
        ]);
        $id = $wpdb->insert_id;
        $replay = CCJV_Core_Runtime_Client::emit_event('admin','rbac.role.created',$id,$p);
        return ['ok'=>true,'id'=>$id,'replay_id'=>$replay];
    }

    public function permissions() {
        global $wpdb;
        return $wpdb->get_results("SELECT * FROM {$wpdb->prefix}ccjv_rbac_permissions ORDER BY role_key ASC, module_key ASC, permission_key ASC", ARRAY_A);
    }

    public function save_permission($request) {
        global $wpdb;
        $p = $request->get_json_params();
        $row = [
            'tenant_id'=>1,
            'role_key'=>sanitize_key($p['role_key'] ?? 'viewer'),
            'module_key'=>sanitize_key($p['module_key'] ?? 'crm'),
            'permission_key'=>sanitize_key($p['permission_key'] ?? 'view'),
            'allowed'=>!empty($p['allowed']) ? 1 : 0,
            'created_at'=>current_time('mysql'),
            'updated_at'=>current_time('mysql')
        ];
        $existing = $wpdb->get_var($wpdb->prepare(
            "SELECT id FROM {$wpdb->prefix}ccjv_rbac_permissions WHERE tenant_id=1 AND role_key=%s AND module_key=%s AND permission_key=%s",
            $row['role_key'],$row['module_key'],$row['permission_key']
        ));
        if ($existing) {
            $wpdb->update($wpdb->prefix.'ccjv_rbac_permissions', $row, ['id'=>$existing]);
            $id = $existing;
        } else {
            $wpdb->insert($wpdb->prefix.'ccjv_rbac_permissions', $row);
            $id = $wpdb->insert_id;
        }
        $replay = CCJV_Core_Runtime_Client::emit_event('admin','rbac.permission.saved',$id,$row);
        return ['ok'=>true,'id'=>$id,'replay_id'=>$replay];
    }

    public function pricing() {
        global $wpdb;
        return $wpdb->get_results("SELECT * FROM {$wpdb->prefix}ccjv_module_pricing ORDER BY module_key ASC", ARRAY_A);
    }

    public function save_pricing($request) {
        global $wpdb;
        $p = $request->get_json_params();
        $row = [
            'tenant_id'=>1,
            'module_key'=>sanitize_key($p['module_key'] ?? 'crm'),
            'token_symbol'=>sanitize_text_field($p['token_symbol'] ?? get_option('ccjv_core_token_symbol','CCJV')),
            'monthly_fee'=>floatval($p['monthly_fee'] ?? 0),
            'upload_reward'=>floatval($p['upload_reward'] ?? 0),
            'view_fee'=>floatval($p['view_fee'] ?? 0),
            'download_fee'=>floatval($p['download_fee'] ?? 0),
            'status'=>sanitize_text_field($p['status'] ?? 'active'),
            'updated_at'=>current_time('mysql')
        ];
        $existing = $wpdb->get_var($wpdb->prepare("SELECT id FROM {$wpdb->prefix}ccjv_module_pricing WHERE tenant_id=1 AND module_key=%s", $row['module_key']));
        if ($existing) {
            $wpdb->update($wpdb->prefix.'ccjv_module_pricing', $row, ['id'=>$existing]);
            $id = $existing;
        } else {
            $wpdb->insert($wpdb->prefix.'ccjv_module_pricing', $row);
            $id = $wpdb->insert_id;
        }
        $replay = CCJV_Core_Runtime_Client::emit_event('admin','module.pricing.saved',$id,$row);
        return ['ok'=>true,'id'=>$id,'replay_id'=>$replay];
    }

    public function audit_replay() {
        global $wpdb;
        $p = $wpdb->prefix . 'ccjv_';
        $events = $wpdb->get_results("SELECT id, module, event_type, record_id, correlation_id, created_at FROM {$p}events ORDER BY id DESC LIMIT 200", ARRAY_A);
        $bridge = $wpdb->get_results("SELECT id, event_type, source_module, status, correlation_id, created_at FROM {$p}runtime_bridge_events ORDER BY id DESC LIMIT 100", ARRAY_A);
        return ['events'=>$events, 'bridge'=>$bridge];
    }

    public function proofs() {
        global $wpdb;
        return $wpdb->get_results("SELECT * FROM {$wpdb->prefix}ccjv_proof_explorer ORDER BY id DESC LIMIT 200", ARRAY_A);
    }

    public function save_proof($request) {
        $p = $request->get_json_params();
        $id = CCJV_Final_Admin_Runtime::record_proof(
            $p['source_module'] ?? 'vault',
            $p['source_record_id'] ?? 0,
            $p['vault_hash'] ?? hash('sha256', wp_json_encode($p)),
            $p['replay_id'] ?? '',
            $p
        );
        $replay = CCJV_Core_Runtime_Client::emit_event('proof','proof.recorded',$id,$p);
        return ['ok'=>true,'id'=>$id,'replay_id'=>$replay];
    }

    public function deepening_summary() {
        return [
            'crm'=>['pipeline','activity timeline','account overview','forecasting','relationship graph foundation'],
            'hrm'=>['readiness','certifications','schedule','org chart','training workflows'],
            'accounting'=>['chart','ledger','AP/AR','payments','reconciliation','reports','treasury cockpit'],
            'projects'=>['kanban','gantt','dependency graph','workload','approvals','documents'],
            'asset_iot'=>['map overlay','maintenance','inspections','digital twins','telemetry','alerts'],
            'procurement_governance'=>['RFQs','bid comparison','PO lifecycle','proposal explorer','votes','quorum'],
            'platform'=>['cockpit','global search','token entitlements','runtime bridge','admin controls','audit/proof explorer']
        ];
    }
}
