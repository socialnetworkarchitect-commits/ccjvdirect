<?php
if (!defined('ABSPATH')) exit;

class CCJV_Asset_IoT_REST {
    public function __construct() { add_action('rest_api_init', [$this,'routes']); }

    public function routes() {
        foreach (['assets','maintenance','inspections','twins','sensors','telemetry','alerts'] as $entity) {
            register_rest_route('ccjv-core/v1', '/asset-iot/' . $entity, [
                'methods'=>'GET','callback'=>[$this,'list_'.$entity],
                'permission_callback'=>function(){ return is_user_logged_in(); }
            ]);
            register_rest_route('ccjv-core/v1', '/asset-iot/' . $entity, [
                'methods'=>'POST','callback'=>[$this,'create_'.$entity],
                'permission_callback'=>function(){ return is_user_logged_in(); }
            ]);
        }
        register_rest_route('ccjv-core/v1', '/asset-iot/map', ['methods'=>'GET','callback'=>[$this,'map'],'permission_callback'=>function(){ return is_user_logged_in(); }]);
        register_rest_route('ccjv-core/v1', '/asset-iot/dashboard', ['methods'=>'GET','callback'=>[$this,'dashboard'],'permission_callback'=>function(){ return is_user_logged_in(); }]);
    }

    private function insert($table, $data, $module, $entity_type, $label) {
        global $wpdb;
        $data['tenant_id'] = 1;
        $data['vault_hash'] = CCJV_Asset_IoT_Depth::hash_payload($data);
        $data['created_at'] = current_time('mysql');
        if ($table !== 'iot_telemetry') $data['updated_at'] = current_time('mysql');
        $wpdb->insert($wpdb->prefix.'ccjv_'.$table, $data);
        $id = $wpdb->insert_id;
        $replay = CCJV_Asset_IoT_Depth::emit($module, $entity_type, $id, $entity_type.'.created', $label, $data);
        $updates = ['replay_id'=>$replay];
        if (in_array($table, ['asset_registry','asset_maintenance'])) $updates['treasury_ref'] = 'asset-module-fee';
        $wpdb->update($wpdb->prefix.'ccjv_'.$table, $updates, ['id'=>$id]);
        return ['ok'=>true,'id'=>$id,'vault_hash'=>$data['vault_hash'],'replay_id'=>$replay,'treasury_ref'=>$updates['treasury_ref'] ?? null];
    }

    public function create_assets($request) {
        $p=$request->get_json_params();
        return $this->insert('asset_registry', [
            'asset_code'=>sanitize_text_field($p['asset_code'] ?? 'A-'.time()),
            'asset_name'=>sanitize_text_field($p['asset_name'] ?? 'New Asset'),
            'asset_type'=>sanitize_text_field($p['asset_type'] ?? 'equipment'),
            'lifecycle_status'=>sanitize_text_field($p['lifecycle_status'] ?? 'active'),
            'latitude'=>floatval($p['latitude'] ?? 0),
            'longitude'=>floatval($p['longitude'] ?? 0),
            'location_label'=>sanitize_text_field($p['location_label'] ?? ''),
            'health_score'=>absint($p['health_score'] ?? 80)
        ], 'assets', 'asset', 'Asset registered');
    }

    public function create_maintenance($request) {
        $p=$request->get_json_params();
        return $this->insert('asset_maintenance', [
            'asset_id'=>absint($p['asset_id'] ?? 0),
            'work_order'=>sanitize_text_field($p['work_order'] ?? 'WO-'.time()),
            'maintenance_type'=>sanitize_text_field($p['maintenance_type'] ?? 'preventive'),
            'priority'=>sanitize_text_field($p['priority'] ?? 'normal'),
            'status'=>sanitize_text_field($p['status'] ?? 'open'),
            'scheduled_at'=>sanitize_text_field($p['scheduled_at'] ?? ''),
            'notes'=>sanitize_textarea_field($p['notes'] ?? '')
        ], 'assets', 'maintenance', 'Maintenance created');
    }

    public function create_inspections($request) {
        $p=$request->get_json_params();
        return $this->insert('asset_inspections', [
            'asset_id'=>absint($p['asset_id'] ?? 0),
            'inspection_type'=>sanitize_text_field($p['inspection_type'] ?? 'routine'),
            'result'=>sanitize_text_field($p['result'] ?? 'pass'),
            'inspector_id'=>get_current_user_id(),
            'inspected_at'=>sanitize_text_field($p['inspected_at'] ?? current_time('mysql')),
            'findings'=>sanitize_textarea_field($p['findings'] ?? '')
        ], 'assets', 'inspection', 'Inspection created');
    }

    public function create_twins($request) {
        $p=$request->get_json_params();
        return $this->insert('asset_twins', [
            'asset_id'=>absint($p['asset_id'] ?? 0),
            'twin_state'=>wp_json_encode($p['twin_state'] ?? ['state'=>'nominal']),
            'model_ref'=>sanitize_text_field($p['model_ref'] ?? ''),
            'telemetry_ref'=>sanitize_text_field($p['telemetry_ref'] ?? ''),
            'status'=>sanitize_text_field($p['status'] ?? 'active')
        ], 'assets', 'digital_twin', 'Digital twin created');
    }

    public function create_sensors($request) {
        $p=$request->get_json_params();
        return $this->insert('iot_sensors', [
            'asset_id'=>absint($p['asset_id'] ?? 0),
            'sensor_code'=>sanitize_text_field($p['sensor_code'] ?? 'S-'.time()),
            'sensor_name'=>sanitize_text_field($p['sensor_name'] ?? 'Sensor'),
            'sensor_type'=>sanitize_text_field($p['sensor_type'] ?? 'telemetry'),
            'unit'=>sanitize_text_field($p['unit'] ?? ''),
            'status'=>sanitize_text_field($p['status'] ?? 'active')
        ], 'iot', 'sensor', 'Sensor registered');
    }

    public function create_telemetry($request) {
        global $wpdb;
        $p=$request->get_json_params();
        $value = floatval($p['value'] ?? 0);
        $status = $value > floatval($p['threshold'] ?? 999999) ? 'anomaly' : 'normal';
        $result = $this->insert('iot_telemetry', [
            'sensor_id'=>absint($p['sensor_id'] ?? 0),
            'asset_id'=>absint($p['asset_id'] ?? 0),
            'metric'=>sanitize_text_field($p['metric'] ?? 'metric'),
            'value'=>$value,
            'unit'=>sanitize_text_field($p['unit'] ?? ''),
            'captured_at'=>sanitize_text_field($p['captured_at'] ?? current_time('mysql')),
            'anomaly_score'=>floatval($p['anomaly_score'] ?? ($status === 'anomaly' ? 1 : 0)),
            'status'=>$status
        ], 'iot', 'telemetry', 'Telemetry captured');

        if ($status === 'anomaly') {
            $this->insert('iot_alerts', [
                'asset_id'=>absint($p['asset_id'] ?? 0),
                'sensor_id'=>absint($p['sensor_id'] ?? 0),
                'alert_type'=>'threshold',
                'severity'=>'high',
                'message'=>'Telemetry threshold anomaly: '.sanitize_text_field($p['metric'] ?? 'metric'),
                'status'=>'open'
            ], 'iot', 'alert', 'Telemetry anomaly alert');
        }
        return $result;
    }

    public function create_alerts($request) {
        $p=$request->get_json_params();
        return $this->insert('iot_alerts', [
            'asset_id'=>absint($p['asset_id'] ?? 0),
            'sensor_id'=>absint($p['sensor_id'] ?? 0),
            'alert_type'=>sanitize_text_field($p['alert_type'] ?? 'anomaly'),
            'severity'=>sanitize_text_field($p['severity'] ?? 'medium'),
            'message'=>sanitize_text_field($p['message'] ?? 'Alert'),
            'status'=>sanitize_text_field($p['status'] ?? 'open')
        ], 'iot', 'alert', 'Alert created');
    }

    private function list_table($table) {
        global $wpdb;
        return $wpdb->get_results("SELECT * FROM {$wpdb->prefix}ccjv_{$table} ORDER BY id DESC LIMIT 200", ARRAY_A);
    }
    public function list_assets(){ return $this->list_table('asset_registry'); }
    public function list_maintenance(){ return $this->list_table('asset_maintenance'); }
    public function list_inspections(){ return $this->list_table('asset_inspections'); }
    public function list_twins(){ return $this->list_table('asset_twins'); }
    public function list_sensors(){ return $this->list_table('iot_sensors'); }
    public function list_telemetry(){ return $this->list_table('iot_telemetry'); }
    public function list_alerts(){ return $this->list_table('iot_alerts'); }

    public function map() { return $this->list_assets(); }

    public function dashboard() {
        global $wpdb;
        return [
            'assets'=>intval($wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}ccjv_asset_registry")),
            'avg_health'=>round(floatval($wpdb->get_var("SELECT COALESCE(AVG(health_score),0) FROM {$wpdb->prefix}ccjv_asset_registry"))),
            'open_maintenance'=>intval($wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}ccjv_asset_maintenance WHERE status='open'")),
            'sensors'=>intval($wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}ccjv_iot_sensors")),
            'telemetry'=>intval($wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}ccjv_iot_telemetry")),
            'open_alerts'=>intval($wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}ccjv_iot_alerts WHERE status='open'"))
        ];
    }
}
