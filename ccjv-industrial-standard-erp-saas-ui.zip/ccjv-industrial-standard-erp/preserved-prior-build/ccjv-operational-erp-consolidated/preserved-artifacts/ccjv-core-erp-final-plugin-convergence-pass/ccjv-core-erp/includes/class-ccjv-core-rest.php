<?php
if (!defined('ABSPATH')) exit;
class CCJV_Core_REST {
    public function __construct() { add_action('rest_api_init', [$this,'routes']); }
    public function routes() {
        register_rest_route('ccjv-core/v1','/records',['methods'=>'POST','callback'=>[$this,'create_record'],'permission_callback'=>function(){return is_user_logged_in();}]);
        register_rest_route('ccjv-core/v1','/records/(?P<module>[a-z0-9_-]+)',['methods'=>'GET','callback'=>[$this,'records'],'permission_callback'=>function(){return is_user_logged_in();}]);
        register_rest_route('ccjv-core/v1','/events',['methods'=>'GET','callback'=>[$this,'events'],'permission_callback'=>function(){return is_user_logged_in();}]);
    }
    public function create_record($request) {
        global $wpdb; $params = $request->get_json_params();
        $module = sanitize_key($params['module'] ?? 'crm');
        $title = sanitize_text_field($params['title'] ?? 'Untitled');
        $status = sanitize_text_field($params['status'] ?? 'active');
        $payload = $params['payload'] ?? [];
        $hash = hash('sha256', wp_json_encode($payload).$title.time());
        $wpdb->insert($wpdb->prefix.'ccjv_records', ['tenant_id'=>1,'module'=>$module,'title'=>$title,'status'=>$status,'payload'=>wp_json_encode($payload),'vault_hash'=>$hash,'created_by'=>get_current_user_id(),'created_at'=>current_time('mysql'),'updated_at'=>current_time('mysql')]);
        $record_id = $wpdb->insert_id;
        $correlation = CCJV_Core_Runtime_Client::emit_event($module,'record.created',$record_id,['title'=>$title,'status'=>$status,'vault_hash'=>$hash]);
        $wpdb->update($wpdb->prefix.'ccjv_records', ['replay_id'=>$correlation,'treasury_ref'=>'module-fee:'.$module], ['id'=>$record_id]);
        return ['ok'=>true,'record_id'=>$record_id,'vault_hash'=>$hash,'replay_id'=>$correlation,'treasury_ref'=>'module-fee:'.$module];
    }
    public function records($request) {
        global $wpdb; $module = sanitize_key($request['module']);
        return $wpdb->get_results($wpdb->prepare("SELECT * FROM {$wpdb->prefix}ccjv_records WHERE module=%s ORDER BY id DESC LIMIT 50", $module), ARRAY_A);
    }
    public function events() {
        global $wpdb; return $wpdb->get_results("SELECT * FROM {$wpdb->prefix}ccjv_events ORDER BY id DESC LIMIT 50", ARRAY_A);
    }
}
