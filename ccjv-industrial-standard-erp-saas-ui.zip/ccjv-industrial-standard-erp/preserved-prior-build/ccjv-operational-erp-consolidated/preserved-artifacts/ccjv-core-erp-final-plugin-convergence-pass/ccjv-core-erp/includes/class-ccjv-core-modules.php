<?php
if (!defined('ABSPATH')) exit;
class CCJV_Core_Modules {
    public static function all() {
        return [
            'crm' => ['label'=>'CRM','icon'=>'👥','fee'=>'25.00','desc'=>'Organizations, contacts, pipelines, opportunities, activities.'],
            'hrm' => ['label'=>'HRM','icon'=>'🧑‍🏭','fee'=>'25.00','desc'=>'Employees, roles, certifications, readiness, schedules.'],
            'accounting' => ['label'=>'Accounting','icon'=>'📘','fee'=>'35.00','desc'=>'Chart, ledger, AP/AR, invoices, reconciliation, reports.'],
            'projects' => ['label'=>'Projects','icon'=>'📋','fee'=>'30.00','desc'=>'Projects, milestones, tasks, dependencies, kanban, gantt.'],
            'assets' => ['label'=>'Assets','icon'=>'🏗️','fee'=>'30.00','desc'=>'Asset registry, fleet, containers, maintenance, digital twins.'],
            'iot' => ['label'=>'IoT','icon'=>'📡','fee'=>'35.00','desc'=>'Sensors, telemetry streams, events, anomalies, dashboards.'],
            'procurement' => ['label'=>'Procurement','icon'=>'🧾','fee'=>'25.00','desc'=>'Vendors, RFQs, bids, POs, workflow approvals.'],
            'governance' => ['label'=>'Governance','icon'=>'⚖️','fee'=>'20.00','desc'=>'Proposals, ballots, votes, quorum, results.'],
            'vault' => ['label'=>'Vault','icon'=>'🗄️','fee'=>'15.00','desc'=>'Evidence, hashes, object records, Avalanche proof links.'],
            'replay' => ['label'=>'Replay','icon'=>'🔁','fee'=>'15.00','desc'=>'Events, correlation IDs, timelines, operational reconstruction.'],
            'treasury' => ['label'=>'Treasury','icon'=>'💠','fee'=>'20.00','desc'=>'Token access, module fees, settlement, reconciliation.'],
            'federation' => ['label'=>'Federation','icon'=>'🌐','fee'=>'20.00','desc'=>'ERP nodes, health, capabilities, sync, runtime topology.'],
        ];
    }
    public static function get($key) {
        $modules = self::all();
        return $modules[$key] ?? null;
    }
}
