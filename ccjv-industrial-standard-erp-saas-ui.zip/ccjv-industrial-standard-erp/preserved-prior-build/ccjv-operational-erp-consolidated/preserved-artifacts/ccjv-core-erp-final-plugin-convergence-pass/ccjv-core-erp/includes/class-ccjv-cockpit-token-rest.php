<?php
if (!defined('ABSPATH')) exit;

class CCJV_Cockpit_Token_REST {
    public function __construct() { add_action('rest_api_init', [$this,'routes']); }

    public function routes() {
        register_rest_route('ccjv-core/v1','/cockpit/summary',['methods'=>'GET','callback'=>[$this,'summary'],'permission_callback'=>function(){return is_user_logged_in();}]);
        register_rest_route('ccjv-core/v1','/cockpit/search',['methods'=>'GET','callback'=>[$this,'search'],'permission_callback'=>function(){return is_user_logged_in();}]);
        register_rest_route('ccjv-core/v1','/cockpit/notifications',['methods'=>'GET','callback'=>[$this,'notifications'],'permission_callback'=>function(){return is_user_logged_in();}]);
        register_rest_route('ccjv-core/v1','/token/entitlements',['methods'=>'GET','callback'=>[$this,'entitlements'],'permission_callback'=>function(){return is_user_logged_in();}]);
        register_rest_route('ccjv-core/v1','/token/check',['methods'=>'POST','callback'=>[$this,'token_check'],'permission_callback'=>function(){return is_user_logged_in();}]);
        register_rest_route('ccjv-core/v1','/runtime/bridge-events',['methods'=>'GET','callback'=>[$this,'bridge_events'],'permission_callback'=>function(){return is_user_logged_in();}]);
        register_rest_route('ccjv-core/v1','/runtime/bridge-events',['methods'=>'POST','callback'=>[$this,'create_bridge_event'],'permission_callback'=>function(){return is_user_logged_in();}]);
    }

    public function summary() {
        global $wpdb;
        $p = $wpdb->prefix . 'ccjv_';
        return [
            'modules'=>class_exists('CCJV_Core_Modules') ? count(CCJV_Core_Modules::all()) : 0,
            'records'=>intval($wpdb->get_var("SELECT COUNT(*) FROM {$p}records")),
            'events'=>intval($wpdb->get_var("SELECT COUNT(*) FROM {$p}events")),
            'bridge_events'=>intval($wpdb->get_var("SELECT COUNT(*) FROM {$p}runtime_bridge_events")),
            'entitlements'=>intval($wpdb->get_var("SELECT COUNT(*) FROM {$p}runtime_entitlements")),
            'runtime_api'=>get_option('ccjv_core_runtime_api',''),
            'runtime_ws'=>get_option('ccjv_core_runtime_ws','')
        ];
    }

    public function entitlements() {
        global $wpdb;
        return $wpdb->get_results("SELECT * FROM {$wpdb->prefix}ccjv_runtime_entitlements ORDER BY module_key ASC LIMIT 200", ARRAY_A);
    }

    public function bridge_events() {
        global $wpdb;
        return $wpdb->get_results("SELECT * FROM {$wpdb->prefix}ccjv_runtime_bridge_events ORDER BY id DESC LIMIT 100", ARRAY_A);
    }

    public function notifications() {
        global $wpdb;
        return $wpdb->get_results("SELECT * FROM {$wpdb->prefix}ccjv_cockpit_notifications ORDER BY id DESC LIMIT 100", ARRAY_A);
    }

    public function create_bridge_event($request) {
        $p = $request->get_json_params();
        $correlation = CCJV_Cockpit_Token_Runtime::emit_bridge_event(
            $p['event_type'] ?? 'manual.sync',
            $p['source_module'] ?? 'cockpit',
            $p['runtime_endpoint'] ?? '/runtime/sync',
            $p['payload'] ?? []
        );
        return ['ok'=>true,'correlation_id'=>$correlation];
    }

    public function token_check($request) {
        global $wpdb;
        $p = $request->get_json_params();
        $wallet = sanitize_text_field($p['wallet_address'] ?? '');
        $module = sanitize_key($p['module_key'] ?? 'crm');
        $hash = hash('sha256', wp_json_encode($p) . microtime(true));
        $status = $wallet ? 'ui_verified_pending_chain' : 'wallet_required';

        $wpdb->insert($wpdb->prefix.'ccjv_runtime_entitlements', [
            'tenant_id'=>1,
            'module_key'=>$module,
            'wallet_address'=>$wallet,
            'token_contract'=>get_option('ccjv_core_token_contract',''),
            'token_symbol'=>get_option('ccjv_core_token_symbol','CCJV'),
            'required_balance'=>floatval($p['required_balance'] ?? 1),
            'allowance_required'=>floatval($p['allowance_required'] ?? 0),
            'monthly_fee'=>floatval($p['monthly_fee'] ?? 0),
            'status'=>$status,
            'last_checked'=>current_time('mysql'),
            'vault_hash'=>$hash,
            'treasury_ref'=>'token-entitlement-'.$module,
            'created_at'=>current_time('mysql'),
            'updated_at'=>current_time('mysql')
        ]);
        $id = $wpdb->insert_id;
        $replay = CCJV_Core_Runtime_Client::emit_event('token','entitlement.checked',$id,['module'=>$module,'wallet'=>$wallet,'status'=>$status]);
        $wpdb->update($wpdb->prefix.'ccjv_runtime_entitlements', ['replay_id'=>$replay], ['id'=>$id]);
        return ['ok'=>true,'id'=>$id,'status'=>$status,'vault_hash'=>$hash,'replay_id'=>$replay];
    }

    public function search($request) {
        global $wpdb;
        $q = '%' . $wpdb->esc_like(sanitize_text_field($request->get_param('q') ?? '')) . '%';
        $p = $wpdb->prefix . 'ccjv_';
        $queries = [
            "SELECT id, module as type, title, status, created_at FROM {$p}records WHERE title LIKE %s LIMIT 20",
            "SELECT id, 'crm_account' as type, account_name as title, status, created_at FROM {$p}crm_accounts WHERE account_name LIKE %s LIMIT 20",
            "SELECT id, 'hrm_person' as type, full_name as title, employment_status as status, created_at FROM {$p}hrm_people WHERE full_name LIKE %s LIMIT 20",
            "SELECT id, 'project' as type, project_name as title, status, created_at FROM {$p}pm_projects WHERE project_name LIKE %s LIMIT 20",
            "SELECT id, 'asset' as type, asset_name as title, lifecycle_status as status, created_at FROM {$p}asset_registry WHERE asset_name LIKE %s LIMIT 20",
            "SELECT id, 'proposal' as type, title, status, created_at FROM {$p}governance_proposals WHERE title LIKE %s LIMIT 20"
        ];
        $out = [];
        foreach ($queries as $sql) {
            $rows = $wpdb->get_results($wpdb->prepare($sql, $q), ARRAY_A);
            if (is_array($rows)) $out = array_merge($out, $rows);
        }
        return array_slice($out, 0, 100);
    }
}
