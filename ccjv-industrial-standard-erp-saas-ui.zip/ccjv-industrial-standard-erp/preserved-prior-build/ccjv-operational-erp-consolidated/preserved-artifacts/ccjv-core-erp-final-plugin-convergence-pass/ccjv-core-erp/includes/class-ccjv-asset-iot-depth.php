<?php
if (!defined('ABSPATH')) exit;

class CCJV_Asset_IoT_Depth {
    public static function install() {
        global $wpdb;
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        $charset = $wpdb->get_charset_collate();
        $p = $wpdb->prefix . 'ccjv_';

        dbDelta("CREATE TABLE {$p}asset_registry (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            tenant_id BIGINT UNSIGNED NOT NULL DEFAULT 1,
            asset_code VARCHAR(120) NULL,
            asset_name VARCHAR(255) NOT NULL,
            asset_type VARCHAR(80) NOT NULL DEFAULT 'equipment',
            lifecycle_status VARCHAR(80) NOT NULL DEFAULT 'active',
            latitude DECIMAL(10,7) NULL,
            longitude DECIMAL(10,7) NULL,
            location_label VARCHAR(255) NULL,
            health_score INT NOT NULL DEFAULT 80,
            vault_hash VARCHAR(128) NULL,
            replay_id VARCHAR(128) NULL,
            treasury_ref VARCHAR(128) NULL,
            created_at DATETIME NOT NULL,
            updated_at DATETIME NULL,
            PRIMARY KEY (id),
            KEY tenant_type (tenant_id,asset_type),
            KEY status (lifecycle_status)
        ) $charset;");

        dbDelta("CREATE TABLE {$p}asset_maintenance (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            tenant_id BIGINT UNSIGNED NOT NULL DEFAULT 1,
            asset_id BIGINT UNSIGNED NOT NULL,
            work_order VARCHAR(120) NULL,
            maintenance_type VARCHAR(80) NOT NULL DEFAULT 'preventive',
            priority VARCHAR(40) NOT NULL DEFAULT 'normal',
            status VARCHAR(80) NOT NULL DEFAULT 'open',
            scheduled_at DATETIME NULL,
            completed_at DATETIME NULL,
            notes LONGTEXT NULL,
            vault_hash VARCHAR(128) NULL,
            replay_id VARCHAR(128) NULL,
            treasury_ref VARCHAR(128) NULL,
            created_at DATETIME NOT NULL,
            updated_at DATETIME NULL,
            PRIMARY KEY (id),
            KEY asset_status (asset_id,status)
        ) $charset;");

        dbDelta("CREATE TABLE {$p}asset_inspections (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            tenant_id BIGINT UNSIGNED NOT NULL DEFAULT 1,
            asset_id BIGINT UNSIGNED NOT NULL,
            inspection_type VARCHAR(120) NOT NULL DEFAULT 'routine',
            result VARCHAR(80) NOT NULL DEFAULT 'pass',
            inspector_id BIGINT UNSIGNED NULL,
            inspected_at DATETIME NULL,
            findings LONGTEXT NULL,
            vault_hash VARCHAR(128) NULL,
            replay_id VARCHAR(128) NULL,
            created_at DATETIME NOT NULL,
            updated_at DATETIME NULL,
            PRIMARY KEY (id),
            KEY asset_result (asset_id,result)
        ) $charset;");

        dbDelta("CREATE TABLE {$p}asset_twins (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            tenant_id BIGINT UNSIGNED NOT NULL DEFAULT 1,
            asset_id BIGINT UNSIGNED NOT NULL,
            twin_state LONGTEXT NULL,
            model_ref VARCHAR(255) NULL,
            telemetry_ref VARCHAR(255) NULL,
            status VARCHAR(80) NOT NULL DEFAULT 'active',
            vault_hash VARCHAR(128) NULL,
            replay_id VARCHAR(128) NULL,
            created_at DATETIME NOT NULL,
            updated_at DATETIME NULL,
            PRIMARY KEY (id),
            KEY asset_id (asset_id)
        ) $charset;");

        dbDelta("CREATE TABLE {$p}iot_sensors (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            tenant_id BIGINT UNSIGNED NOT NULL DEFAULT 1,
            asset_id BIGINT UNSIGNED NULL,
            sensor_code VARCHAR(120) NULL,
            sensor_name VARCHAR(255) NOT NULL,
            sensor_type VARCHAR(80) NOT NULL DEFAULT 'telemetry',
            unit VARCHAR(40) NULL,
            status VARCHAR(80) NOT NULL DEFAULT 'active',
            last_value DECIMAL(18,6) NULL,
            last_seen DATETIME NULL,
            vault_hash VARCHAR(128) NULL,
            replay_id VARCHAR(128) NULL,
            created_at DATETIME NOT NULL,
            updated_at DATETIME NULL,
            PRIMARY KEY (id),
            KEY asset_id (asset_id),
            KEY sensor_type (sensor_type)
        ) $charset;");

        dbDelta("CREATE TABLE {$p}iot_telemetry (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            tenant_id BIGINT UNSIGNED NOT NULL DEFAULT 1,
            sensor_id BIGINT UNSIGNED NOT NULL,
            asset_id BIGINT UNSIGNED NULL,
            metric VARCHAR(120) NOT NULL,
            value DECIMAL(18,6) NOT NULL DEFAULT 0,
            unit VARCHAR(40) NULL,
            captured_at DATETIME NOT NULL,
            anomaly_score DECIMAL(8,4) NOT NULL DEFAULT 0,
            status VARCHAR(80) NOT NULL DEFAULT 'normal',
            vault_hash VARCHAR(128) NULL,
            replay_id VARCHAR(128) NULL,
            created_at DATETIME NOT NULL,
            PRIMARY KEY (id),
            KEY sensor_time (sensor_id,captured_at),
            KEY status (status)
        ) $charset;");

        dbDelta("CREATE TABLE {$p}iot_alerts (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            tenant_id BIGINT UNSIGNED NOT NULL DEFAULT 1,
            asset_id BIGINT UNSIGNED NULL,
            sensor_id BIGINT UNSIGNED NULL,
            alert_type VARCHAR(120) NOT NULL DEFAULT 'anomaly',
            severity VARCHAR(40) NOT NULL DEFAULT 'medium',
            message VARCHAR(255) NOT NULL,
            status VARCHAR(80) NOT NULL DEFAULT 'open',
            vault_hash VARCHAR(128) NULL,
            replay_id VARCHAR(128) NULL,
            created_at DATETIME NOT NULL,
            updated_at DATETIME NULL,
            PRIMARY KEY (id),
            KEY status (status),
            KEY asset_id (asset_id)
        ) $charset;");

        dbDelta("CREATE TABLE {$p}asset_iot_timeline (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            tenant_id BIGINT UNSIGNED NOT NULL DEFAULT 1,
            module VARCHAR(40) NOT NULL DEFAULT 'asset_iot',
            entity_type VARCHAR(80) NOT NULL,
            entity_id BIGINT UNSIGNED NOT NULL,
            event_type VARCHAR(120) NOT NULL,
            label VARCHAR(255) NOT NULL,
            payload LONGTEXT NULL,
            correlation_id VARCHAR(128) NULL,
            created_at DATETIME NOT NULL,
            PRIMARY KEY (id),
            KEY entity (entity_type,entity_id)
        ) $charset;");
    }

    public static function hash_payload($payload) {
        return hash('sha256', wp_json_encode($payload) . microtime(true));
    }

    public static function emit($module, $entity_type, $entity_id, $event_type, $label, $payload = []) {
        global $wpdb;
        $correlation = CCJV_Core_Runtime_Client::emit_event($module, $event_type, $entity_id, $payload);
        $wpdb->insert($wpdb->prefix . 'ccjv_asset_iot_timeline', [
            'tenant_id'=>1,
            'module'=>sanitize_key($module),
            'entity_type'=>sanitize_key($entity_type),
            'entity_id'=>absint($entity_id),
            'event_type'=>sanitize_text_field($event_type),
            'label'=>sanitize_text_field($label),
            'payload'=>wp_json_encode($payload),
            'correlation_id'=>$correlation,
            'created_at'=>current_time('mysql')
        ]);
        return $correlation;
    }
}
