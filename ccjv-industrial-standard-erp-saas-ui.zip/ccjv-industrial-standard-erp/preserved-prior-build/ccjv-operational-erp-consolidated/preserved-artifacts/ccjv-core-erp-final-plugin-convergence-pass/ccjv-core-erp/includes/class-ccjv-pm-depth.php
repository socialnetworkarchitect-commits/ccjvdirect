<?php
if (!defined('ABSPATH')) exit;

class CCJV_PM_Depth {
    public static function install() {
        global $wpdb;
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        $charset = $wpdb->get_charset_collate();
        $p = $wpdb->prefix . 'ccjv_';

        dbDelta("CREATE TABLE {$p}pm_projects (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            tenant_id BIGINT UNSIGNED NOT NULL DEFAULT 1,
            project_code VARCHAR(120) NULL,
            project_name VARCHAR(255) NOT NULL,
            owner_id BIGINT UNSIGNED NULL,
            status VARCHAR(80) NOT NULL DEFAULT 'active',
            priority VARCHAR(40) NOT NULL DEFAULT 'normal',
            budget DECIMAL(18,2) NOT NULL DEFAULT 0,
            starts_at DATE NULL,
            ends_at DATE NULL,
            progress INT NOT NULL DEFAULT 0,
            vault_hash VARCHAR(128) NULL,
            replay_id VARCHAR(128) NULL,
            treasury_ref VARCHAR(128) NULL,
            created_at DATETIME NOT NULL,
            updated_at DATETIME NULL,
            PRIMARY KEY (id),
            KEY tenant_status (tenant_id,status)
        ) $charset;");

        dbDelta("CREATE TABLE {$p}pm_tasks (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            tenant_id BIGINT UNSIGNED NOT NULL DEFAULT 1,
            project_id BIGINT UNSIGNED NOT NULL,
            task_title VARCHAR(255) NOT NULL,
            assignee_id BIGINT UNSIGNED NULL,
            status VARCHAR(80) NOT NULL DEFAULT 'todo',
            priority VARCHAR(40) NOT NULL DEFAULT 'normal',
            starts_at DATE NULL,
            due_date DATE NULL,
            estimate_hours DECIMAL(10,2) NOT NULL DEFAULT 0,
            actual_hours DECIMAL(10,2) NOT NULL DEFAULT 0,
            vault_hash VARCHAR(128) NULL,
            replay_id VARCHAR(128) NULL,
            treasury_ref VARCHAR(128) NULL,
            created_at DATETIME NOT NULL,
            updated_at DATETIME NULL,
            PRIMARY KEY (id),
            KEY project_status (project_id,status),
            KEY tenant_assignee (tenant_id,assignee_id)
        ) $charset;");

        dbDelta("CREATE TABLE {$p}pm_milestones (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            tenant_id BIGINT UNSIGNED NOT NULL DEFAULT 1,
            project_id BIGINT UNSIGNED NOT NULL,
            milestone_name VARCHAR(255) NOT NULL,
            due_date DATE NULL,
            status VARCHAR(80) NOT NULL DEFAULT 'open',
            progress INT NOT NULL DEFAULT 0,
            vault_hash VARCHAR(128) NULL,
            replay_id VARCHAR(128) NULL,
            created_at DATETIME NOT NULL,
            updated_at DATETIME NULL,
            PRIMARY KEY (id),
            KEY project_id (project_id)
        ) $charset;");

        dbDelta("CREATE TABLE {$p}pm_dependencies (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            tenant_id BIGINT UNSIGNED NOT NULL DEFAULT 1,
            predecessor_task_id BIGINT UNSIGNED NOT NULL,
            successor_task_id BIGINT UNSIGNED NOT NULL,
            dependency_type VARCHAR(40) NOT NULL DEFAULT 'finish_to_start',
            status VARCHAR(80) NOT NULL DEFAULT 'active',
            vault_hash VARCHAR(128) NULL,
            replay_id VARCHAR(128) NULL,
            created_at DATETIME NOT NULL,
            updated_at DATETIME NULL,
            PRIMARY KEY (id)
        ) $charset;");

        dbDelta("CREATE TABLE {$p}pm_approvals (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            tenant_id BIGINT UNSIGNED NOT NULL DEFAULT 1,
            project_id BIGINT UNSIGNED NOT NULL,
            entity_type VARCHAR(80) NOT NULL DEFAULT 'task',
            entity_id BIGINT UNSIGNED NOT NULL,
            approver_id BIGINT UNSIGNED NULL,
            decision VARCHAR(80) NOT NULL DEFAULT 'pending',
            comment LONGTEXT NULL,
            vault_hash VARCHAR(128) NULL,
            replay_id VARCHAR(128) NULL,
            created_at DATETIME NOT NULL,
            updated_at DATETIME NULL,
            PRIMARY KEY (id)
        ) $charset;");

        dbDelta("CREATE TABLE {$p}pm_documents (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            tenant_id BIGINT UNSIGNED NOT NULL DEFAULT 1,
            project_id BIGINT UNSIGNED NOT NULL,
            entity_type VARCHAR(80) NULL,
            entity_id BIGINT UNSIGNED NULL,
            document_title VARCHAR(255) NOT NULL,
            vault_hash VARCHAR(128) NULL,
            proof_ref VARCHAR(190) NULL,
            replay_id VARCHAR(128) NULL,
            created_at DATETIME NOT NULL,
            updated_at DATETIME NULL,
            PRIMARY KEY (id)
        ) $charset;");

        dbDelta("CREATE TABLE {$p}pm_timeline (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            tenant_id BIGINT UNSIGNED NOT NULL DEFAULT 1,
            entity_type VARCHAR(80) NOT NULL,
            entity_id BIGINT UNSIGNED NOT NULL,
            event_type VARCHAR(120) NOT NULL,
            label VARCHAR(255) NOT NULL,
            payload LONGTEXT NULL,
            correlation_id VARCHAR(128) NULL,
            created_at DATETIME NOT NULL,
            PRIMARY KEY (id),
            KEY entity (entity_type,entity_id)
        ) $charset;");
    }

    public static function hash_payload($payload) {
        return hash('sha256', wp_json_encode($payload) . microtime(true));
    }

    public static function emit($entity_type, $entity_id, $event_type, $label, $payload = []) {
        global $wpdb;
        $correlation = CCJV_Core_Runtime_Client::emit_event('projects', $event_type, $entity_id, $payload);
        $wpdb->insert($wpdb->prefix . 'ccjv_pm_timeline', [
            'tenant_id'=>1,
            'entity_type'=>sanitize_key($entity_type),
            'entity_id'=>absint($entity_id),
            'event_type'=>sanitize_text_field($event_type),
            'label'=>sanitize_text_field($label),
            'payload'=>wp_json_encode($payload),
            'correlation_id'=>$correlation,
            'created_at'=>current_time('mysql')
        ]);
        return $correlation;
    }
}
