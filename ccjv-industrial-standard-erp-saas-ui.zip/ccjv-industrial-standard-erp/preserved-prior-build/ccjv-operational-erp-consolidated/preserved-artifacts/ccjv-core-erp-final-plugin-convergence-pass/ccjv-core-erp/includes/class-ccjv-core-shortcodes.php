<?php
if (!defined('ABSPATH')) exit;
class CCJV_Core_Shortcodes {
    public function __construct() {
        add_shortcode('ccjv_core_dashboard', [$this,'dashboard']);
        add_shortcode('ccjv_core_workspace', [$this,'workspace']);
        add_shortcode('ccjv_core_module', [$this,'module']);
    }
    public function dashboard() { ob_start(); include CCJV_CORE_ERP_PATH.'templates/dashboard.php'; return ob_get_clean(); }
    public function workspace($atts=[]) { $atts = shortcode_atts(['module'=>'crm'],$atts); return $this->render_module($atts['module']); }
    public function module($atts=[]) { $atts = shortcode_atts(['key'=>'crm'],$atts); return $this->render_module($atts['key']); }
    private function render_module($key) {
        $module_key = sanitize_key($key);
        $module = CCJV_Core_Modules::get($module_key);
        if (!$module) return '<div class="ccjv-erp-panel">Unknown module.</div>';
        ob_start(); include CCJV_CORE_ERP_PATH.'templates/module-workspace.php'; return ob_get_clean();
    }
}
