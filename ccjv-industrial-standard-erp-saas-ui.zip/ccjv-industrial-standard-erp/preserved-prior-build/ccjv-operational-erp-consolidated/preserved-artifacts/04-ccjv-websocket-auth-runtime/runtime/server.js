console.log('ccjv websocket auth runtime');
