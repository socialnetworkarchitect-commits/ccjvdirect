Authenticated websocket tenant isolation runtime.
