<?php
/*
Plugin Name: CCJV Super System (V12)
Description: Auto ERP Registry + Cross-ERP Login + Treasury Dashboard
Version: 12.0
*/

if (!defined('ABSPATH')) exit;

define('CCJV_V12_PATH', plugin_dir_path(__FILE__));
define('CCJV_V12_URL', plugin_dir_url(__FILE__));

require_once CCJV_V12_PATH.'includes/db.php';
require_once CCJV_V12_PATH.'includes/registry.php';
require_once CCJV_V12_PATH.'includes/api.php';
require_once CCJV_V12_PATH.'includes/auth.php';
require_once CCJV_V12_PATH.'includes/treasury.php';
require_once CCJV_V12_PATH.'admin/admin.php';

register_activation_hook(__FILE__, ['CCJV_DB','install']);

add_action('wp_enqueue_scripts', function(){
    wp_enqueue_style('ccjv-v12-css', CCJV_V12_URL.'assets/css/style.css');
    wp_enqueue_script('ccjv-v12-js', CCJV_V12_URL.'assets/js/app.js', [], null, true);
});

add_shortcode('ccjv_treasury', ['CCJV_Treasury','render']);
add_shortcode('ccjv_switcher', ['CCJV_Registry','switcher']);
