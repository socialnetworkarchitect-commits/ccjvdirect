<?php
add_action('admin_menu', function(){
    add_menu_page('CCJV Command','CCJV Command','manage_options','ccjv-command','ccjv_admin');
});

function ccjv_admin(){
    echo "<h1>CCJV Super System V12 Active</h1>";
}
