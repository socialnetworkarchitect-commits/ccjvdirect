<?php
class CCJV_DB {
    public static function install(){
        global $wpdb;
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');

        dbDelta("CREATE TABLE {$wpdb->prefix}ccjv_erps (
            id INT AUTO_INCREMENT PRIMARY KEY,
            name VARCHAR(100),
            token VARCHAR(10),
            contract VARCHAR(100),
            domain VARCHAR(200),
            status VARCHAR(20)
        );");
    }
}
