<?php
class CCJV_Treasury {

    public static function render(){
        ob_start(); ?>
        <div id="treasury">
            <h2>Treasury Dashboard</h2>
            <div id="balances">Loading...</div>
        </div>
        <script src="https://cdn.jsdelivr.net/npm/ethers@5.7.2/dist/ethers.min.js"></script>
        <script>
        async function load(){
            const provider = new ethers.providers.JsonRpcProvider("https://api.avax.network/ext/bc/C/rpc");
            const treasury = "0x0000000000000000000000000000000000000000";
            const bal = await provider.getBalance(treasury);
            document.getElementById("balances").innerText =
                "AVAX: "+ethers.utils.formatEther(bal);
        }
        load();
        </script>
        <?php return ob_get_clean();
    }
}
