<?php
add_action('rest_api_init', function () {

    register_rest_route('ccjv/v1','/register-erp',[
        'methods'=>'POST',
        'callback'=>function($req){
            $data = json_decode($req->get_body(),true);
            CCJV_Registry::add($data);
            return ['status'=>'registered'];
        }
    ]);

    register_rest_route('ccjv/v1','/login',[
        'methods'=>'POST',
        'callback'=>function($req){

            $body = json_decode($req->get_body(),true);

            $wallet = $body['wallet'];

            $token = base64_encode($wallet.'|'.time());

            setcookie("ccjv_session",$token,time()+86400,'/','.yourdomain.com');

            return ['token'=>$token];
        }
    ]);

});
