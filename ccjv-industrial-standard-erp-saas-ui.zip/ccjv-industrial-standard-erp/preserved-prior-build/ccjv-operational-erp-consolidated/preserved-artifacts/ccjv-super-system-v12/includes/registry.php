<?php
class CCJV_Registry {

    public static function add($data){
        global $wpdb;
        $wpdb->insert("{$wpdb->prefix}ccjv_erps",$data);
    }

    public static function all(){
        global $wpdb;
        return $wpdb->get_results("SELECT * FROM {$wpdb->prefix}ccjv_erps WHERE status='active'");
    }

    public static function switcher(){
        $erps = self::all();
        ob_start(); ?>
        <select onchange="window.location=this.value">
        <option>Select ERP</option>
        <?php foreach($erps as $e): ?>
            <option value="<?php echo $e->domain; ?>"><?php echo $e->name; ?></option>
        <?php endforeach; ?>
        </select>
        <?php return ob_get_clean();
    }
}
