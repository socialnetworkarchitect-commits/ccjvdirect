<?php
class CCJV_Auth {
    public static function check(){
        return isset($_COOKIE['ccjv_session']);
    }
}
