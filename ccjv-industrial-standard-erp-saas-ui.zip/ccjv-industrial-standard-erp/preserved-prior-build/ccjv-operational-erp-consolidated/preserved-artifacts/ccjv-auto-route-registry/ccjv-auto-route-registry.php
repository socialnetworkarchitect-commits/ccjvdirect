<?php
/*
Plugin Name: CCJV Auto Route Registry
Description: Auto-generates clean module routes for all current and future CCJV ERPs using a registry-driven model.
Version: 1.0.0
Author: CCJV
*/

if (!defined('ABSPATH')) exit;

/*
Purpose:
- Future ERPs register once.
- Routes auto-generate as /{erp}-{module}
- Entry routes auto-map as /{erp} and /{erp}-dashboard
- Compatible with CCJV Theme-Aware Global Enforcement Layer.
*/

/* -----------------------------
   DEFAULT ERP REGISTRY
------------------------------ */
function ccjv_arr_default_registry() {
    return [
        'ccjv' => [
            'name' => 'CCJV Core ERP',
            'token' => 'CJV',
            'gate_min' => 1,
            'entry_slugs' => ['ccjv-erp', 'command-center', 'workspace', 'tenant'],
            'free_modules' => ['core', 'dashboard', 'reports'],
            'modules' => ['crm', 'hrm', 'accounting', 'projects', 'assets', 'vault']
        ],
        'constructum' => [
            'name' => 'Constructum ERP',
            'token' => 'CST',
            'gate_min' => 1,
            'entry_slugs' => ['constructum', 'constructum-dashboard'],
            'free_modules' => ['core', 'dashboard', 'reports'],
            'modules' => ['crm', 'projects', 'estimating', 'accounting', 'assets']
        ],
        'cibus' => [
            'name' => 'Cibus ERP',
            'token' => 'CIB',
            'gate_min' => 1,
            'entry_slugs' => ['cibus', 'cibus-dashboard'],
            'free_modules' => ['core', 'dashboard', 'reports'],
            'modules' => ['production', 'traceability', 'inventory', 'compliance']
        ],
        'iter' => [
            'name' => 'Iter ERP',
            'token' => 'ITC',
            'gate_min' => 1,
            'entry_slugs' => ['iter', 'iter-dashboard'],
            'free_modules' => ['core', 'dashboard', 'reports'],
            'modules' => ['booking', 'ticketing', 'yield', 'capacity']
        ],
        'surge' => [
            'name' => 'Surge Symposia ERP',
            'token' => 'SYS',
            'gate_min' => 1,
            'entry_slugs' => ['surge', 'surge-dashboard'],
            'free_modules' => ['core', 'dashboard', 'reports'],
            'modules' => ['events', 'ticketing', 'sponsors', 'speakers']
        ],
        'freeassembly' => [
            'name' => 'Free Assembly ERP',
            'token' => 'FRE',
            'gate_min' => 1,
            'entry_slugs' => ['freeassembly', 'freeassembly-dashboard'],
            'free_modules' => ['core', 'dashboard', 'reports'],
            'modules' => ['giving', 'testimony', 'members', 'missions']
        ]
    ];
}

function ccjv_arr_registry() {
    $saved = get_option('ccjv_auto_route_registry', []);
    if (!is_array($saved) || empty($saved)) return ccjv_arr_default_registry();
    return array_replace_recursive(ccjv_arr_default_registry(), $saved);
}

/* -----------------------------
   PUBLIC REGISTRATION FUNCTION
------------------------------ */
function ccjv_register_route_erp($key, $config = []) {
    $key = sanitize_key($key);
    if (!$key) return false;

    $registry = get_option('ccjv_auto_route_registry', ccjv_arr_default_registry());

    $defaults = [
        'name' => ucfirst($key) . ' ERP',
        'token' => strtoupper(substr($key, 0, 3)),
        'gate_min' => 1,
        'entry_slugs' => [$key, $key . '-dashboard'],
        'free_modules' => ['core', 'dashboard', 'reports'],
        'modules' => []
    ];

    $registry[$key] = array_replace_recursive($defaults, $config);
    update_option('ccjv_auto_route_registry', $registry);
    update_option('ccjv_arr_flush_needed', 1);

    return true;
}

/* -----------------------------
   ROUTE GENERATION
------------------------------ */
function ccjv_arr_build_routes() {
    $routes = [];
    $registry = ccjv_arr_registry();

    foreach ($registry as $erp => $cfg) {
        $erp = sanitize_key($erp);

        // Entry/free routes: token gate only, module = core
        $entry_slugs = $cfg['entry_slugs'] ?? [$erp, $erp . '-dashboard'];
        foreach ($entry_slugs as $slug) {
            $routes[sanitize_key($slug)] = [
                'erp' => $erp,
                'module' => 'core',
                'access' => 'entry'
            ];
        }

        // Free modules: still token-gated, not subscription charged
        foreach (($cfg['free_modules'] ?? []) as $module) {
            $module = sanitize_key($module);
            $routes[$erp . '-' . $module] = [
                'erp' => $erp,
                'module' => $module,
                'access' => 'entry'
            ];
        }

        // Paid modules: token gate + 1 token/month/module
        foreach (($cfg['modules'] ?? []) as $module) {
            $module = sanitize_key($module);
            $routes[$erp . '-' . $module] = [
                'erp' => $erp,
                'module' => $module,
                'access' => 'module'
            ];
        }
    }

    return $routes;
}

/* -----------------------------
   REWRITE RULES
------------------------------ */
add_action('init', function () {
    $routes = ccjv_arr_build_routes();

    foreach ($routes as $slug => $ctx) {
        add_rewrite_rule(
            '^' . preg_quote($slug, '/') . '/?$',
            'index.php?ccjv_arr_route=' . $slug,
            'top'
        );
    }

    if (get_option('ccjv_arr_flush_needed')) {
        flush_rewrite_rules(false);
        delete_option('ccjv_arr_flush_needed');
    }
});

add_filter('query_vars', function ($vars) {
    $vars[] = 'ccjv_arr_route';
    return $vars;
});

register_activation_hook(__FILE__, function () {
    if (!get_option('ccjv_auto_route_registry')) {
        update_option('ccjv_auto_route_registry', ccjv_arr_default_registry());
    }
    update_option('ccjv_arr_flush_needed', 1);
});

register_deactivation_hook(__FILE__, function () {
    flush_rewrite_rules(false);
});

/* -----------------------------
   INJECT CONTEXT INTO REQUEST
------------------------------ */
add_action('template_redirect', function () {
    $route = get_query_var('ccjv_arr_route');
    if (!$route) {
        $path = trim(parse_url($_SERVER['REQUEST_URI'] ?? '', PHP_URL_PATH), '/');
        $route = sanitize_key(basename($path));
    }

    $routes = ccjv_arr_build_routes();

    if (isset($routes[$route])) {
        $_GET['erp'] = $routes[$route]['erp'];
        $_GET['module'] = $routes[$route]['module'];
        $_GET['ccjv_access_type'] = $routes[$route]['access'];
    }
}, 0);

/* -----------------------------
   ROUTE PAGE RENDER FALLBACK
------------------------------ */
add_filter('the_content', function ($content) {
    $route = get_query_var('ccjv_arr_route');
    if (!$route) return $content;

    $routes = ccjv_arr_build_routes();
    if (!isset($routes[$route])) return $content;

    $erp = esc_html($routes[$route]['erp']);
    $module = esc_html($routes[$route]['module']);
    $access = esc_html($routes[$route]['access']);

    // If page content exists, let it render. If empty, show a useful fallback.
    if (trim(strip_tags($content)) !== '') return $content;

    return "<div class='ccjv-arr-fallback'>
        <h2>CCJV ERP Route</h2>
        <p><strong>ERP:</strong> {$erp}</p>
        <p><strong>Module:</strong> {$module}</p>
        <p><strong>Access Type:</strong> {$access}</p>
        <p>Add your ERP shortcode or module UI to the matching page when ready.</p>
    </div>";
}, 20);

/* -----------------------------
   ADMIN REGISTRY EDITOR
------------------------------ */
add_action('admin_menu', function () {
    add_menu_page('CCJV Auto Routes', 'CCJV Auto Routes', 'manage_options', 'ccjv-auto-routes', 'ccjv_arr_admin', 'dashicons-randomize', 61);
});

function ccjv_arr_admin() {
    if (!current_user_can('manage_options')) return;

    if (isset($_POST['ccjv_arr_save'])) {
        check_admin_referer('ccjv_arr_save');
        $json = wp_unslash($_POST['registry_json'] ?? '{}');
        $decoded = json_decode($json, true);

        if (is_array($decoded)) {
            update_option('ccjv_auto_route_registry', $decoded);
            update_option('ccjv_arr_flush_needed', 1);
            echo '<div class="updated"><p>Registry saved. Rewrite rules will refresh.</p></div>';
        } else {
            echo '<div class="error"><p>Invalid JSON.</p></div>';
        }
    }

    if (isset($_POST['ccjv_arr_reset'])) {
        check_admin_referer('ccjv_arr_reset');
        update_option('ccjv_auto_route_registry', ccjv_arr_default_registry());
        update_option('ccjv_arr_flush_needed', 1);
        echo '<div class="updated"><p>Registry reset to defaults.</p></div>';
    }

    $registry = ccjv_arr_registry();
    $routes = ccjv_arr_build_routes();

    echo '<div class="wrap"><h1>CCJV Auto Route Registry</h1>';
    echo '<p><strong>Rule:</strong> Entry routes = ERP token gate. Module routes = ERP token gate + 1 token/month/module.</p>';

    echo '<h2>Generated Routes</h2>';
    echo '<table class="widefat striped"><thead><tr><th>Slug</th><th>ERP</th><th>Module</th><th>Access</th></tr></thead><tbody>';
    foreach ($routes as $slug => $r) {
        echo '<tr><td>/' . esc_html($slug) . '</td><td>' . esc_html($r['erp']) . '</td><td>' . esc_html($r['module']) . '</td><td>' . esc_html($r['access']) . '</td></tr>';
    }
    echo '</tbody></table>';

    echo '<h2>Registry JSON</h2>';
    echo '<form method="post">';
    wp_nonce_field('ccjv_arr_save');
    echo '<textarea name="registry_json" style="width:100%;height:520px;font-family:monospace;">' . esc_textarea(json_encode($registry, JSON_PRETTY_PRINT)) . '</textarea>';
    echo '<p><button class="button button-primary" name="ccjv_arr_save">Save Registry</button></p>';
    echo '</form>';

    echo '<form method="post" style="margin-top:20px;">';
    wp_nonce_field('ccjv_arr_reset');
    echo '<button class="button" name="ccjv_arr_reset">Reset Defaults</button>';
    echo '</form>';

    echo '</div>';
}

/* -----------------------------
   DEBUG SHORTCODE
------------------------------ */
add_shortcode('ccjv_route_debug', function () {
    $route = get_query_var('ccjv_arr_route');
    $erp = $_GET['erp'] ?? 'none';
    $module = $_GET['module'] ?? 'none';
    $type = $_GET['ccjv_access_type'] ?? 'none';

    return "<div style='padding:16px;background:#111827;color:#7dd3fc;border-radius:12px'>
        <strong>CCJV Route Debug</strong><br>
        Route: " . esc_html($route ?: 'none') . "<br>
        ERP: " . esc_html($erp) . "<br>
        Module: " . esc_html($module) . "<br>
        Access Type: " . esc_html($type) . "
    </div>";
});

add_action('wp_head', function () { ?>
<style>
.ccjv-arr-fallback{max-width:960px;margin:24px auto;padding:24px;border-radius:18px;background:#0f172a;color:#fff}
</style>
<?php });
