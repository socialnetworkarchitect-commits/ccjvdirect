<?php
/**
 * Plugin Name: CCJV Analytics Engine
 * Description: Tracks usage, module activity, vault actions, and generates reports
 * Version: 1.0.0
 */

if (!defined('ABSPATH')) exit;
if (!defined('CCJV_CORE_ACTIVE')) return;

require_once plugin_dir_path(__FILE__) . 'includes/tracking.php';
require_once plugin_dir_path(__FILE__) . 'includes/reports.php';
