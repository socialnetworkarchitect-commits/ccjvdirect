<?php
if (!defined('ABSPATH')) exit;

// log activity
function ccjv_log_activity($user_id, $type, $details = []) {
    $logs = get_user_meta($user_id, 'ccjv_activity_log', true);
    if (!$logs) $logs = [];

    $logs[] = [
        'time' => current_time('mysql'),
        'type' => $type,
        'details' => $details
    ];

    update_user_meta($user_id, 'ccjv_activity_log', $logs);
}
