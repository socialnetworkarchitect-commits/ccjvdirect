<?php
if (!defined('ABSPATH')) exit;

function ccjv_analytics_shortcode() {

    if (!is_user_logged_in()) return "Connect wallet";

    $user_id = get_current_user_id();
    $logs = get_user_meta($user_id, 'ccjv_activity_log', true);

    if (!$logs) return "No activity";

    ob_start();

    echo "<h2>Analytics</h2>";

    foreach ($logs as $log) {
        echo "<div style='margin:8px 0'>";
        echo "<strong>" . esc_html($log['type']) . "</strong> - ";
        echo esc_html($log['time']);
        echo "</div>";
    }

    return ob_get_clean();
}

add_shortcode('ccjv_analytics', 'ccjv_analytics_shortcode');
