CCJV VPS SUPPORT PACKAGE

THIS PACKAGE DOES NOT CONTAIN WORDPRESS PLUGINS.

PURPOSE:
Deploy distributed infrastructure services required by CCJV.

SERVICES:
- nginx
- php-fpm
- PostgreSQL
- Redis
- Kafka
- NATS
- MinIO
- websocket federation
- Avalanche signer service
- Prometheus
- Grafana

INSTALL:
1. unzip package
2. install Docker + Docker Compose
3. configure DNS
4. configure SSL
5. run:
   docker compose up -d

DO NOT:
- modify WordPress plugins
- configure ERP modules
- alter application logic

THIS PACKAGE IS INFRASTRUCTURE ONLY.
