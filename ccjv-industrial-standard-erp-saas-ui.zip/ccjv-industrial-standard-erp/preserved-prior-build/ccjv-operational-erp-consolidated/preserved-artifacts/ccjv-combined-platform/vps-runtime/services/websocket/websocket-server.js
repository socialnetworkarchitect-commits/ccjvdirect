const http = require('http');

http.createServer((req, res) => {
  res.writeHead(200);
  res.end('CCJV Websocket Federation Active');
}).listen(3001);

console.log('Websocket service running on 3001');
