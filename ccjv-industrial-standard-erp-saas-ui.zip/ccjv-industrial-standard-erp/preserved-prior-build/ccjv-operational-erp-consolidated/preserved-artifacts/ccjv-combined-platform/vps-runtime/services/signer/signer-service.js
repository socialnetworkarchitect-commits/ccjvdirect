const http = require('http');

http.createServer((req, res) => {
  res.writeHead(200);
  res.end('CCJV Avalanche Signer Active');
}).listen(3002);

console.log('Signer service running on 3002');
