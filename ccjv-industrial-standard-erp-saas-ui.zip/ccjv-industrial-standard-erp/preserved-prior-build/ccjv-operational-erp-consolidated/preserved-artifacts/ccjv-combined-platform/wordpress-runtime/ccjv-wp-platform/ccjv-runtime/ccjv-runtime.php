<?php
/**
 * Plugin Name: CCJV Runtime
 * Description: Multi-tenant runtime for CCJV.
 * Version: 0.1.0
 */

if (!defined('ABSPATH')) exit;

class CCJV_Runtime {
    public function __construct() {
        add_action('rest_api_init', [$this, 'routes']);
    }

    public function routes() {
        register_rest_route('ccjv-runtime/v1', '/tenant', [
            'methods' => 'GET',
            'callback' => function() {
                return [
                    'tenant' => 'default',
                    'runtime' => 'active'
                ];
            }
        ]);
    }
}

new CCJV_Runtime();
