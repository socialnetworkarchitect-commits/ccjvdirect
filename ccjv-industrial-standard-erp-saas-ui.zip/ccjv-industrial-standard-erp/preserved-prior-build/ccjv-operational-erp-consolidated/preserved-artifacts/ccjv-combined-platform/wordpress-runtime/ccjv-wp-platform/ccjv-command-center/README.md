# CCJV Command Center

Core control-plane plugin.

## Responsibilities
- tenant management
- treasury settings
- vault settings
- RPC/signer settings
- ERP registration
- observability controls

## Install
Upload to `/wp-content/plugins/` and activate.
