# CCJV Runtime

Core runtime layer.

## Includes
- tenant runtime
- JWT/SIWE integration points
- vault hooks
- treasury hooks
- audit hooks
- REST APIs
