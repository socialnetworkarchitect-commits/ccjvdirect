
# CCJV WordPress Platform Bundle

## Included
- ccjv-command-center
- ccjv-runtime
- impensa-erp

## Install
1. Upload each plugin folder into:
   `/wp-content/plugins/`

2. Activate in WordPress Admin.

3. Configure REST/API endpoints and external runtime services.

## External Infrastructure Required
- PostgreSQL
- Redis
- Kafka/NATS
- MinIO/S3
- Avalanche signer services
- Websocket federation
