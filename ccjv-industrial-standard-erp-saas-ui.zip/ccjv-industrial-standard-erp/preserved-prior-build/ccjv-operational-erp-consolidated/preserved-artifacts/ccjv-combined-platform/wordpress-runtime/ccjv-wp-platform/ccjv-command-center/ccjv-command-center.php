<?php
/**
 * Plugin Name: CCJV Command Center
 * Description: Super admin control plane for CCJV.
 * Version: 0.1.0
 */

if (!defined('ABSPATH')) exit;

class CCJV_Command_Center {
    public function __construct() {
        add_action('admin_menu', [$this, 'menu']);
        add_action('rest_api_init', [$this, 'routes']);
    }

    public function menu() {
        add_menu_page(
            'CCJV Command Center',
            'CCJV',
            'manage_options',
            'ccjv-command-center',
            [$this, 'dashboard'],
            'dashicons-admin-generic'
        );
    }

    public function dashboard() {
        echo '<div class="wrap"><h1>CCJV Command Center</h1>';
        echo '<p>Tenant federation, treasury controls, runtime governance.</p></div>';
    }

    public function routes() {
        register_rest_route('ccjv/v1', '/health', [
            'methods' => 'GET',
            'callback' => function() {
                return ['status' => 'ok', 'service' => 'command-center'];
            }
        ]);
    }
}

new CCJV_Command_Center();
