<?php
/**
 * Plugin Name: Impensa ERP
 * Description: Logistics intelligence ERP for CCJV.
 * Version: 0.1.0
 */

if (!defined('ABSPATH')) exit;

class Impensa_ERP {
    public function __construct() {
        add_shortcode('impensa_dashboard', [$this, 'dashboard']);
    }

    public function dashboard() {
        return '<div id="impensa-dashboard">Impensa ERP Runtime Active</div>';
    }
}

new Impensa_ERP();
