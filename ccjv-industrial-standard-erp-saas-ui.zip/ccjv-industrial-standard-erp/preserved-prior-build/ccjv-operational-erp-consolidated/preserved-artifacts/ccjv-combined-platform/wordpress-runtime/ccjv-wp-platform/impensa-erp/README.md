# Impensa ERP

ERP plugin integrating with:
- CCJV Runtime
- Treasury Runtime
- Vault Runtime
- Observability Runtime
