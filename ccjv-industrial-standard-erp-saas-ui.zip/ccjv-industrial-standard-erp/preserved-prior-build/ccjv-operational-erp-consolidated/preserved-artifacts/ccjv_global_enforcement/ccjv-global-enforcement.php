<?php
/*
Plugin Name: CCJV Global Enforcement Layer
Description: Enforces Token Gates, Subscriptions, and Vault economics across all ERPs
Version: 1.0
*/

if (!defined('ABSPATH')) exit;

// --- DETECT ERP + MODULE ---
function ccjv_detect_erp() {
    return isset($_GET['erp']) ? sanitize_text_field($_GET['erp']) : 'unknown';
}

function ccjv_detect_module() {
    return isset($_GET['module']) ? sanitize_text_field($_GET['module']) : 'core';
}

// --- TOKEN BALANCE (stub) ---
function ccjv_get_wallet_balance($user_id, $token) {
    return floatval(get_user_meta($user_id, 'ccjv_balance_'.$token, true));
}

// --- TOKEN GATE ---
function ccjv_enforce_token_gate($user_id, $erp) {
    $token = get_option("ccjv_token_gate_{$erp}", "OMC");
    $min = floatval(get_option("ccjv_token_gate_min_{$erp}", 0));
    $balance = ccjv_get_wallet_balance($user_id, $token);

    if ($balance < $min) {
        wp_die("Access denied: insufficient {$token}");
    }
}

// --- SUBSCRIPTION ---
function ccjv_enforce_subscription($user_id, $erp, $module) {
    global $wpdb;
    $table = $wpdb->prefix . "ccjv_subscriptions";

    $sub = $wpdb->get_row($wpdb->prepare(
        "SELECT * FROM $table WHERE user_id=%d AND erp=%s AND module=%s AND status='active'",
        $user_id, $erp, $module
    ));

    if (!$sub || strtotime($sub->expires_at) < time()) {
        wp_die("Subscription required for {$module}");
    }
}

// --- VAULT STORE ---
function ccjv_vault_store($user_id, $data) {
    global $wpdb;
    $table = $wpdb->prefix . "ccjv_vault";
    $hash = hash('sha256', json_encode($data));

    $wpdb->insert($table, [
        'user_id' => $user_id,
        'hash' => $hash,
        'data' => json_encode($data),
        'created_at' => current_time('mysql')
    ]);

    return $hash;
}

// --- GLOBAL ENFORCEMENT ---
add_action('init', function() {
    if (!is_user_logged_in()) return;

    $user_id = get_current_user_id();
    $erp = ccjv_detect_erp();
    $module = ccjv_detect_module();

    ccjv_enforce_token_gate($user_id, $erp);
    ccjv_enforce_subscription($user_id, $erp, $module);
});

// --- CREATE TABLES ---
register_activation_hook(__FILE__, function() {
    global $wpdb;
    $charset = $wpdb->get_charset_collate();

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');

    dbDelta("CREATE TABLE {$wpdb->prefix}ccjv_subscriptions (
        id BIGINT AUTO_INCREMENT PRIMARY KEY,
        user_id BIGINT,
        erp VARCHAR(50),
        module VARCHAR(50),
        status VARCHAR(20),
        expires_at DATETIME
    ) $charset;");

    dbDelta("CREATE TABLE {$wpdb->prefix}ccjv_vault (
        id BIGINT AUTO_INCREMENT PRIMARY KEY,
        user_id BIGINT,
        hash TEXT,
        data LONGTEXT,
        created_at DATETIME
    ) $charset;");
});
