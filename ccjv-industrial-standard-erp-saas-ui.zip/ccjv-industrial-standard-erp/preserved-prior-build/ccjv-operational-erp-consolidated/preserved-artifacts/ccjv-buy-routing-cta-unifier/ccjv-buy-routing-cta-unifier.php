<?php
/*
Plugin Name: CCJV Buy Token Routing + CTA Unifier
Description: Unifies Buy Token routing and portal CTA wording across Cibus, Iter, and Surge ERP portals.
Version: 1.0.0
Author: OpenAI
*/

if (!defined('ABSPATH')) exit;

/*
Unified ERP map
*/
function ccjv_cta_unifier_erps() {
    return [
        'cibus' => [
            'label' => 'Cibus ERP',
            'symbol' => get_option('cibus_token_symbol', 'CIB'),
            'buy_url' => get_option('cibus_buy_url', get_option('ccjv_buy_token_url', home_url('/buy-token'))),
        ],
        'iter' => [
            'label' => 'Iter ERP',
            'symbol' => get_option('iter_token_symbol', 'ITC'),
            'buy_url' => get_option('iter_buy_url', get_option('ccjv_buy_token_url', home_url('/buy-token'))),
        ],
        'surge' => [
            'label' => 'Surge Symposia',
            'symbol' => get_option('surge_token', get_option('surge_token_symbol', 'SYS')),
            'buy_url' => get_option('surge_buy', get_option('ccjv_buy_token_url', home_url('/buy-token'))),
        ],
    ];
}

/*
Admin settings under Core X
*/
add_action('admin_menu', function () {
    add_submenu_page(
        'ccjvx',
        'Buy Token Routing',
        'Buy Token Routing',
        'manage_options',
        'ccjv-buy-token-routing',
        'ccjv_cta_unifier_admin_page'
    );
}, 110);

function ccjv_cta_unifier_admin_page() {
    if (!current_user_can('manage_options')) return;

    if (isset($_POST['ccjv_cta_save'])) {
        check_admin_referer('ccjv_cta_unifier_save');

        update_option('ccjv_buy_token_url', esc_url_raw(wp_unslash($_POST['global_buy_url'] ?? '')));
        update_option('ccjv_cta_buy_text', sanitize_text_field(wp_unslash($_POST['buy_text'] ?? 'Get Required Token')));
        update_option('ccjv_cta_enter_text', sanitize_text_field(wp_unslash($_POST['enter_text'] ?? 'Enter ERP')));
        update_option('ccjv_cta_inactive_text', sanitize_text_field(wp_unslash($_POST['inactive_text'] ?? 'Access inactive')));
        update_option('ccjv_cta_active_text', sanitize_text_field(wp_unslash($_POST['active_text'] ?? 'Access active')));

        echo '<div class="updated notice"><p>Buy routing + CTA settings saved.</p></div>';
    }

    $global_buy_url = get_option('ccjv_buy_token_url', home_url('/buy-token'));
    $buy_text = get_option('ccjv_cta_buy_text', 'Get Required Token');
    $enter_text = get_option('ccjv_cta_enter_text', 'Enter ERP');
    $inactive_text = get_option('ccjv_cta_inactive_text', 'Access inactive');
    $active_text = get_option('ccjv_cta_active_text', 'Access active');
    ?>
    <div class="wrap">
        <h1>CCJV Buy Token Routing + CTA Unifier</h1>
        <form method="post">
            <?php wp_nonce_field('ccjv_cta_unifier_save'); ?>
            <table class="form-table" role="presentation">
                <tbody>
                    <tr>
                        <th scope="row">Global Buy Token URL</th>
                        <td>
                            <input type="url" name="global_buy_url" value="<?php echo esc_attr($global_buy_url); ?>" class="large-text" />
                            <p class="description">Fallback buy URL used when an ERP-specific buy URL is not set.</p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">Buy CTA Text</th>
                        <td><input type="text" name="buy_text" value="<?php echo esc_attr($buy_text); ?>" class="regular-text" /></td>
                    </tr>
                    <tr>
                        <th scope="row">Enter ERP CTA Text</th>
                        <td><input type="text" name="enter_text" value="<?php echo esc_attr($enter_text); ?>" class="regular-text" /></td>
                    </tr>
                    <tr>
                        <th scope="row">Inactive Status Text</th>
                        <td><input type="text" name="inactive_text" value="<?php echo esc_attr($inactive_text); ?>" class="regular-text" /></td>
                    </tr>
                    <tr>
                        <th scope="row">Active Status Text</th>
                        <td><input type="text" name="active_text" value="<?php echo esc_attr($active_text); ?>" class="regular-text" /></td>
                    </tr>
                </tbody>
            </table>
            <p><button class="button button-primary" name="ccjv_cta_save" value="1">Save Settings</button></p>
        </form>

        <hr>

        <h2>Portal Shortcodes</h2>
        <p>Use one of these unified shortcodes on the ERP portal pages if you want consistent CTA wording without editing each ERP plugin:</p>
        <ul>
            <li><code>[ccjv_cibus_portal_unified]</code></li>
            <li><code>[ccjv_iter_portal_unified]</code></li>
            <li><code>[ccjv_surge_portal_unified]</code></li>
        </ul>
    </div>
    <?php
}

function ccjv_cta_unifier_render_portal($erp_key) {
    if (!is_user_logged_in()) {
        return '<div class="ccjv-portal-wrap"><p>Please log in to continue.</p></div>';
    }

    $map = ccjv_cta_unifier_erps();
    if (!isset($map[$erp_key])) return '<p>Unknown ERP.</p>';

    $erp = $map[$erp_key];
    $user_id = get_current_user_id();

    $wallet = get_user_meta($user_id, 'ccjv_wallet', true);
    $tenant = get_user_meta($user_id, 'ccjv_tenant', true);

    $buy_text = get_option('ccjv_cta_buy_text', 'Get Required Token');
    $enter_text = get_option('ccjv_cta_enter_text', 'Enter ERP');
    $inactive_text = get_option('ccjv_cta_inactive_text', 'Access inactive');
    $active_text = get_option('ccjv_cta_active_text', 'Access active');

    $has_access = false;
    if (function_exists('ccjv_payment_user_has_access')) {
        $has_access = ccjv_payment_user_has_access($user_id, $erp_key);
    }

    $portal_slug = '/' . $erp_key . '-portal';
    $app_slug = '/' . $erp_key . '-app';

    if ($erp_key === 'surge') {
        $app_slug = '/surge-app';
    } elseif ($erp_key === 'iter') {
        $app_slug = '/' . get_option('iter_app_slug', 'iter-app');
    } elseif ($erp_key === 'cibus') {
        $app_slug = '/cibus-app';
    }

    ob_start();
    ?>
    <div class="ccjv-portal-wrap" style="max-width:960px;margin:0 auto;padding:24px;">
        <div style="border:1px solid #ddd;border-radius:16px;padding:24px;background:#fff;">
            <h2 style="margin-top:0"><?php echo esc_html($erp['label']); ?> Portal</h2>
            <p>Use one unified access flow for wallet, payment, token, and ERP launch.</p>

            <p><strong>Wallet:</strong> <?php echo $wallet ? esc_html($wallet) : 'Not connected'; ?></p>
            <p><strong>Tenant:</strong> <?php echo $tenant ? esc_html($tenant) : 'Not created'; ?></p>
            <p><strong>Required token:</strong> <?php echo esc_html($erp['symbol']); ?></p>

            <?php if (!$has_access): ?>
                <div style="padding:14px;border-radius:12px;background:#fff7ed;border:1px solid #fdba74;margin:18px 0;">
                    <strong><?php echo esc_html($inactive_text); ?></strong><br>
                    Connect your wallet, hold the required token, and ensure payment is active.
                </div>

                <?php if (shortcode_exists('ccjv_wallet_button')): ?>
                    <div style="margin:16px 0;"><?php echo do_shortcode('[ccjv_wallet_button]'); ?></div>
                <?php elseif (shortcode_exists('ccjv_connect_wallet')): ?>
                    <div style="margin:16px 0;"><?php echo do_shortcode('[ccjv_connect_wallet]'); ?></div>
                <?php endif; ?>

                <p>
                    <a href="<?php echo esc_url($erp['buy_url']); ?>" class="button"><?php echo esc_html($buy_text); ?> (<?php echo esc_html($erp['symbol']); ?>)</a>
                    <a href="<?php echo esc_url(home_url('/payment-required')); ?>" class="button button-secondary" style="margin-left:8px;">Resolve Payment</a>
                </p>
            <?php else: ?>
                <div style="padding:14px;border-radius:12px;background:#ecfdf5;border:1px solid #86efac;margin:18px 0;">
                    <strong><?php echo esc_html($active_text); ?></strong><br>
                    Your access checks passed. You can launch the ERP now.
                </div>

                <p>
                    <a href="<?php echo esc_url(home_url($app_slug)); ?>" class="button button-primary"><?php echo esc_html($enter_text); ?></a>
                    <a href="<?php echo esc_url($erp['buy_url']); ?>" class="button button-secondary" style="margin-left:8px;"><?php echo esc_html($buy_text); ?></a>
                </p>
            <?php endif; ?>

            <?php if (shortcode_exists('ccjv_subscription_status')): ?>
                <div style="margin-top:20px;">
                    <?php echo do_shortcode('[ccjv_subscription_status erp="' . esc_attr($erp_key) . '"]'); ?>
                </div>
            <?php endif; ?>
        </div>
    </div>
    <?php
    return ob_get_clean();
}

add_shortcode('ccjv_cibus_portal_unified', function () {
    return ccjv_cta_unifier_render_portal('cibus');
});

add_shortcode('ccjv_iter_portal_unified', function () {
    return ccjv_cta_unifier_render_portal('iter');
});

add_shortcode('ccjv_surge_portal_unified', function () {
    return ccjv_cta_unifier_render_portal('surge');
});
