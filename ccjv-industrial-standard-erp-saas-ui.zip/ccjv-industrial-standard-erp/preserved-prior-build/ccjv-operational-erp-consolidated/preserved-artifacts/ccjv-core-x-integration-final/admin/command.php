<?php
add_action('admin_menu',function(){
    add_menu_page('Core X','Core X','manage_options','ccjvx',function(){
        echo "<h1>Core X Integration Active</h1>";
        echo "<p>Extending Unified Core safely</p>";
    });
});
