<?php
function ccjvx_get_tenant($user_id){
    return get_user_meta($user_id,'ccjv_tenant',true);
}
