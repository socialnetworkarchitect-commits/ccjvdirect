<?php
global $ccjvx_erps;
$ccjvx_erps = [];

function ccjvx_register_erp($key,$config){
    global $ccjvx_erps;
    $ccjvx_erps[$key] = $config;
}

function ccjvx_get_erps(){
    global $ccjvx_erps;
    return $ccjvx_erps;
}
