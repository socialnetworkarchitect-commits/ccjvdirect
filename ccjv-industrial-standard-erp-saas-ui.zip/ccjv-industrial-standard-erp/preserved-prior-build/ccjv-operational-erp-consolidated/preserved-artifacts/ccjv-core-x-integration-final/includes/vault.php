<?php
function ccjvx_store_file(){
    if(!empty($_FILES['file'])){
        $f=$_FILES['file'];
        $hash = hash_file('sha256',$f['tmp_name']);
        move_uploaded_file($f['tmp_name'], wp_upload_dir()['basedir'].'/'.$f['name']);
        update_option('ccjvx_last_hash',$hash);
    }
}
add_action('admin_post_ccjvx_upload','ccjvx_store_file');
