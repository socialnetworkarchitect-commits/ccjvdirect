<?php
function ccjvx_user_has_access($user_id,$erp){
    // hook ready
    return apply_filters('ccjvx_access', true, $user_id, $erp);
}
