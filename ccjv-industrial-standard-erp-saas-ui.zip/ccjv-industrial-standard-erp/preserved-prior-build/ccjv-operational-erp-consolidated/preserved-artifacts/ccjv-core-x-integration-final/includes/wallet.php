<?php
function ccjvx_get_wallet($user_id){
    return get_user_meta($user_id,'ccjv_wallet',true);
}
