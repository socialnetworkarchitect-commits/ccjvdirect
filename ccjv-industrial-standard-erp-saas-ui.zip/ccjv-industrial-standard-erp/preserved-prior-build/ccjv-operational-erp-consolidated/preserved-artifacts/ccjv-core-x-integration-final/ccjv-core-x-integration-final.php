<?php
/*
Plugin Name: CCJV Core X Integration FINAL
Version: 1.0
Description: Extends Unified Core (no conflicts)
*/

if (!defined('ABSPATH')) exit;

// SAFE LOAD (DO NOT BREAK EXISTING CORE)
if (!defined('CCJV_CORE_ACTIVE') && !function_exists('ccjv_core_loaded')) {
    return; // silently wait for core
}

define('CCJV_CORE_X', true);

require_once __DIR__.'/includes/wallet.php';
require_once __DIR__.'/includes/tenant.php';
require_once __DIR__.'/includes/erp-standard.php';
require_once __DIR__.'/includes/payments.php';
require_once __DIR__.'/includes/vault.php';
require_once __DIR__.'/admin/command.php';
