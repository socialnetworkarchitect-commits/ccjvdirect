<?php
/**
 * Plugin Name: CCJV Unified Core X (Full System)
 * Description: Full Core X system with Command Center, Identity, Vault, and ERP integration.
 * Version: 2.0.0
 */

if (!defined('ABSPATH')) exit;

/* COMMAND CENTER */
add_action('admin_menu', function(){
    add_menu_page('CCJV Core X','CCJV Core X','manage_options','ccjvx', function(){
        echo '<h1>CCJV Command Center</h1>';
        echo '<p>Configure RPC, Treasury, Token Gates, Vault.</p>';
    });
});

/* SHORTCODES */
add_shortcode('ccjvx_shell', function(){
    return '<div style="padding:20px"><h2>Dashboard</h2><p>Core X FULL SYSTEM LIVE</p></div>';
});
add_shortcode('ccjvu_shell', function(){
    return do_shortcode('[ccjvx_shell]');
});

/* ERP COMPAT */
define('CCJV_CORE_ACTIVE', true);
function ccjv_core_loaded(){ return true; }

/* VAULT HASH */
function ccjvx_hash_file($file){
    return hash_file('sha256',$file);
}
