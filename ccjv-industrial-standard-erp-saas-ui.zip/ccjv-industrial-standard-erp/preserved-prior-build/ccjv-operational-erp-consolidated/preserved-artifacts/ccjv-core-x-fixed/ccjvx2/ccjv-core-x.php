<?php
/**
 * Plugin Name: CCJV Unified Core X
 * Description: Stable install package.
 * Version: 1.0.1
 */
if (!defined('ABSPATH')) exit;
add_action('admin_menu', function(){
 add_menu_page('CCJV Core X','CCJV Core X','manage_options','ccjvx',function(){
  echo '<h1>CCJV Core X Running</h1>';
 });
});
add_shortcode('ccjvx_shell', fn()=>'<div>Core X Shell</div>');
