CCJV Vault Avalanche Anchor

Shortcodes:
[ccjv_vault]
[ccjv_vault_records]

Purpose:
- Store actual files on your server
- Generate SHA-256 and SHA3-256 hashes
- Anchor proof hashes on Avalanche using MetaMask
- Verify file records in WordPress
- Reuse the same vault engine for CCJV core and sector ERP plugins

How sector plugins integrate:
- use filter ccjv_registered_workspaces to register a workspace slug/name
- use shortcode attributes to pass workspace/module/entity context

Example:
[ccjv_vault workspace="constructum" module="projects" entity_type="project" entity_id="123" file_group="drawings"]
