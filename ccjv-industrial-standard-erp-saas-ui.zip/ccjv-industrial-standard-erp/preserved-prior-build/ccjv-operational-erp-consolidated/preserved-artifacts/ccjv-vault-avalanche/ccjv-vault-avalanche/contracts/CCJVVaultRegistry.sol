// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

contract CCJVVaultRegistry {
    struct VaultRecord {
        bool exists;
        bytes32 fileHash;
        bytes32 fileIdHash;
        bytes32 workspaceHash;
        bytes32 metadataHash;
        address anchoredBy;
        uint256 anchoredAt;
    }

    mapping(bytes32 => VaultRecord) public records;

    event FileAnchored(
        bytes32 indexed fileHash,
        bytes32 indexed fileIdHash,
        bytes32 indexed workspaceHash,
        bytes32 metadataHash,
        address anchoredBy,
        uint256 anchoredAt
    );

    function anchor(bytes32 fileHash, bytes32 fileIdHash, bytes32 workspaceHash, bytes32 metadataHash) external {
        require(fileHash != bytes32(0), "Invalid file hash");
        require(!records[fileHash].exists, "Already anchored");

        records[fileHash] = VaultRecord({
            exists: true,
            fileHash: fileHash,
            fileIdHash: fileIdHash,
            workspaceHash: workspaceHash,
            metadataHash: metadataHash,
            anchoredBy: msg.sender,
            anchoredAt: block.timestamp
        });

        emit FileAnchored(fileHash, fileIdHash, workspaceHash, metadataHash, msg.sender, block.timestamp);
    }

    function verify(bytes32 fileHash) external view returns (
        bool exists,
        bytes32 fileIdHash,
        bytes32 workspaceHash,
        bytes32 metadataHash,
        address anchoredBy,
        uint256 anchoredAt
    ) {
        VaultRecord memory r = records[fileHash];
        return (r.exists, r.fileIdHash, r.workspaceHash, r.metadataHash, r.anchoredBy, r.anchoredAt);
    }
}
