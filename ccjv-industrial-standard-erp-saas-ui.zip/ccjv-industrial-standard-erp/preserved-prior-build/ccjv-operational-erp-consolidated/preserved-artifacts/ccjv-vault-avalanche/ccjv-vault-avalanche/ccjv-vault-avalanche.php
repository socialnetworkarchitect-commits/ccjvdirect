<?php
/*
Plugin Name: CCJV Vault Avalanche Anchor
Description: Server-side file vault with hash generation, Avalanche anchoring, verification UI, and sector plugin compatibility for CCJV.
Version: 1.0.0
Author: OpenAI
*/
if (!defined('ABSPATH')) exit;

class CCJV_Vault_Avalanche {
    const OPT_KEY = 'ccjv_vault_settings';
    const NONCE = 'ccjv_vault_nonce';
    const CAP = 'upload_files';

    public function __construct() {
        register_activation_hook(__FILE__, [$this, 'activate']);
        add_action('admin_menu', [$this, 'admin_menu']);
        add_action('admin_init', [$this, 'register_settings']);
        add_action('admin_enqueue_scripts', [$this, 'admin_assets']);
        add_action('wp_enqueue_scripts', [$this, 'frontend_assets']);
        add_action('rest_api_init', [$this, 'rest_routes']);
        add_shortcode('ccjv_vault', [$this, 'render_frontend']);
        add_shortcode('ccjv_vault_records', [$this, 'render_records']);
        add_filter('ccjv_registered_workspaces', [$this, 'default_workspaces']);
    }

    public function activate() {
        global $wpdb;
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        $charset = $wpdb->get_charset_collate();
        $table = $wpdb->prefix . 'ccjv_vault_files';
        $table_events = $wpdb->prefix . 'ccjv_vault_events';
        dbDelta("CREATE TABLE {$table} (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            workspace_slug VARCHAR(80) NOT NULL DEFAULT 'core',
            module_slug VARCHAR(80) NOT NULL DEFAULT 'vault',
            entity_type VARCHAR(80) NOT NULL DEFAULT 'general',
            entity_id VARCHAR(120) NOT NULL DEFAULT '',
            file_group VARCHAR(80) NOT NULL DEFAULT 'general',
            original_filename VARCHAR(255) NOT NULL,
            stored_filename VARCHAR(255) NOT NULL,
            mime_type VARCHAR(120) NOT NULL DEFAULT '',
            file_ext VARCHAR(20) NOT NULL DEFAULT '',
            file_size BIGINT UNSIGNED NOT NULL DEFAULT 0,
            relative_path TEXT NOT NULL,
            sha256_hash CHAR(64) NOT NULL,
            sha3_hash CHAR(64) NOT NULL,
            file_id_hash CHAR(64) NOT NULL,
            metadata_hash CHAR(64) NOT NULL,
            version_no INT NOT NULL DEFAULT 1,
            wallet_address VARCHAR(80) NOT NULL DEFAULT '',
            chain_id VARCHAR(20) NOT NULL DEFAULT '43114',
            contract_address VARCHAR(80) NOT NULL DEFAULT '',
            tx_hash VARCHAR(100) NOT NULL DEFAULT '',
            tx_status VARCHAR(20) NOT NULL DEFAULT 'pending',
            anchored_at DATETIME NULL,
            created_by BIGINT UNSIGNED NULL,
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME NULL,
            PRIMARY KEY(id),
            UNIQUE KEY sha256_hash (sha256_hash),
            KEY workspace_slug (workspace_slug),
            KEY entity (entity_type, entity_id),
            KEY tx_hash (tx_hash)
        ) {$charset};");
        dbDelta("CREATE TABLE {$table_events} (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            vault_file_id BIGINT UNSIGNED NOT NULL,
            event_type VARCHAR(60) NOT NULL,
            event_data LONGTEXT NULL,
            created_by BIGINT UNSIGNED NULL,
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY(id),
            KEY vault_file_id (vault_file_id)
        ) {$charset};");

        if (!get_option(self::OPT_KEY)) {
            $upload = wp_upload_dir();
            update_option(self::OPT_KEY, [
                'vault_root' => trailingslashit($upload['basedir']) . 'ccjv-vault',
                'max_upload_mb' => 64,
                'allowed_extensions' => 'pdf,doc,docx,xls,xlsx,csv,jpg,jpeg,png,webp,mp4,mp3,txt,zip',
                'chain_id_hex' => '0xa86a',
                'chain_id_dec' => '43114',
                'chain_name' => 'Avalanche C-Chain',
                'rpc_url' => 'https://api.avax.network/ext/bc/C/rpc',
                'explorer_url' => 'https://snowtrace.io',
                'contract_address' => '',
                'default_workspace' => 'core',
                'default_module' => 'vault',
                'verification_message' => 'CCJV Vault Anchor Verification',
                'public_downloads' => 0,
            ]);
        }
    }

    public function settings() {
        $defaults = [
            'vault_root' => '', 'max_upload_mb' => 64, 'allowed_extensions' => 'pdf,doc,docx,xls,xlsx,csv,jpg,jpeg,png,webp,mp4,mp3,txt,zip',
            'chain_id_hex' => '0xa86a', 'chain_id_dec' => '43114', 'chain_name' => 'Avalanche C-Chain', 'rpc_url' => 'https://api.avax.network/ext/bc/C/rpc',
            'explorer_url' => 'https://snowtrace.io', 'contract_address' => '', 'default_workspace' => 'core', 'default_module' => 'vault',
            'verification_message' => 'CCJV Vault Anchor Verification', 'public_downloads' => 0,
        ];
        return wp_parse_args(get_option(self::OPT_KEY, []), $defaults);
    }

    public function admin_menu() {
        add_menu_page('CCJV Vault', 'CCJV Vault', 'manage_options', 'ccjv-vault', [$this, 'settings_page'], 'dashicons-shield-alt', 26);
        add_submenu_page('ccjv-vault', 'Settings', 'Settings', 'manage_options', 'ccjv-vault', [$this, 'settings_page']);
        add_submenu_page('ccjv-vault', 'Files', 'Files', 'upload_files', 'ccjv-vault-files', [$this, 'files_page']);
        add_submenu_page('ccjv-vault', 'Verification', 'Verification', 'upload_files', 'ccjv-vault-verify', [$this, 'verify_page']);
        add_submenu_page('ccjv-vault', 'Contract', 'Contract', 'manage_options', 'ccjv-vault-contract', [$this, 'contract_page']);
    }

    public function register_settings() {
        register_setting('ccjv_vault_group', self::OPT_KEY, [$this, 'sanitize_settings']);
    }

    public function sanitize_settings($input) {
        $out = $this->settings();
        foreach (['vault_root','allowed_extensions','chain_id_hex','chain_id_dec','chain_name','rpc_url','explorer_url','contract_address','default_workspace','default_module','verification_message'] as $key) {
            if (isset($input[$key])) $out[$key] = sanitize_text_field($input[$key]);
        }
        if (isset($input['max_upload_mb'])) $out['max_upload_mb'] = max(1, intval($input['max_upload_mb']));
        $out['public_downloads'] = !empty($input['public_downloads']) ? 1 : 0;
        return $out;
    }

    public function admin_assets($hook) {
        if (strpos($hook, 'ccjv-vault') === false) return;
        wp_enqueue_style('ccjv-vault-admin', plugin_dir_url(__FILE__) . 'assets/css/ccjv-vault.css', [], '1.0.0');
    }

    public function frontend_assets() {
        wp_enqueue_style('ccjv-vault-style', plugin_dir_url(__FILE__) . 'assets/css/ccjv-vault.css', [], '1.0.0');
        wp_enqueue_script('ethers', 'https://cdn.jsdelivr.net/npm/ethers@6.13.4/dist/ethers.umd.min.js', [], '6.13.4', true);
        wp_enqueue_script('ccjv-vault-js', plugin_dir_url(__FILE__) . 'assets/js/ccjv-vault.js', ['ethers'], '1.0.0', true);
        wp_localize_script('ccjv-vault-js', 'CCJVVault', [
            'restUrl' => esc_url_raw(rest_url('ccjv-vault/v1/')),
            'nonce' => wp_create_nonce('wp_rest'),
            'chainIdHex' => $this->settings()['chain_id_hex'],
            'chainName' => $this->settings()['chain_name'],
            'rpcUrl' => $this->settings()['rpc_url'],
            'explorerUrl' => $this->settings()['explorer_url'],
            'contractAddress' => $this->settings()['contract_address'],
            'verificationMessage' => $this->settings()['verification_message'],
            'contractAbi' => [
                'function anchor(bytes32 fileHash, bytes32 fileIdHash, bytes32 workspaceHash, bytes32 metadataHash)',
                'function verify(bytes32 fileHash) view returns (bool exists, bytes32 fileIdHash, bytes32 workspaceHash, bytes32 metadataHash, address anchoredBy, uint256 anchoredAt)'
            ],
        ]);
    }

    public function rest_routes() {
        register_rest_route('ccjv-vault/v1', '/upload', [
            'methods' => 'POST',
            'callback' => [$this, 'api_upload'],
            'permission_callback' => function() { return is_user_logged_in(); }
        ]);
        register_rest_route('ccjv-vault/v1', '/record/(?P<id>\d+)', [
            'methods' => 'GET',
            'callback' => [$this, 'api_get_record'],
            'permission_callback' => function() { return is_user_logged_in(); }
        ]);
        register_rest_route('ccjv-vault/v1', '/anchor', [
            'methods' => 'POST',
            'callback' => [$this, 'api_save_anchor'],
            'permission_callback' => function() { return is_user_logged_in(); }
        ]);
        register_rest_route('ccjv-vault/v1', '/verify/(?P<hash>[a-fA-F0-9]{64})', [
            'methods' => 'GET',
            'callback' => [$this, 'api_verify'],
            'permission_callback' => '__return_true'
        ]);
        register_rest_route('ccjv-vault/v1', '/download/(?P<id>\d+)', [
            'methods' => 'GET',
            'callback' => [$this, 'api_download'],
            'permission_callback' => [$this, 'can_download']
        ]);
    }

    public function can_download($request) {
        $s = $this->settings();
        return !empty($s['public_downloads']) || is_user_logged_in();
    }

    private function normalize_workspace($workspace) {
        $workspace = sanitize_key($workspace ?: $this->settings()['default_workspace']);
        return $workspace ?: 'core';
    }

    private function allowed_exts() {
        return array_filter(array_map('trim', explode(',', strtolower($this->settings()['allowed_extensions']))));
    }

    private function ensure_dir($path) {
        if (!file_exists($path)) wp_mkdir_p($path);
        return is_dir($path);
    }

    private function build_storage_path($workspace, $entity_type, $entity_id, $group) {
        $root = untrailingslashit($this->settings()['vault_root']);
        $parts = [$root, sanitize_key($workspace), sanitize_key($entity_type), sanitize_file_name($entity_id ?: 'general'), sanitize_key($group ?: 'general')];
        $path = join(DIRECTORY_SEPARATOR, $parts);
        $this->ensure_dir($path);
        return $path;
    }

    private function compute_metadata_hash($meta) {
        return hash('sha256', wp_json_encode($meta));
    }

    private function event_log($file_id, $type, $data = null) {
        global $wpdb;
        $wpdb->insert($wpdb->prefix.'ccjv_vault_events', [
            'vault_file_id' => intval($file_id),
            'event_type' => sanitize_key($type),
            'event_data' => $data ? wp_json_encode($data) : null,
            'created_by' => get_current_user_id() ?: null,
        ]);
    }

    public function api_upload(WP_REST_Request $request) {
        if (empty($_FILES['file'])) {
            return new WP_REST_Response(['success'=>false,'message'=>'No file uploaded.'], 400);
        }
        $file = $_FILES['file'];
        if (!empty($file['error'])) {
            return new WP_REST_Response(['success'=>false,'message'=>'Upload error code '.$file['error']], 400);
        }
        $max = intval($this->settings()['max_upload_mb']) * 1024 * 1024;
        if ($file['size'] > $max) {
            return new WP_REST_Response(['success'=>false,'message'=>'File exceeds max upload size.'], 400);
        }
        $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
        if (!in_array($ext, $this->allowed_exts(), true)) {
            return new WP_REST_Response(['success'=>false,'message'=>'File type not allowed.'], 400);
        }

        $workspace = $this->normalize_workspace($request->get_param('workspace_slug'));
        $module = sanitize_key($request->get_param('module_slug') ?: $this->settings()['default_module']);
        $entity_type = sanitize_key($request->get_param('entity_type') ?: 'general');
        $entity_id = sanitize_text_field($request->get_param('entity_id') ?: 'general');
        $group = sanitize_key($request->get_param('file_group') ?: 'general');
        $wallet = sanitize_text_field($request->get_param('wallet_address') ?: '');

        $target_dir = $this->build_storage_path($workspace, $entity_type, $entity_id, $group);
        $safe_name = sanitize_file_name(wp_unique_filename($target_dir, $file['name']));
        $target = trailingslashit($target_dir) . $safe_name;

        if (!move_uploaded_file($file['tmp_name'], $target)) {
            return new WP_REST_Response(['success'=>false,'message'=>'Failed to move file into vault.'], 500);
        }

        $bytes = file_get_contents($target);
        $sha256 = hash('sha256', $bytes);
        $sha3 = in_array('sha3-256', hash_algos(), true) ? hash('sha3-256', $bytes) : hash('sha256', $bytes);
        $relative = ltrim(str_replace(untrailingslashit($this->settings()['vault_root']), '', $target), DIRECTORY_SEPARATOR);
        $meta = [
            'workspace_slug' => $workspace,
            'module_slug' => $module,
            'entity_type' => $entity_type,
            'entity_id' => $entity_id,
            'file_group' => $group,
            'original_filename' => $file['name'],
            'stored_filename' => $safe_name,
            'file_size' => filesize($target),
            'mime_type' => mime_content_type($target) ?: '',
        ];
        $fileIdHash = hash('sha256', $workspace.'|'.$module.'|'.$entity_type.'|'.$entity_id.'|'.$safe_name.'|'.$sha256);
        $metaHash = $this->compute_metadata_hash($meta);

        global $wpdb;
        $wpdb->insert($wpdb->prefix.'ccjv_vault_files', [
            'workspace_slug' => $workspace,
            'module_slug' => $module,
            'entity_type' => $entity_type,
            'entity_id' => $entity_id,
            'file_group' => $group,
            'original_filename' => sanitize_file_name($file['name']),
            'stored_filename' => $safe_name,
            'mime_type' => $meta['mime_type'],
            'file_ext' => $ext,
            'file_size' => filesize($target),
            'relative_path' => $relative,
            'sha256_hash' => $sha256,
            'sha3_hash' => $sha3,
            'file_id_hash' => $fileIdHash,
            'metadata_hash' => $metaHash,
            'wallet_address' => $wallet,
            'chain_id' => $this->settings()['chain_id_dec'],
            'contract_address' => $this->settings()['contract_address'],
            'tx_status' => 'pending',
            'created_by' => get_current_user_id(),
        ]);
        $id = $wpdb->insert_id;
        $this->event_log($id, 'uploaded', ['sha256'=>$sha256, 'sha3'=>$sha3]);

        return new WP_REST_Response([
            'success' => true,
            'record' => [
                'id' => $id,
                'workspace_slug' => $workspace,
                'module_slug' => $module,
                'entity_type' => $entity_type,
                'entity_id' => $entity_id,
                'file_group' => $group,
                'original_filename' => sanitize_file_name($file['name']),
                'file_size' => filesize($target),
                'sha256_hash' => $sha256,
                'sha3_hash' => $sha3,
                'file_id_hash' => $fileIdHash,
                'metadata_hash' => $metaHash,
                'contract_address' => $this->settings()['contract_address'],
                'chain_id_hex' => $this->settings()['chain_id_hex'],
                'download_url' => rest_url('ccjv-vault/v1/download/'.$id),
            ]
        ]);
    }

    public function api_get_record(WP_REST_Request $request) {
        global $wpdb;
        $row = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$wpdb->prefix}ccjv_vault_files WHERE id=%d", intval($request['id'])), ARRAY_A);
        if (!$row) return new WP_REST_Response(['success'=>false,'message'=>'Record not found.'], 404);
        $row['download_url'] = rest_url('ccjv-vault/v1/download/'.$row['id']);
        return new WP_REST_Response(['success'=>true,'record'=>$row]);
    }

    public function api_save_anchor(WP_REST_Request $request) {
        global $wpdb;
        $id = intval($request->get_param('id'));
        $tx = sanitize_text_field($request->get_param('tx_hash'));
        $wallet = sanitize_text_field($request->get_param('wallet_address'));
        if (!$id || !$tx) return new WP_REST_Response(['success'=>false,'message'=>'Missing id or tx hash.'], 400);
        $updated = $wpdb->update($wpdb->prefix.'ccjv_vault_files', [
            'tx_hash' => $tx,
            'wallet_address' => $wallet,
            'tx_status' => 'anchored',
            'anchored_at' => current_time('mysql'),
            'updated_at' => current_time('mysql'),
        ], ['id'=>$id]);
        if ($updated === false) return new WP_REST_Response(['success'=>false,'message'=>'Failed to save anchor.'], 500);
        $this->event_log($id, 'anchored', ['tx_hash'=>$tx,'wallet_address'=>$wallet]);
        return new WP_REST_Response(['success'=>true]);
    }

    public function api_verify(WP_REST_Request $request) {
        global $wpdb;
        $hash = strtolower($request['hash']);
        $row = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$wpdb->prefix}ccjv_vault_files WHERE sha256_hash=%s OR sha3_hash=%s", $hash, $hash), ARRAY_A);
        if (!$row) return new WP_REST_Response(['success'=>false,'found'=>false], 404);
        $row['download_url'] = rest_url('ccjv-vault/v1/download/'.$row['id']);
        return new WP_REST_Response(['success'=>true,'found'=>true,'record'=>$row]);
    }

    public function api_download(WP_REST_Request $request) {
        global $wpdb;
        $row = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$wpdb->prefix}ccjv_vault_files WHERE id=%d", intval($request['id'])), ARRAY_A);
        if (!$row) return new WP_Error('not_found', 'File not found.', ['status'=>404]);
        $path = trailingslashit(untrailingslashit($this->settings()['vault_root'])) . ltrim($row['relative_path'], '/');
        if (!file_exists($path)) return new WP_Error('not_found', 'Stored file missing.', ['status'=>404]);
        $this->event_log($row['id'], 'downloaded', ['user_id'=>get_current_user_id() ?: 0]);
        nocache_headers();
        header('Content-Type: ' . ($row['mime_type'] ?: 'application/octet-stream'));
        header('Content-Length: ' . filesize($path));
        header('Content-Disposition: attachment; filename="' . basename($row['original_filename']) . '"');
        readfile($path);
        exit;
    }

    public function default_workspaces($workspaces) {
        if (!is_array($workspaces)) $workspaces = [];
        $workspaces['core'] = 'CCJV Core';
        return $workspaces;
    }

    private function get_registered_workspaces() {
        $workspaces = apply_filters('ccjv_registered_workspaces', []);
        if (empty($workspaces)) {
            $workspaces = [
                'core' => 'CCJV Core',
                'constructum' => 'Constructum',
                'energychain' => 'EnergyChain',
                'landbank' => 'LandBank',
            ];
        }
        return $workspaces;
    }

    public function settings_page() {
        $s = $this->settings();
        ?>
        <div class="wrap ccjv-vault-admin-wrap">
            <h1>CCJV Vault Settings</h1>
            <form method="post" action="options.php">
                <?php settings_fields('ccjv_vault_group'); ?>
                <table class="form-table" role="presentation">
                    <tr><th>Vault Root</th><td><input class="large-text" type="text" name="<?php echo esc_attr(self::OPT_KEY); ?>[vault_root]" value="<?php echo esc_attr($s['vault_root']); ?>"><p class="description">Actual files are stored here on your server.</p></td></tr>
                    <tr><th>Max Upload MB</th><td><input type="number" min="1" name="<?php echo esc_attr(self::OPT_KEY); ?>[max_upload_mb]" value="<?php echo esc_attr($s['max_upload_mb']); ?>"></td></tr>
                    <tr><th>Allowed Extensions</th><td><input class="large-text" type="text" name="<?php echo esc_attr(self::OPT_KEY); ?>[allowed_extensions]" value="<?php echo esc_attr($s['allowed_extensions']); ?>"></td></tr>
                    <tr><th>Public Downloads</th><td><label><input type="checkbox" name="<?php echo esc_attr(self::OPT_KEY); ?>[public_downloads]" value="1" <?php checked($s['public_downloads'],1); ?>> Allow anonymous downloads via REST URL</label></td></tr>
                </table>
                <h2>Avalanche</h2>
                <table class="form-table" role="presentation">
                    <tr><th>Chain ID Hex</th><td><input type="text" name="<?php echo esc_attr(self::OPT_KEY); ?>[chain_id_hex]" value="<?php echo esc_attr($s['chain_id_hex']); ?>"></td></tr>
                    <tr><th>Chain ID Dec</th><td><input type="text" name="<?php echo esc_attr(self::OPT_KEY); ?>[chain_id_dec]" value="<?php echo esc_attr($s['chain_id_dec']); ?>"></td></tr>
                    <tr><th>Chain Name</th><td><input class="regular-text" type="text" name="<?php echo esc_attr(self::OPT_KEY); ?>[chain_name]" value="<?php echo esc_attr($s['chain_name']); ?>"></td></tr>
                    <tr><th>RPC URL</th><td><input class="large-text" type="text" name="<?php echo esc_attr(self::OPT_KEY); ?>[rpc_url]" value="<?php echo esc_attr($s['rpc_url']); ?>"></td></tr>
                    <tr><th>Explorer URL</th><td><input class="large-text" type="text" name="<?php echo esc_attr(self::OPT_KEY); ?>[explorer_url]" value="<?php echo esc_attr($s['explorer_url']); ?>"></td></tr>
                    <tr><th>Contract Address</th><td><input class="regular-text" type="text" name="<?php echo esc_attr(self::OPT_KEY); ?>[contract_address]" value="<?php echo esc_attr($s['contract_address']); ?>"><p class="description">Deploy the included contract, then paste the address here.</p></td></tr>
                    <tr><th>Verification Message</th><td><input class="large-text" type="text" name="<?php echo esc_attr(self::OPT_KEY); ?>[verification_message]" value="<?php echo esc_attr($s['verification_message']); ?>"></td></tr>
                </table>
                <h2>Defaults</h2>
                <table class="form-table"><tr><th>Default Workspace</th><td><input type="text" name="<?php echo esc_attr(self::OPT_KEY); ?>[default_workspace]" value="<?php echo esc_attr($s['default_workspace']); ?>"></td></tr><tr><th>Default Module</th><td><input type="text" name="<?php echo esc_attr(self::OPT_KEY); ?>[default_module]" value="<?php echo esc_attr($s['default_module']); ?>"></td></tr></table>
                <?php submit_button('Save Vault Settings'); ?>
            </form>
        </div>
        <?php
    }

    public function files_page() {
        global $wpdb;
        $rows = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}ccjv_vault_files ORDER BY id DESC LIMIT 200", ARRAY_A);
        ?>
        <div class="wrap ccjv-vault-admin-wrap"><h1>CCJV Vault Files</h1>
        <p>Use shortcode <code>[ccjv_vault]</code> on a page to upload and anchor files.</p>
        <table class="widefat striped"><thead><tr><th>ID</th><th>Workspace</th><th>Entity</th><th>File</th><th>SHA-256</th><th>Status</th><th>Tx</th><th>Download</th></tr></thead><tbody>
        <?php foreach ($rows as $r): ?>
            <tr>
                <td><?php echo intval($r['id']); ?></td>
                <td><?php echo esc_html($r['workspace_slug']); ?></td>
                <td><?php echo esc_html($r['entity_type'] . ':' . $r['entity_id']); ?></td>
                <td><?php echo esc_html($r['original_filename']); ?></td>
                <td><code><?php echo esc_html(substr($r['sha256_hash'],0,16).'...'); ?></code></td>
                <td><span class="ccjv-pill ccjv-pill-<?php echo esc_attr($r['tx_status']); ?>"><?php echo esc_html($r['tx_status']); ?></span></td>
                <td><?php if ($r['tx_hash']) echo '<code>'.esc_html(substr($r['tx_hash'],0,18)).'...</code>'; ?></td>
                <td><a class="button button-secondary" href="<?php echo esc_url(rest_url('ccjv-vault/v1/download/'.$r['id'])); ?>">Download</a></td>
            </tr>
        <?php endforeach; ?>
        </tbody></table></div><?php
    }

    public function verify_page() {
        ?>
        <div class="wrap ccjv-vault-admin-wrap"><h1>Vault Verification</h1>
        <form method="get">
            <input type="hidden" name="page" value="ccjv-vault-verify">
            <input class="large-text" type="text" name="hash" value="<?php echo esc_attr($_GET['hash'] ?? ''); ?>" placeholder="Paste SHA-256 or SHA3 hash">
            <?php submit_button('Verify', 'primary', '', false); ?>
        </form>
        <?php
        if (!empty($_GET['hash'])) {
            global $wpdb;
            $hash = sanitize_text_field($_GET['hash']);
            $row = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$wpdb->prefix}ccjv_vault_files WHERE sha256_hash=%s OR sha3_hash=%s", $hash, $hash), ARRAY_A);
            if ($row) {
                echo '<div class="notice notice-success"><p>Record found in server vault.</p></div>';
                echo '<table class="widefat striped"><tbody>';
                foreach ($row as $k => $v) echo '<tr><th>'.esc_html($k).'</th><td><code>'.esc_html((string)$v).'</code></td></tr>';
                echo '</tbody></table>';
            } else {
                echo '<div class="notice notice-error"><p>No server-vault record found for that hash.</p></div>';
            }
        }
        echo '</div>';
    }

    public function contract_page() {
        $contract = file_get_contents(plugin_dir_path(__FILE__) . 'contracts/CCJVVaultRegistry.sol');
        ?>
        <div class="wrap ccjv-vault-admin-wrap">
            <h1>CCJV Vault Contract</h1>
            <p>Deploy this contract to Avalanche C-Chain, then paste the deployed address into Vault Settings.</p>
            <h2>Methods used by the plugin</h2>
            <ul>
                <li><code>anchor(bytes32 fileHash, bytes32 fileIdHash, bytes32 workspaceHash, bytes32 metadataHash)</code></li>
                <li><code>verify(bytes32 fileHash)</code></li>
            </ul>
            <textarea class="large-text code" rows="28" readonly><?php echo esc_textarea($contract); ?></textarea>
        </div>
        <?php
    }

    public function render_frontend($atts) {
        if (!is_user_logged_in()) return '<div class="ccjv-vault-wrap"><p>Please log in to use the vault.</p></div>';
        $a = shortcode_atts([
            'workspace' => $this->settings()['default_workspace'],
            'module' => $this->settings()['default_module'],
            'entity_type' => 'general',
            'entity_id' => 'general',
            'file_group' => 'general',
        ], $atts);
        $workspaces = $this->get_registered_workspaces();
        ob_start(); ?>
        <div class="ccjv-vault-wrap" data-default-workspace="<?php echo esc_attr($a['workspace']); ?>" data-default-module="<?php echo esc_attr($a['module']); ?>" data-default-entity-type="<?php echo esc_attr($a['entity_type']); ?>" data-default-entity-id="<?php echo esc_attr($a['entity_id']); ?>" data-default-file-group="<?php echo esc_attr($a['file_group']); ?>">
            <div class="ccjv-vault-card">
                <div class="ccjv-vault-head"><h3>CCJV Vault Upload</h3><span class="ccjv-vault-status" id="ccjv-wallet-status">Wallet not connected</span></div>
                <div class="ccjv-vault-grid">
                    <label>Workspace<select id="ccjv-workspace"><?php foreach ($workspaces as $slug=>$name): ?><option value="<?php echo esc_attr($slug); ?>" <?php selected($slug,$a['workspace']); ?>><?php echo esc_html($name); ?></option><?php endforeach; ?></select></label>
                    <label>Module<input type="text" id="ccjv-module" value="<?php echo esc_attr($a['module']); ?>"></label>
                    <label>Entity Type<input type="text" id="ccjv-entity-type" value="<?php echo esc_attr($a['entity_type']); ?>"></label>
                    <label>Entity ID<input type="text" id="ccjv-entity-id" value="<?php echo esc_attr($a['entity_id']); ?>"></label>
                    <label>File Group<input type="text" id="ccjv-file-group" value="<?php echo esc_attr($a['file_group']); ?>"></label>
                    <label>Wallet Address<input type="text" id="ccjv-wallet-address" readonly></label>
                </div>
                <div class="ccjv-vault-actions">
                    <button type="button" class="button button-primary" id="ccjv-connect-wallet">Connect MetaMask</button>
                    <input type="file" id="ccjv-file-input">
                    <button type="button" class="button button-secondary" id="ccjv-upload-file">Upload to Server Vault</button>
                </div>
                <div id="ccjv-upload-result" class="ccjv-vault-result"></div>
                <div id="ccjv-anchor-panel" class="ccjv-vault-anchor hidden">
                    <h4>Anchor file hash on Avalanche</h4>
                    <p>After upload, click below to write the hash proof to your configured Avalanche contract using MetaMask.</p>
                    <button type="button" class="button button-primary" id="ccjv-anchor-file">Anchor Hash On-Chain</button>
                    <div id="ccjv-anchor-result" class="ccjv-vault-result"></div>
                </div>
            </div>
        </div>
        <?php return ob_get_clean();
    }

    public function render_records($atts) {
        global $wpdb;
        $a = shortcode_atts(['workspace'=>'','entity_type'=>'','entity_id'=>''], $atts);
        $where = '1=1'; $params = [];
        if ($a['workspace']) { $where .= ' AND workspace_slug=%s'; $params[] = sanitize_key($a['workspace']); }
        if ($a['entity_type']) { $where .= ' AND entity_type=%s'; $params[] = sanitize_key($a['entity_type']); }
        if ($a['entity_id']) { $where .= ' AND entity_id=%s'; $params[] = sanitize_text_field($a['entity_id']); }
        $sql = "SELECT * FROM {$wpdb->prefix}ccjv_vault_files WHERE {$where} ORDER BY id DESC LIMIT 100";
        $rows = $params ? $wpdb->get_results($wpdb->prepare($sql, $params), ARRAY_A) : $wpdb->get_results($sql, ARRAY_A);
        ob_start();
        echo '<div class="ccjv-vault-records"><table><thead><tr><th>File</th><th>Workspace</th><th>Entity</th><th>Status</th><th>Hash</th><th>Download</th></tr></thead><tbody>';
        foreach ($rows as $r) {
            echo '<tr><td>'.esc_html($r['original_filename']).'</td><td>'.esc_html($r['workspace_slug']).'</td><td>'.esc_html($r['entity_type'].':'.$r['entity_id']).'</td><td>'.esc_html($r['tx_status']).'</td><td><code>'.esc_html(substr($r['sha256_hash'],0,14)).'...</code></td><td><a href="'.esc_url(rest_url('ccjv-vault/v1/download/'.$r['id'])).'">Download</a></td></tr>';
        }
        echo '</tbody></table></div>';
        return ob_get_clean();
    }
}

new CCJV_Vault_Avalanche();
