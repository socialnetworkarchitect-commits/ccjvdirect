(function(){
  const $ = (s) => document.querySelector(s);
  let currentRecord = null;
  let walletAddress = '';

  async function sha256Hex(text){
    const data = new TextEncoder().encode(text);
    const hash = await crypto.subtle.digest('SHA-256', data);
    return Array.from(new Uint8Array(hash)).map(b=>b.toString(16).padStart(2,'0')).join('');
  }

  async function ensureWallet(){
    if(!window.ethereum){ alert('MetaMask is required.'); return false; }
    try {
      await window.ethereum.request({ method:'wallet_switchEthereumChain', params:[{ chainId: CCJVVault.chainIdHex }] });
    } catch(e) {
      try {
        await window.ethereum.request({ method:'wallet_addEthereumChain', params:[{ chainId: CCJVVault.chainIdHex, chainName: CCJVVault.chainName, rpcUrls:[CCJVVault.rpcUrl], nativeCurrency:{name:'AVAX',symbol:'AVAX',decimals:18}, blockExplorerUrls:[CCJVVault.explorerUrl] }] });
      } catch(addErr) {}
    }
    return true;
  }

  async function connectWallet(){
    if(!await ensureWallet()) return;
    const accounts = await window.ethereum.request({ method:'eth_requestAccounts' });
    walletAddress = accounts[0] || '';
    if ($('#ccjv-wallet-address')) $('#ccjv-wallet-address').value = walletAddress;
    if ($('#ccjv-wallet-status')) $('#ccjv-wallet-status').textContent = walletAddress ? 'Connected: ' + walletAddress.slice(0,6) + '...' + walletAddress.slice(-4) : 'Wallet not connected';
    try {
      await window.ethereum.request({ method:'personal_sign', params:[CCJVVault.verificationMessage, walletAddress] });
    } catch(e) {}
  }

  async function uploadFile(){
    const file = $('#ccjv-file-input')?.files?.[0];
    if(!file){ alert('Choose a file first.'); return; }
    const fd = new FormData();
    fd.append('file', file);
    fd.append('workspace_slug', $('#ccjv-workspace').value);
    fd.append('module_slug', $('#ccjv-module').value);
    fd.append('entity_type', $('#ccjv-entity-type').value);
    fd.append('entity_id', $('#ccjv-entity-id').value);
    fd.append('file_group', $('#ccjv-file-group').value);
    fd.append('wallet_address', $('#ccjv-wallet-address').value || '');

    const res = await fetch(CCJVVault.restUrl + 'upload', {
      method:'POST',
      headers:{ 'X-WP-Nonce': CCJVVault.nonce },
      body: fd
    });
    const json = await res.json();
    const box = $('#ccjv-upload-result');
    if(!json.success){ box.innerHTML = '<div class="ccjv-error">' + (json.message || 'Upload failed') + '</div>'; return; }
    currentRecord = json.record;
    box.innerHTML = '<div class="ccjv-success"><strong>Stored on server vault.</strong><br>SHA-256: <code>' + currentRecord.sha256_hash + '</code><br>Record ID: ' + currentRecord.id + '</div>';
    $('#ccjv-anchor-panel').classList.remove('hidden');
  }

  async function anchorFile(){
    if(!currentRecord){ alert('Upload a file first.'); return; }
    if(!walletAddress){ await connectWallet(); if(!walletAddress) return; }
    if(!CCJVVault.contractAddress){ alert('Set the contract address in CCJV Vault settings first.'); return; }
    if(typeof ethers === 'undefined'){ alert('Ethers library failed to load.'); return; }

    const provider = new ethers.BrowserProvider(window.ethereum);
    const signer = await provider.getSigner();
    const contract = new ethers.Contract(CCJVVault.contractAddress, CCJVVault.contractAbi, signer);
    const workspaceHash = '0x' + await sha256Hex($('#ccjv-workspace').value || 'core');
    const tx = await contract.anchor('0x' + currentRecord.sha256_hash, '0x' + currentRecord.file_id_hash, workspaceHash, '0x' + currentRecord.metadata_hash);

    await fetch(CCJVVault.restUrl + 'anchor', {
      method:'POST',
      headers:{ 'Content-Type':'application/json', 'X-WP-Nonce': CCJVVault.nonce },
      body: JSON.stringify({ id: currentRecord.id, tx_hash: tx.hash, wallet_address: walletAddress })
    });

    const box = $('#ccjv-anchor-result');
    box.innerHTML = '<div class="ccjv-success"><strong>Anchored on Avalanche.</strong><br>Tx: <code>' + tx.hash + '</code></div>';
  }

  document.addEventListener('DOMContentLoaded', function(){
    const connectBtn = $('#ccjv-connect-wallet');
    const uploadBtn = $('#ccjv-upload-file');
    const anchorBtn = $('#ccjv-anchor-file');
    if (connectBtn) connectBtn.addEventListener('click', connectWallet);
    if (uploadBtn) uploadBtn.addEventListener('click', uploadFile);
    if (anchorBtn) anchorBtn.addEventListener('click', anchorFile);
  });
})();
