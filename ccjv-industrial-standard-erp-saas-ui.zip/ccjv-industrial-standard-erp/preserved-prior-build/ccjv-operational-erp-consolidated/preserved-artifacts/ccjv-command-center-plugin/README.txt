CCJV Command Center Plugin

Deploy this plugin on:
- ccjv.ca

Purpose:
- master operational dashboard for the 39-site token-gated ERP network

What it includes:
- treasury KPI cards
- active sessions / verified wallets / failed verifications
- sector site registry
- token matrix
- ERP access tier matrix
- system health panel
- editable JSON-driven settings

Recommended stack on ccjv.ca:
- CCJV Gate Receiver
- CCJV Command Center

Recommended stack on sector sites:
- sector WordPress theme
- Constructum SIWE Verifier