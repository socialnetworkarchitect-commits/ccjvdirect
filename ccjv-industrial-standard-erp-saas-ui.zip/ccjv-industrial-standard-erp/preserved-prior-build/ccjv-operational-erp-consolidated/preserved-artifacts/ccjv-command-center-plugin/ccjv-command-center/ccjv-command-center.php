<?php
/**
 * Plugin Name: CCJV Command Center
 * Description: Master enterprise control panel for CCJV, designed to monitor token-gated ERP operations across sector sites.
 * Version: 1.0.0
 * Author: OpenAI
 * License: GPLv2 or later
 * Text Domain: ccjv-command-center
 */

if (!defined('ABSPATH')) { exit; }

define('CCJVC_VERSION', '1.0.0');
define('CCJVC_URL', plugin_dir_url(__FILE__));
define('CCJVC_DIR', plugin_dir_path(__FILE__));

class CCJV_Command_Center {

    public function __construct() {
        add_action('admin_menu', array($this, 'admin_menu'));
        add_action('admin_init', array($this, 'register_settings'));
        add_action('admin_enqueue_scripts', array($this, 'enqueue_assets'));
        add_shortcode('ccjv_command_center', array($this, 'render_front_shortcode'));
    }

    private function defaults() {
        return array(
            'network_name' => 'CCJV Token-Gated ERP Network',
            'sector_sites_json' => "[\n  {\"name\":\"Constructum\",\"token\":\"CST\",\"site\":\"https://constructum.ca\",\"erp\":\"https://ccjv.ca\",\"status\":\"active\"},\n  {\"name\":\"EnergyChain\",\"token\":\"ENRC\",\"site\":\"https://energychain.ca\",\"erp\":\"https://ccjv.ca\",\"status\":\"planned\"}\n]",
            'token_matrix_json' => "[\n  {\"token\":\"CST\",\"label\":\"Constructum\",\"supply\":\"0\",\"circulating\":\"0\",\"treasury\":\"0\",\"price\":\"0\"},\n  {\"token\":\"ENRC\",\"label\":\"EnergyChain\",\"supply\":\"0\",\"circulating\":\"0\",\"treasury\":\"0\",\"price\":\"0\"}\n]",
            'access_tiers_json' => "[\n  {\"tier\":\"Basic\",\"min_tokens\":\"1\",\"modules\":\"Dashboard, View Projects\"},\n  {\"tier\":\"Operator\",\"min_tokens\":\"10\",\"modules\":\"Project Management, CRM\"},\n  {\"tier\":\"Manager\",\"min_tokens\":\"50\",\"modules\":\"HRM, Accounting\"},\n  {\"tier\":\"Executive\",\"min_tokens\":\"100\",\"modules\":\"Reporting, Financial Overview\"},\n  {\"tier\":\"Admin\",\"min_tokens\":\"500\",\"modules\":\"Full ERP Control\"}\n]",
            'treasury_avax' => '0',
            'treasury_target_avax' => '100000000',
            'active_sessions' => '0',
            'verified_wallets' => '0',
            'failed_verifications' => '0',
            'rpc_health' => 'Unknown',
            'api_health' => 'Unknown',
            'xmarkets_url' => 'https://xmarkets.ca',
            'constructum_verifier_url' => '',
            'notes' => 'Use this as the master operational dashboard on ccjv.ca.',
        );
    }

    private function get_options() {
        return wp_parse_args(get_option('ccjvc_options', array()), $this->defaults());
    }

    public function admin_menu() {
        add_menu_page(
            __('CCJV Command Center', 'ccjv-command-center'),
            __('CCJV Command Center', 'ccjv-command-center'),
            'manage_options',
            'ccjv-command-center',
            array($this, 'admin_page'),
            'dashicons-chart-area',
            57
        );
    }

    public function register_settings() {
        register_setting('ccjvc_group', 'ccjvc_options', array($this, 'sanitize'));

        add_settings_section(
            'ccjvc_main',
            __('Command Center Settings', 'ccjv-command-center'),
            function () {
                echo '<p>Configure the operational dashboard for the token-gated ERP network.</p>';
            },
            'ccjv-command-center'
        );

        $text_fields = array(
            'network_name' => 'Network Name',
            'treasury_avax' => 'Treasury AVAX',
            'treasury_target_avax' => 'Treasury Target AVAX',
            'active_sessions' => 'Active Sessions',
            'verified_wallets' => 'Verified Wallets',
            'failed_verifications' => 'Failed Verifications',
            'rpc_health' => 'RPC Health',
            'api_health' => 'API Health',
            'xmarkets_url' => 'XMarkets URL',
            'constructum_verifier_url' => 'Constructum Verifier Session URL',
            'notes' => 'Notes',
        );

        foreach ($text_fields as $key => $label) {
            add_settings_field(
                'ccjvc_' . $key,
                $label,
                array($this, 'text_field'),
                'ccjv-command-center',
                'ccjvc_main',
                array('key' => $key)
            );
        }

        $json_fields = array(
            'sector_sites_json' => 'Sector Sites JSON',
            'token_matrix_json' => 'Token Matrix JSON',
            'access_tiers_json' => 'Access Tiers JSON',
        );

        foreach ($json_fields as $key => $label) {
            add_settings_field(
                'ccjvc_' . $key,
                $label,
                array($this, 'textarea_field'),
                'ccjv-command-center',
                'ccjvc_main',
                array('key' => $key)
            );
        }
    }

    public function sanitize($input) {
        $defaults = $this->defaults();
        $clean = array();

        foreach ($defaults as $key => $default) {
            if (in_array($key, array('xmarkets_url', 'constructum_verifier_url'), true)) {
                $clean[$key] = isset($input[$key]) ? esc_url_raw(trim($input[$key])) : $default;
            } else {
                $clean[$key] = isset($input[$key]) ? trim(wp_kses_post($input[$key])) : $default;
            }
        }

        return $clean;
    }

    public function text_field($args) {
        $o = $this->get_options();
        $key = $args['key'];
        $value = isset($o[$key]) ? $o[$key] : '';
        echo '<input type="text" class="regular-text" name="ccjvc_options[' . esc_attr($key) . ']" value="' . esc_attr($value) . '" />';
    }

    public function textarea_field($args) {
        $o = $this->get_options();
        $key = $args['key'];
        $value = isset($o[$key]) ? $o[$key] : '';
        echo '<textarea name="ccjvc_options[' . esc_attr($key) . ']" rows="10" class="large-text code">' . esc_textarea($value) . '</textarea>';
    }

    public function enqueue_assets($hook) {
        if ($hook !== 'toplevel_page_ccjv-command-center') {
            return;
        }
        wp_enqueue_style('ccjvc-style', CCJVC_URL . 'assets/css/ccjvc.css', array(), CCJVC_VERSION);
    }

    private function decode_json_field($value, $fallback = array()) {
        $decoded = json_decode($value, true);
        return is_array($decoded) ? $decoded : $fallback;
    }

    private function safe_percent($part, $whole) {
        $p = floatval($part);
        $w = floatval($whole);
        if ($w <= 0) { return 0; }
        return min(100, max(0, ($p / $w) * 100));
    }

    public function admin_page() {
        if (!current_user_can('manage_options')) { return; }

        $o = $this->get_options();
        $sites = $this->decode_json_field($o['sector_sites_json']);
        $tokens = $this->decode_json_field($o['token_matrix_json']);
        $tiers = $this->decode_json_field($o['access_tiers_json']);
        $progress = $this->safe_percent($o['treasury_avax'], $o['treasury_target_avax']);
        ?>
        <div class="wrap ccjvc-wrap">
            <h1><?php echo esc_html($o['network_name']); ?></h1>
            <p class="ccjvc-muted"><?php echo esc_html($o['notes']); ?></p>

            <div class="ccjvc-grid ccjvc-grid-4">
                <div class="ccjvc-card">
                    <h3>Treasury AVAX</h3>
                    <div class="ccjvc-kpi"><?php echo esc_html($o['treasury_avax']); ?></div>
                    <div class="ccjvc-muted">Target: <?php echo esc_html($o['treasury_target_avax']); ?></div>
                </div>
                <div class="ccjvc-card">
                    <h3>Verified Wallets</h3>
                    <div class="ccjvc-kpi"><?php echo esc_html($o['verified_wallets']); ?></div>
                    <div class="ccjvc-muted">Qualified ecosystem users</div>
                </div>
                <div class="ccjvc-card">
                    <h3>Active Sessions</h3>
                    <div class="ccjvc-kpi"><?php echo esc_html($o['active_sessions']); ?></div>
                    <div class="ccjvc-muted">Live ERP sessions</div>
                </div>
                <div class="ccjvc-card">
                    <h3>Failed Verifications</h3>
                    <div class="ccjvc-kpi"><?php echo esc_html($o['failed_verifications']); ?></div>
                    <div class="ccjvc-muted">Security / eligibility failures</div>
                </div>
            </div>

            <div class="ccjvc-card">
                <h3>Treasury Target Progress</h3>
                <div class="ccjvc-progress">
                    <span style="width: <?php echo esc_attr($progress); ?>%"></span>
                </div>
                <div class="ccjvc-muted"><?php echo esc_html(round($progress, 2)); ?>% of AVAX target reached</div>
            </div>

            <div class="ccjvc-grid ccjvc-grid-2">
                <div class="ccjvc-card">
                    <h2>Sector Sites</h2>
                    <table class="widefat striped">
                        <thead><tr><th>Name</th><th>Token</th><th>Site</th><th>Status</th></tr></thead>
                        <tbody>
                        <?php if ($sites) : foreach ($sites as $site) : ?>
                            <tr>
                                <td><?php echo esc_html(isset($site['name']) ? $site['name'] : ''); ?></td>
                                <td><?php echo esc_html(isset($site['token']) ? $site['token'] : ''); ?></td>
                                <td><?php if (!empty($site['site'])) : ?><a href="<?php echo esc_url($site['site']); ?>" target="_blank" rel="noopener"><?php echo esc_html($site['site']); ?></a><?php endif; ?></td>
                                <td><?php echo esc_html(isset($site['status']) ? $site['status'] : ''); ?></td>
                            </tr>
                        <?php endforeach; else : ?>
                            <tr><td colspan="4">No sites configured.</td></tr>
                        <?php endif; ?>
                        </tbody>
                    </table>
                </div>

                <div class="ccjvc-card">
                    <h2>System Health</h2>
                    <table class="widefat striped">
                        <tbody>
                            <tr><td><strong>RPC Health</strong></td><td><?php echo esc_html($o['rpc_health']); ?></td></tr>
                            <tr><td><strong>API Health</strong></td><td><?php echo esc_html($o['api_health']); ?></td></tr>
                            <tr><td><strong>XMarkets</strong></td><td><?php if (!empty($o['xmarkets_url'])) : ?><a href="<?php echo esc_url($o['xmarkets_url']); ?>" target="_blank" rel="noopener"><?php echo esc_html($o['xmarkets_url']); ?></a><?php endif; ?></td></tr>
                            <tr><td><strong>Constructum Verifier</strong></td><td><?php if (!empty($o['constructum_verifier_url'])) : ?><a href="<?php echo esc_url($o['constructum_verifier_url']); ?>" target="_blank" rel="noopener"><?php echo esc_html($o['constructum_verifier_url']); ?></a><?php endif; ?></td></tr>
                        </tbody>
                    </table>
                </div>
            </div>

            <div class="ccjvc-card">
                <h2>Token Matrix</h2>
                <table class="widefat striped">
                    <thead><tr><th>Token</th><th>Label</th><th>Supply</th><th>Circulating</th><th>Treasury</th><th>Price</th></tr></thead>
                    <tbody>
                    <?php if ($tokens) : foreach ($tokens as $token) : ?>
                        <tr>
                            <td><?php echo esc_html(isset($token['token']) ? $token['token'] : ''); ?></td>
                            <td><?php echo esc_html(isset($token['label']) ? $token['label'] : ''); ?></td>
                            <td><?php echo esc_html(isset($token['supply']) ? $token['supply'] : ''); ?></td>
                            <td><?php echo esc_html(isset($token['circulating']) ? $token['circulating'] : ''); ?></td>
                            <td><?php echo esc_html(isset($token['treasury']) ? $token['treasury'] : ''); ?></td>
                            <td><?php echo esc_html(isset($token['price']) ? $token['price'] : ''); ?></td>
                        </tr>
                    <?php endforeach; else : ?>
                        <tr><td colspan="6">No token matrix configured.</td></tr>
                    <?php endif; ?>
                    </tbody>
                </table>
            </div>

            <div class="ccjvc-grid ccjvc-grid-2">
                <div class="ccjvc-card">
                    <h2>ERP Access Tiers</h2>
                    <table class="widefat striped">
                        <thead><tr><th>Tier</th><th>Min Tokens</th><th>Modules</th></tr></thead>
                        <tbody>
                        <?php if ($tiers) : foreach ($tiers as $tier) : ?>
                            <tr>
                                <td><?php echo esc_html(isset($tier['tier']) ? $tier['tier'] : ''); ?></td>
                                <td><?php echo esc_html(isset($tier['min_tokens']) ? $tier['min_tokens'] : ''); ?></td>
                                <td><?php echo esc_html(isset($tier['modules']) ? $tier['modules'] : ''); ?></td>
                            </tr>
                        <?php endforeach; else : ?>
                            <tr><td colspan="3">No access tiers configured.</td></tr>
                        <?php endif; ?>
                        </tbody>
                    </table>
                </div>

                <div class="ccjvc-card">
                    <h2>Deployment Reminder</h2>
                    <ol>
                        <li>Install the sector theme on each website.</li>
                        <li>Install the SIWE verifier plugin on each sector site.</li>
                        <li>Install the CCJV receiver on the ERP side.</li>
                        <li>Use this Command Center on ccjv.ca as the master operational dashboard.</li>
                        <li>Update JSON matrices here as new sites and tokens go live.</li>
                    </ol>
                </div>
            </div>

            <hr>
            <h2>Settings</h2>
            <form method="post" action="options.php">
                <?php
                settings_fields('ccjvc_group');
                do_settings_sections('ccjv-command-center');
                submit_button();
                ?>
            </form>
        </div>
        <?php
    }

    public function render_front_shortcode() {
        $o = $this->get_options();
        $sites = $this->decode_json_field($o['sector_sites_json']);
        ob_start(); ?>
        <div class="ccjvc-front">
            <h2><?php echo esc_html($o['network_name']); ?></h2>
            <p><?php echo esc_html($o['notes']); ?></p>
            <ul>
                <?php foreach ($sites as $site) : ?>
                    <li><?php echo esc_html($site['name'] . ' (' . $site['token'] . ') - ' . $site['status']); ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
        <?php return ob_get_clean();
    }
}

new CCJV_Command_Center();