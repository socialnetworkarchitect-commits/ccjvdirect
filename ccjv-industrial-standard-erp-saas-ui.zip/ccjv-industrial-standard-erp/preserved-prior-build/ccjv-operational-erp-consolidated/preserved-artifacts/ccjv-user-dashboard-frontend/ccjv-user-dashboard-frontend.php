<?php
/*
Plugin Name: CCJV User Dashboard Frontend
Description: Frontend dashboard for wallet status, tenants, ventures, subscriptions, ERP access, token status, vault files, and approvals.
Version: 1.0.0
Author: OpenAI
*/

if (!defined('ABSPATH')) exit;

if (!defined('CCJV_CORE_ACTIVE')) {
    add_action('admin_notices', function () {
        echo '<div class="notice notice-error"><p><strong>CCJV User Dashboard Frontend</strong> requires CCJV Unified Core Hardened.</p></div>';
    });
    return;
}

define('CCJV_USER_DASHBOARD_FRONTEND', true);

require_once plugin_dir_path(__FILE__) . 'includes/helpers.php';
require_once plugin_dir_path(__FILE__) . 'includes/shortcodes.php';

add_action('wp_enqueue_scripts', function () {
    wp_enqueue_style('ccjv-user-dashboard-frontend', plugin_dir_url(__FILE__) . 'assets/dashboard.css', [], '1.0.0');
});
