<?php
if (!defined('ABSPATH')) exit;

add_shortcode('ccjv_user_dashboard', function () {
    if (!is_user_logged_in()) {
        return '<div class="ccjv-udf-wrap"><div class="ccjv-udf-card"><h2>Please log in</h2><p>You need to be logged in to view your dashboard.</p></div></div>';
    }

    $user_id = get_current_user_id();
    $user = wp_get_current_user();
    $wallet = ccjv_udf_get_wallet($user_id);
    $tenant = ccjv_udf_get_tenant($user_id);
    $ventures = ccjv_udf_get_ventures($user_id);
    $erps = ccjv_udf_get_erps();
    $vault_hash = ccjv_udf_get_vault_hash();
    $token_status = ccjv_udf_get_token_status_text($user_id);
    $approvals = ccjv_udf_get_approvals();

    ob_start();
    ?>
    <div class="ccjv-udf-wrap">
        <div class="ccjv-udf-hero">
            <div>
                <h1>My Dashboard</h1>
                <p>Wallet status, tenants, ventures, subscriptions, ERP access, vault files, and approvals.</p>
            </div>
            <div class="ccjv-udf-badges">
                <span class="ccjv-udf-badge"><?php echo esc_html($user->display_name ?: $user->user_login); ?></span>
                <span class="ccjv-udf-badge"><?php echo esc_html($token_status); ?></span>
            </div>
        </div>

        <div class="ccjv-udf-grid ccjv-udf-grid-3">
            <div class="ccjv-udf-card">
                <h3>Wallet Status</h3>
                <p><strong>Status:</strong> <?php echo $wallet ? 'Connected' : 'Not connected'; ?></p>
                <p><strong>Wallet:</strong><br><?php echo $wallet ? esc_html($wallet) : 'No wallet saved yet'; ?></p>
                <p class="ccjv-udf-muted">Use your wallet connection page to update this value.</p>
            </div>

            <div class="ccjv-udf-card">
                <h3>Tenant</h3>
                <p><strong>Current tenant:</strong> <?php echo esc_html($tenant); ?></p>
                <p class="ccjv-udf-muted">Tenant is the container for ventures, ERP access, and vault records.</p>
            </div>

            <div class="ccjv-udf-card">
                <h3>Vault</h3>
                <p><strong>Latest hash:</strong><br><?php echo $vault_hash ? esc_html($vault_hash) : 'No hash recorded yet'; ?></p>
                <p class="ccjv-udf-muted">Files are stored on your VPS. Hashes are prepared for Avalanche proof.</p>
            </div>
        </div>

        <div class="ccjv-udf-grid ccjv-udf-grid-2">
            <div class="ccjv-udf-card">
                <h3>Ventures</h3>
                <?php if ($ventures): ?>
                    <ul class="ccjv-udf-list">
                        <?php foreach ($ventures as $venture): ?>
                            <li>
                                <strong><?php echo esc_html($venture['name'] ?? 'Untitled Venture'); ?></strong>
                                <span class="ccjv-udf-muted">Tenant: <?php echo esc_html($venture['tenant'] ?? ''); ?></span>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                <?php else: ?>
                    <p>No ventures found for this tenant yet.</p>
                <?php endif; ?>
            </div>

            <div class="ccjv-udf-card">
                <h3>Approvals</h3>
                <ul class="ccjv-udf-list">
                    <?php foreach ($approvals as $approval): ?>
                        <li>
                            <strong><?php echo esc_html($approval['title']); ?></strong>
                            <span class="ccjv-udf-muted"><?php echo esc_html($approval['status']); ?></span>
                        </li>
                    <?php endforeach; ?>
                </ul>
            </div>
        </div>

        <div class="ccjv-udf-card">
            <h3>ERP Access & Subscriptions</h3>
            <div class="ccjv-udf-grid ccjv-udf-grid-3">
                <?php foreach ($erps as $key => $config): 
                    $name = is_array($config) ? ($config['name'] ?? ucfirst($key)) : $config;
                    $sub = ccjv_udf_get_subscription_status($user_id, $key);
                    $has_access = ccjv_udf_user_has_access($user_id, $key);
                ?>
                    <div class="ccjv-udf-card ccjv-udf-subcard">
                        <h4><?php echo esc_html($name); ?></h4>
                        <p><strong>Access:</strong> <?php echo $has_access ? 'Active' : 'Inactive'; ?></p>
                        <p><strong>Status:</strong> <?php echo esc_html($sub['status']); ?></p>
                        <p><strong>Paid until:</strong> <?php echo $sub['paid_until'] ? esc_html($sub['paid_until']) : 'Not set'; ?></p>
                        <p><strong>Tx ref:</strong> <?php echo $sub['tx_ref'] ? esc_html($sub['tx_ref']) : 'None'; ?></p>
                        <?php if (function_exists('ccjv_payment_enforcement_get_fee')): ?>
                            <p><strong>Monthly fee:</strong> <?php echo esc_html(ccjv_payment_enforcement_get_fee($key)); ?> token(s)</p>
                        <?php endif; ?>
                        <?php if (shortcode_exists('ccjv_subscription_status')): ?>
                            <div class="ccjv-udf-inner-status">
                                <?php echo do_shortcode('[ccjv_subscription_status erp="' . esc_attr($key) . '"]'); ?>
                            </div>
                        <?php endif; ?>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
    <?php
    return ob_get_clean();
});
