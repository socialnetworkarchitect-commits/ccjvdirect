<?php
if (!defined('ABSPATH')) exit;

function ccjv_udf_get_wallet($user_id) {
    $wallet = get_user_meta($user_id, 'ccjv_wallet', true);
    if (!$wallet && function_exists('ccjvx_get_wallet')) {
        $wallet = ccjvx_get_wallet($user_id);
    }
    return $wallet ?: '';
}

function ccjv_udf_get_tenant($user_id) {
    $tenant = get_user_meta($user_id, 'ccjv_tenant', true);
    if (!$tenant && function_exists('ccjvx_get_tenant')) {
        $tenant = ccjvx_get_tenant($user_id);
    }
    return $tenant ?: 'No tenant assigned';
}

function ccjv_udf_get_ventures($user_id) {
    $tenant = ccjv_udf_get_tenant($user_id);
    $ventures = get_option('ccjv_ventures', []);
    if (!is_array($ventures)) return [];

    $out = [];
    foreach ($ventures as $venture) {
        if (is_array($venture) && ($venture['tenant'] ?? '') === $tenant) {
            $out[] = $venture;
        }
    }
    return $out;
}

function ccjv_udf_get_erps() {
    if (function_exists('ccjvx_get_erps')) {
        $erps = ccjvx_get_erps();
        if (is_array($erps)) return $erps;
    }
    return [
        'cibus' => ['name' => 'Cibus ERP'],
        'iter'  => ['name' => 'IterCoin ERP'],
        'surge' => ['name' => 'Surge Symposia ERP'],
    ];
}

function ccjv_udf_get_subscription_status($user_id, $erp_key) {
    if (function_exists('ccjv_payment_enforcement_get_subscription')) {
        $sub = ccjv_payment_enforcement_get_subscription($user_id, $erp_key);
        if ($sub) {
            return [
                'status' => $sub->status ?: 'inactive',
                'paid_until' => $sub->paid_until ?: '',
                'tx_ref' => $sub->tx_ref ?: '',
            ];
        }
    }
    return [
        'status' => 'inactive',
        'paid_until' => '',
        'tx_ref' => '',
    ];
}

function ccjv_udf_user_has_access($user_id, $erp_key) {
    if (function_exists('ccjv_payment_user_has_access')) {
        return ccjv_payment_user_has_access($user_id, $erp_key);
    }
    if (function_exists('ccjvx_user_has_access')) {
        return ccjvx_user_has_access($user_id, $erp_key);
    }
    return false;
}

function ccjv_udf_get_vault_hash() {
    $hash = get_option('ccjvx_last_hash');
    if (!$hash) {
        $hash = get_option('ccjv_last_hash');
    }
    return $hash ?: '';
}

function ccjv_udf_get_token_status_text($user_id) {
    $wallet = ccjv_udf_get_wallet($user_id);
    if (!$wallet) return 'Wallet not connected';
    return 'Wallet connected';
}

function ccjv_udf_get_approvals() {
    return [
        ['title' => 'No active approvals workflow connected yet', 'status' => 'info']
    ];
}
