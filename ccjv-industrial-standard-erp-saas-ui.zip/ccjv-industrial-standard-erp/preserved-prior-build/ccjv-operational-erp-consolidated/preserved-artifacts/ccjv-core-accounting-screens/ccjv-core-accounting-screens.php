<?php
/*
Plugin Name: CCJV Core Accounting Screens
Description: Adds tenant-aware Chart of Accounts, Journal Entry UI, and Ledger View on top of the CCJV Core ERP Engine.
Version: 1.0.0
Author: OpenAI
*/

if (!defined('ABSPATH')) exit;

if (!defined('CCJV_CORE_ACTIVE') && !function_exists('ccjv_core_loaded')) {
    add_action('admin_notices', function () {
        echo '<div class="notice notice-error"><p><strong>CCJV Core Accounting Screens</strong> requires the CCJV core stack.</p></div>';
    });
    return;
}

function ccjv_accounting_get_current_tenant($user_id = 0) {
    if (!$user_id) $user_id = get_current_user_id();

    $tenant = get_user_meta($user_id, 'ccjv_tenant', true);
    if (!$tenant && function_exists('ccjvx_get_tenant')) {
        $tenant = ccjvx_get_tenant($user_id);
    }

    return $tenant ?: '';
}

function ccjv_accounting_user_allowed() {
    if (!is_user_logged_in()) return false;

    if (function_exists('ccjv_core_module_access_state')) {
        $state = ccjv_core_module_access_state('accounting', get_current_user_id());
        return !empty($state['allowed']);
    }

    return true;
}

function ccjv_accounting_get_accounts($tenant_id) {
    global $wpdb;
    $table = $wpdb->prefix . 'ccjv_accounts';
    return $wpdb->get_results($wpdb->prepare(
        "SELECT * FROM {$table} WHERE tenant_id=%s ORDER BY type ASC, name ASC",
        $tenant_id
    ));
}

function ccjv_accounting_get_ledger($tenant_id, $account_id = 0) {
    global $wpdb;
    $table = $wpdb->prefix . 'ccjv_journal';

    if ($account_id) {
        return $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM {$table} WHERE tenant_id=%s AND account_id=%d ORDER BY id DESC",
            $tenant_id, $account_id
        ));
    }

    return $wpdb->get_results($wpdb->prepare(
        "SELECT * FROM {$table} WHERE tenant_id=%s ORDER BY id DESC",
        $tenant_id
    ));
}

add_shortcode('ccjv_core_accounting_screen', function () {
    if (!ccjv_accounting_user_allowed()) {
        return '<p>Access denied.</p>';
    }

    $tenant_id = ccjv_accounting_get_current_tenant();
    if (!$tenant_id) {
        return '<p>No tenant context found.</p>';
    }

    $messages = [];

    if (isset($_POST['ccjv_add_account'])) {
        if (!isset($_POST['_wpnonce']) || !wp_verify_nonce($_POST['_wpnonce'], 'ccjv_add_account')) {
            $messages[] = '<p>Security check failed while saving account.</p>';
        } else {
            if (function_exists('ccjv_create_account')) {
                ccjv_create_account(
                    $tenant_id,
                    sanitize_text_field(wp_unslash($_POST['account_name'] ?? '')),
                    sanitize_text_field(wp_unslash($_POST['account_type'] ?? 'asset'))
                );
                $messages[] = '<p>Account created.</p>';
            } else {
                $messages[] = '<p>Core accounting engine function <code>ccjv_create_account()</code> not found.</p>';
            }
        }
    }

    if (isset($_POST['ccjv_add_journal'])) {
        if (!isset($_POST['_wpnonce']) || !wp_verify_nonce($_POST['_wpnonce'], 'ccjv_add_journal')) {
            $messages[] = '<p>Security check failed while posting journal entry.</p>';
        } else {
            if (function_exists('ccjv_post_journal')) {
                ccjv_post_journal(
                    $tenant_id,
                    absint($_POST['account_id'] ?? 0),
                    (float)($_POST['debit'] ?? 0),
                    (float)($_POST['credit'] ?? 0),
                    sanitize_textarea_field(wp_unslash($_POST['memo'] ?? ''))
                );
                $messages[] = '<p>Journal entry posted.</p>';
            } else {
                $messages[] = '<p>Core accounting engine function <code>ccjv_post_journal()</code> not found.</p>';
            }
        }
    }

    $accounts = ccjv_accounting_get_accounts($tenant_id);
    $filter_account_id = isset($_GET['account_id']) ? absint($_GET['account_id']) : 0;
    $ledger = ccjv_accounting_get_ledger($tenant_id, $filter_account_id);

    ob_start(); ?>
    <div style="max-width:1280px;margin:0 auto;padding:24px">
        <div class="ccjv-card">
            <h2>Core Accounting</h2>
            <p>Tenant-aware Chart of Accounts, Journal Entry UI, and Ledger View on top of the Core ERP Engine.</p>
            <p><strong>Tenant:</strong> <?php echo esc_html($tenant_id); ?></p>
        </div>

        <?php if ($messages): ?>
            <div class="ccjv-card">
                <?php foreach ($messages as $message) echo wp_kses_post($message); ?>
            </div>
        <?php endif; ?>

        <div class="ccjv-card">
            <h3>Chart of Accounts</h3>
            <form method="post">
                <?php wp_nonce_field('ccjv_add_account'); ?>
                <p><input type="text" name="account_name" placeholder="Account Name" required class="regular-text"></p>
                <p>
                    <select name="account_type">
                        <option value="asset">asset</option>
                        <option value="liability">liability</option>
                        <option value="equity">equity</option>
                        <option value="revenue">revenue</option>
                        <option value="expense">expense</option>
                    </select>
                </p>
                <p><button class="button button-primary" name="ccjv_add_account" value="1">Add Account</button></p>
            </form>

            <?php if (!$accounts): ?>
                <p>No accounts yet.</p>
            <?php else: ?>
                <table class="widefat striped">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Name</th>
                            <th>Type</th>
                            <th>Balance</th>
                            <th>View Ledger</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($accounts as $account): ?>
                            <tr>
                                <td><?php echo (int)$account->id; ?></td>
                                <td><?php echo esc_html($account->name); ?></td>
                                <td><?php echo esc_html($account->type); ?></td>
                                <td><?php echo esc_html((string)$account->balance); ?></td>
                                <td><a href="<?php echo esc_url(add_query_arg('account_id', (int)$account->id)); ?>">Open</a></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </div>

        <div class="ccjv-card">
            <h3>Journal Entry</h3>
            <form method="post">
                <?php wp_nonce_field('ccjv_add_journal'); ?>
                <p>
                    <select name="account_id" required>
                        <option value="">Select Account</option>
                        <?php foreach ($accounts as $account): ?>
                            <option value="<?php echo (int)$account->id; ?>"><?php echo esc_html($account->name . ' (' . $account->type . ')'); ?></option>
                        <?php endforeach; ?>
                    </select>
                </p>
                <p><input type="number" step="0.00000001" name="debit" placeholder="Debit" class="regular-text"></p>
                <p><input type="number" step="0.00000001" name="credit" placeholder="Credit" class="regular-text"></p>
                <p><textarea name="memo" placeholder="Memo" rows="4" class="large-text"></textarea></p>
                <p><button class="button button-primary" name="ccjv_add_journal" value="1">Post Journal Entry</button></p>
            </form>
        </div>

        <div class="ccjv-card">
            <h3>Ledger View</h3>
            <?php if ($filter_account_id): ?>
                <p>Showing ledger for account ID <strong><?php echo (int)$filter_account_id; ?></strong> — <a href="<?php echo esc_url(remove_query_arg('account_id')); ?>">clear filter</a></p>
            <?php else: ?>
                <p>Showing all tenant journal entries.</p>
            <?php endif; ?>

            <?php if (!$ledger): ?>
                <p>No ledger entries yet.</p>
            <?php else: ?>
                <table class="widefat striped">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Account ID</th>
                            <th>Debit</th>
                            <th>Credit</th>
                            <th>Memo</th>
                            <th>Created</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($ledger as $entry): ?>
                            <tr>
                                <td><?php echo (int)$entry->id; ?></td>
                                <td><?php echo (int)$entry->account_id; ?></td>
                                <td><?php echo esc_html((string)$entry->debit); ?></td>
                                <td><?php echo esc_html((string)$entry->credit); ?></td>
                                <td><?php echo esc_html($entry->memo); ?></td>
                                <td><?php echo esc_html($entry->created_at); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </div>
    </div>
    <?php
    return ob_get_clean();
});

add_action('admin_menu', function () {
    add_submenu_page(
        'ccjv',
        'Core Accounting Screens',
        'Core Accounting Screens',
        'manage_options',
        'ccjv-core-accounting-screens',
        function () {
            echo '<div class="wrap"><h1>Core Accounting Screens</h1>';
            echo '<p>This layer adds tenant-aware accounting screens on top of the Core ERP Engine.</p>';
            echo '<ul>';
            echo '<li><code>[ccjv_core_accounting_screen]</code></li>';
            echo '</ul></div>';
        }
    );
}, 95);
