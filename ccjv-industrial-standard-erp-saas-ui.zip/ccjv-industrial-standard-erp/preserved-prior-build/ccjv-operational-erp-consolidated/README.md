# CCJV Operational ERP Consolidated Runtime

This is a cumulative CCJV Core ERP control-plane build created from the uploaded CCJV runtime artifacts.

## What it is

An installable WordPress plugin providing:

- Multi-tenant SaaS structure
- Multi-user dashboards
- Super Admin dashboard
- Tenant dashboard
- User dashboard shortcodes
- Module registry
- Token/pricing control center
- Vault center
- Treasury center
- Replay center
- Proof/Avalanche center
- Observability center
- Runtime health center
- Runtime reporting center
- Preserved source artifacts inventory

## Constitutional rules

- Everything saved belongs in the Vault.
- Everything in the Vault should be hashed.
- Hashes anchor through Avalanche proof runtime.
- ERP access is token gated.
- Module access is token/month gated.
- Vault uploads support rewards.
- Vault views/downloads support fees.
- All modules work inside workspaces.
- All ERPs inherit one CCJV runtime authority.

## Important honesty note

This build consolidates and preserves uploaded artifacts and provides an operational CCJV Core ERP control plane. Because the uploaded artifacts include many overlapping small plugins, their source is preserved under `preserved-artifacts/` and represented through one operational registry/control plane rather than blindly including every PHP file and risking fatal duplicate class/function errors.

## Install

Upload `ccjv-operational-erp-consolidated` to WordPress plugins and activate.

## Smart codes

- `[ccjv_wallet_connect]`
- `[ccjv_user_dashboard]`
- `[ccjv_tenant_dashboard]`
