<?php
/**
 * Plugin Name: CCJV Vault UI
 * Description: Vault upload, reward, and paid access system
 * Version: 1.0.0
 */

if (!defined('ABSPATH')) exit;
if (!defined('CCJV_CORE_ACTIVE')) return;

require_once plugin_dir_path(__FILE__) . 'includes/upload.php';
require_once plugin_dir_path(__FILE__) . 'includes/view.php';
