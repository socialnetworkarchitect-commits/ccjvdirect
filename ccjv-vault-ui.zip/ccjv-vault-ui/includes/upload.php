<?php
if (!defined('ABSPATH')) exit;

function ccjv_vault_upload_shortcode() {

    if (!is_user_logged_in()) return "Connect wallet";

    ob_start(); ?>
    <form method="post" enctype="multipart/form-data">
        <input type="file" name="vault_file" required />
        <button type="submit">Upload</button>
    </form>
    <?php
    return ob_get_clean();
}
add_shortcode('ccjv_upload', 'ccjv_vault_upload_shortcode');

add_action('init', function(){

    if (!isset($_FILES['vault_file'])) return;

    $user_id = get_current_user_id();
    if (!$user_id) return;

    $file = $_FILES['vault_file'];
    $upload = wp_handle_upload($file, ['test_form'=>false]);

    if (!empty($upload['file'])) {

        $path = $upload['file'];

        // store record
        $records = get_user_meta($user_id, 'ccjv_vault_files', true);
        if (!$records) $records = [];

        $records[] = $path;
        update_user_meta($user_id, 'ccjv_vault_files', $records);

        // reward
        if (function_exists('ccjv_reward_user')) {
            ccjv_reward_user($user_id, 'OMC', 1); // simple reward
        }
    }
});
