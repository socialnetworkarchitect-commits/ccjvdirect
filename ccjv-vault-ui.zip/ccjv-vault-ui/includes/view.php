<?php
if (!defined('ABSPATH')) exit;

function ccjv_vault_view_shortcode() {

    $user_id = get_current_user_id();
    if (!$user_id) return "Connect wallet";

    $files = get_user_meta($user_id, 'ccjv_vault_files', true);
    if (!$files) return "No files";

    ob_start();

    foreach ($files as $file) {

        echo "<div style='margin:10px 0'>";
        echo basename($file);

        echo "<form method='post'>";
        echo "<input type='hidden' name='view_file' value='" . esc_attr($file) . "'>";
        echo "<button>View</button>";
        echo "</form>";

        echo "</div>";
    }

    return ob_get_clean();
}
add_shortcode('ccjv_vault', 'ccjv_vault_view_shortcode');

add_action('init', function(){

    if (!isset($_POST['view_file'])) return;

    $user_id = get_current_user_id();
    if (!$user_id) wp_die("No access");

    $file = sanitize_text_field($_POST['view_file']);

    // charge small fee
    if (function_exists('ccjv_charge_fee')) {
        if (!ccjv_charge_fee($user_id, 'OMC', 0.1)) {
            wp_die("Insufficient tokens to view file");
        }
    }

    if (file_exists($file)) {
        header('Content-Type: application/octet-stream');
        readfile($file);
        exit;
    }
});
