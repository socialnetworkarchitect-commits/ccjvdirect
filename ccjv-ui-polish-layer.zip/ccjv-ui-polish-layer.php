<?php
/*
Plugin Name: CCJV UI Polish Layer
Description: World-class UI polish for dashboard, portals, ERP pages, and core admin sections.
Version: 1.0.0
Author: OpenAI
*/

if (!defined('ABSPATH')) exit;

add_action('wp_enqueue_scripts', function () {
    wp_enqueue_style(
        'ccjv-ui-polish',
        plugin_dir_url(__FILE__) . 'assets/ccjv-ui-polish.css',
        [],
        '1.0.0'
    );

    wp_enqueue_script(
        'ccjv-ui-polish',
        plugin_dir_url(__FILE__) . 'assets/ccjv-ui-polish.js',
        [],
        '1.0.0',
        true
    );
});

add_action('admin_enqueue_scripts', function () {
    wp_enqueue_style(
        'ccjv-ui-polish-admin',
        plugin_dir_url(__FILE__) . 'assets/ccjv-ui-polish-admin.css',
        [],
        '1.0.0'
    );
});
