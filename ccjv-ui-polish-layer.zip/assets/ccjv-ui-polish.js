document.addEventListener('DOMContentLoaded', function () {
  document.querySelectorAll('.ccjv-card h3, .ccjv-udf-card h3').forEach(function(el){
    el.classList.add('ccjv-erp-card-title');
  });

  document.querySelectorAll('.ccjv-section h2, .ccjv-udf-hero h1').forEach(function(el){
    el.style.fontWeight = '800';
  });

  document.querySelectorAll('.ccjv-section').forEach(function(section){
    section.classList.add('ccjv-core-dashboard-shell');
  });

  var vault = document.querySelectorAll('.ccjv-section')[3];
  if (vault && !vault.textContent.trim().replace(/Vault/i,'').trim()){
    var empty = document.createElement('div');
    empty.className = 'ccjv-vault-empty';
    empty.textContent = 'No vault items are available yet.';
    vault.appendChild(empty);
  }
});
