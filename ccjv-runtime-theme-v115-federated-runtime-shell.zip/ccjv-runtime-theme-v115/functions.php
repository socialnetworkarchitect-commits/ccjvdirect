<?php
require_once get_template_directory() . '/inc/enqueue.php';
add_theme_support('title-tag');
add_theme_support('menus');
