<?php
function ccjv_enqueue_runtime_assets() {
    $theme_uri = get_template_directory_uri();

    wp_enqueue_style(
        'ccjv-runtime-style',
        $theme_uri . '/dist/assets/index.css',
        [],
        time()
    );

    wp_enqueue_script(
        'ccjv-runtime-app',
        $theme_uri . '/dist/assets/index.js',
        [],
        time(),
        true
    );
}
add_action('wp_enqueue_scripts', 'ccjv_enqueue_runtime_assets');
