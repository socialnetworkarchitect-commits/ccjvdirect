<?php get_header(); ?>
<div id="ccjv-runtime-root"></div>
<?php get_footer(); ?>
