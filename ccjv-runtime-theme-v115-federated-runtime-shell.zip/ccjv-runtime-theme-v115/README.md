# CCJV Runtime Theme V115

Upload through:
Appearance -> Themes -> Add New -> Upload Theme

This package contains:
- Runtime shell
- SPA mounting layer
- Treasury runtime shell
- Vault runtime shell
- AI runtime shell
- GIS runtime shell
- Federated runtime structure
